# VaultCove Privacy — 0.6.0 R1

VaultCove is offline-first. Vault records are stored locally in encrypted form. There is no cloud vault, advertising, analytics, browsing-history profile, or telemetry in this build.

## Website access and Always-On Handler

User-invoked filling can use temporary `activeTab` access. For users who want the field handler to appear automatically, VaultCove offers a one-time, explicit optional HTTPS permission. After approval, the extension can inspect HTTPS pages locally for supported login/password forms and register its handler persistently. The permission is optional and can be removed from Settings. VaultCove does not send encountered page URLs or a browsing-history profile to a server.

## Website thumbnails

VaultCove does not contact a third-party favicon/logo service. With explicit optional `favicon` permission, it uses Chrome's local favicon cache. A thumbnail is shown only for a matching saved login after VaultCove has locally recorded that saved site as visited. The marker is encrypted inside the vault; unrelated browsing is not retained as a VaultCove history list.

## Authenticator confirmation

VaultCove can create a standard local TOTP setup compatible with Google Authenticator, Microsoft Authenticator, Aegis and other authenticator apps. VaultCove does not connect to the user's Google account. Google does not receive, sync, store or read VaultCove website passwords or vault records. The TOTP secret itself remains inside the encrypted local vault, while recovery-code hashes are also encrypted there.

Because verification is local, this is an additional access-confirmation step, not a separate cloud-held encryption key against full compromise of the same device.

## Developer update check

When enabled, the Developer Mode build performs at most one normal request per day to the official public `VaultCove-release` metadata file. VaultCove does not attach vault data, usernames, passwords, saved website lists, security scores, cards, bank records, notes, TOTP secrets, master passwords, vault keys or browsing data to that request. The Store build removes this updater path.

## Password-change email notices

The future optional licensing/notice service may receive only a generic event type, time, and random device/license metadata. It must never receive the website/domain, username/account title, old/new password, TOTP secret, notes, cards or bank information.

## Migration

LastPass and Zoho Vault CSV files are parsed locally. These vendor CSVs are plaintext; users should delete them after verifying migration and creating an encrypted VaultCove backup.

## Secure sharing

`.vckey` public identity files contain public keys only. VCShare v2 can package multiple selected logins into one recipient-specific encrypted `.vcshare`. Sharing private keys remain inside the encrypted local vault. No VaultCove relay or cloud share server exists in this build.

## New-login and password-change capture

When enabled and the vault is unlocked, VaultCove can detect submitted credential candidates on pages where its handler is active. Candidates remain inside the encrypted vault and require local Save/Update review. VaultCove does not silently register them and does not send them to email, licensing, analytics or cloud services.
