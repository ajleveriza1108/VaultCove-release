import { createItem, normalizeVault, purgeItem, restoreItem, softDeleteItem, upsertItem } from '../core/model.js';
import { initializeVault, loadUnlockedVault, lockVault, rotateMasterPasswordVerified, saveUnlockedVault, unlockVault } from '../core/vault.js';
import { createPortableExport, decryptPortableExport, downloadExport } from '../core/export.js';
import { assessPassword, generatePassword, vaultHealth } from '../core/password.js';
import { buildTotpUri, generateRecoveryCodes, generateTotp, generateTotpSecret, hashRecoveryCodes, verifyRecoveryCode, verifyTotp } from '../core/totp.js';
import { getLicenseState, featureAllowed } from '../core/license.js';
import { clearSensitiveAccess, getSessionExpiry, getSettings, hasSensitiveAccess, setSettings, touchSession } from '../core/storage.js';
import { importMigrationCsv, mergeImportedItems } from '../core/migration.js';
import { maskIdentifier } from '../core/redaction.js';
import {
  addTrustedShareContact,
  createSecureShare,
  downloadJsonFile,
  ensureSharingIdentity,
  exportPublicSharingIdentity,
  openSecureShare,
  recordShareHistory,
  validatePublicSharingIdentity
} from '../core/share.js';
import { installTooltips } from './tooltip.js';

const $ = (id) => document.getElementById(id);
const els = Object.fromEntries([...document.querySelectorAll('[id]')].map((el) => [el.id, el]));
let vault = null;
let currentView = 'dashboard';
let licenseState = null;
let totpTimer = null;
let generatedPassword = '';
let settingsState = null;
let pendingMigration = null;
let pendingSensitiveAction = null;
let handlerPermissionState = [];
let selectedItemId = null;
let unlockBusy = false;
let sensitiveVerifyBusy = false;
let tooltipObserver = null;
let pendingTotpSetup = null;

const viewNames = {
  dashboard: 'Vault Overview', all: 'Vault', favorites: 'Favorites', login: 'Logins', card: 'Cards', bank: 'Bank Accounts',
  identity: 'Identities', note: 'Secure Notes', totp: 'TOTP Codes', generator: 'Password Generator', security: 'Security Center',
  migration: 'Migration Center', shared: 'Shared', backup: 'Backup & Restore', trash: 'Trash', settings: 'Settings'
};

const viewSubtitles = {
  dashboard: 'Everything stays on your device. You’re in control.',
  all: 'Browse every encrypted item stored in this local vault.',
  favorites: 'Fast access to the encrypted items you marked as favorites.',
  login: 'Passwords and usernames remain encrypted until the vault is unlocked.',
  card: 'Payment-card fields are stored inside the encrypted vault payload.',
  bank: 'Bank details remain local and encrypted on this device.',
  identity: 'Keep identity and address records inside your offline vault.',
  note: 'Store private text without sending it to a cloud service.',
  totp: 'Authenticator codes are generated locally from encrypted TOTP secrets.',
  generator: 'Generate cryptographically random passwords entirely on this device.',
  security: 'Password health is calculated locally after you unlock the vault.',
  migration: 'Import LastPass or Zoho Vault CSV exports locally, then immediately re-encrypt them into VaultCove.',
  shared: 'Share selected logins with another VaultCove or VaultCore user using recipient-key encryption.',
  backup: 'Create or restore a portable encrypted .vcvault backup.',
  trash: 'Restore recently removed items or permanently delete them.',
  settings: 'Control auto-lock, master-password and privacy settings.'
};

function toast(text, isError = false) {
  els.toast.textContent = text;
  els.toast.style.borderColor = isError ? '#8f3650' : '#3d6d94';
  els.toast.classList.add('show');
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => els.toast.classList.remove('show'), 3500);
}

function showGate(panel) {
  document.body.classList.add('lockedState');
  els.gate.classList.remove('hidden');
  els.app.classList.add('hidden');
  els.setupPanel.classList.add('hidden');
  els.unlockPanel.classList.add('hidden');
  els[panel].classList.remove('hidden');
  if (panel === 'unlockPanel' && els.unlockTotpLabel) els.unlockTotpLabel.classList.toggle('hidden', !settingsState?.vaultTotpEnabled);
}

function showApp() {
  document.body.classList.remove('lockedState');
  els.gate.classList.add('hidden');
  els.app.classList.remove('hidden');
}

function escapeHtml(value) {
  return String(value ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#039;');
}

async function runtimeMessage(payload) {
  const response = await chrome.runtime.sendMessage(payload);
  if (!response?.ok) throw new Error(response?.error || 'VaultCove request failed.');
  return response;
}

function closeSensitiveDialog() {
  els.sensitivePassword.value = '';
  if (els.sensitiveTotp) els.sensitiveTotp.value = '';
  if (els.sensitiveError) { els.sensitiveError.textContent = ''; els.sensitiveError.classList.add('hidden'); }
  pendingSensitiveAction = null;
  if (els.sensitiveDialog.open) els.sensitiveDialog.close();
}

async function ensureSensitiveAccess(reason, action) {
  if (await hasSensitiveAccess()) return action();
  pendingSensitiveAction = action;
  els.sensitiveReason.textContent = reason;
  els.sensitivePassword.value = '';
  if (els.sensitiveTotp) els.sensitiveTotp.value = '';
  if (els.sensitiveTotpLabel) els.sensitiveTotpLabel.classList.toggle('hidden', !settingsState?.vaultTotpEnabled);
  if (els.sensitiveError) { els.sensitiveError.textContent = ''; els.sensitiveError.classList.add('hidden'); }
  els.sensitiveDialog.showModal();
  setTimeout(() => els.sensitivePassword.focus(), 0);
  return undefined;
}

async function refreshHandlerPermissions() {
  const result = await runtimeMessage({ type: 'LIST_SITE_HANDLERS' });
  handlerPermissionState = Array.isArray(result.origins) ? result.origins : [];
  return handlerPermissionState;
}

async function refreshUpdateBanner({ force = false } = {}) {
  const mount = $('updateBanner');
  if (!mount || !settingsState?.updateChecksEnabled) return;
  try {
    const result = await runtimeMessage({ type: 'CHECK_FOR_UPDATES', force });
    if (!result.enabled) return;
    if (result.updateAvailable) {
      mount.innerHTML = `<div class="updateNotice ${result.critical ? 'critical' : ''}"><div><strong>${result.critical ? 'Security update available' : 'VaultCove update available'} · ${escapeHtml(result.version)}</strong><span>${escapeHtml(result.summary || 'A newer verified developer release is available from the official VaultCove release repository.')}</span></div><div><button id="updateNotes" class="outline">View release</button><button id="updateDownload">Download update</button></div></div>`;
      $('updateNotes')?.addEventListener('click', () => { if (result.notesUrl) chrome.tabs.create({ url: result.notesUrl }); });
      $('updateDownload')?.addEventListener('click', () => { if (result.downloadUrl) chrome.tabs.create({ url: result.downloadUrl }); });
    } else {
      mount.innerHTML = `<div class="updateCurrent"><span>✓ Developer update check: VaultCove ${escapeHtml(result.currentVersion || '')} is current</span><button id="manualUpdateCheck" class="linkButton">Check again</button></div>`;
      $('manualUpdateCheck')?.addEventListener('click', () => refreshUpdateBanner({ force: true }));
    }
  } catch (error) {
    mount.innerHTML = `<div class="updateCurrent mutedUpdate"><span>Update check unavailable. VaultCove continues fully offline.</span><button id="manualUpdateCheck" class="linkButton">Retry</button></div>`;
    $('manualUpdateCheck')?.addEventListener('click', () => refreshUpdateBanner({ force: true }));
  }
}

function clearDecryptedUi() {
  vault = null;
  clearInterval(totpTimer);
  els.content.replaceChildren();
  els.search.value = '';
  els.itemId.value = '';
  els.itemName.value = '';
  els.itemNotes.value = '';
  els.itemTags.value = '';
  els.dynamicFields.replaceChildren();
  els.exportSecret.textContent = '';
  if (els.itemDialog.open) els.itemDialog.close();
  if (els.secretDialog.open) els.secretDialog.close();
  if (els.sensitiveDialog.open) els.sensitiveDialog.close();
}

async function enforceUiAutoLock() {
  if (!vault) return;
  const expiresAt = await getSessionExpiry();
  if (!expiresAt || Date.now() >= expiresAt) {
    await lockVault();
    clearDecryptedUi();
    showGate('unlockPanel');
    toast('Vault auto-locked.');
  }
}

async function enforceSensitiveUiExpiry() {
  if (!vault || !els.itemDialog.open || !els.itemId.value) return;
  if (await hasSensitiveAccess()) return;
  els.itemDialog.close();
  els.dynamicFields.replaceChildren();
  els.itemId.value = '';
  toast('Sensitive Access expired. Decrypted item fields were closed; unsaved changes were discarded.');
}

let lastActivityTouch = 0;
function markVaultActivity() {
  if (!vault) return;
  const now = Date.now();
  if (now - lastActivityTouch < 10000) return;
  lastActivityTouch = now;
  touchSession().catch(() => {});
}

function activeItems() { return vault.items.filter((item) => !item.deletedAt); }
function countType(type) { return activeItems().filter((item) => item.type === type).length; }

function itemMeta(item) {
  if (item.type === 'login') return item.username ? maskIdentifier(item.username) : ((item.urls || [])[0] || 'Login');
  if (item.type === 'card') return item.number ? `•••• ${item.number.replace(/\D/g,'').slice(-4)}` : item.cardholder || 'Payment card';
  if (item.type === 'bank') return item.accountNumber ? `•••• ${item.accountNumber.replace(/\s/g,'').slice(-4)}` : item.bankName || 'Bank account';
  if (item.type === 'identity') {
    const displayName = [item.firstName,item.lastName].filter(Boolean).join(' ');
    return displayName || (item.email ? maskIdentifier(item.email) : 'Identity');
  }
  return 'Encrypted secure note';
}

function itemTypeLabel(item) {
  return ({login:'Login',card:'Card',bank:'Bank Account',identity:'Identity',note:'Note'})[item.type] || 'Item';
}

function safeHostname(value) {
  try {
    const source = /^https?:/i.test(String(value || '')) ? String(value) : `https://${String(value || '')}`;
    return new URL(source).hostname.toLowerCase().replace(/^www\./, '');
  } catch { return ''; }
}

function visualHost(item) {
  if (item?.type !== 'login') return '';
  return safeHostname(item.siteVisual?.host || (item.urls || [])[0] || '');
}

function faviconUrl(item, size = 64) {
  if (!settingsState?.websiteIconsEnabled || !item?.siteVisual?.visitedAt) return '';
  const host = visualHost(item);
  if (!host) return '';
  const url = new URL(chrome.runtime.getURL('/_favicon/'));
  url.searchParams.set('pageUrl', `https://${host}/`);
  url.searchParams.set('size', String(size));
  return url.toString();
}

function siteCardVisual(item) {
  const host = visualHost(item);
  const icon = faviconUrl(item);
  const initials = (host || item.name || 'VC').replace(/[^a-z0-9]/gi, '').slice(0, 2).toUpperCase() || 'VC';
  return `<div class="siteCardVisual"><div class="siteFallback"><span>🔒</span><b>${escapeHtml(initials)}</b></div>${icon ? `<img data-vc-favicon src="${escapeHtml(icon)}" alt="">` : ''}</div>`;
}

function wireFaviconFallbacks(root = document) {
  root.querySelectorAll('[data-vc-favicon]').forEach((img) => {
    img.addEventListener('error', () => img.remove(), { once: true });
  });
}

function vaultTotpProtection() {
  return vault?.security?.vaultTotp || { enabled: false, secret: '', recoveryCodeHashes: [] };
}

function secondFactorLabelText() {
  return settingsState?.vaultTotpEnabled ? 'Authenticator or recovery code' : '';
}

function relativeTime(iso) {
  const value = Date.parse(iso || '');
  if (!Number.isFinite(value)) return '';
  const seconds = Math.max(0, Math.floor((Date.now() - value) / 1000));
  if (seconds < 60) return `${seconds}s ago`;
  const minutes = Math.floor(seconds / 60); if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60); if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24); if (days < 30) return `${days}d ago`;
  return new Date(value).toLocaleDateString();
}

function visibleItems() {
  const q = els.search.value.trim().toLowerCase();
  return vault.items.filter((item) => {
    const deleted = Boolean(item.deletedAt);
    if (currentView === 'trash') {
      if (!deleted) return false;
    } else if (deleted) return false;
    if (['login','card','bank','identity','note'].includes(currentView) && item.type !== currentView) return false;
    if (currentView === 'totp' && !(item.type === 'login' && item.totpSecret)) return false;
    if (currentView === 'favorites' && !item.favorite) return false;
    if (q) {
      const haystack = JSON.stringify({name:item.name,username:item.username,urls:item.urls,tags:item.tags,bankName:item.bankName,cardholder:item.cardholder,email:item.email}).toLowerCase();
      if (!haystack.includes(q)) return false;
    }
    return true;
  }).sort((a,b) => Number(Boolean(b.favorite))-Number(Boolean(a.favorite)) || a.name.localeCompare(b.name));
}

function pageHead(title = viewNames[currentView], subtitle = viewSubtitles[currentView], withStatus = false) {
  const status = withStatus ? `<div class="statusPills"><span class="pill good">Offline Only</span><span class="pill">▣ Local Encrypted Storage</span><span class="pill">⌁ No Cloud Sync</span></div>` : '';
  return `<div class="pageHead"><div><h1>${escapeHtml(title)}</h1><p>${escapeHtml(subtitle)}</p></div>${status}</div>`;
}

function render() {
  clearInterval(totpTimer);
  els.search.classList.toggle('hidden', ['generator','security','migration','shared','backup','settings'].includes(currentView));
  els.newItem.classList.toggle('hidden', ['security','settings','trash','migration','shared','backup','generator'].includes(currentView));
  document.querySelectorAll('nav button[data-view]').forEach((button) => button.classList.toggle('active', button.dataset.view === currentView));
  if (currentView === 'dashboard') return renderDashboard();
  if (currentView === 'security') return renderSecurity();
  if (currentView === 'settings') return renderSettings();
  if (currentView === 'migration') return renderMigration();
  if (currentView === 'backup') return renderBackup();
  if (currentView === 'shared') return renderShared();
  if (currentView === 'generator') return renderGenerator();
  return renderItems();
}

function renderDashboard() {
  const items = activeItems();
  const handlerOn = Array.isArray(handlerPermissionState) && handlerPermissionState.length > 0;
  const alwaysOn = Array.isArray(handlerPermissionState) && handlerPermissionState.includes('https://*/*');
  const autoLoginOn = Boolean(settingsState?.autoLoginEnabled);
  const health = vaultHealth(items);
  const recent = [...items].sort((a,b) => Date.parse(b.updatedAt || b.createdAt || 0) - Date.parse(a.updatedAt || a.createdAt || 0)).slice(0,5);
  const scoreLabel = health.score >= 90 ? 'Excellent' : health.score >= 75 ? 'Good' : health.score >= 50 ? 'Needs attention' : 'At risk';
  const recentRows = recent.length ? recent.map((item) => `
    <div class="recentRow" data-open-id="${escapeHtml(item.id)}">
      <div class="recentIcon">${escapeHtml(({login:'↗',card:'▭',bank:'▥',identity:'◉',note:'▤'})[item.type] || '•')}</div>
      <div class="recentMain"><strong>${escapeHtml(item.name)}</strong><small>${escapeHtml(itemMeta(item))}</small></div>
      <span class="typeBadge">${escapeHtml(itemTypeLabel(item))}</span><span class="recentTime">${escapeHtml(activityLabel(item))}</span>
    </div>`).join('') : '<div class="emptyState">No items yet. Use Quick Add to create your first encrypted record.</div>';

  els.content.innerHTML = `
    ${pageHead('Vault Overview','Everything stays on your device. You’re in control.',true)}
    <div id="updateBanner"></div>
    <div class="summaryGrid">
      ${summaryCard('login','●','Logins',countType('login'),'items')}
      ${summaryCard('card','▭','Cards',countType('card'),'cards')}
      ${summaryCard('bank','▥','Bank Accounts',countType('bank'),'accounts')}
      ${summaryCard('note','▤','Secure Notes',countType('note'),'notes')}
      ${summaryCard('identity','◉','Identities',countType('identity'),'identities')}
      ${summaryCard('totp','◴','TOTP Codes',items.filter((item)=>item.type==='login'&&item.totpSecret).length,'accounts')}
    </div>
    <div class="dashboardGrid">
      <section class="panel">
        <div class="panelTitle"><h2>◇ Security Health</h2><button id="openSecurity" class="linkButton">View details</button></div>
        <div class="healthBody">
          <div class="scoreRing" style="--score:${Math.max(0,Math.min(360,health.score*3.6))}deg"><div><strong>${health.score}</strong><span>${escapeHtml(scoreLabel)}</span></div></div>
          <div>
            <div class="healthMetric"><i>◇</i><div><b>Weak Passwords</b><small>Needs stronger credentials</small></div><em>${health.weak}</em></div>
            <div class="healthMetric"><i>↻</i><div><b>Reused Passwords</b><small>Same password on multiple logins</small></div><em>${health.reused}</em></div>
            <div class="healthMetric"><i>●</i><div><b>Strong Logins</b><small>Locally assessed after unlock</small></div><em>${health.strong}</em></div>
          </div>
        </div>
      </section>
      <section class="panel">
        <div class="panelTitle"><h2>◴ Recent Activity</h2><button id="viewAllItems" class="linkButton">View all</button></div>
        <div class="recentList">${recentRows}</div>
      </section>
      <section class="panel quickPanel">
        <div class="panelTitle"><h2>ϟ Quick Actions</h2></div>
        <div class="quickGrid">
          <button id="dashAddLogin">＋ Add Login</button><button id="dashGenerate">⌁ Generate Password</button>
          <button id="dashExport">⇧ Export Encrypted Backup</button><button id="dashImport">⇩ Import Backup</button>
          <button id="dashMaster">◇ Change Master Password</button><button id="dashLock" class="dangerQuick">▣ Lock Now</button>
        </div>
      </section>
    </div>
    <div class="lowerGrid">
      <section class="panel">
        <div class="panelTitle"><h2>▥ Backup & Recovery</h2></div>
        <p class="mutedText">Keep an encrypted portable copy of your vault.</p>
        <div class="backupNote"><strong>Encrypted export requires a unique export secret.</strong><br>Store the secret separately from the .vcvault file — both are required to restore the backup.</div>
        <div class="backupActions"><button id="dashExport2">⇧ Export Encrypted Backup</button><button id="dashBackupPage" class="outline">Open Backup & Restore</button></div>
      </section>
      <section class="panel">
        <div class="panelTitle"><h2>◆ Browser Integration</h2><span class="pill good">Ready</span></div>
        <div class="browserRows">
          <div class="browserRow"><i>⚙</i><div><strong>Website Handler</strong><b>${alwaysOn ? 'Always-On Handler enabled' : handlerOn ? 'Individual site access enabled' : 'On-demand only'}</b><small>${alwaysOn ? 'VaultCove can appear automatically on supported HTTPS login/password forms without a toolbar click. Secrets are released only after trusted-site validation.' : 'Enable Always-On once for automatic login-field icons, or keep the permission-minimal on-demand/per-site mode.'}</small>${alwaysOn ? '' : '<button id="dashEnableAlwaysOn" class="miniAction">Enable Always-On Handler</button>'}</div></div>
          <div class="browserRow"><i>↗</i><div><strong>Automatic Login</strong><b>${autoLoginOn ? 'Enabled for opted-in entries' : 'Off by default'}</b><small>Only exact-host HTTPS entries explicitly marked Auto-login may be submitted automatically.</small></div></div>
          <div class="browserRow"><i>◇</i><div><strong>Domain Matching</strong><b>Exact HTTPS Hostname</b><small>VaultCove will not fill a credential onto an unrelated hostname or insecure HTTP page.</small></div></div>
        </div>
      </section>
    </div>`;

  $('openSecurity').addEventListener('click', () => switchView('security'));
  $('viewAllItems').addEventListener('click', () => switchView('all'));
  $('dashAddLogin').addEventListener('click', () => openItemDialog(null,'login'));
  $('dashGenerate').addEventListener('click', () => switchView('generator'));
  $('dashExport').addEventListener('click', exportVault);
  $('dashExport2').addEventListener('click', exportVault);
  $('dashImport').addEventListener('click', () => switchView('backup'));
  $('dashBackupPage').addEventListener('click', () => switchView('backup'));
  $('dashMaster').addEventListener('click', () => switchView('settings'));
  $('dashLock').addEventListener('click', lockFromUi);
  $('dashEnableAlwaysOn')?.addEventListener('click', async () => {
    try {
      const granted = await chrome.permissions.request({ origins: ['https://*/*'] });
      if (!granted) return toast('Always-On Handler permission was not granted.', true);
      await setSettings({ alwaysOnHandlerEnabled: true, inlineHandlerEnabled: true });
      await runtimeMessage({ type: 'SYNC_ALWAYS_ON_HANDLER', injectExisting: true });
      settingsState = await getSettings();
      await refreshHandlerPermissions();
      renderDashboard();
      toast('Always-On Handler enabled. Existing HTTPS tabs may require one reload.');
    } catch (error) { toast(error.message, true); }
  });
  document.querySelectorAll('[data-open-id]').forEach((row) => row.addEventListener('click', () => {
    const item = vault.items.find((candidate) => candidate.id === row.dataset.openId); if (item) openItemDialog(item);
  }));
  wireSummaryCards();
  refreshUpdateBanner().catch(() => {});
}

function summaryCard(view, icon, label, count, unit) {
  return `<button class="summaryCard" data-summary-view="${escapeHtml(view)}"><span class="summaryIcon">${escapeHtml(icon)}</span><span><span>${escapeHtml(label)}</span><strong>${count}</strong><small>${escapeHtml(unit)}</small></span></button>`;
}

function wireSummaryCards() {
  document.querySelectorAll('[data-summary-view]').forEach((button) => button.addEventListener('click', () => switchView(button.dataset.summaryView)));
}

function emptyStateMarkup() {
  const byView = {
    trash: ['⌫', 'Trash is empty', 'Items moved to Trash will appear here until restored or permanently deleted.', ''],
    totp: ['◴', 'No TOTP codes yet', 'Add a compatible TOTP secret to a saved login to generate authenticator codes locally.', ''],
    card: ['▭', 'No payment cards yet', 'Store card details locally inside your encrypted VaultCove vault.', 'Add Card'],
    bank: ['▥', 'No bank accounts yet', 'Keep bank records encrypted locally and protected by Sensitive Access.', 'Add Bank Account'],
    identity: ['◉', 'No identities yet', 'Keep identity and address records inside your offline encrypted vault.', 'Add Identity'],
    note: ['▤', 'No secure notes yet', 'Store private text without uploading it to a cloud service.', 'Add Secure Note'],
    favorites: ['★', 'No favorites yet', 'Mark important vault items as favorites for quicker access.', ''],
    login: ['●', 'No matching logins', 'Add a login or adjust your search. Imported LastPass records remain encrypted here.', 'Add Login'],
    all: ['▣', 'No vault items yet', 'Use Quick Add to create your first encrypted record.', 'Add Login']
  };
  const [icon, title, text, action] = byView[currentView] || byView.all;
  return `<div class="emptyState richEmpty"><div class="emptyIcon">${escapeHtml(icon)}</div><strong>${escapeHtml(title)}</strong><p>${escapeHtml(text)}</p>${action ? `<button id="emptyAdd">＋ ${escapeHtml(action)}</button>` : ''}</div>`;
}

function activityLabel(item) {
  const imported = item.importedAt ? Date.parse(item.importedAt) : 0;
  const updated = Date.parse(item.updatedAt || item.createdAt || 0);
  if (imported && Math.abs(updated - imported) < 5000) return `Imported ${relativeTime(item.importedAt)}`;
  if (item.lastPasswordChangeAt && Math.abs(updated - Date.parse(item.lastPasswordChangeAt)) < 5000) return `Password changed ${relativeTime(item.lastPasswordChangeAt)}`;
  return `Updated ${relativeTime(item.updatedAt || item.createdAt)}`;
}

function viewModeControls() {
  const mode = settingsState?.vaultViewMode === 'list' ? 'list' : 'grid';
  return `<div class="viewModeSwitch" role="group" aria-label="Vault view"><button data-vault-view="grid" class="${mode === 'grid' ? 'active' : ''}" data-tooltip="Show visual website cards. Site icons appear only after that saved site has been visited with VaultCove active.">▦ Grid</button><button data-vault-view="list" class="${mode === 'list' ? 'active' : ''}" data-tooltip="Show a compact list for quickly scanning large vaults.">☷ List</button></div>`;
}

function vaultCardMarkup(item) {
  const login = item.type === 'login';
  const status = login && item.pendingPasswordChange ? 'Change pending' : activityLabel(item);
  const visual = login ? siteCardVisual(item) : `<div class="siteCardVisual genericVisual"><div class="siteFallback"><span>${escapeHtml(({card:'▭',bank:'▥',identity:'◉',note:'▤'})[item.type] || '🔒')}</span></div></div>`;
  return `<button class="siteVaultCard ${item.id === selectedItemId ? 'selected' : ''}" data-select-id="${escapeHtml(item.id)}">
    ${visual}
    <div class="siteCardBody"><div class="siteCardTitle"><strong>${escapeHtml(`${item.favorite ? '★ ' : ''}${item.name}`)}</strong><span>${escapeHtml(itemTypeLabel(item))}</span></div><small>${escapeHtml(itemMeta(item))}</small><div class="siteCardFooter"><span>${escapeHtml(status)}</span>${login && item.requireReauthBeforeFill ? '<b>MASTER CHECK</b>' : ''}</div></div>
  </button>`;
}

function renderSelectedDrawer(item) {
  if (!item) return '<aside class="itemDrawer emptyDrawer"><strong>Select an item</strong><p>Choose a vault item to see protected details and available actions.</p></aside>';
  const chips = [...(item.tags || [])].slice(0, 5).map((tag) => `<span class="chip">${escapeHtml(tag)}</span>`).join('');
  const protectedFill = item.type === 'login' && item.requireReauthBeforeFill ? '<span class="chip secureChip">Master check before fill</span>' : '';
  const auto = item.type === 'login' && item.autoLogin ? '<span class="chip autoChip">Auto-login</span>' : '';
  return `<aside class="itemDrawer" data-drawer-id="${escapeHtml(item.id)}">
    <div class="drawerType">${escapeHtml(itemTypeLabel(item))}</div>
    <h2>${escapeHtml(item.name)}</h2>
    <p class="drawerMeta">${escapeHtml(itemMeta(item))}</p>
    <div class="chips">${protectedFill}${auto}${chips}</div>
    ${item.type === 'login' ? `<div class="drawerSecurity"><strong>Credential protection</strong><span>Username and password remain hidden here. Reveal, Copy and Edit require Sensitive Access.</span></div>` : ''}
    <div class="drawerActions"><button data-edit-selected>Open / Edit</button><button data-favorite-selected class="outline">${item.favorite ? '★ Remove favorite' : '☆ Add favorite'}</button></div>
    <small class="drawerActivity">${escapeHtml(activityLabel(item))}</small>
  </aside>`;
}

function renderItems() {
  const items = visibleItems();
  els.content.innerHTML = `${pageHead()}<div id="itemsMount"></div>`;
  const mount = $('itemsMount');
  if (!items.length) {
    mount.innerHTML = emptyStateMarkup();
    $('emptyAdd')?.addEventListener('click', () => openItemDialog(null, ['login','card','bank','identity','note'].includes(currentView) ? currentView : 'login'));
    return;
  }

  if (currentView === 'totp' || currentView === 'trash') {
    const grid = document.createElement('div'); grid.className = 'itemGrid';
    for (const item of items) {
      const node = document.createElement('article'); node.className = 'vaultItem';
      node.innerHTML = `<div class="type">${escapeHtml(itemTypeLabel(item))}</div><div class="name">${escapeHtml(`${item.favorite ? '★ ' : ''}${item.name}`)}</div><div class="meta">${escapeHtml(itemMeta(item))}</div>`;
      if (currentView === 'totp' && item.totpSecret) {
        const code=document.createElement('div'); code.className='totpCode'; code.dataset.totpId=item.id; code.textContent='••• •••'; node.append(code);
      }
      if (currentView === 'trash') {
        const actions=document.createElement('div'); actions.className='trashActions';
        const restore=document.createElement('button'); restore.textContent='Restore'; restore.addEventListener('click', async(e)=>{e.stopPropagation();restoreItem(vault,item.id);await saveUnlockedVault(vault);render();toast('Item restored.');});
        const purge=document.createElement('button'); purge.textContent='Delete forever'; purge.className='danger'; purge.addEventListener('click', async(event)=>{event.stopPropagation();try{await ensureSensitiveAccess('Re-enter your master password before permanently deleting this encrypted item.',async()=>{if(!confirm('Permanently delete this encrypted item? This cannot be undone.'))return;purgeItem(vault,item.id);await saveUnlockedVault(vault);render();toast('Item permanently deleted.');});}catch(error){toast(error.message,true);}});
        actions.append(restore,purge); node.append(actions);
      } else node.addEventListener('click', () => openItemDialog(item));
      grid.append(node);
    }
    if (currentView === 'totp') {
      const accessBar=document.createElement('div');accessBar.className='totpAccessBar';
      const copy=document.createElement('div');copy.innerHTML='<strong>Protected authenticator codes</strong><small>TOTP values stay hidden until you freshly verify the master password. The short Sensitive Access window then expires automatically.</small>';
      const button=document.createElement('button');button.type='button';button.textContent='Verify & show codes';button.addEventListener('click',()=>ensureSensitiveAccess('Re-enter your master password before displaying live TOTP authenticator codes.',()=>refreshTotpCodes()).catch((error)=>toast(error.message,true)));
      accessBar.append(copy,button);mount.append(accessBar);
    }
    mount.append(grid); refreshTotpCodes(); return;
  }

  if (!items.some((item) => item.id === selectedItemId)) selectedItemId = items[0]?.id || null;
  const selected = items.find((item) => item.id === selectedItemId) || null;
  const mode = settingsState?.vaultViewMode === 'list' ? 'list' : 'grid';
  let browser;
  if (mode === 'grid') {
    browser = `<div class="vaultCardGrid">${items.map(vaultCardMarkup).join('')}</div>`;
  } else {
    const rows = items.map((item) => {
      const status = item.type === 'login' && item.pendingPasswordChange ? 'Password change pending' : activityLabel(item);
      return `<button class="vaultListRow ${item.id === selectedItemId ? 'selected' : ''}" data-select-id="${escapeHtml(item.id)}">
        <span class="listTypeIcon">${escapeHtml(({login:'●',card:'▭',bank:'▥',identity:'◉',note:'▤'})[item.type] || '•')}</span>
        <span class="listMain"><strong>${escapeHtml(`${item.favorite ? '★ ' : ''}${item.name}`)}</strong><small>${escapeHtml(itemMeta(item))}</small></span>
        <span class="listStatus">${escapeHtml(status)}</span><span class="listArrow">›</span>
      </button>`;
    }).join('');
    browser = `<div class="vaultList">${rows}</div>`;
  }
  mount.innerHTML = `<div class="vaultBrowseToolbar"><span>${items.length} item${items.length === 1 ? '' : 's'}</span>${viewModeControls()}</div><div class="vaultListLayout"><div>${browser}</div>${renderSelectedDrawer(selected)}</div>`;
  wireFaviconFallbacks(mount);
  document.querySelectorAll('[data-select-id]').forEach((button) => button.addEventListener('click', () => { selectedItemId = button.dataset.selectId; renderItems(); }));
  document.querySelectorAll('[data-vault-view]').forEach((button) => button.addEventListener('click', async () => {
    settingsState.vaultViewMode = button.dataset.vaultView === 'list' ? 'list' : 'grid';
    await setSettings({ vaultViewMode: settingsState.vaultViewMode });
    renderItems();
  }));
  $('[data-edit-selected]')?.addEventListener('click', () => selected && openItemDialog(selected));
  $('[data-favorite-selected]')?.addEventListener('click', async () => {
    if (!selected) return;
    selected.favorite = !selected.favorite; upsertItem(vault, selected); await saveUnlockedVault(vault); renderItems(); toast(selected.favorite ? 'Added to Favorites.' : 'Removed from Favorites.');
  });
}

function renderSecurity() {
  const health = vaultHealth(vault.items);
  const pending = vault.items.filter((item) => item.type === 'login' && !item.deletedAt && item.pendingPasswordChange?.password);
  const newLoginCaptures = Array.isArray(vault.pendingLoginCaptures) ? vault.pendingLoginCaptures : [];
  const pendingHtml = pending.length ? pending.map((item) => {
    const change = item.pendingPasswordChange;
    const detectionLabel = change.confidence === 'submitted-login' ? 'Different password submitted on login form' : 'Password-change form detected';
    return `<div class="passwordChangeCard" data-change-id="${escapeHtml(item.id)}">
      <div><strong>${escapeHtml(item.name)}</strong><small>${escapeHtml(detectionLabel)} · ${escapeHtml(change.hostname || 'Saved HTTPS login')} · ${escapeHtml(relativeTime(change.detectedAt))}</small><p>A possible password update was captured locally and stored only inside the encrypted vault. It is not displayed here and is never applied until you approve it. A different password submitted on a login form may simply be a typo, so review before updating.</p></div>
      <div class="passwordChangeActions"><button data-approve-change="${escapeHtml(item.id)}">Update saved password</button><button data-ignore-change="${escapeHtml(item.id)}" class="outline">Ignore</button></div>
    </div>`;
  }).join('') : '<div class="emptyState">No pending password changes.</div>';

  const newLoginHtml = newLoginCaptures.length ? newLoginCaptures.map((capture) => `<div class="passwordChangeCard" data-new-login-id="${escapeHtml(capture.id)}">
    <div><strong>${escapeHtml(capture.name || capture.hostname || 'New login')}</strong><small>${escapeHtml(capture.hostname || 'HTTPS website')} · ${escapeHtml(maskIdentifier(capture.username || ''))} · ${escapeHtml(relativeTime(capture.detectedAt))}</small><p>VaultCove detected a submitted account that is not currently saved for this website and identifier. The password remains hidden and is stored only inside the encrypted vault candidate until you save or ignore it.</p></div>
    <div class="passwordChangeActions"><button data-save-new-login="${escapeHtml(capture.id)}">Save login</button><button data-ignore-new-login="${escapeHtml(capture.id)}" class="outline">Ignore</button></div>
  </div>`).join('') : '<div class="emptyState">No pending new logins.</div>';

  els.content.innerHTML = `${pageHead()}<div class="stats"></div>
    <section class="settingsCard"><h3>Local vault health</h3><p>VaultCove checks saved login passwords only after you unlock the vault. No password, password hash, domain or score is sent anywhere.</p><div class="healthBar"><div style="width:${health.score}%"></div></div><p>${health.strong} strong · ${health.weak} weak · ${health.reused} reused</p></section>
    <section class="settingsCard"><h3>New-login review</h3><p>When an enabled VaultCove handler sees a submitted login that is not already saved for that site and account identifier, it stores a review candidate only inside the encrypted vault. VaultCove does not silently add it.</p><div class="passwordChangeList">${newLoginHtml}</div></section>
    <section class="settingsCard"><h3>Password-change review</h3><p>The optional login handler looks only for high-confidence password-change forms. A detected candidate is kept inside the encrypted vault until you approve or discard it.</p><div class="passwordChangeList">${pendingHtml}</div></section>`;
  const stats = els.content.querySelector('.stats');
  for (const [label, value] of [['Security score', `${health.score}%`], ['Login items', health.total], ['Weak passwords', health.weak], ['Reused passwords', health.reused]]) {
    const node = document.createElement('div'); node.className = 'stat'; const strong = document.createElement('strong'); strong.textContent = value; const span = document.createElement('span'); span.textContent = label; node.append(strong, span); stats.append(node);
  }

  document.querySelectorAll('[data-approve-change]').forEach((button) => button.addEventListener('click', () => {
    const id = button.dataset.approveChange;
    ensureSensitiveAccess('Re-enter your master password before replacing a saved password.', async () => {
      const item = vault.items.find((candidate) => candidate.id === id);
      const pendingChange = item?.pendingPasswordChange;
      if (!item || !pendingChange?.password) throw new Error('This password change is no longer pending.');
      if (item.password && item.password !== pendingChange.password) {
        item.passwordHistory = [...(item.passwordHistory || []), { password: item.password, changedAt: pendingChange.detectedAt || new Date().toISOString() }].slice(-10);
      }
      item.password = pendingChange.password;
      item.lastPasswordChangeAt = new Date().toISOString();
      item.pendingPasswordChange = null;
      upsertItem(vault, item);
      await saveUnlockedVault(vault);
      await runtimeMessage({ type: 'PASSWORD_CHANGE_CONFIRMED', itemId: item.id });
      renderSecurity();
      toast('Saved password updated inside the encrypted vault.');
    }).catch((error) => toast(error.message, true));
  }));
  document.querySelectorAll('[data-ignore-change]').forEach((button) => button.addEventListener('click', () => {
    const id = button.dataset.ignoreChange;
    ensureSensitiveAccess('Re-enter your master password before discarding a captured password-change candidate.', async () => {
      const item = vault.items.find((candidate) => candidate.id === id);
      if (!item) throw new Error('Login no longer exists.');
      item.pendingPasswordChange = null;
      upsertItem(vault, item);
      await saveUnlockedVault(vault);
      renderSecurity();
      toast('Password-change candidate discarded.');
    }).catch((error) => toast(error.message, true));
  }));

  document.querySelectorAll('[data-save-new-login]').forEach((button) => button.addEventListener('click', () => {
    const id = button.dataset.saveNewLogin;
    ensureSensitiveAccess('Re-enter your master password before promoting a captured website credential into the permanent vault.', async () => {
      const capture = (vault.pendingLoginCaptures || []).find((candidate) => candidate.id === id);
      if (!capture?.password || !capture?.username) throw new Error('This new-login candidate is no longer pending.');
      const duplicate = vault.items.find((item) => item.type === 'login' && !item.deletedAt && (item.urls || []).some((url) => {
        try { return new URL(url).hostname.replace(/^www\./, '') === String(capture.hostname || '').replace(/^www\./, ''); } catch { return false; }
      }) && String(item.username || '').trim().toLowerCase() === String(capture.username || '').trim().toLowerCase());
      if (duplicate) throw new Error('This website/account is already saved in VaultCove. Review the existing login instead.');
      const item = createItem('login', {
        name: capture.name || capture.hostname || 'New Login',
        username: capture.username,
        password: capture.password,
        urls: [capture.origin || `https://${capture.hostname}`],
        autoLogin: false,
        requireReauthBeforeFill: false
      });
      upsertItem(vault, item);
      vault.pendingLoginCaptures = (vault.pendingLoginCaptures || []).filter((candidate) => candidate.id !== id);
      await saveUnlockedVault(vault);
      selectedItemId = item.id;
      renderSecurity();
      toast('New login encrypted and saved to VaultCove.');
    }).catch((error) => toast(error.message, true));
  }));
  document.querySelectorAll('[data-ignore-new-login]').forEach((button) => button.addEventListener('click', async () => {
    const id = button.dataset.ignoreNewLogin;
    vault.pendingLoginCaptures = (vault.pendingLoginCaptures || []).filter((candidate) => candidate.id !== id);
    await saveUnlockedVault(vault);
    renderSecurity();
    toast('New-login candidate ignored.');
  }));

  const newLoginHighlight = new URLSearchParams(location.search).get('newLogin');
  if (newLoginHighlight) document.querySelector(`[data-new-login-id="${CSS.escape(newLoginHighlight)}"]`)?.scrollIntoView({ block: 'center', behavior: 'smooth' });

  const highlight = new URLSearchParams(location.search).get('passwordChange');
  if (highlight) document.querySelector(`[data-change-id="${CSS.escape(highlight)}"]`)?.scrollIntoView({ block: 'center', behavior: 'smooth' });
}

function renderGenerator() {
  generatedPassword = generatedPassword || generatePassword({length:20});
  els.content.innerHTML = `${pageHead()}<section class="settingsCard generatorShell"><h3>Local Password Generator</h3><p>Generation uses the browser cryptographic random-number generator. Nothing is transmitted.</p><div class="generatorOutput"><input id="generatedPassword" value="${escapeHtml(generatedPassword)}" readonly><button id="copyGenerated">Copy</button><button id="regenPassword" class="outline">Regenerate</button></div><div class="generatorOptions"><label class="rangeRow"><span>Length</span><input id="generatorLength" type="range" min="12" max="64" value="20"><b id="generatorLengthValue">20</b></label><label><input id="genLower" type="checkbox" checked> Lowercase</label><label><input id="genUpper" type="checkbox" checked> Uppercase</label><label><input id="genDigits" type="checkbox" checked> Numbers</label><label><input id="genSymbols" type="checkbox" checked> Symbols</label></div></section>`;
  const regenerate = () => {
    try {
      const length=Number($('generatorLength').value); $('generatorLengthValue').textContent=String(length);
      generatedPassword=generatePassword({length,lower:$('genLower').checked,upper:$('genUpper').checked,digits:$('genDigits').checked,symbols:$('genSymbols').checked});
      $('generatedPassword').value=generatedPassword;
    } catch (error) { toast(error.message,true); }
  };
  $('regenPassword').addEventListener('click',regenerate);
  $('generatorLength').addEventListener('input',regenerate);
  for (const id of ['genLower','genUpper','genDigits','genSymbols']) $(id).addEventListener('change',regenerate);
  $('copyGenerated').addEventListener('click',async()=>{await navigator.clipboard.writeText($('generatedPassword').value);toast('Generated password copied.');});
}

async function renderMigration() {
  if (licenseState.status === 'expired') return renderBackup();
  pendingMigration = null;
  els.content.innerHTML = `${pageHead()}<div class="settingsGrid migrationGrid">
    <section class="settingsCard">
      <h3>Import from another password manager</h3>
      <p>VaultCove reads the export only inside this extension. Nothing is uploaded. After import, records are stored inside the encrypted VaultCove vault.</p>
      <label>Source format<select id="migrationFormat"><option value="auto">Detect automatically</option><option value="lastpass">LastPass CSV</option><option value="zoho">Zoho Vault CSV</option></select></label>
      <label>Export file<input id="migrationFile" type="file" accept=".csv,text/csv,text/plain"></label>
      <label class="check"><input id="migrationSkipDuplicates" type="checkbox" checked> Skip likely duplicate items already in VaultCove</label>
      <div class="migrationActions"><button id="migrationPreview">Preview locally</button><button id="migrationImport" class="outline" disabled>Import & encrypt</button></div>
      <div class="migrationWarning"><strong>Important:</strong> LastPass and Zoho CSV exports are plaintext. Delete the source CSV securely after you verify the VaultCove import and encrypted backup.</div>
    </section>
    <section class="settingsCard">
      <h3>Migration preview</h3>
      <div id="migrationPreviewMount" class="migrationPreview"><p>Select an export file to inspect it locally. Password values are never displayed in this preview.</p></div>
    </section>
    <section class="settingsCard">
      <h3>Supported today</h3>
      <p><strong>LastPass:</strong> CSV exports containing URL, username, password, name, notes/grouping and compatible TOTP values.</p>
      <p><strong>Zoho Vault:</strong> General/Zoho Vault CSV exports. VaultCove maps web logins and preserves recognized bank/card/identity/note fields when present.</p>
      <p>Encrypted vendor-specific backup containers are not decrypted by VaultCove. Export a supported CSV from the source manager first.</p>
    </section>
  </div>`;

  const mount = $('migrationPreviewMount');
  const previewButton = $('migrationPreview');
  const importButton = $('migrationImport');
  previewButton.addEventListener('click', async () => {
    try {
      const file = $('migrationFile').files?.[0];
      if (!file) throw new Error('Choose a LastPass or Zoho Vault CSV first.');
      if (file.size > 25 * 1024 * 1024) throw new Error('For safety, migration files are limited to 25 MB in this build.');
      const text = await file.text();
      pendingMigration = importMigrationCsv(text, $('migrationFormat').value);
      const counts = pendingMigration.items.reduce((out, item) => { out[item.type] = (out[item.type] || 0) + 1; return out; }, {});
      const sample = pendingMigration.items.slice(0, 8).map((item) => `<div class="migrationRow"><strong>${escapeHtml(item.name)}</strong><span>${escapeHtml(itemTypeLabel(item))}</span><small>${escapeHtml(item.type === 'login' ? (item.username || '(no username)') : itemMeta(item))}</small></div>`).join('');
      const warnings = pendingMigration.warnings?.length ? `<div class="migrationWarning">${pendingMigration.warnings.slice(0, 8).map(escapeHtml).join('<br>')}</div>` : '';
      mount.innerHTML = `<div class="migrationSummary"><strong>${pendingMigration.items.length}</strong><span>items detected from ${escapeHtml(pendingMigration.source)}</span></div><p>${Object.entries(counts).map(([type,count]) => `${escapeHtml(type)}: ${count}`).join(' · ')}</p>${warnings}<div class="migrationRows">${sample}</div>`;
      importButton.disabled = pendingMigration.items.length === 0;
    } catch (error) {
      pendingMigration = null; importButton.disabled = true; mount.textContent = error.message; toast(error.message, true);
    }
  });
  importButton.addEventListener('click', async () => {
    try {
      if (!pendingMigration) throw new Error('Preview the migration file first.');
      if (!featureAllowed(licenseState, 'edit')) throw new Error('A valid license or trial is required to import.');
      const merged = mergeImportedItems(vault.items, pendingMigration.items, { skipDuplicates: $('migrationSkipDuplicates').checked });
      if (!merged.accepted.length) throw new Error('No new items remain after duplicate filtering.');
      vault.items.push(...merged.accepted);
      await saveUnlockedVault(vault);
      const imported = merged.accepted.length;
      const skipped = merged.skipped;
      pendingMigration = null;
      $('migrationFile').value = '';
      importButton.disabled = true;
      mount.innerHTML = `<div class="migrationSummary"><strong>${imported}</strong><span>items imported and encrypted</span></div><p>${skipped} likely duplicate item(s) skipped.</p>`;
      toast(`${imported} imported item(s) encrypted into VaultCove.`);
    } catch (error) { toast(error.message, true); }
  });
}

function shareSelectorCard(item) {
  return `<label class="shareLoginCard" data-share-card="${escapeHtml(item.id)}"><input type="checkbox" name="shareLoginIds" value="${escapeHtml(item.id)}">${siteCardVisual(item)}<div class="shareLoginBody"><strong>${escapeHtml(item.name)}</strong><small>${escapeHtml(itemMeta(item))}</small><span>${item.siteVisual?.visitedAt ? 'Visited site visual available' : 'Fallback card until site is visited'}</span></div></label>`;
}

async function renderShared() {
  if (licenseState.status === 'expired') return renderBackup();
  const hadIdentity = Boolean(vault.sharingIdentity?.shareId);
  const identity = await ensureSharingIdentity(vault);
  if (!hadIdentity) await saveUnlockedVault(vault);
  const contacts = vault.trustedShareContacts || [];
  const logins = activeItems().filter((item) => item.type === 'login');
  const history = (vault.shareHistory || []).slice(0, 20);
  const contactOptions = contacts.map((contact) => `<option value="${escapeHtml(contact.shareId)}">${escapeHtml(contact.displayName || contact.shareId)} · ${escapeHtml(contact.shareId)}</option>`).join('');
  const historyHtml = history.length ? history.map((entry) => `<div class="shareHistoryRow"><strong>${escapeHtml(entry.direction === 'out' ? 'Shared by me' : 'Shared with me')}</strong><span>${escapeHtml(entry.itemName || 'Login')}</span><small>${escapeHtml(entry.peerName || entry.peerShareId || '')} · ${escapeHtml(relativeTime(entry.occurredAt))}</small></div>`).join('') : '<div class="emptyState compactEmpty">No secure-share history yet.</div>';

  els.content.innerHTML = `${pageHead()}<div class="shareGrid">
    <section class="settingsCard shareIdentityCard"><h3>Your VaultCove Sharing Identity</h3><p>This public identity can be given to another VaultCove or compatible VaultCore user. Your private sharing keys remain inside the encrypted vault.</p><div class="shareIdBox"><strong>${escapeHtml(identity.shareId)}</strong><span>${escapeHtml(identity.fingerprint)}</span></div><button id="exportShareIdentity">Export public .vckey</button></section>
    <section class="settingsCard"><h3>Trusted recipients</h3><p>Import a recipient's public <code>.vckey</code> before creating a share. Public keys cannot decrypt your vault.</p><label>Recipient public identity<input id="contactFile" type="file" accept=".vckey,application/json"></label><button id="importContact" class="outline">Trust this public identity</button><div class="trustedContacts">${contacts.length ? contacts.map((contact) => `<div><strong>${escapeHtml(contact.displayName || contact.shareId)}</strong><small>${escapeHtml(contact.shareId)} · ${escapeHtml(contact.fingerprint)}</small></div>`).join('') : '<p>No trusted recipients yet.</p>'}</div></section>
    <section class="settingsCard shareBundleCard"><div class="shareBundleHead"><div><h3>Create encrypted .vcshare bundle</h3><p>VCShare v2 can encrypt multiple selected login cards for one recipient. The package is recipient-key encrypted and signed.</p></div><strong id="shareSelectedCount">0 selected</strong></div><div class="shareSelectToolbar"><input id="shareSearch" type="search" placeholder="Search logins to share"><button id="shareSelectAll" class="outline" type="button">Select visible</button><button id="shareClear" class="outline" type="button">Clear</button></div><div id="shareLoginGrid" class="shareLoginGrid">${logins.length ? logins.map(shareSelectorCard).join('') : '<div class="emptyState compactEmpty">No login available.</div>'}</div><label>Recipient<select id="shareRecipient">${contactOptions || '<option value="">Import a recipient first</option>'}</select></label><div class="shareChecks"><label class="check"><input id="shareUsername" type="checkbox" checked> Username</label><label class="check"><input id="sharePassword" type="checkbox" checked> Password</label><label class="check"><input id="shareNotes" type="checkbox"> Notes</label><label class="check"><input id="shareTotp" type="checkbox"> TOTP secret (extra warning)</label></div><label>Expire package after<select id="shareExpiry"><option value="7">7 days</option><option value="1">1 day</option><option value="30">30 days</option><option value="0">Never</option></select></label><button id="createShare" disabled>Create encrypted .vcshare bundle</button><div class="migrationWarning"><strong>Important:</strong> a decrypted password cannot be remotely revoked. If access must truly be revoked after receipt, change the real website password.</div></section>
    <section class="settingsCard"><h3>Receive secure share</h3><p>VaultCove verifies the sender signature and recipient identity before decrypting. Every received item is immediately re-encrypted under your own vault key.</p><label>Secure share file<input id="shareFile" type="file" accept=".vcshare,application/json"></label><button id="importShare" class="outline">Verify & import share</button></section>
    <section class="settingsCard shareHistoryCard"><h3>Local share history</h3><p>History is stored only inside your encrypted vault. It contains metadata, never the shared passwords.</p><div class="shareHistory">${historyHtml}</div></section>
  </div>`;
  wireFaviconFallbacks(els.content);

  const selectedIds = () => [...document.querySelectorAll('input[name="shareLoginIds"]:checked')].map((input) => input.value);
  const updateShareSelection = () => {
    const count = selectedIds().length;
    $('shareSelectedCount').textContent = `${count} selected`;
    $('createShare').disabled = !(count && contacts.length && $('shareRecipient').value);
    document.querySelectorAll('.shareLoginCard').forEach((card) => card.classList.toggle('selected', card.querySelector('input')?.checked));
  };
  document.querySelectorAll('input[name="shareLoginIds"]').forEach((input) => input.addEventListener('change', updateShareSelection));
  $('shareRecipient')?.addEventListener('change', updateShareSelection);
  $('shareSearch')?.addEventListener('input', () => {
    const q = $('shareSearch').value.trim().toLowerCase();
    document.querySelectorAll('.shareLoginCard').forEach((card) => {
      const item = logins.find((candidate) => candidate.id === card.dataset.shareCard);
      const haystack = `${item?.name || ''} ${item?.username || ''} ${(item?.urls || []).join(' ')}`.toLowerCase();
      card.classList.toggle('hidden', Boolean(q && !haystack.includes(q)));
    });
  });
  $('shareSelectAll')?.addEventListener('click', () => { document.querySelectorAll('.shareLoginCard:not(.hidden) input[name="shareLoginIds"]').forEach((input) => { input.checked = true; }); updateShareSelection(); });
  $('shareClear')?.addEventListener('click', () => { document.querySelectorAll('input[name="shareLoginIds"]').forEach((input) => { input.checked = false; }); updateShareSelection(); });

  $('exportShareIdentity').addEventListener('click', async () => {
    const publicIdentity = await exportPublicSharingIdentity(vault);
    downloadJsonFile(publicIdentity, `VaultCove-${identity.shareId}.vckey`, 'application/json');
    toast('Public sharing identity exported. It contains no private key.');
  });

  $('importContact').addEventListener('click', async () => {
    try {
      const file = $('contactFile').files?.[0]; if (!file) throw new Error('Choose a .vckey file first.');
      const contact = await validatePublicSharingIdentity(JSON.parse(await file.text()));
      if (!confirm(`Trust ${contact.displayName}\n${contact.shareId}\nFingerprint: ${contact.fingerprint}?\n\nCompare the fingerprint with the recipient through a separate trusted channel.`)) return;
      addTrustedShareContact(vault, contact); await saveUnlockedVault(vault); toast('Trusted recipient saved inside the encrypted vault.'); await renderShared();
    } catch (error) { toast(error.message, true); }
  });

  $('createShare').addEventListener('click', () => ensureSensitiveAccess('Re-enter your master password and second factor before creating a decrypted credential share.', async () => {
    const ids = selectedIds();
    const items = ids.map((id) => vault.items.find((candidate) => candidate.id === id && candidate.type === 'login' && !candidate.deletedAt)).filter(Boolean);
    const contact = contacts.find((candidate) => candidate.shareId === $('shareRecipient').value);
    if (!items.length || !contact) throw new Error('Select at least one login and a trusted recipient.');
    if (items.length > 50) throw new Error('Select at most 50 logins per secure share.');
    if ($('shareTotp').checked && !confirm('Sharing TOTP secrets can let the recipient generate authentication codes for every selected account that has one. Continue?')) return;
    const days = Number($('shareExpiry').value) || 0;
    const expiresAt = days > 0 ? new Date(Date.now() + days * 86400000).toISOString() : null;
    const pkg = await createSecureShare(vault, { magic:'VAULTCOVE-PUBLIC-IDENTITY', version:2, ...contact }, items, { expiresAt, include: { username:$('shareUsername').checked, password:$('sharePassword').checked, notes:$('shareNotes').checked, totp:$('shareTotp').checked } });
    const filename = items.length === 1 ? `${items[0].name.replace(/[^a-z0-9._-]+/gi,'-').replace(/^-+|-+$/g,'') || 'VaultCove'}.vcshare` : `VaultCove-${items.length}-logins.vcshare`;
    downloadJsonFile(pkg, filename);
    recordShareHistory(vault, { direction:'out', itemName:items.length === 1 ? items[0].name : `${items.length} login bundle`, itemCount:items.length, peerName:contact.displayName, peerShareId:contact.shareId, expiresAt }); await saveUnlockedVault(vault);
    toast(`Encrypted VCShare bundle created for ${items.length} login${items.length === 1 ? '' : 's'}.`); await renderShared();
  }).catch((error) => toast(error.message, true)));

  $('importShare').addEventListener('click', () => ensureSensitiveAccess('Re-enter your master password and second factor before decrypting and importing a secure share.', async () => {
    const file = $('shareFile').files?.[0]; if (!file) throw new Error('Choose a .vcshare file first.');
    const opened = await openSecureShare(vault, JSON.parse(await file.text()));
    if (!opened.sender.trusted && !confirm(`The package signature is valid, but sender ${opened.sender.shareId} is not in your trusted recipients.\nFingerprint: ${opened.sender.fingerprint}\n\nImport anyway?`)) return;
    vault.items.push(...opened.items);
    recordShareHistory(vault, { direction:'in', itemName:opened.items.length === 1 ? opened.items[0].name : `${opened.items.length} login bundle`, itemCount:opened.items.length, peerName:opened.sender.displayName, peerShareId:opened.sender.shareId });
    await saveUnlockedVault(vault);
    toast(`${opened.items.length} secure-share login${opened.items.length === 1 ? '' : 's'} verified and imported.`); currentView='login'; selectedItemId=opened.items[0]?.id || null; render();
  }).catch((error) => toast(error.message, true)));
  updateShareSelection();
}

async function renderBackup() {
  if (licenseState.status === 'expired') {
    els.search.classList.add('hidden'); els.newItem.classList.add('hidden');
    els.content.innerHTML=`${pageHead('Trial ended — export access only','Your vault remains yours. Create a complete encrypted backup at any time.')}<div class="settingsGrid"><section class="settingsCard"><h3>Encrypted portable backup</h3><p>Editing and restore are disabled after trial expiration, but export remains available so your data is never held hostage.</p><button id="exportVault">Create encrypted export</button></section><section class="settingsCard"><h3>License</h3><p>${escapeHtml(licenseState.message || 'A license is required to resume normal use.')}</p></section></div>`;
    $('exportVault').addEventListener('click', exportVault); return;
  }
  els.content.innerHTML=`${pageHead()}<div class="settingsGrid"><section class="settingsCard"><h3>Export encrypted vault</h3><p>Creates a <code>.vcvault</code> file encrypted with a new random 256-bit export secret. The secret is shown once and is not embedded in the file.</p><button id="exportVault">Create encrypted export</button></section><section class="settingsCard"><h3>Restore encrypted vault</h3><p>Choose a VaultCove backup and enter the matching export secret. Decryption happens locally.</p><label>Restore file<input id="importFile" type="file" accept=".vcvault,application/octet-stream"></label><label>Export secret<input id="importSecret" autocomplete="off" placeholder="VC1-..."></label><button id="importVault" class="outline">Restore into this vault</button></section></div>`;
  $('exportVault').addEventListener('click', exportVault); $('importVault').addEventListener('click', importVault);
}

async function renderSettings() {
  settingsState = await getSettings();
  if (licenseState.status === 'expired') return renderBackup();
  await refreshHandlerPermissions();
  const origins = handlerPermissionState;
  const broadOrigin = 'https://*/*';
  const broadGranted = await chrome.permissions.contains({ origins: [broadOrigin] });
  const faviconGranted = await chrome.permissions.contains({ permissions: ['favicon'] });
  const perSiteOrigins = origins.filter((origin) => origin !== broadOrigin);
  const siteRows = perSiteOrigins.length ? perSiteOrigins.map((origin) => `<div class="permissionRow"><strong>${escapeHtml(origin.replace(/^https:\/\//,'').replace(/\/\*$/,''))}</strong><span>Persistent site access</span></div>`).join('') : '<div class="emptyState compactEmpty">No individual website permissions are stored.</div>';
  const protection = vaultTotpProtection();
  const strength = assessPassword('');

  els.content.innerHTML = `${pageHead()}<div class="settingsGrid">
    <section class="settingsCard"><h3>Auto-lock & Sensitive Access</h3><p>Vault unlock controls normal use. Viewing, copying, editing, exporting, sharing, or protected filling gets a fresh Sensitive Access check.</p><label>Lock vault after inactivity (minutes)<input id="lockMinutesSetting" type="number" min="1" max="120" value="${settingsState.lockMinutes}"></label><label>Sensitive Access window (seconds)<input id="sensitiveSecondsSetting" type="number" min="5" max="300" value="${settingsState.sensitiveAccessSeconds}"></label><label>Secure Login field-clear fallback (milliseconds)<input id="clearDelaySetting" type="number" min="250" max="5000" step="50" value="${settingsState.secureLoginClearMs || 1200}"></label><p class="settingHint">Secure Login submits first, then clears the injected password field if it is still present and unchanged.</p><button id="saveSettings">Save security timing</button></section>

    <section class="settingsCard alwaysOnCard"><h3>Always-On Login Handler</h3><p>Enable once to let VaultCove appear automatically on supported HTTPS login/password forms without clicking the extension first. The handler stays in an isolated world and receives only masked account summaries until you choose Fill or Secure Login.</p><div class="integrationStatus"><strong>${broadGranted ? 'Always-On Handler enabled' : 'Always-On Handler is not enabled'}</strong><span>${broadGranted ? 'Optional HTTPS permission is active. VaultCove scans for login fields but does not send vault data to websites.' : 'On-demand activeTab filling and individual per-site permissions remain available.'}</span></div>${broadGranted ? '<button id="disableAlwaysOn" class="outline">Disable Always-On Handler</button>' : '<button id="enableAlwaysOn">Enable Always-On Handler</button>'}<p class="settingHint">This optional permission covers HTTPS pages because a password manager cannot know every future login site in advance. The Chrome Web Store build keeps it optional and explains why it is needed.</p><div class="permissionList">${siteRows}</div>${perSiteOrigins.length ? '<button id="removeAllHandlers" class="outline">Remove individual site permissions</button>' : ''}<label class="check"><input id="autoLoginSetting" type="checkbox" ${settingsState.autoLoginEnabled ? 'checked' : ''} ${(broadGranted || perSiteOrigins.length) ? '' : 'disabled'}> Enable automatic login only for entries individually marked Auto-login</label><label class="check"><input id="newLoginCaptureSetting" type="checkbox" ${settingsState.newLoginCaptureEnabled ? 'checked' : ''}> Detect submitted new logins locally and ask before saving them</label><label class="check"><input id="passwordChangeSetting" type="checkbox" ${settingsState.passwordChangeDetectionEnabled ? 'checked' : ''}> Detect password changes and offer the inline strong-password generator</label></section>

    <section class="settingsCard"><h3>Website thumbnails</h3><p>The visual Vault can use Chrome's local favicon cache. VaultCove shows an icon only after that saved login has actually been visited while VaultCove was active; otherwise it keeps the private lock-card fallback.</p><div class="integrationStatus"><strong>${faviconGranted && settingsState.websiteIconsEnabled ? 'Local website icons enabled' : 'Private fallback cards enabled'}</strong><span>No third-party icon service is contacted and no domain list is uploaded.</span></div>${faviconGranted && settingsState.websiteIconsEnabled ? '<button id="disableSiteIcons" class="outline">Use fallback cards only</button>' : '<button id="enableSiteIcons">Enable local website icons</button>'}</section>

    <section class="settingsCard"><h3>VaultCove authenticator confirmation</h3><p>${protection.enabled ? 'A standard TOTP authenticator code is required with the master password for unlock and Sensitive Access.' : 'Optionally protect VaultCove itself with a standard TOTP authenticator such as Google Authenticator.'}</p><div class="integrationStatus"><strong>${protection.enabled ? 'Authenticator protection enabled' : 'Authenticator protection disabled'}</strong><span>Google Authenticator does not receive, sync, store, or have access to your VaultCove passwords. VaultCove verifies a standard TOTP code locally. This adds an access-confirmation step but is not a separate cloud-held encryption key against full device compromise.</span></div>${protection.enabled ? `<p class="settingHint">${(protection.recoveryCodeHashes || []).length} unused recovery code(s) remain.</p><button id="disableVaultTotp" class="outline">Disable authenticator protection</button>` : '<button id="setupVaultTotp">Set up Google Authenticator-compatible protection</button>'}</section>

    <section class="settingsCard masterPasswordCard"><h3>Change master password</h3><p>VaultCove verifies the current password${protection.enabled ? ' and authenticator code' : ''}, checks the new password strength, atomically re-wraps the same random vault key, then locks the vault so the new password must be used immediately.</p><label>Current master password<input id="currentMaster" type="password" autocomplete="current-password"></label>${protection.enabled ? '<label>Authenticator or recovery code<input id="masterTotp" autocomplete="one-time-code" inputmode="numeric"></label>' : ''}<label>New master password<input id="newMaster" type="password" autocomplete="new-password"></label><div class="masterStrength"><span>Strength</span><strong id="masterStrengthLabel">${escapeHtml(strength.label)}</strong><div><i id="masterStrengthBar"></i></div></div><label>Confirm new password<input id="newMasterConfirm" type="password" autocomplete="new-password"></label><label>Type <code>CHANGE MASTER PASSWORD</code> to confirm<input id="masterConfirmPhrase" autocomplete="off"></label><div class="migrationWarning"><strong>Before changing it:</strong> keep a current encrypted <code>.vcvault</code> backup and its export secret. VaultCove cannot recover a forgotten master password or lost authenticator setup.</div><button id="changeMaster" class="danger">Change master password & lock VaultCove</button></section>

    <section class="settingsCard"><h3>Developer updates</h3><p>This Developer Mode build checks only the official public <code>VaultCove-release</code> metadata once per day. No vault, username, password, website list, security score, or browsing data is added to the request.</p><label class="check"><input id="updateCheckSetting" type="checkbox" ${settingsState.updateChecksEnabled ? 'checked' : ''}> Check official developer release metadata daily</label><button id="checkUpdatesNow" class="outline">Check for updates now</button><p class="settingHint">The Chrome Web Store build removes the GitHub updater permission and uses Chrome's official extension update mechanism.</p></section>
    <section class="settingsCard"><h3>Email security notice</h3><p>The future license service can send a generic email after an approved password update. It never includes the website, username, account title, old password, or new password.</p><label class="check"><input id="emailNoticeSetting" type="checkbox" ${settingsState.securityEmailNoticeEnabled ? 'checked' : ''}> Prepare generic email notice after an approved password update</label><div class="migrationWarning"><strong>Testing build:</strong> no email transport is connected yet.</div></section>
    <section class="settingsCard"><h3>Privacy model</h3><p>No cloud vault, analytics, advertising or telemetry. Autofill secrets are released only for a verified matching HTTPS destination. Website icons use Chrome's local favicon cache only when explicitly enabled.</p><p><strong>${escapeHtml(licenseState.message)}</strong></p></section>
    <section class="settingsCard"><h3>What encryption can and cannot protect</h3><p>A stolen Chrome profile sees only the encrypted vault. Once a credential is deliberately filled into a destination page, that page can read it; Secure Login therefore validates the destination, injects at the last practical moment, submits promptly and clears the field after submission when safe.</p></section>
  </div>`;

  $('saveSettings').addEventListener('click', async () => {
    const minutes = Math.max(1, Math.min(120, Number($('lockMinutesSetting').value) || 5));
    const sensitiveAccessSeconds = Math.max(5, Math.min(300, Number($('sensitiveSecondsSetting').value) || 30));
    const secureLoginClearMs = Math.max(250, Math.min(5000, Number($('clearDelaySetting').value) || 1200));
    await setSettings({ lockMinutes: minutes, sensitiveAccessSeconds, secureLoginClearMs });
    settingsState = await getSettings(); toast('Security timing saved.');
  });

  $('enableAlwaysOn')?.addEventListener('click', async () => {
    try {
      const granted = await chrome.permissions.request({ origins: [broadOrigin] });
      if (!granted) return toast('Always-On Handler permission was not granted.', true);
      await setSettings({ alwaysOnHandlerEnabled: true, inlineHandlerEnabled: true });
      await runtimeMessage({ type: 'SYNC_ALWAYS_ON_HANDLER', injectExisting: true });
      settingsState = await getSettings(); toast('Always-On Handler enabled. Existing HTTPS tabs may require one reload.'); await renderSettings();
    } catch (error) { toast(error.message, true); }
  });
  $('disableAlwaysOn')?.addEventListener('click', async () => {
    if (!confirm('Disable automatic VaultCove handler access across HTTPS websites? Individual site permissions can remain.')) return;
    await chrome.permissions.remove({ origins: [broadOrigin] });
    await setSettings({ alwaysOnHandlerEnabled: false, inlineHandlerEnabled: false, autoLoginEnabled: false });
    await runtimeMessage({ type: 'SYNC_ALWAYS_ON_HANDLER' });
    settingsState = await getSettings(); toast('Always-On Handler disabled.'); await renderSettings();
  });
  $('removeAllHandlers')?.addEventListener('click', async () => {
    if (!confirm('Remove individual per-site VaultCove permissions?')) return;
    for (const origin of perSiteOrigins) await chrome.permissions.remove({ origins: [origin] });
    await runtimeMessage({ type: 'SYNC_BROWSER_INTEGRATION' }); await refreshHandlerPermissions(); await renderSettings(); toast('Individual site permissions removed.');
  });

  $('enableSiteIcons')?.addEventListener('click', async () => {
    try {
      const granted = faviconGranted || await chrome.permissions.request({ permissions: ['favicon'] });
      if (!granted) return toast('Website icon permission was not granted.', true);
      await setSettings({ websiteIconsEnabled: true }); settingsState = await getSettings(); toast('Local visited-site icons enabled.'); await renderSettings();
    } catch (error) { toast(error.message, true); }
  });
  $('disableSiteIcons')?.addEventListener('click', async () => { await setSettings({ websiteIconsEnabled: false }); settingsState = await getSettings(); toast('Vault will use private fallback cards.'); await renderSettings(); });

  $('setupVaultTotp')?.addEventListener('click', () => ensureSensitiveAccess('Re-enter your master password before adding a second factor to VaultCove.', beginVaultTotpSetup).catch((error) => toast(error.message, true)));
  $('disableVaultTotp')?.addEventListener('click', () => ensureSensitiveAccess('Verify your master password and authenticator code before disabling VaultCove authenticator confirmation.', async () => {
    vault.security = vault.security || {};
    vault.security.vaultTotp = { enabled:false, secret:'', recoveryCodeHashes:[], enabledAt:null };
    await saveUnlockedVault(vault); await setSettings({ vaultTotpEnabled:false }); settingsState = await getSettings(); toast('VaultCove authenticator protection disabled.'); await renderSettings();
  }).catch((error) => toast(error.message, true)));

  $('newMaster')?.addEventListener('input', updateMasterStrength);
  $('changeMaster').addEventListener('click', changeMaster);
  $('autoLoginSetting').addEventListener('change', async () => { await setSettings({ autoLoginEnabled:$('autoLoginSetting').checked }); settingsState=await getSettings(); toast($('autoLoginSetting').checked ? 'Automatic login enabled only for opted-in credentials.' : 'Automatic login disabled.'); });
  $('newLoginCaptureSetting').addEventListener('change', async () => { await setSettings({ newLoginCaptureEnabled:$('newLoginCaptureSetting').checked }); settingsState=await getSettings(); toast($('newLoginCaptureSetting').checked ? 'New-login capture enabled.' : 'New-login capture disabled.'); });
  $('passwordChangeSetting').addEventListener('change', async () => { await setSettings({ passwordChangeDetectionEnabled:$('passwordChangeSetting').checked }); settingsState=await getSettings(); toast($('passwordChangeSetting').checked ? 'Password-change detection and inline generator enabled.' : 'Password-change detection disabled.'); });
  $('emailNoticeSetting').addEventListener('change', async () => { await setSettings({ securityEmailNoticeEnabled:$('emailNoticeSetting').checked }); settingsState=await getSettings(); toast('Email security-notice preference saved.'); });
  $('updateCheckSetting')?.addEventListener('change', async () => { await setSettings({ updateChecksEnabled:$('updateCheckSetting').checked }); settingsState=await getSettings(); toast($('updateCheckSetting').checked ? 'Daily developer update checks enabled.' : 'Automatic update checks disabled.'); });
  $('checkUpdatesNow')?.addEventListener('click', async () => { try { const result=await runtimeMessage({type:'CHECK_FOR_UPDATES',force:true}); toast(result.updateAvailable ? `VaultCove ${result.version} is available.` : `VaultCove ${result.currentVersion} is up to date.`); } catch(error){ toast(error.message,true); } });
  updateMasterStrength();
}

function updateMasterStrength() {
  const input = $('newMaster'); if (!input || !$('masterStrengthLabel') || !$('masterStrengthBar')) return;
  const result = assessPassword(input.value);
  $('masterStrengthLabel').textContent = result.label;
  $('masterStrengthBar').style.width = `${Math.max(0, Math.min(100, result.score * 25))}%`;
  $('masterStrengthBar').dataset.score = String(result.score);
}

async function beginVaultTotpSetup() {
  const secret = generateTotpSecret();
  const recoveryCodes = generateRecoveryCodes(10);
  pendingTotpSetup = { secret, recoveryCodes };
  $('totpSetupSecret').value = secret;
  $('totpSetupUri').value = buildTotpUri(secret, 'Local Vault', 'VaultCove');
  $('totpSetupCode').value = '';
  $('totpRecoveryPanel').classList.add('hidden');
  $('totpRecoveryCodes').textContent = '';
  els.totpSetupDialog.showModal();
  setTimeout(() => $('totpSetupCode').focus(), 0);
}

async function exportVaultNow() {
  const { payload, secret } = await createPortableExport(normalizeVault(vault));
  downloadExport(payload);
  els.exportSecret.textContent = secret;
  els.secretDialog.showModal();
}

async function exportVault() {
  try {
    if (!featureAllowed(licenseState, 'export')) throw new Error('Export is unavailable.');
    await ensureSensitiveAccess(
      'Re-enter your master password before exporting the complete decrypted vault. The exported file is encrypted, but creating it exposes every vault record to this trusted extension context.',
      exportVaultNow
    );
  } catch (error) { toast(error.message, true); }
}

async function importVaultNow() {
  const file = $('importFile').files?.[0];
  if (!file) throw new Error('Choose a .vcvault file first.');
  const payload = JSON.parse(await file.text());
  const restored = normalizeVault(await decryptPortableExport(payload, $('importSecret').value.trim()));
  if (!confirm(`Replace the current vault with ${restored.items.length} restored items?`)) return;
  vault = restored;
  await saveUnlockedVault(vault);
  render();
  toast('Encrypted backup restored.');
}

async function importVault() {
  try {
    if (!featureAllowed(licenseState, 'import')) throw new Error('A valid license or trial is required to restore.');
    await ensureSensitiveAccess(
      'Re-enter your master password before replacing the current encrypted vault with a backup.',
      importVaultNow
    );
  } catch (error) { toast(error.message, true); }
}

async function changeMaster() {
  try {
    const current = String($('currentMaster')?.value || '');
    const password = String($('newMaster')?.value || '');
    const confirmPassword = String($('newMasterConfirm')?.value || '');
    const secondFactor = String($('masterTotp')?.value || '');
    const phrase = String($('masterConfirmPhrase')?.value || '').trim();
    const strength = assessPassword(password);
    if (!current) throw new Error('Enter the current master password.');
    if (password.length < 16 || strength.score < 3) throw new Error('Use a new master password of at least 16 characters with Strong or Very strong strength.');
    if (password !== confirmPassword) throw new Error('New master passwords do not match.');
    if (current === password) throw new Error('Choose a new master password that is different from the current one.');
    if (phrase !== 'CHANGE MASTER PASSWORD') throw new Error('Type CHANGE MASTER PASSWORD exactly to confirm this security change.');
    if (settingsState?.vaultTotpEnabled && !secondFactor) throw new Error('Enter the current authenticator or recovery code.');
    if (!confirm('Change the VaultCove master password now? The vault will immediately lock and require the new password.')) return;
    await rotateMasterPasswordVerified(current, password, secondFactor);
    await clearSensitiveAccess();
    for (const id of ['currentMaster','newMaster','newMasterConfirm','masterTotp','masterConfirmPhrase']) if ($(id)) $(id).value = '';
    vault = null;
    showGate('unlockPanel');
    els.unlockTotpLabel.classList.toggle('hidden', !settingsState?.vaultTotpEnabled);
    toast('Master password changed safely. VaultCove is locked; unlock again with the new password.');
  } catch (error) { toast(error.message, true); }
}

function fieldsForType(type, item = {}) {
  const attr = (value) => String(value ?? '').replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;');
  const field = (id, label, typeAttr = 'text', value = '') => `<label>${label}<input id="${id}" type="${typeAttr}" value="${attr(value)}"></label>`;
  const protectedField = (id, label, typeAttr = 'password', value = '', { allowReveal = true } = {}) => `<label class="protectedField">${label}<div class="protectedInput"><input id="${id}" type="${typeAttr}" value="${attr(value)}">${allowReveal && typeAttr === 'password' ? `<button type="button" class="fieldAction" data-reveal-field="${id}">Reveal</button>` : ''}<button type="button" class="fieldAction" data-copy-field="${id}">Copy</button></div></label>`;
  if (type === 'login') return `<div class="fieldGrid">${protectedField('fUsername','Username / email','text',item.username,{allowReveal:false})}${protectedField('fPassword','Password','password',item.password)}</div>${field('fUrl','Website URL','url',(item.urls||[])[0]||'')}<label>Additional trusted hosts (optional)<input id="fTrustedHosts" value="${attr((item.trustedHosts||[]).join(', '))}" placeholder="login.example.com, account.example.com"></label><p class="fieldHint">Only explicitly listed hosts plus the safe www/non-www alias may use this credential. Other subdomains never inherit access automatically.</p><div class="fieldGrid">${protectedField('fTotp','TOTP secret (Base32)','password',item.totpSecret)}<label>Password generator<button id="generatePasswordBtn" type="button" class="outline">Generate 20-character password</button></label></div><label class="check autoLoginCheck"><input id="fReauthFill" type="checkbox" ${item.requireReauthBeforeFill ? 'checked' : ''}> Require master password before filling this credential</label><label class="check autoLoginCheck"><input id="fAutoLogin" type="checkbox" ${item.autoLogin ? 'checked' : ''} ${item.requireReauthBeforeFill ? 'disabled' : ''}> Auto-login when this item is opted in and the current HTTPS site has persistent VaultCove access</label><p class="fieldHint">Protected credentials cannot auto-login. Use this for banking and other high-risk accounts. Imported logins start with Auto-login off.</p>`;
  if (type === 'card') return `<div class="fieldGrid">${field('fCardholder','Cardholder','text',item.cardholder)}${field('fBrand','Brand','text',item.brand)}${protectedField('fNumber','Card number','password',item.number)}${protectedField('fSecurityCode','Security code','password',item.securityCode)}${field('fExpMonth','Expiry month','text',item.expMonth)}${field('fExpYear','Expiry year','text',item.expYear)}</div><label>Billing address<textarea id="fBillingAddress" rows="3">${escapeHtml(item.billingAddress)}</textarea></label>`;
  if (type === 'bank') return `<div class="fieldGrid">${field('fBankName','Bank name','text',item.bankName)}${field('fAccountHolder','Account holder','text',item.accountHolder)}${field('fAccountType','Account type','text',item.accountType)}${protectedField('fAccountNumber','Account number','password',item.accountNumber)}${protectedField('fRouting','Routing number','password',item.routingNumber)}${field('fSwift','SWIFT / BIC','text',item.swiftBic)}${protectedField('fIban','IBAN','password',item.iban)}${field('fBranch','Branch','text',item.branch)}${protectedField('fPin','PIN (optional)','password',item.pin)}</div>`;
  if (type === 'identity') return `<div class="fieldGrid">${field('fFirstName','First name','text',item.firstName)}${field('fMiddleName','Middle name','text',item.middleName)}${field('fLastName','Last name','text',item.lastName)}${field('fCompany','Company','text',item.company)}${protectedField('fEmail','Email','email',item.email,{allowReveal:false})}${protectedField('fPhone','Phone','tel',item.phone,{allowReveal:false})}${field('fAddress1','Address line 1','text',item.address1)}${field('fAddress2','Address line 2','text',item.address2)}${field('fCity','City','text',item.city)}${field('fState','State / Province','text',item.state)}${field('fPostal','Postal code','text',item.postalCode)}${field('fCountry','Country','text',item.country)}${protectedField('fGovernmentId','Government ID (optional)','password',item.governmentId)}</div>`;
  return `<label>Secure text<textarea id="fText" rows="10">${escapeHtml(item.text)}</textarea></label>`;
}

function openItemDialogNow(item = null, type = 'login', prefill = {}) {
  const source = item || createItem(type, prefill);
  els.itemId.value = item?.id || '';
  els.itemType.value = source.type;
  els.itemType.disabled = Boolean(item);
  els.itemName.value = source.name || '';
  els.itemNotes.value = source.notes || '';
  els.itemTags.value = (source.tags || []).join(', ');
  els.itemFavorite.checked = Boolean(source.favorite);
  els.dialogTitle.textContent = item ? `Edit ${source.name}` : 'New encrypted item';
  els.deleteItem.classList.toggle('hidden', !item);
  els.dynamicFields.innerHTML = fieldsForType(source.type, source);
  wireDynamicFields(source.type);
  els.itemDialog.showModal();
}

function openItemDialog(item = null, type = 'login', prefill = {}) {
  if (!featureAllowed(licenseState, 'edit')) { toast('A valid license or trial is required.', true); return; }
  if (!item) return openItemDialogNow(null, type, prefill);
  return ensureSensitiveAccess('Re-enter your master password before viewing or editing decrypted vault fields.', () => openItemDialogNow(item, type, prefill)).catch((error) => toast(error.message, true));
}

function wireDynamicFields(type) {
  if (type === 'login') $('generatePasswordBtn')?.addEventListener('click', () => {
    $('fPassword').value = generatePassword({ length: 20 });
    $('fPassword').type = 'text';
    setTimeout(() => { if ($('fPassword')) $('fPassword').type = 'password'; }, 10000);
  });

  if (type === 'login') $('fReauthFill')?.addEventListener('change', () => { const auto=$('fAutoLogin'); if (!auto) return; auto.disabled=$('fReauthFill').checked; if (auto.disabled) auto.checked=false; });

  document.querySelectorAll('[data-reveal-field]').forEach((button) => button.addEventListener('click', () => {
    const action = () => {
      const input = $(button.dataset.revealField);
      if (!input) return;
      const showing = input.type === 'text';
      input.type = showing ? 'password' : 'text';
      button.textContent = showing ? 'Reveal' : 'Hide';
      if (!showing) setTimeout(() => { if (input?.isConnected) { input.type = 'password'; button.textContent = 'Reveal'; } }, Math.max(5, Number(settingsState?.revealTimeoutSeconds) || 10) * 1000);
    };
    if (els.itemId.value) ensureSensitiveAccess('Re-enter your master password before revealing this secret.', action).catch((error) => toast(error.message, true)); else action();
  }));

  document.querySelectorAll('[data-copy-field]').forEach((button) => button.addEventListener('click', () => {
    const action = async () => {
      const input = $(button.dataset.copyField);
      if (!input) return;
      await navigator.clipboard.writeText(input.value || '');
      toast('Sensitive value copied. Other local apps may read your clipboard; clear it when finished.');
    };
    if (els.itemId.value) ensureSensitiveAccess('Re-enter your master password before copying this secret.', action).catch((error) => toast(error.message, true)); else action().catch((error) => toast(error.message, true));
  }));
}

function readDialogItem(existing) {
  const type = els.itemType.value;
  const item = existing ? { ...existing } : createItem(type);
  item.name = els.itemName.value.trim() || item.name;
  item.notes = els.itemNotes.value;
  item.tags = els.itemTags.value.split(',').map((v) => v.trim()).filter(Boolean).slice(0, 20);
  item.favorite = els.itemFavorite.checked;
  if (type === 'login') {
    const newPassword = $('fPassword').value;
    if (existing?.password && newPassword !== existing.password) item.passwordHistory = [...(existing.passwordHistory || []), { password: existing.password, changedAt: new Date().toISOString() }].slice(-10);
    item.username = $('fUsername').value; item.password = newPassword; item.urls = [$('fUrl').value.trim()].filter(Boolean); item.trustedHosts = ($('fTrustedHosts')?.value || '').split(',').map((value)=>value.trim()).filter(Boolean).slice(0,20); item.totpSecret = $('fTotp').value.trim(); item.requireReauthBeforeFill = Boolean($('fReauthFill')?.checked); item.autoLogin = item.requireReauthBeforeFill ? false : Boolean($('fAutoLogin')?.checked);
    if (existing?.pendingPasswordChange?.password === newPassword) item.pendingPasswordChange = null;
  }
  if (type === 'card') Object.assign(item, { cardholder: $('fCardholder').value, brand: $('fBrand').value, number: $('fNumber').value, securityCode: $('fSecurityCode').value, expMonth: $('fExpMonth').value, expYear: $('fExpYear').value, billingAddress: $('fBillingAddress').value });
  if (type === 'bank') Object.assign(item, { bankName: $('fBankName').value, accountHolder: $('fAccountHolder').value, accountType: $('fAccountType').value, accountNumber: $('fAccountNumber').value, routingNumber: $('fRouting').value, swiftBic: $('fSwift').value, iban: $('fIban').value, branch: $('fBranch').value, pin: $('fPin').value });
  if (type === 'identity') Object.assign(item, { firstName: $('fFirstName').value, middleName: $('fMiddleName').value, lastName: $('fLastName').value, company: $('fCompany').value, email: $('fEmail').value, phone: $('fPhone').value, address1: $('fAddress1').value, address2: $('fAddress2').value, city: $('fCity').value, state: $('fState').value, postalCode: $('fPostal').value, country: $('fCountry').value, governmentId: $('fGovernmentId').value });
  if (type === 'note') item.text = $('fText').value;
  return item;
}

async function performSaveDialog() {
  const existing = vault.items.find((item) => item.id === els.itemId.value) || null;
  const item = readDialogItem(existing);
  upsertItem(vault, item);
  await saveUnlockedVault(vault);
  els.itemDialog.close();
  render();
  toast('Encrypted item saved.');
}

async function saveDialog(event) {
  event.preventDefault();
  try {
    const existing = vault.items.find((item) => item.id === els.itemId.value) || null;
    if (existing) {
      await ensureSensitiveAccess('Re-enter your master password before saving changes to decrypted sensitive fields.', performSaveDialog);
      return;
    }
    await performSaveDialog();
  } catch (error) { toast(error.message, true); }
}

async function refreshTotpCodes() {
  const logins = visibleItems().filter((item) => item.type === 'login' && item.totpSecret);
  if (!logins.length) return;

  if (!(await hasSensitiveAccess())) {
    document.querySelectorAll('[data-totp-id]').forEach((node) => { node.textContent = '••• ••• · verify master password'; });
    return;
  }

  async function tick() {
    if (!(await hasSensitiveAccess())) {
      clearInterval(totpTimer);
      document.querySelectorAll('[data-totp-id]').forEach((node) => { node.textContent = '••• ••• · Sensitive Access expired'; });
      return;
    }
    for (const item of logins) {
      try {
        const result = await generateTotp(item.totpSecret);
        const direct = document.querySelector(`[data-totp-id="${CSS.escape(item.id)}"]`);
        if (direct) {
          direct.textContent = `${result.code.slice(0, 3)} ${result.code.slice(3)} · ${result.remaining}s`;
          continue;
        }
        const nodes = [...document.querySelectorAll('.vaultItem')];
        const node = nodes.find((candidate) => candidate.querySelector('.name')?.textContent.includes(item.name));
        if (!node) continue;
        let chip = node.querySelector('.totpChip');
        if (!chip) {
          chip = document.createElement('div');
          chip.className = 'chip totpChip';
          node.querySelector('.chips')?.append(chip) || (node.append(Object.assign(document.createElement('div'), { className: 'chips' })), node.querySelector('.chips').append(chip));
        }
        chip.textContent = `TOTP ${result.code} · ${result.remaining}s`;
      } catch {}
    }
  }
  await tick();
  totpTimer = setInterval(tick, 1000);
}

function switchView(view) {
  currentView = view; els.search.value = ''; render(); if (view === 'dashboard') wireSummaryCards();
}

async function lockFromUi() {
  await lockVault(); clearDecryptedUi(); showGate('unlockPanel'); toast('Vault locked.');
}

async function bootstrap() {
  const params = new URLSearchParams(location.search);
  const requestedView = params.get('view');
  if (requestedView && Object.hasOwn(viewNames, requestedView)) currentView = requestedView;

  [licenseState, settingsState] = await Promise.all([
    getLicenseState(),
    getSettings()
  ]);
  await refreshHandlerPermissions();
  if (els.unlockTotpLabel) els.unlockTotpLabel.classList.toggle('hidden', !settingsState?.vaultTotpEnabled);
  if (els.sensitiveTotpLabel) els.sensitiveTotpLabel.classList.toggle('hidden', !settingsState?.vaultTotpEnabled);
  els.licenseBadge.textContent = licenseState.mode === 'testing' ? 'Testing · Full access' : licenseState.status;

  const state = await loadUnlockedVault();
  if (state.state === 'setup') return showGate('setupPanel');
  if (state.state === 'locked') return showGate('unlockPanel');
  vault = state.vault;
  showApp();

  if (licenseState.status === 'expired') {
    currentView = 'backup';
    document.querySelectorAll('nav button[data-view]').forEach((button) => { button.classList.toggle('hidden', !['backup', 'settings'].includes(button.dataset.view)); });
  }

  render();
  if (currentView === 'dashboard') wireSummaryCards();
  if (licenseState.status !== 'expired') applyUrlAction();
}

function applyUrlAction() {
  const params=new URLSearchParams(location.search); if(params.get('action')==='new-login'){const url=params.get('url')||'';let name='New Login';try{name=new URL(url).hostname.replace(/^www\./,'');}catch{}openItemDialog(null,'login',{name,urls:url?[url]:[]});history.replaceState({},'',location.pathname);}
}

document.querySelectorAll('nav button[data-view]').forEach(button=>button.addEventListener('click',()=>switchView(button.dataset.view)));
els.search.addEventListener('input',()=>{if(currentView==='dashboard'&&els.search.value.trim())currentView='all';render();});
els.newItem.addEventListener('click',()=>openItemDialog(null,['login','card','bank','identity','note'].includes(currentView)?currentView:'login'));
els.itemType.addEventListener('change',()=>{els.dynamicFields.innerHTML=fieldsForType(els.itemType.value,{});wireDynamicFields(els.itemType.value);});
els.itemForm.addEventListener('submit',saveDialog);
els.cancelItem.addEventListener('click',()=>els.itemDialog.close());
els.dialogClose.addEventListener('click',()=>els.itemDialog.close());
els.deleteItem.addEventListener('click', async () => {
  const id = els.itemId.value;
  if (!id) return;
  try {
    await ensureSensitiveAccess('Re-enter your master password before moving this sensitive item to Trash.', async () => {
      if (!confirm('Move this item to Trash?')) return;
      softDeleteItem(vault, id);
      await saveUnlockedVault(vault);
      els.itemDialog.close();
      render();
      toast('Item moved to Trash.');
    });
  } catch (error) { toast(error.message, true); }
});
els.setupSubmit.addEventListener('click',async()=>{try{const p=els.setupPassword.value;if(p.length<14)throw new Error('Use at least 14 characters for the master password.');if(p!==els.setupConfirm.value)throw new Error('Master passwords do not match.');vault=await initializeVault(p);els.setupPassword.value='';els.setupConfirm.value='';currentView='dashboard';showApp();render();wireSummaryCards();}catch(e){toast(e.message,true);}});
els.unlockSubmit.addEventListener('click',async()=>{
  if (unlockBusy) return;
  const password = els.unlockPassword.value;
  unlockBusy = true;
  els.unlockSubmit.disabled = true;
  els.unlockSubmit.classList.add('busy');
  els.unlockPassword.disabled = true;
  if (els.unlockError) { els.unlockError.textContent = ''; els.unlockError.classList.add('hidden'); }
  try {
    vault = await unlockVault(password, String(els.unlockTotp?.value || ''));
    els.unlockPassword.value = '';
    if (els.unlockTotp) els.unlockTotp.value = '';
    currentView = licenseState?.status === 'expired' ? 'backup' : 'dashboard';
    showApp(); render(); if (currentView === 'dashboard') wireSummaryCards(); applyUrlAction();
  } catch (e) {
    els.unlockPassword.value = '';
    if (els.unlockTotp) els.unlockTotp.value = '';
    if (els.unlockError) { els.unlockError.textContent = e.message; els.unlockError.classList.remove('hidden'); }
    toast(e.message, true);
  } finally {
    unlockBusy = false;
    els.unlockSubmit.disabled = false;
    els.unlockSubmit.classList.remove('busy');
    els.unlockPassword.disabled = false;
    if (!vault) setTimeout(() => els.unlockPassword.focus(), 0);
  }
});
els.unlockPassword.addEventListener('input',()=>{if(els.unlockError){els.unlockError.textContent='';els.unlockError.classList.add('hidden');}});
els.unlockPassword.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();els.unlockSubmit.click();}});
els.unlockTotp?.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();els.unlockSubmit.click();}});
els.lockButton.addEventListener('click',lockFromUi);
els.copyExportSecret.addEventListener('click',async()=>{await navigator.clipboard.writeText(els.exportSecret.textContent);toast('Export secret copied. Store it separately from the export file.');});
els.closeSecret.addEventListener('click',()=>els.secretDialog.close());
els.cancelSensitive.addEventListener('click', closeSensitiveDialog);
els.confirmSensitive.addEventListener('click', async () => {
  if (sensitiveVerifyBusy) return;
  const action = pendingSensitiveAction;
  const password = els.sensitivePassword.value;
  if (!action) return closeSensitiveDialog();
  sensitiveVerifyBusy = true;
  els.confirmSensitive.disabled = true;
  els.confirmSensitive.classList.add('busy');
  els.sensitivePassword.disabled = true;
  if (els.sensitiveError) { els.sensitiveError.textContent = ''; els.sensitiveError.classList.add('hidden'); }
  try {
    await runtimeMessage({ type: 'VERIFY_SENSITIVE_ACCESS', masterPassword: password, secondFactor: String(els.sensitiveTotp?.value || '') });
    pendingSensitiveAction = null;
    els.sensitivePassword.value = '';
    if (els.sensitiveTotp) els.sensitiveTotp.value = '';
    if (els.sensitiveDialog.open) els.sensitiveDialog.close();
    await action();
    if (currentView === 'totp') refreshTotpCodes().catch(() => {});
  } catch (error) {
    els.sensitivePassword.value = '';
    if (els.sensitiveTotp) els.sensitiveTotp.value = '';
    if (els.sensitiveError) { els.sensitiveError.textContent = error.message; els.sensitiveError.classList.remove('hidden'); }
    toast(error.message, true);
  } finally {
    sensitiveVerifyBusy = false;
    els.confirmSensitive.disabled = false;
    els.confirmSensitive.classList.remove('busy');
    els.sensitivePassword.disabled = false;
    if (els.sensitiveDialog.open) setTimeout(() => els.sensitivePassword.focus(), 0);
  }
});
els.sensitivePassword.addEventListener('keydown', (event) => {
  if (event.key === 'Enter') {
    event.preventDefault();
    els.confirmSensitive.click();
  }
});
els.sensitiveTotp?.addEventListener('keydown', (event) => { if (event.key === 'Enter') { event.preventDefault(); els.confirmSensitive.click(); } });

els.closeTotpSetup?.addEventListener('click', () => { pendingTotpSetup = null; if (els.totpSetupDialog.open) els.totpSetupDialog.close(); });
els.copyTotpSecret?.addEventListener('click', async () => { await navigator.clipboard.writeText($('totpSetupSecret').value); toast('Authenticator setup key copied.'); });
els.copyTotpUri?.addEventListener('click', async () => { await navigator.clipboard.writeText($('totpSetupUri').value); toast('Authenticator URI copied. It contains the TOTP setup secret; keep it private.'); });
els.confirmTotpSetup?.addEventListener('click', async () => {
  try {
    if (!pendingTotpSetup) throw new Error('Start authenticator setup again.');
    const code = String($('totpSetupCode').value || '').trim();
    if (!(await verifyTotp(pendingTotpSetup.secret, code))) throw new Error('The authenticator code is incorrect. Check the device time and try again.');
    const recoveryCodeHashes = await hashRecoveryCodes(pendingTotpSetup.recoveryCodes);
    vault.security = vault.security || {};
    vault.security.vaultTotp = { enabled:true, secret:pendingTotpSetup.secret, recoveryCodeHashes, enabledAt:new Date().toISOString() };
    await saveUnlockedVault(vault);
    await setSettings({ vaultTotpEnabled:true });
    settingsState = await getSettings();
    await clearSensitiveAccess();
    $('totpRecoveryCodes').textContent = pendingTotpSetup.recoveryCodes.join('\n');
    $('totpRecoveryPanel').classList.remove('hidden');
    $('confirmTotpSetup').disabled = true;
    $('totpSetupCode').disabled = true;
    toast('VaultCove authenticator confirmation enabled. Save the recovery codes now.');
  } catch (error) { toast(error.message, true); }
});
els.copyRecoveryCodes?.addEventListener('click', async () => { if (!pendingTotpSetup?.recoveryCodes) return; await navigator.clipboard.writeText(pendingTotpSetup.recoveryCodes.join('\n')); toast('Recovery codes copied. Store them somewhere safe outside VaultCove.'); });

installTooltips(document);
tooltipObserver = new MutationObserver(() => installTooltips(document));
tooltipObserver.observe(document.body, { childList:true, subtree:true });

document.addEventListener('keydown',(event)=>{if((event.ctrlKey||event.metaKey)&&event.key.toLowerCase()==='k'&&vault){event.preventDefault();els.search.classList.remove('hidden');els.search.focus();}});
document.addEventListener('pointerdown', markVaultActivity, { passive: true }); document.addEventListener('keydown', markVaultActivity);
setInterval(() => enforceUiAutoLock().catch(() => {}), 5000);
setInterval(() => enforceSensitiveUiExpiry().catch(() => {}), 2000);
bootstrap().catch(e=>toast(e.message,true));
