# VaultCove Security Model — 0.6.0 R1

## At rest

The local vault is encrypted using a random 256-bit vault key. The master password derives a wrapping key using PBKDF2-HMAC-SHA-256 and wraps that random vault key. AES-256-GCM provides confidentiality and integrity. Usernames, passwords, URLs, notes, TOTP secrets, sharing private keys, pending login/password-change candidates, and visited-site visual metadata stay inside the encrypted payload.

## Sensitive Access

Normal unlock and secret disclosure are separate. Reveal, Copy, Edit, export/restore, master-password changes and protected filling can require fresh master-password verification. Sensitive Access expires quickly. When the VaultCove authenticator guard is enabled, Sensitive Access also requires a current TOTP or unused recovery code.

## Master-password changes

VaultCove verifies the current master password against the already-unlocked random vault key, requires a strong different replacement in the UI, and requires the authenticator/recovery code when enabled. The random vault key is re-wrapped rather than every credential being decrypted/re-encrypted independently. Before replacing the persisted envelope, VaultCove proves that the new master password can unwrap exactly the same vault key. A successful change immediately clears the unlocked session.

## Browser filling and Always-On Handler

User-invoked filling can use temporary `activeTab`. Always-On Handler is a separate optional feature: only after an explicit user gesture grants optional `https://*/*` access does VaultCove dynamically register a persistent HTTPS content script. Broad access is not a mandatory manifest host permission.

The content handler receives only masked credential summaries. A password is released only after the service worker validates the real sender frame and trusted HTTPS destination for a specific Fill/Secure Login operation.

Host matching accepts exact hosts, a safe `www.`/non-`www.` alias, and narrowly reviewed first-party host families such as the explicit Google account family. It never uses arbitrary suffix or `*.google.com` credential trust.

Secure Login does not use the clipboard. It injects only the selected credential, submits promptly, and clears the page password value after a short guarded fallback when safe. Once a legitimate destination page receives a password, that page's JavaScript can potentially read it; no traditional browser password manager can guarantee otherwise.

## Inline password generator and login/change capture

The handler can recognize explicit `autocomplete="new-password"` fields and high-confidence signup/change-password patterns. Generated values use `crypto.getRandomValues()` locally. New-account candidates and password-change candidates are stored only inside the encrypted vault and are never permanently applied without user review.

## Local authenticator confirmation

VaultCove supports standard TOTP enrollment compatible with Google Authenticator and other authenticator apps. The authenticator app does **not** connect to the VaultCove vault and does not receive or store website passwords. Recovery codes are generated locally and only their hashes remain in the encrypted vault after enrollment.

Because TOTP verification is performed locally, this feature is an additional application access-confirmation gate, not a separate cloud-held encryption key. A fully compromised local machine/browser profile plus the correct master password is outside this guarantee. Future independently controlled second-factor options should use a remote privacy-minimal verifier or hardware/public-key authentication rather than overclaiming local TOTP.

## Website thumbnails

VaultCove does not query a remote logo/favicon service. If the user explicitly enables Chrome's optional `favicon` permission, VaultCove can render icons from Chrome's local favicon cache. An icon is used only when encrypted `siteVisual` metadata says that matching saved site was actually visited while VaultCove was active. Otherwise a local lock-card fallback is rendered. VaultCove does not keep a general browsing-history database.

## VCShare v2

VCShare v2 can bundle up to 50 selected login records. It uses P-256 ECDH + HKDF-SHA-256 to derive an AES-256-GCM encryption key for the intended recipient and ECDSA P-256 to sign the package. Recipient private keys stay inside the encrypted local vault. Version 1 packages remain importable. Revocation cannot make an already-decrypted password unknown; change the website password for true revocation.

## Developer updates

The Developer build contacts only the official public VaultCove release metadata endpoint and digitally verifies signed metadata before trusting it. The Chrome Web Store build removes the GitHub developer-update host permission and update fetch implementation. Remote executable code is not used.

## Not protected against

VaultCove cannot guarantee secrecy if malware controls the operating system, Chrome process memory/DevTools, screen/accessibility capture, the keyboard, the master password, or the legitimate destination page after a password has intentionally been filled. Endpoint security, rapid auto-lock, phishing-safe matching, and passkeys remain important.
