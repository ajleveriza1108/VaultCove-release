import {
  changeMasterPassword,
  createVaultEnvelope,
  decryptJson,
  reencryptVault,
  unlockVaultEnvelope,
  verifyMasterPasswordForVaultKey
} from './crypto.js';
import { VAULT_AAD } from './constants.js';
import { createEmptyVault, normalizeVault } from './model.js';
import { verifyRecoveryCode, verifyTotp } from './totp.js';
import {
  clearSensitiveAccess,
  clearSession,
  getSessionKey,
  getVaultEnvelope,
  grantSensitiveAccess,
  saveSessionKey,
  setVaultEnvelope,
  touchSession
} from './storage.js';

async function verifySecondFactor(vault, code, { consumeRecovery = false } = {}) {
  const protection = vault?.security?.vaultTotp;
  if (!protection?.enabled) return { ok: true, recoveryIndex: -1 };
  const candidate = String(code || '').trim();
  if (await verifyTotp(protection.secret, candidate)) return { ok: true, recoveryIndex: -1 };
  const recovery = await verifyRecoveryCode(candidate, protection.recoveryCodeHashes || []);
  if (!recovery.valid) throw new Error('Incorrect authenticator or recovery code.');
  if (consumeRecovery) protection.recoveryCodeHashes.splice(recovery.index, 1);
  return { ok: true, recoveryIndex: recovery.index };
}

export async function initializeVault(masterPassword) {
  if ((await getVaultEnvelope())) throw new Error('A vault already exists.');
  const vaultData = createEmptyVault();
  const { envelope, rawVaultKey } = await createVaultEnvelope(masterPassword, vaultData);
  await setVaultEnvelope(envelope);
  await saveSessionKey(rawVaultKey);
  return vaultData;
}

export async function unlockVault(masterPassword, secondFactor = '') {
  const envelope = await getVaultEnvelope();
  if (!envelope) throw new Error('No vault exists yet.');
  const { rawVaultKey, vaultKey, vaultData } = await unlockVaultEnvelope(masterPassword, envelope);
  const vault = normalizeVault(vaultData);
  const result = await verifySecondFactor(vault, secondFactor, { consumeRecovery: true });
  if (result.recoveryIndex >= 0) {
    const updated = await reencryptVault(envelope, vaultKey, vault);
    await setVaultEnvelope(updated);
  }
  await saveSessionKey(rawVaultKey);
  return vault;
}

export async function loadUnlockedVault({ touch = true } = {}) {
  const envelope = await getVaultEnvelope();
  if (!envelope) return { state: 'setup', vault: null };
  const session = await getSessionKey();
  if (!session) return { state: 'locked', vault: null };
  try {
    const vault = normalizeVault(await decryptJson(session.vaultKey, envelope.vault, VAULT_AAD));
    if (touch) await touchSession();
    return { state: 'unlocked', vault, vaultKey: session.vaultKey, rawVaultKey: session.rawVaultKey };
  } catch {
    await clearSession();
    return { state: 'locked', vault: null };
  }
}

export async function saveUnlockedVault(vault, { touch = true } = {}) {
  const envelope = await getVaultEnvelope();
  const session = await getSessionKey();
  if (!envelope || !session) throw new Error('Vault is locked.');
  vault.updatedAt = new Date().toISOString();
  const updated = await reencryptVault(envelope, session.vaultKey, normalizeVault(vault));
  await setVaultEnvelope(updated);
  if (touch) await touchSession();
}

export async function verifySensitiveAccess(masterPassword, seconds = null, secondFactor = '') {
  const envelope = await getVaultEnvelope();
  const session = await getSessionKey();
  if (!envelope || !session) throw new Error('Vault is locked.');
  try {
    const valid = await verifyMasterPasswordForVaultKey(masterPassword, envelope, session.rawVaultKey);
    if (!valid) throw new Error('Incorrect master password.');
    const state = await loadUnlockedVault({ touch: false });
    if (state.state !== 'unlocked') throw new Error('Vault is locked.');
    await verifySecondFactor(state.vault, secondFactor);
  } catch (error) {
    await clearSensitiveAccess();
    if (error?.message === 'Incorrect master password.' || error?.message === 'Incorrect authenticator or recovery code.') throw error;
    throw new Error('Master-password verification failed. Lock and unlock VaultCove again if this continues.');
  }
  const until = await grantSensitiveAccess(seconds);
  await touchSession();
  return until;
}

export async function rotateMasterPasswordVerified(currentMasterPassword, newMasterPassword, secondFactor = '') {
  const current = String(currentMasterPassword || '');
  const replacement = String(newMasterPassword || '');
  if (!current || !replacement) throw new Error('Current and new master passwords are required.');
  if (current === replacement) throw new Error('The new master password must be different from the current master password.');
  const envelope = await getVaultEnvelope();
  const session = await getSessionKey();
  if (!envelope || !session) throw new Error('Vault is locked.');
  const valid = await verifyMasterPasswordForVaultKey(current, envelope, session.rawVaultKey);
  if (!valid) throw new Error('Current master password is incorrect.');
  const state = await loadUnlockedVault({ touch: false });
  if (state.state !== 'unlocked') throw new Error('Vault is locked.');
  await verifySecondFactor(state.vault, secondFactor);

  // Re-wrap the same random vault key, then prove the new wrap can be opened
  // before replacing the only persisted envelope. This keeps rotation atomic.
  const updated = await changeMasterPassword(envelope, session.rawVaultKey, replacement);
  const verified = await verifyMasterPasswordForVaultKey(replacement, updated, session.rawVaultKey);
  if (!verified) throw new Error('The new master-password wrap could not be verified. The existing vault was left unchanged.');
  await setVaultEnvelope(updated);
  await clearSession();
  return true;
}

export async function rotateMasterPassword(newMasterPassword) {
  const envelope = await getVaultEnvelope();
  const session = await getSessionKey();
  if (!envelope || !session) throw new Error('Vault is locked.');
  const updated = await changeMasterPassword(envelope, session.rawVaultKey, newMasterPassword);
  await setVaultEnvelope(updated);
  await clearSession();
}

export async function lockVault() { await clearSession(); }
