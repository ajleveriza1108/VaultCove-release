# VaultCove 0.6.0 R1 — Always-On Handler + Visual Vault + Authenticator Guard + Multi-Share

VaultCove is an offline-first Manifest V3 password and private-record vault. The canonical Windows development root is:

`D:\Windows Projects\VaultCove`

## 0.6.0 R1 highlights

- **Always-On Handler:** after one explicit optional HTTPS permission grant, VaultCove dynamically registers its login handler across HTTPS pages so login-field icons can appear automatically without first clicking the toolbar icon. The `activeTab` on-demand path remains available when broad access is not granted.
- **Inline password generator:** signup/new-password/change-password forms can display a local Generate & Fill action directly in the field handler. Generated values use the browser cryptographic RNG and are never sent to a remote service.
- **New-login + password-change intelligence:** submitted new accounts and possible password changes remain separate encrypted review flows. VaultCove asks before permanently saving or replacing a credential.
- **Visual Grid Vault:** Logins and other normal vault views support Grid/List modes. Saved website cards use Chrome's local favicon cache only when the user enables the optional `favicon` permission and VaultCove has locally recorded that matching saved site as visited; otherwise a private lock-card fallback is shown.
- **Global explanatory tooltips:** dashboard navigation, major buttons, toggles and selectors expose concise hover/focus explanations and keyboard-accessible labels.
- **Verified master-password rotation:** changing the master password requires the current password, a strong different replacement, exact `CHANGE MASTER PASSWORD` confirmation, and the VaultCove authenticator/recovery code when enabled. VaultCove verifies the new key-wrap before replacing the persisted envelope, then immediately locks the vault.
- **Google Authenticator-compatible local confirmation:** VaultCove can enroll a standard TOTP secret with Google Authenticator, Microsoft Authenticator, Aegis or another TOTP app and provides one-time recovery codes. Google never receives, stores, syncs, or reads VaultCove passwords.
- **VCShare v2 bundles:** one signed recipient-encrypted `.vcshare` can contain up to 50 selected login accounts. The Shared page uses the same visual visited-site cards for selection.
- **Google/Gmail multi-account matching:** explicitly reviewed Google account hosts continue to surface multiple imported Google credentials without trusting arbitrary `*.google.com` subdomains.
- **Reliable authentication retries:** failed master-password attempts remain stateless and cannot poison a later correct retry.

## Important authenticator boundary

The optional TOTP feature is a **local access-confirmation gate**. Because VaultCove verifies TOTP locally, it is not a separate cloud-held encryption key. It helps protect an unattended/unlocked application and sensitive actions, but it does not claim to defeat an attacker who fully controls the same device/browser profile and already knows the master password. For a truly independent future second factor, VaultCove would need a separately controlled verifier such as a remote privacy-minimal service or hardware/public-key authenticator.

## Security boundaries

Passwords are encrypted at rest. A destination website must temporarily receive a password when the user chooses to fill it; HTML `type="password"` is only visual masking. Secure Login validates the HTTPS destination, decrypts only the selected credential, injects at the last practical moment, submits promptly, and clears the password field after a guarded fallback when safe.

Always-On Handler access is optional and user-granted. No vault data, saved-site list, usernames, passwords, TOTP secrets, financial records, notes, vault keys, master passwords, or security-health data is sent to the developer update endpoint.

## Developer testing

Run:

`node tests\core-tests.mjs`

`node tests\static-security-checks.mjs`

Then reload the unpacked extension from `chrome://extensions` using exactly:

`D:\Windows Projects\VaultCove`

Test with dummy accounts before storing real financial credentials.
