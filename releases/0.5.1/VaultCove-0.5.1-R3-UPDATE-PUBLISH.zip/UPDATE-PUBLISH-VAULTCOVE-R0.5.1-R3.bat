@echo off
setlocal EnableExtensions
chcp 65001 >nul
cls
echo ==============================================================================
echo VaultCove 0.5.1 R3 - CLEAN REPAIR + NEW-LOGIN CAPTURE + RELIABLE GIT PUBLISH
echo ==============================================================================
echo Run normally - DO NOT Run as Administrator.
echo Canonical project: D:\Windows Projects\VaultCove
echo Package contract: exactly 1 BAT + 1 PS1.
echo.

set "PS1=%~dp0UPDATE-PUBLISH-VAULTCOVE-R0.5.1-R3.ps1"
if not exist "%PS1%" (
  echo [FAIL] Missing PowerShell file beside this BAT:
  echo        %PS1%
  echo.
  pause
  exit /b 2
)

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%PS1%" %*
set "RC=%ERRORLEVEL%"
echo.
if not "%RC%"=="0" (
  echo [FAIL] VaultCove pipeline returned exit code %RC%.
) else (
  echo [PASS] VaultCove 0.5.1 R3 pipeline completed.
)
echo.
pause
exit /b %RC%
