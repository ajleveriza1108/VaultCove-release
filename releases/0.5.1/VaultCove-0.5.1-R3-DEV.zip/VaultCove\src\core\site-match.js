function normalizeHostname(value) {
  const raw = String(value || '').trim().toLowerCase().replace(/\.$/, '');
  if (!raw) return '';
  try {
    const source = /^[a-z][a-z0-9+.-]*:/i.test(raw) ? raw : `https://${raw}`;
    const url = new URL(source);
    return url.hostname.toLowerCase().replace(/\.$/, '');
  } catch {
    return '';
  }
}

export function canonicalHostname(value) {
  const host = normalizeHostname(value);
  return host.startsWith('www.') ? host.slice(4) : host;
}

export function permissionOriginForHost(hostname) {
  const host = normalizeHostname(hostname);
  if (!host) throw new Error('A valid HTTPS hostname is required.');
  return `https://${host}/*`;
}

export function savedHostsForLogin(item) {
  if (!item || item.type !== 'login') return [];
  const values = [...(item.urls || []), ...(item.trustedHosts || [])];
  return [...new Set(values.map(normalizeHostname).filter(Boolean))];
}

export function loginMatchesTrustedHost(item, currentHostname) {
  if (!item || item.type !== 'login' || item.deletedAt) return false;
  const current = normalizeHostname(currentHostname);
  if (!current) return false;
  const currentCanonical = canonicalHostname(current);

  return savedHostsForLogin(item).some((saved) => {
    if (saved === current) return true;
    // Safe convenience alias only: www.example.com <-> example.com.
    // Other subdomains never match implicitly and must be explicitly trusted.
    return canonicalHostname(saved) === currentCanonical && (saved.startsWith('www.') || current.startsWith('www.'));
  });
}

export function siteMatchKind(item, currentHostname) {
  const current = normalizeHostname(currentHostname);
  if (!current) return 'none';
  const hosts = savedHostsForLogin(item);
  if (hosts.includes(current)) return 'exact';
  if (hosts.some((saved) => canonicalHostname(saved) === canonicalHostname(current) && (saved.startsWith('www.') || current.startsWith('www.')))) return 'www-alias';
  return 'none';
}

export function safeDisplayHost(value) {
  return normalizeHostname(value) || '';
}
