import {
  changeMasterPassword,
  createVaultEnvelope,
  decryptJson,
  reencryptVault,
  unlockVaultEnvelope,
  verifyMasterPasswordForVaultKey
} from './crypto.js';
import { VAULT_AAD } from './constants.js';
import { createEmptyVault, normalizeVault } from './model.js';
import {
  clearSession,
  getSessionKey,
  getVaultEnvelope,
  grantSensitiveAccess,
  saveSessionKey,
  setVaultEnvelope,
  touchSession
} from './storage.js';

export async function initializeVault(masterPassword) {
  if ((await getVaultEnvelope())) throw new Error('A vault already exists.');
  const vaultData = createEmptyVault();
  const { envelope, rawVaultKey } = await createVaultEnvelope(masterPassword, vaultData);
  await setVaultEnvelope(envelope);
  await saveSessionKey(rawVaultKey);
  return vaultData;
}

export async function unlockVault(masterPassword) {
  const envelope = await getVaultEnvelope();
  if (!envelope) throw new Error('No vault exists yet.');
  const { rawVaultKey, vaultData } = await unlockVaultEnvelope(masterPassword, envelope);
  await saveSessionKey(rawVaultKey);
  return normalizeVault(vaultData);
}

export async function loadUnlockedVault({ touch = true } = {}) {
  const envelope = await getVaultEnvelope();
  if (!envelope) return { state: 'setup', vault: null };
  const session = await getSessionKey();
  if (!session) return { state: 'locked', vault: null };
  try {
    const vault = normalizeVault(await decryptJson(session.vaultKey, envelope.vault, VAULT_AAD));
    if (touch) await touchSession();
    return { state: 'unlocked', vault, vaultKey: session.vaultKey, rawVaultKey: session.rawVaultKey };
  } catch {
    await clearSession();
    return { state: 'locked', vault: null };
  }
}

export async function saveUnlockedVault(vault, { touch = true } = {}) {
  const envelope = await getVaultEnvelope();
  const session = await getSessionKey();
  if (!envelope || !session) throw new Error('Vault is locked.');
  vault.updatedAt = new Date().toISOString();
  const updated = await reencryptVault(envelope, session.vaultKey, normalizeVault(vault));
  await setVaultEnvelope(updated);
  if (touch) await touchSession();
}

export async function verifySensitiveAccess(masterPassword, seconds = null) {
  const envelope = await getVaultEnvelope();
  const session = await getSessionKey();
  if (!envelope || !session) throw new Error('Vault is locked.');
  const valid = await verifyMasterPasswordForVaultKey(masterPassword, envelope, session.rawVaultKey);
  if (!valid) throw new Error('Incorrect master password.');
  const until = await grantSensitiveAccess(seconds);
  await touchSession();
  return until;
}

export async function rotateMasterPassword(newMasterPassword) {
  const envelope = await getVaultEnvelope();
  const session = await getSessionKey();
  if (!envelope || !session) throw new Error('Vault is locked.');
  const updated = await changeMasterPassword(envelope, session.rawVaultKey, newMasterPassword);
  await setVaultEnvelope(updated);
  await touchSession();
}

export async function lockVault() {
  await clearSession();
}
