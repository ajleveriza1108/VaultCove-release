import { TESTING_FULL_ACCESS } from './constants.js';
import { ensureDeviceId } from './storage.js';

export async function getLicenseState() {
  const deviceId = await ensureDeviceId();
  if (TESTING_FULL_ACCESS) {
    return {
      mode: 'testing',
      status: 'full',
      deviceId,
      trialEndsAt: null,
      licensedDevices: null,
      maxDevices: 7,
      message: 'Testing build: all features are enabled.'
    };
  }
  // Production hook. The future licensing client will validate a signed server response
  // using only license metadata + this random installation ID. Vault contents, domains,
  // usernames, passwords and financial data must never be transmitted for licensing.
  return {
    mode: 'production',
    status: 'unconfigured',
    deviceId,
    maxDevices: 7,
    message: 'Production licensing is not configured in this build.'
  };
}

export function featureAllowed(licenseState, feature) {
  if (licenseState.status === 'full') return true;
  if (licenseState.status === 'trial') return true;
  if (licenseState.status === 'expired') return feature === 'export' || feature === 'license';
  return false;
}
