# VaultCove Privacy — 0.5.1 R1

VaultCove is offline-first. Vault records are stored locally in encrypted form. There is no cloud vault, advertising, analytics, browsing-history profile, or telemetry in this build.

## Website access

User-invoked filling uses temporary `activeTab` access. Persistent field icons are optional and permission is requested for the current HTTPS website only. Users can remove all persistent website permissions from Settings.

## Developer update check

When enabled, the Developer Mode build performs at most one normal request per day to the official public `VaultCove-release` metadata file. VaultCove does not attach vault data, usernames, passwords, saved website lists, security scores, cards, bank records, notes, TOTP secrets, master passwords, vault keys or device browsing data to that request. The Store build removes this updater path.

## Password-change email notices

The future optional licensing/notice service may receive only a generic event type, time, and random device/license metadata. It must never receive the website/domain, username/account title, old/new password, TOTP secret, notes, cards or bank information.

## Migration

LastPass and Zoho Vault CSV files are parsed locally. These vendor CSVs are plaintext; users should delete them after verifying migration and creating an encrypted VaultCove backup.

## Secure sharing

`.vckey` public identity files contain public keys only. `.vcshare` packages contain encrypted credential payloads plus public routing/signature metadata. Sharing private keys remain inside the encrypted local vault.

## New-login capture

When enabled and the vault is unlocked, VaultCove can detect a submitted username/account identifier and password on a website where its handler is active. If that website/account is not already saved, the candidate is written only into the encrypted vault payload and shown for local Save/Ignore review. VaultCove does not silently register it and does not send the candidate to an email, license service, analytics service, or cloud vault.
