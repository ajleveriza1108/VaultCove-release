function normalizeBase32(value) {
  return value.toUpperCase().replace(/[^A-Z2-7]/g, '');
}

function decodeBase32(value) {
  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
  const input = normalizeBase32(value);
  let bits = '';
  for (const char of input) {
    const index = alphabet.indexOf(char);
    if (index < 0) throw new Error('Invalid Base32 TOTP secret.');
    bits += index.toString(2).padStart(5, '0');
  }
  const bytes = [];
  for (let i = 0; i + 8 <= bits.length; i += 8) bytes.push(parseInt(bits.slice(i, i + 8), 2));
  return new Uint8Array(bytes);
}

export async function generateTotp(secret, timestamp = Date.now(), period = 30, digits = 6) {
  const keyBytes = decodeBase32(secret);
  if (!keyBytes.length) throw new Error('TOTP secret is empty.');
  const counter = Math.floor(timestamp / 1000 / period);
  const buffer = new ArrayBuffer(8);
  const view = new DataView(buffer);
  view.setUint32(0, Math.floor(counter / 2 ** 32));
  view.setUint32(4, counter >>> 0);
  const key = await crypto.subtle.importKey('raw', keyBytes, { name: 'HMAC', hash: 'SHA-1' }, false, ['sign']);
  const digest = new Uint8Array(await crypto.subtle.sign('HMAC', key, buffer));
  const offset = digest[digest.length - 1] & 0x0f;
  const code = (((digest[offset] & 0x7f) << 24) |
    ((digest[offset + 1] & 0xff) << 16) |
    ((digest[offset + 2] & 0xff) << 8) |
    (digest[offset + 3] & 0xff)) % 10 ** digits;
  return {
    code: String(code).padStart(digits, '0'),
    remaining: period - (Math.floor(timestamp / 1000) % period)
  };
}
