const ICONS = {
  login: '<path d="M9 6h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H9"/><path d="m11 15 3-3-3-3"/><path d="M14 12H4"/>',
  card: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 10h18"/><path d="M7 15h4"/>',
  bank: '<path d="m3 9 9-5 9 5"/><path d="M5 10h14"/><path d="M6 10v7M10 10v7M14 10v7M18 10v7"/><path d="M4 20h16"/>',
  note: '<path d="M6 3h9l4 4v14H6z"/><path d="M15 3v5h5"/><path d="M9 12h6M9 16h6"/>',
  identity: '<rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="8" cy="11" r="2"/><path d="M5.5 16c.7-1.7 1.5-2.5 2.5-2.5s1.8.8 2.5 2.5M13 10h5M13 14h5"/>',
  totp: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  weak: '<path d="M12 3 3.5 19h17z"/><path d="M12 9v4M12 16h.01"/>',
  reused: '<path d="M20 7h-5V2"/><path d="M20 7a8 8 0 1 0 2 5"/><path d="M4 17h5v5"/>',
  strong: '<path d="M12 3 5 6v5c0 4.8 2.8 8 7 10 4.2-2 7-5.2 7-10V6z"/><path d="m9 12 2 2 4-5"/>',
  add: '<path d="M12 5v14M5 12h14"/>',
  generator: '<path d="M15 4V2M15 8V6M12 5h6"/><rect x="4" y="8" width="16" height="11" rx="2"/><path d="M8 12h.01M12 12h.01M16 12h.01M8 16h8"/>',
  export: '<path d="M12 16V4"/><path d="m8 8 4-4 4 4"/><path d="M5 13v6h14v-6"/>',
  import: '<path d="M12 4v12"/><path d="m8 12 4 4 4-4"/><path d="M5 5v14h14V5"/>',
  master: '<circle cx="8" cy="12" r="4"/><path d="M12 12h9M17 12v3M20 12v2"/>',
  lock: '<rect x="5" y="10" width="14" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>',
  browser: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a15 15 0 0 1 0 18M12 3a15 15 0 0 0 0 18"/>',
  autologin: '<path d="M8 5h8a3 3 0 0 1 3 3v8a3 3 0 0 1-3 3H8"/><path d="m11 9 3 3-3 3M14 12H4"/>',
  match: '<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3"/>',
  activity: '<path d="M4 12h4l2-5 4 10 2-5h4"/>',
  backup: '<path d="M5 4h11l3 3v13H5z"/><path d="M8 4v6h8V4M8 20v-6h8v6"/>',
  arrowRight: '<path d="M5 12h14M14 7l5 5-5 5"/>'
};

export function uiIcon(name, size = 18, className = '') {
  const body = ICONS[name] || ICONS.note;
  const safeSize = Number.isFinite(Number(size)) ? Math.max(12, Math.min(32, Number(size))) : 18;
  const classAttr = className ? ` class="${String(className).replace(/[^a-zA-Z0-9_-]/g, '')}"` : '';
  return `<svg${classAttr} aria-hidden="true" viewBox="0 0 24 24" width="${safeSize}" height="${safeSize}" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${body}</svg>`;
}
