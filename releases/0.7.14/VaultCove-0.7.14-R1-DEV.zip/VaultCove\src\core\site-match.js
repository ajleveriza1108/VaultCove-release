function normalizeHostname(value) {
  const raw = String(value || '').trim().toLowerCase().replace(/\.$/, '');
  if (!raw) return '';
  try {
    const source = /^[a-z][a-z0-9+.-]*:/i.test(raw) ? raw : `https://${raw}`;
    const url = new URL(source);
    return url.hostname.toLowerCase().replace(/\.$/, '');
  } catch {
    return '';
  }
}

function looksLikeUsableHost(host) {
  const value = String(host || '').trim().toLowerCase();
  if (!value || value.length > 253) return false;
  if (/^\d{1,3}(?:\.\d{1,3}){3}$/.test(value)) {
    return value.split('.').every((part) => Number(part) >= 0 && Number(part) <= 255);
  }
  if (!value.includes('.')) return false;
  return value.split('.').every((label) => /^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/i.test(label));
}

// Explicit first-party login families. These are deliberately narrow allowlists,
// not registrable-domain or suffix matching. A host must be listed verbatim.
const TRUSTED_SITE_FAMILIES = Object.freeze([
  Object.freeze({
    id: 'google-account',
    hosts: Object.freeze([
      'accounts.google.com',
      'mail.google.com',
      'myaccount.google.com',
      'gmail.com',
      'www.gmail.com'
    ])
  })
]);

const SITE_FAMILY_BY_HOST = new Map(
  TRUSTED_SITE_FAMILIES.flatMap((family) => family.hosts.map((host) => [host, family.id]))
);

export function canonicalHostname(value) {
  const host = normalizeHostname(value);
  return host.startsWith('www.') ? host.slice(4) : host;
}

export function trustedSiteFamily(value) {
  return SITE_FAMILY_BY_HOST.get(normalizeHostname(value)) || '';
}

export function permissionOriginForHost(hostname) {
  const host = normalizeHostname(hostname);
  if (!host) throw new Error('A valid HTTPS hostname is required.');
  return `https://${host}/*`;
}

function inferredHostFromLoginName(item) {
  const host = normalizeHostname(item?.name || '');
  return looksLikeUsableHost(host) ? host : '';
}

export function savedHostsForLogin(item) {
  if (!item || item.type !== 'login') return [];
  const values = [...(item.urls || []), ...(item.trustedHosts || [])];
  const hosts = values.map(normalizeHostname).filter(looksLikeUsableHost);
  const inferred = inferredHostFromLoginName(item);
  if (inferred) hosts.push(inferred);
  return [...new Set(hosts)];
}

function hostsAreSafeAliases(saved, current) {
  if (saved === current) return true;

  // Generic convenience alias: www.example.com <-> example.com only.
  const genericWwwAlias = canonicalHostname(saved) === canonicalHostname(current)
    && (saved.startsWith('www.') || current.startsWith('www.'));
  if (genericWwwAlias) return true;

  // Selected first-party services intentionally use separate login/application
  // hosts. Both sides must be explicit members of the same reviewed family.
  const savedFamily = trustedSiteFamily(saved);
  return Boolean(savedFamily && savedFamily === trustedSiteFamily(current));
}

export function loginMatchesTrustedHost(item, currentHostname) {
  if (!item || item.type !== 'login' || item.deletedAt) return false;
  if (item.sharedAccess?.mode === 'use-only') {
    const expiresAt = Date.parse(String(item.sharedAccess?.expiresAt || ''));
    if (Number.isFinite(expiresAt) && Date.now() > expiresAt) return false;
  }
  const current = normalizeHostname(currentHostname);
  if (!looksLikeUsableHost(current)) return false;
  return savedHostsForLogin(item).some((saved) => hostsAreSafeAliases(saved, current));
}

export function siteMatchKind(item, currentHostname) {
  const current = normalizeHostname(currentHostname);
  if (!looksLikeUsableHost(current)) return 'none';
  const hosts = savedHostsForLogin(item);
  if (hosts.includes(current)) return 'exact';
  if (hosts.some((saved) => canonicalHostname(saved) === canonicalHostname(current) && (saved.startsWith('www.') || current.startsWith('www.')))) return 'www-alias';
  const family = trustedSiteFamily(current);
  if (family && hosts.some((saved) => trustedSiteFamily(saved) === family)) return 'trusted-family';
  return 'none';
}

export function resolveLoginHttpsTarget(item) {
  if (!item || item.type !== 'login') return null;
  const candidates = [...(item.urls || []), ...(item.trustedHosts || [])];
  const inferred = inferredHostFromLoginName(item);
  if (inferred) candidates.push(inferred);

  for (const candidate of candidates) {
    const raw = String(candidate || '').trim();
    if (!raw) continue;
    try {
      let url;
      if (/^https?:\/\//i.test(raw)) {
        url = new URL(raw);
      } else {
        url = new URL(`https://${raw}`);
      }
      if (!looksLikeUsableHost(url.hostname)) continue;
      // LastPass exports may contain old http:// URLs. VaultCove never fills
      // passwords over HTTP; upgrade the navigation target to HTTPS instead.
      if (url.protocol === 'http:') url.protocol = 'https:';
      if (url.protocol !== 'https:') continue;
      return url;
    } catch {}
  }
  return null;
}

export function normalizeImportedLoginUrl(value, fallbackName = '') {
  const raw = String(value || '').trim();
  const pseudo = { type: 'login', name: fallbackName, urls: raw ? [raw] : [], trustedHosts: [] };
  const resolved = resolveLoginHttpsTarget(pseudo);
  return resolved ? resolved.toString() : '';
}
