import {
  DEFAULT_LOCK_MINUTES,
  DEFAULT_SENSITIVE_ACCESS_SECONDS,
  DEVICE_STORAGE_KEY,
  SESSION_EXPIRES_KEY,
  SESSION_KEY,
  SESSION_LAST_ACTIVITY_KEY,
  SENSITIVE_ACCESS_UNTIL_KEY,
  SETTINGS_STORAGE_KEY,
  VAULT_STORAGE_KEY
} from './constants.js';
import { base64UrlToBytes, bytesToBase64Url, randomBytes } from './encoding.js';
import { importAesKey } from './crypto.js';

export async function hardenStorageAccess() {
  if (chrome.storage?.local?.setAccessLevel) {
    await chrome.storage.local.setAccessLevel({ accessLevel: 'TRUSTED_CONTEXTS' });
  }
  if (chrome.storage?.session?.setAccessLevel) {
    await chrome.storage.session.setAccessLevel({ accessLevel: 'TRUSTED_CONTEXTS' });
  }
}

export async function getVaultEnvelope() {
  const result = await chrome.storage.local.get(VAULT_STORAGE_KEY);
  return result[VAULT_STORAGE_KEY] ?? null;
}

export async function setVaultEnvelope(envelope) {
  await chrome.storage.local.set({ [VAULT_STORAGE_KEY]: envelope });
}

export async function vaultExists() {
  return Boolean(await getVaultEnvelope());
}

export async function getSettings() {
  const result = await chrome.storage.local.get(SETTINGS_STORAGE_KEY);
  return {
    lockMinutes: DEFAULT_LOCK_MINUTES,
    sensitiveAccessSeconds: DEFAULT_SENSITIVE_ACCESS_SECONDS,
    requireReauthForSecrets: true,
    clipboardWarning: true,
    revealTimeoutSeconds: 10,
    secureLoginClearMs: 1200,
    inlineHandlerEnabled: true,
    alwaysOnHandlerEnabled: true,
    handlerDisabledHosts: [],
    autoLoginEnabled: false,
    vaultTotpEnabled: false,
    websiteIconsEnabled: false,
    vaultViewMode: 'grid',
    theme: 'midnight',
    compactUi: true,
    updateChecksEnabled: true,
    passwordChangeDetectionEnabled: true,
    newLoginCaptureEnabled: true,
    securityEmailNoticeEnabled: false,
    securityNoticeEmail: '',
    firstRunSecurityComplete: true,
    ...result[SETTINGS_STORAGE_KEY]
  };
}

export async function setSettings(settings) {
  const current = await getSettings();
  await chrome.storage.local.set({ [SETTINGS_STORAGE_KEY]: { ...current, ...settings } });
}

const DEVICE_RECOVERY_TOKEN_KEY = 'vaultcoveDeviceRecoveryToken';

export async function ensureDeviceRecoveryToken() {
  const result = await chrome.storage.local.get(DEVICE_RECOVERY_TOKEN_KEY);
  if (result[DEVICE_RECOVERY_TOKEN_KEY]) return result[DEVICE_RECOVERY_TOKEN_KEY];
  const token = `vcrt_${bytesToBase64Url(randomBytes(24))}`;
  await chrome.storage.local.set({ [DEVICE_RECOVERY_TOKEN_KEY]: token });
  return token;
}

export async function setDeviceRecoveryToken(token) {
  const value = String(token || '').trim();
  if (!/^vcrt_[A-Za-z0-9_-]{20,}$/.test(value)) throw new Error('Invalid VaultCove device recovery token.');
  await chrome.storage.local.set({ [DEVICE_RECOVERY_TOKEN_KEY]: value });
  return value;
}

export async function ensureDeviceId() {
  const result = await chrome.storage.local.get(DEVICE_STORAGE_KEY);
  if (result[DEVICE_STORAGE_KEY]) return result[DEVICE_STORAGE_KEY];
  const id = `vcdev_${bytesToBase64Url(randomBytes(18))}`;
  await chrome.storage.local.set({ [DEVICE_STORAGE_KEY]: id });
  return id;
}

export async function saveSessionKey(rawVaultKey) {
  const settings = await getSettings();
  const now = Date.now();
  const expiresAt = now + Math.max(1, settings.lockMinutes) * 60_000;
  await chrome.storage.session.set({
    [SESSION_KEY]: bytesToBase64Url(rawVaultKey),
    [SESSION_EXPIRES_KEY]: expiresAt,
    [SESSION_LAST_ACTIVITY_KEY]: now,
    [SENSITIVE_ACCESS_UNTIL_KEY]: 0
  });
  return expiresAt;
}

export async function touchSession() {
  const result = await chrome.storage.session.get([SESSION_KEY, SESSION_EXPIRES_KEY]);
  if (!result[SESSION_KEY]) return false;
  const settings = await getSettings();
  const now = Date.now();
  await chrome.storage.session.set({
    [SESSION_LAST_ACTIVITY_KEY]: now,
    [SESSION_EXPIRES_KEY]: now + Math.max(1, settings.lockMinutes) * 60_000
  });
  return true;
}

export async function getSessionKey() {
  const result = await chrome.storage.session.get([SESSION_KEY, SESSION_EXPIRES_KEY]);
  if (!result[SESSION_KEY]) return null;
  if (!result[SESSION_EXPIRES_KEY] || Date.now() >= result[SESSION_EXPIRES_KEY]) {
    await clearSession();
    return null;
  }
  const rawVaultKey = base64UrlToBytes(result[SESSION_KEY]);
  return {
    rawVaultKey,
    vaultKey: await importAesKey(rawVaultKey, true),
    expiresAt: result[SESSION_EXPIRES_KEY]
  };
}

export async function grantSensitiveAccess(seconds = null) {
  const settings = await getSettings();
  const ttl = Math.max(5, Math.min(300, Number(seconds ?? settings.sensitiveAccessSeconds) || DEFAULT_SENSITIVE_ACCESS_SECONDS));
  const until = Date.now() + ttl * 1000;
  await chrome.storage.session.set({ [SENSITIVE_ACCESS_UNTIL_KEY]: until });
  return until;
}

export async function hasSensitiveAccess() {
  const result = await chrome.storage.session.get([SESSION_KEY, SESSION_EXPIRES_KEY, SENSITIVE_ACCESS_UNTIL_KEY]);
  if (!result[SESSION_KEY] || !result[SESSION_EXPIRES_KEY] || Date.now() >= result[SESSION_EXPIRES_KEY]) return false;
  return Number(result[SENSITIVE_ACCESS_UNTIL_KEY] || 0) > Date.now();
}

export async function clearSensitiveAccess() {
  await chrome.storage.session.remove(SENSITIVE_ACCESS_UNTIL_KEY);
}

export async function clearSession() {
  await chrome.storage.session.remove([
    SESSION_KEY,
    SESSION_EXPIRES_KEY,
    SESSION_LAST_ACTIVITY_KEY,
    SENSITIVE_ACCESS_UNTIL_KEY
  ]);
}

export async function getSessionExpiry() {
  const result = await chrome.storage.session.get(SESSION_EXPIRES_KEY);
  return result[SESSION_EXPIRES_KEY] ?? 0;
}
