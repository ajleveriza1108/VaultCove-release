@echo off
setlocal EnableExtensions
chcp 65001 >nul
cls
echo ==============================================================================
echo VaultCove 0.7.14 R1 - SELECTIVE ENCRYPTED BACKUP + GAP-FREE SETTINGS
echo ==============================================================================
echo Run normally - DO NOT Run as Administrator.
echo Canonical project: D:\Windows Projects\VaultCove
echo Baseline: verified VaultCove 0.7.13 is directly supported.
echo Package contract: exactly 1 BAT + 1 PS1.
echo.

set "PS1=%~dp0UPDATE-PUBLISH-VAULTCOVE-R0.7.14-R1.ps1"
if not exist "%PS1%" (
  echo [FAIL] Missing publisher script: %PS1%
  echo.
  pause
  exit /b 1
)

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%PS1%"
set "RC=%ERRORLEVEL%"

echo.
if "%RC%"=="0" (
  echo [PASS] VaultCove 0.7.14 R1 pipeline completed successfully.
) else (
  echo [FAIL] VaultCove pipeline returned exit code %RC%.
)
echo.
pause
exit /b %RC%
