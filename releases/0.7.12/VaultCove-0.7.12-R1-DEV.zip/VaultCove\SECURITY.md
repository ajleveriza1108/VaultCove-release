# VaultCove Security Model - 0.7.12 R1


## First-run security essentials

A newly created vault enters a one-time Security Essentials gate before normal use. The user configures auto-lock timing and the generic security-notice email preference, is offered Google Authenticator-compatible TOTP and an encrypted Offline Recovery Kit, and must acknowledge that the master password is not recoverable by VaultCove. Secure HTTPS handling, reviewed new-login capture, password-change detection, Sensitive Access, and local encryption start with secure defaults. Existing vaults upgraded from earlier releases are marked setup-complete by migration defaults and are not interrupted.

## Backup restore input integrity

Backup restore reads the selected `.vcvault` file and matching backup secret from the exact visible restore controls before opening Sensitive Access. New backup secrets are prefixless 256-bit random Base64URL values; legacy `VC1-...` secrets remain supported for compatibility. This prevents a modal/view refresh from invalidating the DOM input reference. The master password authorizes the restore operation; the export secret independently decrypts and authenticates the portable backup.

## Native file-save pointer handling

Encrypted `.vckey` export asks Chrome for the save destination directly from the export click while transient user activation is still valid. VaultCove exits pointer lock if present and forces a normal cursor state before the native picker. Choosing the destination does not write secret material; the encrypted file is written only after Sensitive Access and the separate `.vckey` password succeed. A browser download fallback is retained when the File System Access picker is unavailable.

## Encrypted vault

VaultCove generates a random 256-bit vault key. The master password derives a wrapping key with PBKDF2-HMAC-SHA-256. AES-256-GCM protects the encrypted vault payload and detects tampering.

Encrypted vault data includes usernames, passwords, URLs, notes, TOTP secrets, private VCShare keys, pending new-login/password-change candidates, visited-site visual metadata, and Recovery Kit history metadata.

## Sensitive Access and master-password changes

Unlock and secret disclosure are separate. Reveal, Copy, Edit, export, restore, sharing, protected filling, and master-password changes can require fresh master-password verification. Sensitive Access expires after a short configurable window.

Changing the master password requires the current master password, a strong and different replacement, confirmation, the exact confirmation phrase `CHANGE MASTER PASSWORD`, and the VaultCove authenticator/recovery code when enabled. VaultCove verifies the new wrapped vault key before committing it and locks immediately after success.

## Website handler and Secure Login

The Developer build runs the HTTPS handler automatically for testing. The Chrome Web Store preflight removes mandatory website access and keeps broad HTTPS access optional.

The page handler receives masked login summaries only. It does not receive stored passwords. The service worker validates the actual HTTPS sender and trusted-site relationship before releasing one selected credential.

Handler account search is performed in the trusted extension background. Search does not expose the complete unmasked username or password to the website.

Clicking a login card or List action creates a short-lived one-time Secure Login selection for that exact credential. VaultCove arms the selection before navigating to the saved HTTPS URL so a fast-loading page cannot race ahead of the selected-item state.

Secure Login does not use the system clipboard. It fills only the chosen credential, submits promptly, and clears the injected page password after a guarded fallback when safe. Once a legitimate destination receives the password, that page can potentially read it; traditional password autofill cannot guarantee otherwise.

## New logins, password changes, and password generation

Signup and password-change detection create encrypted pending candidates. VaultCove asks the user before permanently saving a new login or replacing an existing password. The inline generator uses browser cryptographic randomness and can fill matching New Password and Confirm Password fields.

## VaultCove Authenticator protection

VaultCove can enroll a standard TOTP secret compatible with Google Authenticator and other TOTP apps. The authenticator app does not receive, store, or synchronize website passwords from VaultCove. Recovery codes are generated locally and only their hashes remain in the encrypted vault after setup.

Because verification is local, TOTP is an additional local access-confirmation gate, not a separate cloud-held encryption key.

## VCKey and VCShare

`.vckey` v2 exports only the public sharing identity. It is encrypted with a separate file password using PBKDF2-HMAC-SHA-256 at 600,000 iterations and AES-256-GCM. VaultCove requires fresh master verification for reveal/export/import and rejects a `.vckey` password that is the same as the current master password.

VCShare v3 is the dedicated **Use Only shared-login** format. User 1 chooses a trusted recipient and a separate package password, then freshly verifies User 1's Master Password. The inner package is recipient-bound with P-256 ECDH + HKDF-SHA-256, AES-256-GCM, and an ECDSA P-256 sender signature. A second PBKDF2-HMAC-SHA-256 (600,000 iterations) + AES-256-GCM password envelope protects the file with the package password.

User 2 must supply that package password and freshly verify User 2's own Master Password before import. Imported credentials are immediately moved into a second local sealed envelope: a fresh per-item AES-256-GCM key protects username/password, and that key is wrapped by User 2's vault key. Normal UI/model fields do not contain the plaintext shared username/password. The recipient can invoke Secure Login but cannot reveal, copy, edit, auto-login-enable, reshare, or capture password changes for the shared credential.

This is enforceable against normal VaultCove use, not against a malicious recipient who fully controls their operating system or modifies VaultCove code/runtime memory. Once a credential is delivered to a website for login, a compromised recipient device or page can potentially capture it. Rotate the website password when true revocation is required.

## Offline Recovery Kit

`.vcrecovery` uses PBKDF2-HMAC-SHA-256 at 700,000 iterations and AES-256-GCM. It can contain the private sharing identity, a random device-recovery token, and optionally the local VaultCove authenticator configuration. It deliberately does not contain website passwords.

The Recovery Password must be separate from the VaultCove master password. Keep the file offline and separate from the only device being protected.

If the sole copy of a private key is destroyed and no Recovery Kit or second authorized device exists, VaultCove cannot recreate that same key. This is an intentional cryptographic limitation, not a recoverable cloud backup.

## Licensing privacy and device recovery

The Apps Script reference backend may receive a serial during activation, verified license email, random installation ID, random device-recovery token, user-provided device label, platform/app version, OTP responses, and random license/session tokens.

The server stores a keyed hash of the device-recovery token rather than the raw token in the Devices sheet. A restored Recovery Kit can help reclaim the same known device record after a reset. Email OTP is still required; the recovery token alone is not sufficient to activate a license.

Standard licenses allow 7 used device slots. Admin licenses allow 20. Retained devices continue to reserve a slot and can continue a valid signed session. Release and Revoke clear the server-side refresh-token hash. Restore makes the record eligible again, but a cleared device session must reactivate.

VaultCove does not use MAC addresses, Windows serial numbers, IMEI values, or hidden hardware fingerprints for device licensing.

## Update distribution

Developer update metadata is fetched only from the official public VaultCove release source and is digitally verified. The Store build removes the developer GitHub update path. Remote executable JavaScript, remote WASM, `eval`, and `new Function` are not used.

## Out of scope

No browser extension can guarantee secrecy if malware controls the operating system, Chrome process memory, DevTools, screen/accessibility capture, the keyboard, or the user's master password. Endpoint security remains necessary.

## 0.7.8 lock, handler, folder, and `.vckey` conversion boundaries

- Locked/setup UI is a full-viewport gate and is not allowed to inherit sidebar/Compact geometry.
- Browser handlers are session-state views, not authorities. After unlock they re-query the extension background and acknowledge the fresh unlocked state before a handler-initiated unlock tab closes.
- Vault folder names and membership live inside the encrypted vault payload. Deleting a folder only clears its items' `folderId`; it never deletes the items.
- `.vckey` to TXT conversion is intentionally high-friction: Google Authenticator-compatible protection must be enabled, fresh Sensitive Access must succeed, and the separate `.vckey` password must decrypt the file. There is no third TXT-conversion password.
- Converted TXT output is restricted to the public sharing identity. It never contains a master password, `.vckey` password, saved credential, TOTP secret, or private sharing key.

## Sealed Trash
Moving an item to Trash is not a normal plaintext soft delete. VaultCove removes the original credential fields from the active decrypted vault model, encrypts the complete original item with a fresh random 256-bit AES-GCM key, and then encrypts/wraps that item key with the active vault key under separate authenticated additional data. The remaining tombstone contains only minimal display/retention metadata and the authenticated ciphertext envelope.

Trash items are not eligible for Secure Login, handler matching, TOTP display, editing, copying, sharing, password-health analysis, folder organization, or item-detail opening. Restore is the only normal path that unwraps and decrypts the sealed payload back into the active vault. Trash expires after 30 days; expiry is enforced locally on unlock/load/save, and a user may also permanently delete early after Sensitive Access confirmation.

This second envelope is defense-in-depth against accidental disclosure by ordinary unlocked-vault UI/data paths. It does not claim to protect against malicious code that already controls the VaultCove extension process and active vault key.

