function normalizeHostname(value) {
  const raw = String(value || '').trim().toLowerCase().replace(/\.$/, '');
  if (!raw) return '';
  try {
    const source = /^[a-z][a-z0-9+.-]*:/i.test(raw) ? raw : `https://${raw}`;
    const url = new URL(source);
    return url.hostname.toLowerCase().replace(/\.$/, '');
  } catch {
    return '';
  }
}

// Explicit first-party login families. These are deliberately narrow allowlists,
// not registrable-domain or suffix matching. A host must be listed verbatim.
const TRUSTED_SITE_FAMILIES = Object.freeze([
  Object.freeze({
    id: 'google-account',
    hosts: Object.freeze([
      'accounts.google.com',
      'mail.google.com',
      'myaccount.google.com',
      'gmail.com',
      'www.gmail.com'
    ])
  })
]);

const SITE_FAMILY_BY_HOST = new Map(
  TRUSTED_SITE_FAMILIES.flatMap((family) => family.hosts.map((host) => [host, family.id]))
);

export function canonicalHostname(value) {
  const host = normalizeHostname(value);
  return host.startsWith('www.') ? host.slice(4) : host;
}

export function trustedSiteFamily(value) {
  return SITE_FAMILY_BY_HOST.get(normalizeHostname(value)) || '';
}

export function permissionOriginForHost(hostname) {
  const host = normalizeHostname(hostname);
  if (!host) throw new Error('A valid HTTPS hostname is required.');
  return `https://${host}/*`;
}

export function savedHostsForLogin(item) {
  if (!item || item.type !== 'login') return [];
  const values = [...(item.urls || []), ...(item.trustedHosts || [])];
  return [...new Set(values.map(normalizeHostname).filter(Boolean))];
}

function hostsAreSafeAliases(saved, current) {
  if (saved === current) return true;

  // Generic convenience alias: www.example.com <-> example.com only.
  const genericWwwAlias = canonicalHostname(saved) === canonicalHostname(current)
    && (saved.startsWith('www.') || current.startsWith('www.'));
  if (genericWwwAlias) return true;

  // Selected first-party services intentionally use separate login/application
  // hosts. Both sides must be explicit members of the same reviewed family.
  const savedFamily = trustedSiteFamily(saved);
  return Boolean(savedFamily && savedFamily === trustedSiteFamily(current));
}

export function loginMatchesTrustedHost(item, currentHostname) {
  if (!item || item.type !== 'login' || item.deletedAt) return false;
  const current = normalizeHostname(currentHostname);
  if (!current) return false;
  return savedHostsForLogin(item).some((saved) => hostsAreSafeAliases(saved, current));
}

export function siteMatchKind(item, currentHostname) {
  const current = normalizeHostname(currentHostname);
  if (!current) return 'none';
  const hosts = savedHostsForLogin(item);
  if (hosts.includes(current)) return 'exact';
  if (hosts.some((saved) => {
    const family = trustedSiteFamily(saved);
    return family && family === trustedSiteFamily(current);
  })) return 'trusted-family';
  if (hosts.some((saved) => canonicalHostname(saved) === canonicalHostname(current) && (saved.startsWith('www.') || current.startsWith('www.')))) return 'www-alias';
  return 'none';
}

export function safeDisplayHost(value) {
  return normalizeHostname(value) || '';
}
