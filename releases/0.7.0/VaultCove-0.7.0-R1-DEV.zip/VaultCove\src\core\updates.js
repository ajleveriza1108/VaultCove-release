import { DEV_UPDATE_ENABLED, UPDATE_METADATA_URL } from './build.js';
import { RELEASE_PUBLIC_KEY_SPKI_BASE64 } from './release-key.js';

const CACHE_KEY = 'vaultcoveUpdateState';
const CHECK_INTERVAL_MS = 24 * 60 * 60 * 1000;

function versionParts(value) {
  return String(value || '0').split('.').map((part) => Number.parseInt(part, 10) || 0).slice(0, 4);
}

export function compareVersions(left, right) {
  const a = versionParts(left);
  const b = versionParts(right);
  const count = Math.max(a.length, b.length, 3);
  for (let i = 0; i < count; i += 1) {
    const delta = (a[i] || 0) - (b[i] || 0);
    if (delta) return Math.sign(delta);
  }
  return 0;
}

function base64ToBytes(value) {
  const binary = atob(String(value || '').replace(/\s+/g, ''));
  return Uint8Array.from(binary, (char) => char.charCodeAt(0));
}

function base64UrlToBytes(value) {
  const raw = String(value || '').replace(/-/g, '+').replace(/_/g, '/');
  return base64ToBytes(raw + '='.repeat((4 - raw.length % 4) % 4));
}

function signedFields(raw) {
  return {
    product: String(raw.product || ''),
    channel: String(raw.channel || ''),
    version: String(raw.version || ''),
    published: String(raw.published || ''),
    critical: Boolean(raw.critical),
    sha256: String(raw.sha256 || '').toLowerCase(),
    downloadUrl: String(raw.downloadUrl || ''),
    notesUrl: String(raw.notesUrl || ''),
    summary: String(raw.summary || ''),
    schemaVersion: Number(raw.schemaVersion || 1)
  };
}

export function canonicalUpdatePayload(raw) {
  return JSON.stringify(signedFields(raw));
}

async function verifyMetadataSignature(raw) {
  if (!RELEASE_PUBLIC_KEY_SPKI_BASE64 || RELEASE_PUBLIC_KEY_SPKI_BASE64 === 'UNCONFIGURED') {
    throw new Error('VaultCove release verification key is not configured.');
  }
  if (raw.signatureAlgorithm !== 'ECDSA-P256-SHA256' || !raw.signature) throw new Error('Update metadata is not digitally signed.');
  const key = await crypto.subtle.importKey('spki', base64ToBytes(RELEASE_PUBLIC_KEY_SPKI_BASE64), { name: 'ECDSA', namedCurve: 'P-256' }, false, ['verify']);
  const valid = await crypto.subtle.verify(
    { name: 'ECDSA', hash: 'SHA-256' },
    key,
    base64UrlToBytes(raw.signature),
    new TextEncoder().encode(canonicalUpdatePayload(raw))
  );
  if (!valid) throw new Error('VaultCove update metadata signature verification failed.');
}

function sanitizeMetadata(raw) {
  if (!raw || typeof raw !== 'object') throw new Error('Update metadata is invalid.');
  const data = signedFields(raw);
  if (data.product !== 'VaultCove') throw new Error('Update metadata is for a different product.');
  if (!/^\d+\.\d+\.\d+(?:\.\d+)?$/.test(data.version)) throw new Error('Update version is invalid.');
  if (!/^[a-f0-9]{64}$/.test(data.sha256)) throw new Error('Update package SHA-256 is invalid.');
  if (data.downloadUrl && !(
    /^https:\/\/github\.com\/ajleveriza1108\/VaultCove-release\/releases\/download\//i.test(data.downloadUrl) ||
    /^https:\/\/raw\.githubusercontent\.com\/ajleveriza1108\/VaultCove-release\//i.test(data.downloadUrl)
  )) throw new Error('Update download URL is not an official VaultCove release URL.');
  if (data.notesUrl && !/^https:\/\/github\.com\/ajleveriza1108\/VaultCove-release\//i.test(data.notesUrl)) throw new Error('Update notes URL is not an official VaultCove release URL.');
  return { ...data, summary: data.summary.slice(0, 240) };
}

export async function getCachedUpdateState() {
  const result = await chrome.storage.local.get(CACHE_KEY);
  return result[CACHE_KEY] || null;
}

export async function checkForUpdates({ force = false } = {}) {
  if (!DEV_UPDATE_ENABLED) return { enabled: false, channel: 'store' };
  const currentVersion = chrome.runtime.getManifest().version;
  const cached = await getCachedUpdateState();
  if (!force && cached?.checkedAt && Date.now() - Number(cached.checkedAt) < CHECK_INTERVAL_MS) return cached;

  const response = await fetch(UPDATE_METADATA_URL, {
    method: 'GET',
    cache: 'no-store',
    credentials: 'omit',
    referrerPolicy: 'no-referrer'
  });
  if (!response.ok) throw new Error(`Update check failed (${response.status}).`);
  const raw = await response.json();
  await verifyMetadataSignature(raw);
  const metadata = sanitizeMetadata(raw);
  const state = {
    enabled: true,
    verified: true,
    checkedAt: Date.now(),
    currentVersion,
    updateAvailable: compareVersions(metadata.version, currentVersion) > 0,
    ...metadata
  };
  await chrome.storage.local.set({ [CACHE_KEY]: state });
  return state;
}
