# VaultCove Privacy - 0.7.0 R1

VaultCove is designed as an offline-first encrypted vault.

## Data kept locally

Vault records, passwords, usernames, saved URLs, secure notes, cards, bank records, identities, website TOTP secrets, private VCShare keys, pending login/password-change candidates, local security-health results, and visited-site visual metadata remain inside the encrypted local vault.

Website thumbnails use Chrome's local favicon cache only after the user enables the optional favicon feature and VaultCove has handled a matching saved site. VaultCove does not upload a list of saved or visited domains to an icon service.

## Developer update checks

The Developer build can check the official VaultCove release metadata for a newer version. It does not attach vault records, saved websites, usernames, passwords, cards, bank data, notes, TOTP secrets, master passwords, vault keys, or security-health data to that request.

## Licensing and devices

When the user tests Apps Script licensing, VaultCove may transmit only the fields allowed by the licensing protocol: serial during activation, license email, random installation ID, random device-recovery token, user device label, platform/app version, verification codes/challenge IDs, and random refresh/management tokens.

Never sent to licensing: master password, vault key, saved website list, usernames, passwords, website TOTP secrets, cards, bank accounts, secure notes, private VCShare keys, browsing history, MAC address, Windows serial, IMEI, or a hardware fingerprint.

The serial becomes associated with a verified email after the first successful activation if no email is already bound. Device-management actions require a fresh email verification session.

## VaultCove Authenticator

Google Authenticator or another TOTP app is used only to generate a local verification code for VaultCove. VaultCove does not send website passwords to Google Authenticator and does not connect the password vault to the user's Google account.

## Offline Recovery Kit

VaultCove does not upload `.vcrecovery` files. Recovery Kits are created locally and should be stored by the user on offline media. They may contain private sharing keys, a random device-recovery token, and optional VaultCove authenticator configuration, all encrypted with the user's separate Recovery Password. Website passwords are not included in the Recovery Kit.

## Sharing

`.vckey` contains a public sharing identity encrypted with its own file password. `.vcshare` contains recipient-encrypted shared records. A private sharing key never leaves the encrypted vault except when the user deliberately creates an encrypted offline Recovery Kit.

## Testing status

The current development build is Testing - Full Access. Trial expiration and feature lockout are not enforced while the product is being tested.
