import { createItem } from './model.js';

function normalizedHeader(value) {
  return String(value ?? '').replace(/^\uFEFF/, '').trim().toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
}

function csvRows(text) {
  const rows = [];
  let row = [];
  let field = '';
  let quoted = false;
  const source = String(text ?? '').replace(/^\uFEFF/, '');

  for (let i = 0; i < source.length; i += 1) {
    const ch = source[i];
    if (quoted) {
      if (ch === '"') {
        if (source[i + 1] === '"') { field += '"'; i += 1; }
        else quoted = false;
      } else field += ch;
      continue;
    }
    if (ch === '"') quoted = true;
    else if (ch === ',') { row.push(field); field = ''; }
    else if (ch === '\n') { row.push(field.replace(/\r$/, '')); rows.push(row); row = []; field = ''; }
    else field += ch;
  }
  if (field.length || row.length) { row.push(field.replace(/\r$/, '')); rows.push(row); }
  return rows.filter((candidate) => candidate.some((value) => String(value).trim() !== ''));
}

export function parseCsv(text) {
  const rows = csvRows(text);
  if (rows.length < 2) throw new Error('The CSV does not contain any data rows.');
  const originalHeaders = rows[0].map((header, index) => String(header || `Column ${index + 1}`).replace(/^\uFEFF/, '').trim());
  const headers = originalHeaders.map(normalizedHeader);
  const records = rows.slice(1).map((values) => {
    const record = { __headers: originalHeaders };
    headers.forEach((header, index) => { record[header || `column ${index + 1}`] = String(values[index] ?? ''); });
    return record;
  }).filter((record) => headers.some((header) => String(record[header] ?? '').trim() !== ''));
  return { headers, originalHeaders, records };
}

function valueOf(row, ...aliases) {
  for (const alias of aliases) {
    const key = normalizedHeader(alias);
    if (Object.prototype.hasOwnProperty.call(row, key) && String(row[key]).trim() !== '') return String(row[key]).trim();
  }
  return '';
}

function boolValue(value) {
  return /^(1|true|yes|y|favorite|fav)$/i.test(String(value ?? '').trim());
}

function safeUrl(value) {
  const text = String(value ?? '').trim();
  if (!text || /^http:\/\/sn\/?$/i.test(text)) return '';
  return text;
}

function extractTotpSecret(value) {
  const raw = String(value ?? '').trim();
  if (!raw || /^\d{6,8}$/.test(raw)) return '';
  if (/^otpauth:\/\//i.test(raw)) {
    try { return new URL(raw).searchParams.get('secret')?.replace(/[\s-]/g, '').toUpperCase() || ''; } catch { return ''; }
  }
  const compact = raw.replace(/[\s-]/g, '').toUpperCase();
  return /^[A-Z2-7]+=*$/.test(compact) && compact.length >= 16 ? compact.replace(/=+$/, '') : '';
}

function withSourceTags(tags, source, folder = '') {
  const out = ['Imported', source];
  if (folder) out.push(`Folder: ${folder}`);
  for (const tag of tags || []) if (tag && !out.includes(tag)) out.push(tag);
  return out.slice(0, 20);
}

function appendUnmappedFields(row, usedHeaders, notes = '') {
  const extras = [];
  const used = new Set([...usedHeaders].map(normalizedHeader));
  for (const header of row.__headers || []) {
    const key = normalizedHeader(header);
    const value = String(row[key] ?? '').trim();
    if (value && !used.has(key)) extras.push(`${header}: ${value}`);
  }
  if (!extras.length) return notes;
  return [notes, 'Imported fields:', ...extras].filter(Boolean).join('\n');
}

export function detectMigrationFormat(csv) {
  const h = new Set(csv.headers);
  if (['url','username','password','extra','name'].filter((key) => h.has(key)).length >= 4) return 'lastpass';
  if (h.has('password name') || h.has('password url') || (h.has('username') && h.has('password') && (h.has('category') || h.has('password name')))) return 'zoho';
  return 'generic';
}

export function importLastPassCsv(text) {
  const csv = parseCsv(text);
  const required = ['url','username','password','extra','name'];
  if (required.filter((key) => csv.headers.includes(key)).length < 4) throw new Error('This does not look like a LastPass CSV export.');
  const warnings = [];
  const items = [];

  for (const row of csv.records) {
    const name = valueOf(row, 'name') || 'Imported LastPass item';
    const url = safeUrl(valueOf(row, 'url'));
    const username = valueOf(row, 'username');
    const password = valueOf(row, 'password');
    const extra = valueOf(row, 'extra');
    const grouping = valueOf(row, 'grouping');
    const favorite = boolValue(valueOf(row, 'fav'));
    const rawTotp = valueOf(row, 'totp');
    const totpSecret = extractTotpSecret(rawTotp);
    const isNote = /^http:\/\/sn\/?$/i.test(valueOf(row, 'url')) || (!url && !username && !password && Boolean(extra));

    if (isNote) {
      items.push(createItem('note', { name, text: extra, favorite, tags: withSourceTags([], 'LastPass', grouping) }));
      continue;
    }

    let notes = extra;
    if (rawTotp && !totpSecret) {
      notes = [notes, 'LastPass TOTP field was preserved but not activated because it was not a recognizable secret:', rawTotp].filter(Boolean).join('\n');
      warnings.push(`TOTP for “${name}” could not be safely recognized as a secret and was kept in Notes.`);
    }
    items.push(createItem('login', {
      name,
      username,
      password,
      urls: url ? [url] : [],
      totpSecret,
      notes,
      favorite,
      importedAt: new Date().toISOString(),
      tags: withSourceTags([], 'LastPass', grouping)
    }));
  }
  return { source: 'LastPass CSV', format: 'lastpass', items, warnings };
}

function zohoCategory(row) {
  return valueOf(row, 'category', 'password category', 'type', 'secret type').toLowerCase();
}

function zohoItem(row) {
  const category = zohoCategory(row);
  const name = valueOf(row, 'password name', 'name', 'title', 'secret name') || 'Imported Zoho Vault item';
  const folder = valueOf(row, 'folder', 'folder name');
  const favorite = boolValue(valueOf(row, 'favorite', 'fav'));
  const tags = withSourceTags(valueOf(row, 'tags').split(/[;,]/).map((v) => v.trim()).filter(Boolean), 'Zoho Vault', folder);
  const noteText = valueOf(row, 'notes', 'note', 'description', 'secure note', 'comments');

  if (/bank|financial/.test(category)) {
    const used = ['password name','name','title','secret name','category','password category','type','secret type','folder','folder name','favorite','fav','tags','notes','note','description','comments','bank name','bank','account holder','account holder name','account type','account number','routing number','aba routing number','iban','swift','swift bic','bic','branch','pin'];
    return createItem('bank', {
      name,
      bankName: valueOf(row, 'bank name', 'bank'),
      accountHolder: valueOf(row, 'account holder', 'account holder name'),
      accountType: valueOf(row, 'account type'),
      accountNumber: valueOf(row, 'account number'),
      routingNumber: valueOf(row, 'routing number', 'aba routing number'),
      iban: valueOf(row, 'iban'),
      swiftBic: valueOf(row, 'swift', 'swift bic', 'bic'),
      branch: valueOf(row, 'branch'),
      pin: valueOf(row, 'pin'),
      notes: appendUnmappedFields(row, used, noteText), favorite, tags
    });
  }

  if (/card|payment/.test(category)) {
    const used = ['password name','name','title','secret name','category','password category','type','secret type','folder','folder name','favorite','fav','tags','notes','note','description','comments','cardholder','card holder','name on card','brand','card type','card number','number','security code','cvv','cvc','expiry month','expiration month','exp month','expiry year','expiration year','exp year','billing address'];
    return createItem('card', {
      name,
      cardholder: valueOf(row, 'cardholder', 'card holder', 'name on card'),
      brand: valueOf(row, 'brand', 'card type'),
      number: valueOf(row, 'card number', 'number'),
      securityCode: valueOf(row, 'security code', 'cvv', 'cvc'),
      expMonth: valueOf(row, 'expiry month', 'expiration month', 'exp month'),
      expYear: valueOf(row, 'expiry year', 'expiration year', 'exp year'),
      billingAddress: valueOf(row, 'billing address'),
      notes: appendUnmappedFields(row, used, noteText), favorite, tags
    });
  }

  if (/address|identity|personal/.test(category)) {
    const used = ['password name','name','title','secret name','category','password category','type','secret type','folder','folder name','favorite','fav','tags','notes','note','description','comments','first name','middle name','last name','company','email','phone','telephone','address 1','address line 1','address 2','address line 2','city','state','province','postal code','zip','country','government id','id number'];
    return createItem('identity', {
      name,
      firstName: valueOf(row, 'first name'), middleName: valueOf(row, 'middle name'), lastName: valueOf(row, 'last name'),
      company: valueOf(row, 'company'), email: valueOf(row, 'email'), phone: valueOf(row, 'phone', 'telephone'),
      address1: valueOf(row, 'address 1', 'address line 1'), address2: valueOf(row, 'address 2', 'address line 2'),
      city: valueOf(row, 'city'), state: valueOf(row, 'state', 'province'), postalCode: valueOf(row, 'postal code', 'zip'), country: valueOf(row, 'country'),
      governmentId: valueOf(row, 'government id', 'id number'), notes: appendUnmappedFields(row, used, noteText), favorite, tags
    });
  }

  if (/note/.test(category)) {
    return createItem('note', { name, text: appendUnmappedFields(row, ['password name','name','title','secret name','category','password category','type','secret type','folder','folder name','favorite','fav','tags','notes','note','description','secure note','comments'], noteText), favorite, tags });
  }

  const url = safeUrl(valueOf(row, 'password url', 'url', 'website', 'login url'));
  const username = valueOf(row, 'username', 'user name', 'login');
  const password = valueOf(row, 'password');
  const rawTotp = valueOf(row, 'totp', 'totp secret', 'otp secret');
  const totpSecret = extractTotpSecret(rawTotp);
  const used = ['password name','name','title','secret name','category','password category','type','secret type','folder','folder name','favorite','fav','tags','notes','note','description','comments','password url','url','website','login url','username','user name','login','password','totp','totp secret','otp secret'];
  let notes = appendUnmappedFields(row, used, noteText);
  if (rawTotp && !totpSecret) notes = [notes, `Unrecognized TOTP field: ${rawTotp}`].filter(Boolean).join('\n');
  return createItem('login', { name, username, password, urls: url ? [url] : [], totpSecret, notes, favorite, tags, importedAt: new Date().toISOString() });
}

export function importZohoVaultCsv(text) {
  const csv = parseCsv(text);
  const looksZoho = csv.headers.includes('password name') || csv.headers.includes('password url') || (csv.headers.includes('username') && csv.headers.includes('password'));
  if (!looksZoho) throw new Error('This does not look like a Zoho Vault CSV export.');
  return { source: 'Zoho Vault CSV', format: 'zoho', items: csv.records.map(zohoItem), warnings: [] };
}

export function importMigrationCsv(text, requestedFormat = 'auto') {
  const csv = parseCsv(text);
  const format = requestedFormat === 'auto' ? detectMigrationFormat(csv) : requestedFormat;
  if (format === 'lastpass') return importLastPassCsv(text);
  if (format === 'zoho') return importZohoVaultCsv(text);
  throw new Error('VaultCove could not identify this CSV. Choose LastPass or Zoho Vault explicitly, or export a supported CSV format.');
}

function duplicateKey(item) {
  const url = item.type === 'login' ? String(item.urls?.[0] || '').toLowerCase() : '';
  const username = item.type === 'login' ? String(item.username || '').toLowerCase() : '';
  return [item.type, String(item.name || '').trim().toLowerCase(), username, url].join('|');
}

export function mergeImportedItems(existingItems, importedItems, { skipDuplicates = true } = {}) {
  const keys = new Set((existingItems || []).filter((item) => !item.deletedAt).map(duplicateKey));
  const accepted = [];
  let skipped = 0;
  for (const item of importedItems || []) {
    const key = duplicateKey(item);
    if (skipDuplicates && keys.has(key)) { skipped += 1; continue; }
    keys.add(key); accepted.push(item);
  }
  return { accepted, skipped };
}
