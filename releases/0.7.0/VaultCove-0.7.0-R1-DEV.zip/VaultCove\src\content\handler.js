(() => {
  if (globalThis.__vaultCoveHandlerLoaded) return;
  globalThis.__vaultCoveHandlerLoaded = true;

  const markUrl = 'data:image/svg+xml,' + encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><path fill="#1283ff" d="M32 3 57 13v17c0 15-10 25-25 31C17 55 7 45 7 30V13z"/><path fill="#071a34" d="M32 9 51 17v13c0 11-7 19-19 24-12-5-19-13-19-24V17z"/><circle cx="32" cy="30" r="13" fill="none" stroke="#dfefff" stroke-width="4"/><path fill="#dfefff" d="M29 29a3 3 0 1 1 6 0c0 1.2-.6 2.2-1.5 2.7L36 40h-8l2.5-8.3A3.1 3.1 0 0 1 29 29Z"/><path fill="#38c9ff" d="M14 39c8-6 13-4 18 1 6-5 12-7 18-1-4 7-10 12-18 15-8-3-14-8-18-15Z"/></svg>`);
  let rootHost = null;
  let shadow = null;
  let state = { enabled: false, unlocked: false, matches: [], autoLoginItemId: null, newLoginCaptureEnabled: false };
  let lastLoginCaptureReport = '';
  let lastLoginCaptureReportAt = 0;
  let scanTimer = null;
  let autoTimer = null;
  let autoAttemptedFor = '';
  let lastChangeReport = '';
  let lastChangeReportAt = 0;
  let observer = null;
  let lastFields = [];
  const observedRoots = new WeakSet();

  function visible(el) {
    if (!(el instanceof HTMLInputElement)) return false;
    const rect = el.getBoundingClientRect();
    const style = getComputedStyle(el);
    return rect.width >= 45 && rect.height >= 16 && style.visibility !== 'hidden' && style.display !== 'none' && !el.disabled && !el.readOnly;
  }

  function fieldToken(el) {
    return `${el.type || ''} ${el.name || ''} ${el.id || ''} ${el.autocomplete || ''} ${el.placeholder || ''} ${el.getAttribute('aria-label') || ''}`.toLowerCase();
  }

  function isUsernameField(el) {
    const type = (el.type || '').toLowerCase();
    if (!['text', 'email', 'tel', ''].includes(type)) return false;
    return /(user|email|login|account|identifier)/.test(fieldToken(el));
  }

  function observeRoot(root) {
    if (!observer || !root || observedRoots.has(root)) return;
    observer.observe(root, {
      subtree: true,
      childList: true,
      attributes: true,
      attributeFilter: ['type', 'name', 'id', 'autocomplete', 'placeholder', 'disabled', 'readonly']
    });
    observedRoots.add(root);
  }

  function openRoots() {
    const roots = [document];
    for (let index = 0; index < roots.length && index < 64; index += 1) {
      const root = roots[index];
      observeRoot(root);
      for (const node of root.querySelectorAll('*')) {
        if (node.shadowRoot && !roots.includes(node.shadowRoot)) roots.push(node.shadowRoot);
      }
    }
    return roots;
  }

  function allInputs(scope = null) {
    if (scope && scope !== document) return [...scope.querySelectorAll('input')];
    return openRoots().flatMap((root) => [...root.querySelectorAll('input')]);
  }

  function loginFields() {
    const inputs = allInputs().filter(visible);
    const passwordFields = inputs.filter((el) => (el.type || '').toLowerCase() === 'password');
    if (passwordFields.length) {
      const forms = new Set(passwordFields.map((el) => el.form).filter(Boolean));
      const usernames = inputs.filter((el) => isUsernameField(el) && (!el.form || !forms.size || forms.has(el.form)));
      return [...new Set([...usernames, ...passwordFields])].slice(0, 12);
    }
    return inputs.filter(isUsernameField).slice(0, 6);
  }

  function pageStage(fields) {
    return fields.some((el) => (el.type || '').toLowerCase() === 'password') ? 'password' : 'username';
  }

  function ensureRoot() {
    if (rootHost?.isConnected && shadow) return;
    rootHost = document.createElement('div');
    rootHost.dataset.vaultcove = 'handler-root';
    rootHost.style.cssText = 'all:initial;position:fixed;inset:0;z-index:2147483647;pointer-events:none;';
    shadow = rootHost.attachShadow({ mode: 'closed' });
    const style = document.createElement('style');
    style.textContent = `
      *{box-sizing:border-box;font-family:Inter,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}
      .vc-icon{position:fixed;width:22px;height:22px;border:0;border-radius:8px;padding:1px;background:#07192d;box-shadow:0 4px 16px rgba(0,0,0,.34),0 0 0 1px rgba(35,136,255,.82);cursor:pointer;pointer-events:auto;display:grid;place-items:center;transition:transform .12s ease,box-shadow .12s ease}
      .vc-icon:hover{transform:translateY(-1px);box-shadow:0 6px 20px rgba(0,0,0,.42),0 0 0 1px #43cfff}
      .vc-icon img{width:19px;height:19px;display:block}
      .vc-badge{position:absolute;right:-6px;top:-7px;min-width:14px;height:14px;padding:0 3px;border-radius:999px;background:#1688ff;color:white;font:bold 8px/14px system-ui;text-align:center;box-shadow:0 1px 5px rgba(0,0,0,.4)}
      .vc-badge.locked{background:#6b7f94}.vc-badge.pending{background:#d69220}
      .vc-menu{position:fixed;width:min(320px,calc(100vw - 16px));max-height:350px;overflow:auto;background:#07192d;color:#eef7ff;border:1px solid #28547d;border-radius:12px;box-shadow:0 16px 42px rgba(0,0,0,.48);padding:9px;pointer-events:auto}
      .vc-head{display:flex;align-items:center;gap:8px;padding:4px 4px 8px;border-bottom:1px solid #183b5c}.vc-head img{width:27px;height:27px}.vc-head strong{font-size:13px}.vc-head small{display:block;color:#82a8c8;font-size:10px;margin-top:2px;max-width:250px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
      .vc-search-wrap{position:sticky;top:-9px;z-index:2;background:#07192d;padding:7px 2px 5px}.vc-search{width:100%;border:1px solid #28547d;border-radius:8px;background:#041325;color:#eef7ff;padding:8px 9px;font-size:10px;outline:none}.vc-search:focus{border-color:#43cfff;box-shadow:0 0 0 2px rgba(67,207,255,.12)}.vc-result-count{color:#82a8c8;font-size:8px;margin:5px 2px 0}.vc-empty{padding:15px 8px;color:#94abc0;font-size:11px;line-height:1.45;text-align:center}.vc-row{padding:8px;border-radius:9px;background:#0c2744;margin-top:7px;border:1px solid #173e64}
      .vc-row-main{display:flex;justify-content:space-between;gap:8px;align-items:start}.vc-row strong{font-size:11px;display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.vc-row small{display:block;color:#8eabc4;font-size:9px;margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
      .vc-actions{display:flex;gap:6px;margin-top:7px}.vc-actions button,.vc-open{border:0;border-radius:7px;background:#1487ff;color:white;font:bold 9px system-ui;padding:7px 9px;cursor:pointer}.vc-actions .fill{background:#123657;color:#d9edff;border:1px solid #2c5f8d}.vc-auto{color:#54d79b;font-size:8px;white-space:nowrap;margin-top:2px}.vc-pending{color:#f4c565;font-size:8px;white-space:nowrap;margin-top:2px}.vc-open{margin-top:8px;width:100%}.vc-note{padding:6px 7px;color:#61cfff;font-size:9px}.vc-generator{margin-top:7px;padding:9px;border-radius:9px;background:linear-gradient(135deg,#0c3152,#0b2540);border:1px solid #24618d}.vc-generator strong{font-size:11px}.vc-generator small{display:block;color:#91b5d0;font-size:9px;line-height:1.4;margin:3px 0 7px}.vc-generator-row{display:flex;gap:6px;align-items:center}.vc-generator select{background:#07192d;color:#eaf7ff;border:1px solid #315c7c;border-radius:7px;padding:6px;font-size:9px}.vc-generator button{flex:1;border:0;border-radius:7px;background:#1688ff;color:white;font:bold 9px system-ui;padding:7px 9px;cursor:pointer}.vc-generated{color:#64dda3!important}
    `;
    shadow.append(style);
    (document.documentElement || document.body)?.append(rootHost);
  }

  function clearUi() {
    if (!shadow) return;
    [...shadow.querySelectorAll('.vc-icon,.vc-menu')].forEach((node) => node.remove());
  }

  function closeMenus() {
    if (!shadow) return;
    [...shadow.querySelectorAll('.vc-menu')].forEach((node) => node.remove());
  }

  async function fill(itemId, submit, automatic = false, stage = 'password') {
    try {
      const response = await chrome.runtime.sendMessage({ type: 'FILL_PAGE_LOGIN', itemId, submit, automatic, stage });
      if (!response?.ok) throw new Error(response?.error || 'VaultCove could not fill this login.');
      closeMenus();
      return response;
    } catch (error) {
      if (!automatic) showTransient(String(error?.message || error));
      return null;
    }
  }

  function showTransient(text) {
    ensureRoot();
    closeMenus();
    const menu = document.createElement('div');
    menu.className = 'vc-menu';
    menu.style.right = '12px';
    menu.style.top = '12px';
    const note = document.createElement('div');
    note.className = 'vc-empty';
    note.textContent = text;
    menu.append(note);
    shadow.append(menu);
    setTimeout(() => menu.remove(), 3500);
  }

  function passwordFormContext(fields = lastFields) {
    const passwords = (fields || []).filter((el) => (el.type || '').toLowerCase() === 'password');
    const tokens = passwords.map((el) => fieldToken(el));
    const explicitNew = passwords.filter((el) => String(el.autocomplete || '').toLowerCase() === 'new-password' || /(new|confirm|change|reset|create).{0,18}pass|pass.{0,18}(new|confirm|change|reset|create)/.test(fieldToken(el)));
    if (!explicitNew.length) return { kind: 'login', fields: [] };
    const hasCurrent = passwords.some((el) => String(el.autocomplete || '').toLowerCase() === 'current-password' || /(current|old).{0,15}pass/.test(fieldToken(el)));
    const pageText = `${document.title || ''} ${location.pathname || ''}`.toLowerCase();
    const kind = hasCurrent || /(change|reset|recover).{0,20}pass|pass.{0,20}(change|reset|recover)/.test(`${tokens.join(' ')} ${pageText}`) ? 'change' : 'signup';
    return { kind, fields: explicitNew };
  }

  function generateStrongPassword(length = 24) {
    const lower = 'abcdefghijkmnopqrstuvwxyz';
    const upper = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
    const digits = '23456789';
    const symbols = '!@#$%^&*()-_=+[]{}:,.?';
    const sets = [lower, upper, digits, symbols];
    const alphabet = sets.join('');
    const bytes = new Uint32Array(Math.max(16, Math.min(64, Number(length) || 24)));
    crypto.getRandomValues(bytes);
    const chars = sets.map((set, index) => set[bytes[index] % set.length]);
    for (let i = sets.length; i < bytes.length; i += 1) chars.push(alphabet[bytes[i] % alphabet.length]);
    for (let i = chars.length - 1; i > 0; i -= 1) {
      const swapBytes = new Uint32Array(1); crypto.getRandomValues(swapBytes);
      const j = swapBytes[0] % (i + 1); [chars[i], chars[j]] = [chars[j], chars[i]];
    }
    return chars.join('');
  }

  function setNativeValue(input, value) {
    const descriptor = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value');
    descriptor?.set?.call(input, value);
    input.dispatchEvent(new Event('input', { bubbles: true, composed: true }));
    input.dispatchEvent(new Event('change', { bubbles: true, composed: true }));
  }

  function generateAndFillPassword(length) {
    const context = passwordFormContext();
    if (!context.fields.length) return showTransient('VaultCove did not find a supported New Password field.');
    const password = generateStrongPassword(length);
    for (const field of context.fields) {
      if (field.isConnected && !field.disabled && !field.readOnly) setNativeValue(field, password);
    }
    const first = context.fields[0]; first?.focus();
    showTransient(`Generated and filled a ${password.length}-character password locally. VaultCove will ask before saving or updating after submission.`);
  }

  function appendGenerator(menu) {
    const context = passwordFormContext();
    if (!context.fields.length) return;
    const box = document.createElement('div'); box.className = 'vc-generator';
    const title = document.createElement('strong'); title.textContent = context.kind === 'change' ? 'Password change detected' : 'New password detected';
    const hint = document.createElement('small'); hint.textContent = context.kind === 'change' ? 'Generate a strong replacement locally. VaultCove will ask before updating the saved login.' : 'Generate a strong password locally. VaultCove will ask before saving the new login.';
    const row = document.createElement('div'); row.className = 'vc-generator-row';
    const length = document.createElement('select');
    for (const value of [20,24,32,40]) { const option = document.createElement('option'); option.value = String(value); option.textContent = `${value} chars`; if (value === 24) option.selected = true; length.append(option); }
    const button = document.createElement('button'); button.type = 'button'; button.textContent = 'Generate and fill';
    button.addEventListener('click', () => generateAndFillPassword(Number(length.value)));
    row.append(length, button); box.append(title, hint, row); menu.append(box);
  }

  function appendLoginRows(container, matches) {
    container.replaceChildren();
    for (const item of matches) {
      const row = document.createElement('div'); row.className = 'vc-row';
      const main = document.createElement('div'); main.className = 'vc-row-main';
      const info = document.createElement('div');
      const name = document.createElement('strong'); name.textContent = `${item.favorite ? 'Favorite: ' : ''}${item.name}`;
      const user = document.createElement('small'); user.textContent = item.usernameMasked || '(no username)';
      info.append(name, user); main.append(info);
      const flags = document.createElement('div');
      if (item.autoLogin) { const flag = document.createElement('div'); flag.className = 'vc-auto'; flag.textContent = 'AUTO-LOGIN'; flags.append(flag); }
      if (item.pendingPasswordChange) { const flag = document.createElement('div'); flag.className = 'vc-pending'; flag.textContent = 'CHANGE DETECTED'; flags.append(flag); }
      if (item.requireReauthBeforeFill) { const flag = document.createElement('div'); flag.className = 'vc-pending'; flag.textContent = 'MASTER CHECK'; flags.append(flag); }
      if (flags.childElementCount) main.append(flags);
      const actions = document.createElement('div'); actions.className = 'vc-actions';
      const fillButton = document.createElement('button'); fillButton.type = 'button'; fillButton.className = 'fill'; fillButton.textContent = 'Fill'; fillButton.addEventListener('click', () => fill(item.id, false));
      const loginButton = document.createElement('button'); loginButton.type = 'button'; loginButton.textContent = 'Secure Login'; loginButton.addEventListener('click', () => fill(item.id, true));
      actions.append(fillButton, loginButton); row.append(main, actions); container.append(row);
    }
  }

  function showMenu(icon) {
    ensureRoot();
    closeMenus();
    const rect = icon.getBoundingClientRect();
    const menu = document.createElement('div');
    menu.className = 'vc-menu';
    const width = Math.min(340, Math.max(270, innerWidth - 16));
    const left = Math.min(Math.max(8, rect.right - width), Math.max(8, innerWidth - width - 8));
    const top = rect.bottom + 8 + 390 < innerHeight ? rect.bottom + 8 : Math.max(8, rect.top - 398);
    menu.style.left = `${left}px`;
    menu.style.top = `${top}px`;

    const head = document.createElement('div');
    head.className = 'vc-head';
    const img = document.createElement('img'); img.src = markUrl; img.alt = '';
    const title = document.createElement('div');
    const strong = document.createElement('strong'); strong.textContent = 'VaultCove';
    const small = document.createElement('small'); small.textContent = location.hostname || 'Secure login frame';
    title.append(strong, small); head.append(img, title); menu.append(head);
    appendGenerator(menu);

    if (!state.unlocked) {
      const empty = document.createElement('div'); empty.className = 'vc-empty'; empty.textContent = 'VaultCove is locked. Unlock it from the extension before filling credentials.';
      const open = document.createElement('button'); open.className = 'vc-open'; open.type = 'button'; open.textContent = 'Open VaultCove';
      open.addEventListener('click', () => chrome.runtime.sendMessage({ type: 'OPEN_DASHBOARD' }));
      menu.append(empty, open);
    } else if (!Number(state.matchCount || state.matches.length)) {
      const empty = document.createElement('div'); empty.className = 'vc-empty'; empty.textContent = 'No login is saved for this trusted HTTPS website.';
      menu.append(empty);
    } else {
      const note = document.createElement('div'); note.className = 'vc-note'; note.textContent = 'Trusted-site matching - usernames masked - passwords never enter this menu'; menu.append(note);

      const searchWrap = document.createElement('div'); searchWrap.className = 'vc-search-wrap';
      const search = document.createElement('input');
      search.type = 'search';
      search.className = 'vc-search';
      search.placeholder = `Search ${state.matchCount || state.matches.length} account${Number(state.matchCount || state.matches.length) === 1 ? '' : 's'}...`;
      search.autocomplete = 'off';
      search.spellcheck = false;
      search.setAttribute('aria-label', 'Search matching VaultCove accounts');
      const count = document.createElement('div'); count.className = 'vc-result-count';
      searchWrap.append(search, count);
      menu.append(searchWrap);

      const results = document.createElement('div');
      menu.append(results);
      const updateResults = (response) => {
        const shown = response.matches || [];
        const total = Number(response.filteredMatchCount ?? shown.length);
        count.textContent = total > shown.length ? `${shown.length} of ${total} matches shown` : `${total} match${total === 1 ? '' : 'es'}`;
        if (!shown.length) {
          results.innerHTML = '<div class="vc-empty">No matching account. Search by account name or username.</div>';
        } else {
          appendLoginRows(results, shown);
        }
      };
      updateResults(state);

      let searchTimer = null;
      search.addEventListener('input', () => {
        clearTimeout(searchTimer);
        const query = search.value;
        searchTimer = setTimeout(async () => {
          try {
            const response = await chrome.runtime.sendMessage({ type: 'GET_PAGE_LOGINS', query });
            if (!response?.ok || !menu.isConnected) return;
            state = { ...state, ...response };
            updateResults(response);
          } catch {}
        }, 120);
      });
      setTimeout(() => search.focus({ preventScroll: true }), 0);
    }
    shadow.append(menu);
  }

  function positionIcon(icon, input) {
    const rect = input.getBoundingClientRect();
    const size = 22;
    const left = Math.max(4, Math.min(innerWidth - size - 4, rect.right - size - 8));
    const top = Math.max(4, Math.min(innerHeight - size - 4, rect.top + Math.max(1, (rect.height - size) / 2)));
    icon.style.left = `${left}px`;
    icon.style.top = `${top}px`;
    icon.hidden = rect.bottom < 0 || rect.top > innerHeight || rect.right < 0 || rect.left > innerWidth;
  }

  function renderIcons(fields) {
    lastFields = fields || [];
    ensureRoot();
    clearUi();
    for (const input of fields) {
      const icon = document.createElement('button');
      icon.type = 'button'; icon.className = 'vc-icon'; icon.title = 'VaultCove login handler'; icon.setAttribute('aria-label', 'Open VaultCove login handler');
      const img = document.createElement('img'); img.src = markUrl; img.alt = '';
      const badge = document.createElement('span');
      const pending = state.matches?.some((item) => item.pendingPasswordChange);
      badge.className = `vc-badge${state.unlocked ? '' : ' locked'}${pending ? ' pending' : ''}`;
      const generatorReady = passwordFormContext(fields).fields.length > 0;
      badge.textContent = state.unlocked ? (Number(state.matchCount || state.matches.length) ? String(Math.min(99, Number(state.matchCount || state.matches.length))) : generatorReady ? 'G' : '0') : 'L';
      icon.append(img, badge); positionIcon(icon, input);
      icon.addEventListener('mousedown', (event) => event.preventDefault());
      icon.addEventListener('click', (event) => { event.stopPropagation(); showMenu(icon); });
      shadow.append(icon);
    }
  }

  async function refreshState(fields) {
    try {
      const response = await chrome.runtime.sendMessage({ type: 'GET_PAGE_LOGINS' });
      if (!response?.ok) return;
      state = response;
      if (!state.enabled || !state.supported) { clearUi(); return; }
      renderIcons(fields);

      if (state.unlocked && state.autoLoginItemId && fields.length) {
        const stage = pageStage(fields);
        const key = `${location.href}|${stage}|${state.autoLoginItemId}`;
        if (autoAttemptedFor !== key) {
          autoAttemptedFor = key;
          clearTimeout(autoTimer);
          autoTimer = setTimeout(() => fill(state.autoLoginItemId, true, true, stage), 250);
        }
      }
    } catch {
      clearUi();
    }
  }

  function scan() {
    clearTimeout(scanTimer);
    scanTimer = setTimeout(() => {
      const fields = loginFields();
      if (!fields.length) { clearUi(); return; }
      refreshState(fields);
    }, 120);
  }

  function usernameForScope(scope) {
    const inputs = allInputs(scope);
    const username = inputs.find((el) => isUsernameField(el) && String(el.value || '').trim());
    return String(username?.value || '').trim();
  }

  function highConfidencePasswordChange(scope) {
    const passwordFields = allInputs(scope).filter((el) => (el.type || '').toLowerCase() === 'password' && !el.disabled && !el.readOnly);
    if (!passwordFields.length) return null;

    const valued = passwordFields.map((el) => ({ el, value: String(el.value || ''), token: fieldToken(el) })).filter((entry) => entry.value.length >= 4);
    if (!valued.length) return null;

    const explicitNew = valued.filter((entry) => String(entry.el.autocomplete || '').toLowerCase() === 'new-password' || /(new|confirm|change|reset|create).{0,18}pass|pass.{0,18}(new|confirm|change|reset|create)/.test(entry.token));
    if (explicitNew.length) {
      const duplicate = explicitNew.find((entry, index) => explicitNew.some((other, otherIndex) => otherIndex !== index && other.value === entry.value));
      const chosen = duplicate || explicitNew[0];
      return { password: chosen.value, reason: duplicate ? 'matching-new-password-fields' : 'explicit-new-password-field' };
    }

    if (valued.length >= 3) {
      const last = valued[valued.length - 1];
      const previous = valued[valued.length - 2];
      const first = valued[0];
      if (last.value === previous.value && last.value !== first.value) {
        return { password: last.value, reason: 'current-plus-matching-new-password-fields' };
      }
    }
    return null;
  }

  function submittedLoginCandidate(scope) {
    const passwords = allInputs(scope)
      .filter((el) => (el.type || '').toLowerCase() === 'password' && !el.disabled && !el.readOnly)
      .map((el) => ({ el, value: String(el.value || '') }))
      .filter((entry) => entry.value.length >= 4);
    if (!passwords.length) return null;
    const current = passwords.find((entry) => String(entry.el.autocomplete || '').toLowerCase() === 'current-password');
    const chosen = current || passwords[0];
    return { password: chosen.value, reason: 'submitted-login-password' };
  }

  function reportPasswordChange(scope, { allowSubmittedLogin = false } = {}) {
    if (!state.passwordChangeDetectionEnabled) return;
    let candidate = highConfidencePasswordChange(scope);
    let confidence = 'high';
    if (!candidate && allowSubmittedLogin) {
      candidate = submittedLoginCandidate(scope);
      confidence = 'submitted-login';
    }
    if (!candidate) return;
    const username = usernameForScope(scope) || usernameForScope(document);
    const signature = `${location.hostname}|${username}|${candidate.password}|${confidence}`;
    const now = Date.now();
    if (signature === lastChangeReport && now - lastChangeReportAt < 5000) return;
    lastChangeReport = signature;
    lastChangeReportAt = now;
    chrome.runtime.sendMessage({
      type: 'PASSWORD_CHANGE_CANDIDATE',
      username,
      password: candidate.password,
      reason: candidate.reason,
      confidence
    }).catch(() => {});
  }

  function reportNewLogin(scope) {
    if (!state.newLoginCaptureEnabled || !state.unlocked) return;
    const username = usernameForScope(scope) || usernameForScope(document);
    if (!username) return;
    const candidate = highConfidencePasswordChange(scope) || submittedLoginCandidate(scope);
    if (!candidate) return;
    const signature = `${location.hostname}|${username}|${candidate.password}|new-login`;
    const now = Date.now();
    if (signature === lastLoginCaptureReport && now - lastLoginCaptureReportAt < 5000) return;
    lastLoginCaptureReport = signature;
    lastLoginCaptureReportAt = now;
    chrome.runtime.sendMessage({
      type: 'NEW_LOGIN_CANDIDATE',
      username,
      password: candidate.password,
      reason: candidate.reason,
      pageTitle: String(document.title || location.hostname).slice(0, 120)
    }).catch(() => {});
  }

  function firstElementFromEvent(event) {
    return event.composedPath?.().find((node) => node instanceof Element) || (event.target instanceof Element ? event.target : null);
  }

  function submitScopeFromEventTarget(target) {
    if (!(target instanceof Element)) return document;
    return target.closest('form') || target.getRootNode?.() || document;
  }

  // Record only matching saved-login sites, locally and inside the encrypted vault.
  // The background rejects unsupported/unapproved pages and records no general history.
  chrome.runtime.sendMessage({ type: 'MARK_VISITED_SAVED_SITE' }).catch(() => {});

  observer = new MutationObserver(scan);
  observeRoot(document);
  addEventListener('resize', scan, { passive: true });
  addEventListener('scroll', scan, { passive: true, capture: true });
  document.addEventListener('focusin', scan, true);
  document.addEventListener('submit', (event) => { const scope = submitScopeFromEventTarget(firstElementFromEvent(event)); reportPasswordChange(scope, { allowSubmittedLogin: true }); reportNewLogin(scope); }, true);
  document.addEventListener('click', (event) => {
    const origin = firstElementFromEvent(event);
    const target = origin?.closest?.('button,input[type="submit"],input[type="button"],a[role="button"]') || null;
    if (target) {
      const text = `${target.textContent || ''} ${target.value || ''} ${target.getAttribute('aria-label') || ''}`.toLowerCase();
      const scope = submitScopeFromEventTarget(target);
      if (/(save|update|change|reset|create).{0,18}(pass|password)|(?:pass|password).{0,18}(save|update|change|reset|create)/.test(text)) {
        reportPasswordChange(scope);
      }
      if (/(sign\s*up|register|create\s*(?:account)?|join|sign\s*in|log\s*in|continue|submit|next)/.test(text)) reportNewLogin(scope);
    }
    if (rootHost && event.target !== rootHost) closeMenus();
  }, true);
  scan();
})();
