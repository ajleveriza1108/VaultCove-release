# VaultCove Security Model — 0.5.2 R1

## At rest

The local vault is encrypted using a random 256-bit vault key. The master password derives a key using PBKDF2-HMAC-SHA-256 and wraps the vault key. AES-256-GCM provides confidentiality and integrity. Vault contents, including usernames, passwords, URLs, notes and sharing private keys, stay inside the encrypted payload.

## Sensitive Access

Normal unlock and secret disclosure are separate. Reveal, Copy, Edit, export/restore, master-password changes and protected filling can require fresh master-password verification. Sensitive Access expires quickly.

## Browser filling

Normal Fill/Secure Login uses `activeTab`. Persistent field icons are optional and requested per HTTPS site at runtime. VaultCove never requests blanket persistent access from the popup.

Host matching accepts exact hosts plus only the `www.` alias automatically. A small reviewed first-party family allowlist may link separate official login/application hosts when a service requires it; 0.5.2 adds the explicit Google account family so `accounts.google.com` credentials can appear on `mail.google.com`. This is not `*.google.com` trust: root `google.com`, arbitrary Google subdomains, suffix lookalikes and attacker domains are rejected. Other subdomains require an explicit trusted-host entry. Phishing suffixes such as `facebook.com.attacker.example` never match `facebook.com`.

Secure Login does not use the clipboard. It injects only the selected credential after destination validation, submits promptly, discards extension references, and clears the page password value after a short fallback interval when safe. Once a legitimate destination page receives a password, page JavaScript can potentially read it; no browser password manager can guarantee otherwise.

## VCShare v1

VCShare uses P-256 ECDH + HKDF-SHA-256 to derive a one-time AES-256-GCM key for the recipient. Packages are signed using ECDSA P-256. Recipient private keys remain in the encrypted local vault. A received credential is re-encrypted under the recipient's own vault key. Revocation cannot make a password unknown after the recipient has decrypted it; change the website password for true revocation.

## Developer updates

The Developer build contacts only the official public VaultCove release metadata endpoint. `latest.json` is digitally verified using an embedded release public key before its version/download metadata is trusted. The release-signing private key is generated outside the project and must never be committed.

The Chrome Web Store package removes the developer update host permission and update fetch implementation.

## Not protected against

VaultCove cannot guarantee secrecy if malware already controls the operating system, Chrome process memory, the user's keyboard, the master password, or the legitimate destination website after a password has intentionally been filled. Endpoint security, rapid auto-lock, phishing-safe matching and passkeys remain important.

## New-login capture boundary

A submitted new-login candidate is accepted only from an HTTPS page with an active on-demand or explicitly permitted persistent VaultCove handler, while the vault is unlocked. Existing matching website/account identifiers are rejected from this path. Candidate usernames/passwords are stored only inside the normal encrypted vault payload until the user saves or ignores them.
