# VaultCove 0.5.2 R1 — Reliable Master Auth + Google Multi-Account Matching

VaultCove is an offline-first Manifest V3 password and private-record vault. The canonical development root is:

`D:\Windows Projects\VaultCove`

## 0.5.2 R1 highlights

- **Reliable master-password retries:** unlock and Sensitive Access verification are serialized and duplicate submissions are blocked, so a wrong attempt cannot race with the next correct attempt.
- **Clear authentication errors:** a normal wrong master password is reported as incorrect, while vault-authentication damage is reserved for actual encrypted-payload authentication failure.
- **Gmail multi-account detection:** imported/saved Google credentials on explicitly trusted Google account hosts are surfaced together on `mail.google.com`, without broad `*.google.com` trust.

- **New-login capture:** submitted credentials that are not already saved for the trusted website/account are held as encrypted review candidates. VaultCove asks before permanently saving them.
- **Password changes stay separate:** an existing saved account continues through password-change review rather than becoming a duplicate login.
- **Store-preflight repair:** developer GitHub update endpoint strings and update host access are stripped and rechecked before the Store ZIP is accepted.

- Compact popup: Fill + **Secure Login**, with Reveal/Copy/Edit moved under a compact overflow menu.
- Persistent handler access is granted **one HTTPS website at a time**. Normal user-invoked filling continues to use `activeTab`.
- Trusted-site matching supports exact hosts and only the safe `www.`/non-`www.` alias automatically. Other subdomains require explicit trusted-host entries.
- Secure Login fills at the last practical moment, submits immediately, then clears the injected password field after a short fallback window if the page has not navigated and the value is unchanged.
- Per-login **Require master password before filling** protection for banking/high-risk credentials. Protected logins cannot auto-login.
- Imported LastPass records are marked as imported activity rather than falsely shown as recently changed.
- Scalable list + detail-drawer vault GUI and improved empty states.
- **VCShare v1** recipient-key encrypted login sharing for VaultCove / compatible VaultCore clients. `.vcshare` packages are encrypted to one recipient and digitally signed by the sender.
- Developer update notice checks only signed `latest.json` metadata from `ajleveriza1108/VaultCove-release` once per day when enabled.
- DEV and STORE build profiles are separated by the release publisher. The Store preflight package removes the GitHub updater host permission and network fetch path.

## Security boundaries

Passwords are encrypted at rest. A destination website must temporarily receive a password when the user chooses to fill it; HTML `type="password"` is only visual masking. Secure Login therefore minimizes the exposure window but does not claim to protect against malicious JavaScript already controlling the legitimate destination page.

VaultCove does not send saved websites, usernames, passwords, TOTP secrets, cards, bank data, notes, vault keys, master passwords, or security-health data to the developer update endpoint.

## Developer testing

Run:

`node tests\core-tests.mjs`

`node tests\static-security-checks.mjs`

Then reload the unpacked extension from `chrome://extensions` and test with dummy accounts before storing real financial credentials.
