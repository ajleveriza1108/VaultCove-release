import {
  clearSession,
  ensureDeviceId,
  getSessionExpiry,
  getSettings,
  hardenStorageAccess,
  hasSensitiveAccess,
  setSettings,
  touchSession
} from './core/storage.js';
import { initializeVault, loadUnlockedVault, saveUnlockedVault, unlockVault, verifySensitiveAccess } from './core/vault.js';
import { featureAllowed, getLicenseState } from './core/license.js';
import { publicLoginSummary } from './core/redaction.js';
import { createGenericSecurityNotice } from './core/security-events.js';
import { loginMatchesTrustedHost, permissionOriginForHost } from './core/site-match.js';
import { checkForUpdates } from './core/updates.js';
import { createPendingLoginCapture, findExistingLoginForCapture, prunePendingLoginCaptures, samePendingLoginCapture } from './core/login-capture.js';

const AUTO_LOCK_ALARM = 'vaultcove-auto-lock';

let masterAuthQueue = Promise.resolve();
function queueMasterAuth(operation) {
  const run = masterAuthQueue.then(operation, operation);
  masterAuthQueue = run.catch(() => undefined);
  return run;
}
const UPDATE_CHECK_ALARM = 'vaultcove-update-check';
const HANDLER_SCRIPT_ID = 'vaultcove-inline-handler';
const LEGACY_BROAD_HANDLER_ORIGIN = 'https://*/*';
const UPDATE_METADATA_ORIGIN = 'https://raw.githubusercontent.com/*';
const EMAIL_NOTICE_QUEUE_KEY = 'securityEmailNoticeQueue';
const PASSWORD_NOTICE_PREFIX = 'vaultcove-password-change:';
const NEW_LOGIN_NOTICE_PREFIX = 'vaultcove-new-login:';
const ON_DEMAND_HANDLER_TABS_KEY = 'onDemandHandlerTabs';
const ON_DEMAND_HANDLER_TTL_MS = 30 * 60 * 1000;



function trustedExtensionSender(sender) {
  const base = chrome.runtime.getURL('');
  return typeof sender?.url === 'string' && sender.url.startsWith(base);
}

async function getOnDemandHandlerTabs() {
  const result = await chrome.storage.session.get(ON_DEMAND_HANDLER_TABS_KEY);
  const raw = result[ON_DEMAND_HANDLER_TABS_KEY];
  return raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : {};
}

async function saveOnDemandHandlerTabs(value) {
  const entries = Object.fromEntries(Object.entries(value || {}).filter(([, record]) => Number(record?.expiresAt || 0) > Date.now()));
  await chrome.storage.session.set({ [ON_DEMAND_HANDLER_TABS_KEY]: entries });
}

async function markOnDemandHandlerTab(tabId, pageUrl) {
  if (!Number.isInteger(tabId) || !pageUrl) return;
  const tabs = await getOnDemandHandlerTabs();
  tabs[String(tabId)] = {
    origin: pageUrl.origin,
    expiresAt: Date.now() + ON_DEMAND_HANDLER_TTL_MS
  };
  await saveOnDemandHandlerTabs(tabs);
}

async function clearOnDemandHandlerTab(tabId) {
  if (!Number.isInteger(tabId)) return;
  const tabs = await getOnDemandHandlerTabs();
  if (!(String(tabId) in tabs)) return;
  delete tabs[String(tabId)];
  await saveOnDemandHandlerTabs(tabs);
}

async function isOnDemandHandlerTab(tabId, pageUrl) {
  if (!Number.isInteger(tabId) || !pageUrl) return false;
  const tabs = await getOnDemandHandlerTabs();
  const record = tabs[String(tabId)];
  if (!record || Number(record.expiresAt || 0) <= Date.now()) {
    if (record) await clearOnDemandHandlerTab(tabId);
    return false;
  }
  return record.origin === pageUrl.origin;
}

async function injectOnDemandHandler(tabId) {
  if (!Number.isInteger(tabId)) throw new Error('No active tab is available.');
  const tab = await chrome.tabs.get(tabId);
  const pageUrl = parseHttpsUrl(tab?.url || '');
  if (!pageUrl) return { enabled: false, reason: 'unsupported-page' };

  await markOnDemandHandlerTab(tabId, pageUrl);
  try {
    try {
      await chrome.scripting.executeScript({
        target: { tabId, allFrames: true },
        files: ['src/content/handler.js']
      });
    } catch {
      // activeTab may not cover cross-origin child frames. The top frame is still
      // useful and keeps the on-demand path permission-minimal. Persistent mode
      // can cover additional HTTPS frames after the user grants optional access.
      await chrome.scripting.executeScript({
        target: { tabId, frameIds: [0] },
        files: ['src/content/handler.js']
      });
    }
    return { enabled: true, mode: 'activeTab', origin: pageUrl.origin };
  } catch (error) {
    await clearOnDemandHandlerTab(tabId);
    throw new Error(`VaultCove could not attach the on-demand login handler to this page: ${error?.message || error}`);
  }
}

function parseHttpsUrl(value) {
  try {
    const url = new URL(value);
    return url.protocol === 'https:' ? url : null;
  } catch {
    return null;
  }
}

function loginMatchesSite(item, hostname) {
  return loginMatchesTrustedHost(item, hostname);
}

function frameUrlFromSender(sender) {
  return parseHttpsUrl(sender?.url || sender?.tab?.url || '');
}

async function grantedHandlerOrigins() {
  const all = await chrome.permissions.getAll();
  return (all.origins || []).filter((origin) => origin.startsWith('https://') && origin !== UPDATE_METADATA_ORIGIN && origin !== LEGACY_BROAD_HANDLER_ORIGIN);
}

async function hasHandlerPermissionForUrl(pageUrl) {
  if (!pageUrl) return false;
  try {
    return chrome.permissions.contains({ origins: [permissionOriginForHost(pageUrl.hostname)] });
  } catch {
    return false;
  }
}

async function injectHandlerIntoOpenTabs(origins) {
  if (!origins?.length) return;
  try {
    const tabs = await chrome.tabs.query({ url: origins });
    await Promise.allSettled(tabs.filter((tab) => tab.id).map((tab) => chrome.scripting.executeScript({
      target: { tabId: tab.id, allFrames: true },
      files: ['src/content/handler.js']
    })));
  } catch {
    // Registration is authoritative; a browser may require a reload for already-open tabs.
  }
}

async function syncBrowserIntegration({ injectExisting = false } = {}) {
  const origins = await grantedHandlerOrigins();
  const registered = await chrome.scripting.getRegisteredContentScripts();
  if (registered.some((script) => script.id === HANDLER_SCRIPT_ID)) {
    await chrome.scripting.unregisterContentScripts({ ids: [HANDLER_SCRIPT_ID] });
  }
  if (origins.length) {
    await chrome.scripting.registerContentScripts([{
      id: HANDLER_SCRIPT_ID,
      matches: origins,
      js: ['src/content/handler.js'],
      runAt: 'document_idle',
      allFrames: true,
      matchOriginAsFallback: true,
      persistAcrossSessions: true
    }]);
    if (injectExisting) await injectHandlerIntoOpenTabs(origins);
  }
  return { enabled: origins.length > 0, origins };
}

async function migrateLegacyBroadHandlerPermission() {
  const hadBroad = await chrome.permissions.contains({ origins: [LEGACY_BROAD_HANDLER_ORIGIN] });
  if (!hadBroad) return false;
  await chrome.permissions.remove({ origins: [LEGACY_BROAD_HANDLER_ORIGIN] });
  await setSettings({ inlineHandlerEnabled: false, autoLoginEnabled: false });
  return true;
}

async function initialize() {
  await hardenStorageAccess();
  await ensureDeviceId();
  await migrateLegacyBroadHandlerPermission();
  chrome.alarms.create(AUTO_LOCK_ALARM, { periodInMinutes: 1 });
  chrome.alarms.create(UPDATE_CHECK_ALARM, { periodInMinutes: 24 * 60 });
  await syncBrowserIntegration();
}

chrome.runtime.onInstalled.addListener(() => initialize().catch(console.error));
chrome.runtime.onStartup.addListener(() => initialize().catch(console.error));
chrome.permissions.onAdded.addListener(() => syncBrowserIntegration({ injectExisting: true }).catch(console.error));
chrome.permissions.onRemoved.addListener(() => syncBrowserIntegration().catch(console.error));
chrome.tabs.onRemoved.addListener((tabId) => clearOnDemandHandlerTab(tabId).catch(() => {}));
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  (async () => {
    const tabs = await getOnDemandHandlerTabs();
    const record = tabs[String(tabId)];
    if (!record) return;
    if (changeInfo.url) {
      const pageUrl = parseHttpsUrl(changeInfo.url);
      if (!pageUrl || pageUrl.origin !== record.origin) { await clearOnDemandHandlerTab(tabId); return; }
    }
    if (changeInfo.status === 'complete') {
      const pageUrl = parseHttpsUrl(tab?.url || '');
      if (pageUrl?.origin === record.origin) {
        try {
          await chrome.scripting.executeScript({ target: { tabId, frameIds: [0] }, files: ['src/content/handler.js'] });
        } catch {}
      }
    }
  })().catch(() => {});
});

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === AUTO_LOCK_ALARM) {
    const expiresAt = await getSessionExpiry();
    if (expiresAt && Date.now() >= expiresAt) await clearSession();
    return;
  }
  if (alarm.name === UPDATE_CHECK_ALARM) {
    const settings = await getSettings();
    if (settings.updateChecksEnabled) checkForUpdates().catch(() => {});
  }
});

async function buildPageLoginState(pageUrl, { handlerRequest = false, tabId = null } = {}) {
  if (!pageUrl) return { ok: true, supported: false, unlocked: false, matches: [], handlerEnabled: false };

  const [settings, licenseState, state, permission] = await Promise.all([
    getSettings(),
    getLicenseState(),
    loadUnlockedVault({ touch: false }),
    hasHandlerPermissionForUrl(pageUrl)
  ]);
  const persistentHandlerEnabled = Boolean(permission);
  const onDemandHandlerEnabled = handlerRequest ? await isOnDemandHandlerTab(tabId, pageUrl) : false;
  const handlerEnabled = persistentHandlerEnabled || onDemandHandlerEnabled;

  if (!featureAllowed(licenseState, 'autofill')) {
    return {
      ok: true,
      supported: true,
      unlocked: state.state === 'unlocked',
      enabled: handlerRequest ? handlerEnabled : true,
      handlerEnabled: persistentHandlerEnabled,
      handlerMode: onDemandHandlerEnabled ? 'activeTab' : persistentHandlerEnabled ? 'persistent' : 'off',
      matches: []
    };
  }
  if (state.state !== 'unlocked') {
    return {
      ok: true,
      supported: true,
      unlocked: false,
      enabled: handlerRequest ? handlerEnabled : true,
      handlerEnabled: persistentHandlerEnabled,
      handlerMode: onDemandHandlerEnabled ? 'activeTab' : persistentHandlerEnabled ? 'persistent' : 'off',
      matches: []
    };
  }

  const freshCaptures = prunePendingLoginCaptures(state.vault.pendingLoginCaptures);
  if (freshCaptures.length !== (state.vault.pendingLoginCaptures || []).length) {
    state.vault.pendingLoginCaptures = freshCaptures;
    await saveUnlockedVault(state.vault, { touch: false });
  }

  const matches = state.vault.items
    .filter((item) => loginMatchesSite(item, pageUrl.hostname))
    .sort((a, b) => Number(Boolean(b.favorite)) - Number(Boolean(a.favorite)) || String(a.name).localeCompare(String(b.name)))
    .map(publicLoginSummary);

  const autoCandidates = persistentHandlerEnabled && settings.autoLoginEnabled ? matches.filter((item) => item.autoLogin) : [];
  return {
    ok: true,
    supported: true,
    unlocked: true,
    enabled: handlerRequest ? handlerEnabled : true,
    handlerEnabled: persistentHandlerEnabled,
    handlerMode: onDemandHandlerEnabled ? 'activeTab' : persistentHandlerEnabled ? 'persistent' : 'off',
    hostname: pageUrl.hostname,
    matches,
    autoLoginItemId: autoCandidates.length === 1 ? autoCandidates[0].id : null,
    autoLoginEnabled: Boolean(persistentHandlerEnabled && settings.autoLoginEnabled),
    passwordChangeDetectionEnabled: Boolean(settings.passwordChangeDetectionEnabled),
    newLoginCaptureEnabled: Boolean(settings.newLoginCaptureEnabled)
  };
}
async function pageLoginState(sender) {
  return buildPageLoginState(frameUrlFromSender(sender), { handlerRequest: true, tabId: sender?.tab?.id ?? null });
}

async function activeTabLoginState(message) {
  if (!Number.isInteger(message.tabId)) throw new Error('No active web tab is available.');
  const tab = await chrome.tabs.get(message.tabId);
  return buildPageLoginState(parseHttpsUrl(tab?.url || ''), { handlerRequest: false, tabId: message.tabId });
}


async function fillCredentialIntoFrame(tabId, frameId, item, { submit = false, clearAfterMs = 1200 } = {}) {
  const target = Number.isInteger(frameId) ? { tabId, frameIds: [frameId] } : { tabId };
  const results = await chrome.scripting.executeScript({
    target,
    world: 'ISOLATED',
    func: (username, password, shouldSubmit, clearDelayMs) => {
      function visible(el) {
        const rect = el.getBoundingClientRect();
        const style = getComputedStyle(el);
        return rect.width > 0 && rect.height > 0 && style.visibility !== 'hidden' && style.display !== 'none' && !el.disabled && !el.readOnly;
      }
      function setNativeValue(input, value) {
        const prototype = input instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
        const descriptor = Object.getOwnPropertyDescriptor(prototype, 'value');
        descriptor?.set?.call(input, value);
        input.dispatchEvent(new Event('input', { bubbles: true, composed: true }));
        input.dispatchEvent(new Event('change', { bubbles: true, composed: true }));
      }
      function token(el) {
        return `${el.type || ''} ${el.name || ''} ${el.id || ''} ${el.autocomplete || ''} ${el.placeholder || ''} ${el.getAttribute('aria-label') || ''}`.toLowerCase();
      }
      function openRoots() {
        const roots = [document];
        for (let index = 0; index < roots.length && index < 64; index += 1) {
          for (const node of roots[index].querySelectorAll('*')) {
            if (node.shadowRoot && !roots.includes(node.shadowRoot)) roots.push(node.shadowRoot);
          }
        }
        return roots;
      }
      function queryAll(selector) {
        return openRoots().flatMap((root) => [...root.querySelectorAll(selector)]);
      }
      function findUsername(inputs, passwordInput) {
        return inputs.find((el) => el !== passwordInput && ['text', 'email', 'tel', ''].includes((el.type || '').toLowerCase()) && /(user|email|login|account|identifier)/.test(token(el)))
          || inputs.find((el) => el !== passwordInput && ['text', 'email', 'tel', ''].includes((el.type || '').toLowerCase()));
      }
      function submitFrom(field) {
        const form = field?.form || field?.closest?.('form');
        if (form?.requestSubmit) {
          form.requestSubmit();
          return true;
        }
        const candidates = queryAll('button,input[type="submit"],input[type="button"],a[role="button"]').filter(visible);
        const button = candidates.find((el) => {
          const text = `${el.textContent || ''} ${el.value || ''} ${el.getAttribute('aria-label') || ''}`.toLowerCase();
          return /(log\s*in|sign\s*in|continue|next|submit)/.test(text);
        });
        if (button) { button.click(); return true; }
        return false;
      }

      const inputs = queryAll('input').filter(visible);
      const passwordInput = inputs.find((el) => (el.type || '').toLowerCase() === 'password');
      const usernameInput = findUsername(inputs, passwordInput);
      if (!passwordInput && !usernameInput) return { ok: false, reason: 'No supported visible login field was found.' };

      if (usernameInput && username) setNativeValue(usernameInput, username);
      if (passwordInput) setNativeValue(passwordInput, password || '');
      const focusTarget = passwordInput || usernameInput;
      focusTarget?.focus();
      let submitted = false;
      if (shouldSubmit) submitted = submitFrom(focusTarget);
      if (shouldSubmit && passwordInput && password) {
        const injectedPassword = password;
        setTimeout(() => {
          try {
            if (passwordInput.isConnected && passwordInput.value === injectedPassword) setNativeValue(passwordInput, '');
          } catch {}
        }, Math.max(250, Math.min(5000, Number(clearDelayMs) || 1200)));
      }
      return {
        ok: true,
        usernameFilled: Boolean(usernameInput && username),
        passwordFilled: Boolean(passwordInput),
        submitted
      };
    },
    args: [item.username || '', item.password || '', Boolean(submit), clearAfterMs]
  });
  return results?.[0]?.result || { ok: false, reason: 'Page fill did not return a result.' };
}

async function handlePageFill(message, sender) {
  const pageUrl = frameUrlFromSender(sender);
  if (!pageUrl || !sender?.tab?.id) throw new Error('VaultCove only fills HTTPS web pages.');

  const [licenseState, settings, state] = await Promise.all([
    getLicenseState(),
    getSettings(),
    loadUnlockedVault({ touch: false })
  ]);
  if (!featureAllowed(licenseState, 'autofill')) throw new Error('Autofill is unavailable for this license state.');
  if (state.state !== 'unlocked') throw new Error('VaultCove is locked.');

  const item = state.vault.items.find((candidate) => candidate.id === message.itemId && !candidate.deletedAt);
  if (!item || !loginMatchesSite(item, pageUrl.hostname)) {
    throw new Error('Blocked: the saved login is not trusted for this HTTPS frame hostname.');
  }

  const automatic = Boolean(message.automatic);
  const submit = Boolean(message.submit);
  if (item.requireReauthBeforeFill && !(await hasSensitiveAccess())) {
    throw new Error('Sensitive Access required before filling this protected credential. Open VaultCove and verify your master password.');
  }
  if (automatic) {
    if (!settings.autoLoginEnabled || !item.autoLogin) throw new Error('Automatic login is not enabled for this item.');
    if (!(await hasHandlerPermissionForUrl(pageUrl))) throw new Error('Persistent access is not enabled for this website.');
    const stage = message.stage === 'password' ? 'password' : 'username';
    const guardKey = `autoLoginGuard:${sender.tab.id}:${sender.frameId ?? 0}:${pageUrl.hostname}:${pageUrl.pathname}:${stage}`;
    const guard = await chrome.storage.session.get(guardKey);
    if (Date.now() - Number(guard[guardKey] || 0) < 20000) throw new Error('Automatic login was already attempted on this page recently.');
    await chrome.storage.session.set({ [guardKey]: Date.now() });
  }

  const result = await fillCredentialIntoFrame(sender.tab.id, sender.frameId, item, { submit, clearAfterMs: settings.secureLoginClearMs });
  if (!automatic) await touchSession();
  return result;
}


async function fillActiveTabLogin(message) {
  if (!Number.isInteger(message.tabId)) throw new Error('No active tab is available.');
  const tab = await chrome.tabs.get(message.tabId);
  const pageUrl = parseHttpsUrl(tab?.url || '');
  if (!pageUrl) throw new Error('VaultCove fills credentials only on HTTPS pages.');
  const [licenseState, settings, state] = await Promise.all([getLicenseState(), getSettings(), loadUnlockedVault({ touch: false })]);
  if (!featureAllowed(licenseState, 'autofill')) throw new Error('Autofill is unavailable for this license state.');
  if (state.state !== 'unlocked') throw new Error('VaultCove is locked.');
  const item = state.vault.items.find((candidate) => candidate.id === message.itemId && !candidate.deletedAt);
  if (!item || !loginMatchesSite(item, pageUrl.hostname)) throw new Error('Blocked: the saved login is not trusted for this HTTPS hostname.');
  if (item.requireReauthBeforeFill && !(await hasSensitiveAccess())) throw new Error('Sensitive Access required before filling this protected credential.');
  const result = await fillCredentialIntoFrame(message.tabId, 0, item, { submit: Boolean(message.submit), clearAfterMs: settings.secureLoginClearMs });
  await touchSession();
  return result;
}

async function getSensitiveLoginField(message) {
  if (!(await hasSensitiveAccess())) throw new Error('Sensitive Access expired. Re-enter your master password.');
  if (!Number.isInteger(message.tabId)) throw new Error('No active tab is available.');
  const tab = await chrome.tabs.get(message.tabId);
  const pageUrl = parseHttpsUrl(tab?.url || '');
  if (!pageUrl) throw new Error('Sensitive login values are available only for HTTPS pages.');

  const state = await loadUnlockedVault({ touch: false });
  if (state.state !== 'unlocked') throw new Error('VaultCove is locked.');
  const item = state.vault.items.find((candidate) => candidate.id === message.itemId && !candidate.deletedAt);
  if (!item || !loginMatchesSite(item, pageUrl.hostname)) throw new Error('Blocked: this login is not trusted for the active HTTPS hostname.');
  if (!['username', 'password'].includes(message.field)) throw new Error('Unsupported sensitive field.');
  await touchSession();
  return { value: String(item[message.field] || '') };
}

async function setSiteHandler(message) {
  if (!Number.isInteger(message.tabId)) throw new Error('No active tab is available.');
  const tab = await chrome.tabs.get(message.tabId);
  const pageUrl = parseHttpsUrl(tab?.url || '');
  if (!pageUrl) throw new Error('Persistent VaultCove access is available only for HTTPS websites.');
  const origin = permissionOriginForHost(pageUrl.hostname);
  if (!message.enabled) {
    await chrome.permissions.remove({ origins: [origin] });
    await syncBrowserIntegration();
    return { enabled: false, origin };
  }
  const granted = await chrome.permissions.contains({ origins: [origin] });
  if (!granted) throw new Error('Website permission must be granted by the user from the VaultCove popup.');
  await syncBrowserIntegration({ injectExisting: true });
  return { enabled: true, origin };
}

async function siteHandlerState(message) {
  if (!Number.isInteger(message.tabId)) return { enabled: false, supported: false };
  const tab = await chrome.tabs.get(message.tabId);
  const pageUrl = parseHttpsUrl(tab?.url || '');
  if (!pageUrl) return { enabled: false, supported: false };
  return { enabled: await hasHandlerPermissionForUrl(pageUrl), supported: true, origin: permissionOriginForHost(pageUrl.hostname), hostname: pageUrl.hostname };
}

async function removeAllSiteHandlers() {
  const origins = await grantedHandlerOrigins();
  if (origins.length) await chrome.permissions.remove({ origins });
  await setSettings({ autoLoginEnabled: false });
  await syncBrowserIntegration();
  return { removed: origins.length };
}

function normalizeUsername(value) {
  return String(value || '').trim().toLowerCase();
}

async function showPasswordChangeNotification(itemId) {
  await chrome.notifications.create(`${PASSWORD_NOTICE_PREFIX}${itemId}`, {
    type: 'basic',
    iconUrl: 'icons/icon128.png',
    title: 'VaultCove password change detected',
    message: 'A saved login appears to have a new password. Review it in VaultCove. No password or account details are sent by email.',
    buttons: [{ title: 'Review in VaultCove' }],
    priority: 2
  });
}

async function handlePasswordChangeCandidate(message, sender) {
  const pageUrl = frameUrlFromSender(sender);
  if (!pageUrl || !sender?.tab?.id) return { detected: false };
  const settings = await getSettings();
  const persistentHandlerEnabled = Boolean(await hasHandlerPermissionForUrl(pageUrl));
  const onDemandHandlerEnabled = await isOnDemandHandlerTab(sender.tab.id, pageUrl);
  if (!settings.passwordChangeDetectionEnabled || (!persistentHandlerEnabled && !onDemandHandlerEnabled)) return { detected: false };

  const password = String(message.password || '');
  const confidence = String(message.confidence || '');
  if (password.length < 4 || password.length > 4096 || !['high', 'submitted-login'].includes(confidence)) return { detected: false };

  const state = await loadUnlockedVault({ touch: false });
  if (state.state !== 'unlocked') return { detected: false };
  let matches = state.vault.items.filter((item) => loginMatchesSite(item, pageUrl.hostname));
  const username = normalizeUsername(message.username);
  let usernameMatches = [];
  if (username) {
    usernameMatches = matches.filter((item) => normalizeUsername(item.username) === username);
    if (usernameMatches.length) matches = usernameMatches;
  }
  if (confidence === 'submitted-login' && (!username || usernameMatches.length !== 1)) return { detected: false };
  if (matches.length !== 1) return { detected: false };

  const item = matches[0];
  if (item.password === password || item.pendingPasswordChange?.password === password) return { detected: false };
  item.pendingPasswordChange = {
    password,
    detectedAt: new Date().toISOString(),
    hostname: pageUrl.hostname,
    source: String(message.reason || 'password-form').slice(0, 80),
    confidence
  };
  await saveUnlockedVault(state.vault, { touch: false });
  await showPasswordChangeNotification(item.id);
  return { detected: true, itemId: item.id };
}

async function showNewLoginNotification(captureId) {
  await chrome.notifications.create(`${NEW_LOGIN_NOTICE_PREFIX}${captureId}`, {
    type: 'basic',
    iconUrl: 'icons/icon128.png',
    title: 'VaultCove new login detected',
    message: 'A submitted login is not yet saved in VaultCove. Review it before adding it to your encrypted vault.',
    buttons: [{ title: 'Review in VaultCove' }],
    priority: 1
  });
}

async function handleNewLoginCandidate(message, sender) {
  const pageUrl = frameUrlFromSender(sender);
  if (!pageUrl || !sender?.tab?.id) return { detected: false };
  const settings = await getSettings();
  const persistentHandlerEnabled = Boolean(await hasHandlerPermissionForUrl(pageUrl));
  const onDemandHandlerEnabled = await isOnDemandHandlerTab(sender.tab.id, pageUrl);
  if (!settings.newLoginCaptureEnabled || (!persistentHandlerEnabled && !onDemandHandlerEnabled)) return { detected: false };

  const username = String(message.username || '').trim();
  const password = String(message.password || '');
  if (!username || username.length > 512 || password.length < 4 || password.length > 4096) return { detected: false };

  const state = await loadUnlockedVault({ touch: false });
  if (state.state !== 'unlocked') return { detected: false };
  if (findExistingLoginForCapture(state.vault.items, pageUrl.hostname, username)) {
    return { detected: false, reason: 'existing-login' };
  }

  const capture = createPendingLoginCapture({
    hostname: pageUrl.hostname,
    origin: pageUrl.origin,
    username,
    password,
    name: String(message.pageTitle || pageUrl.hostname),
    source: String(message.reason || 'submitted-credential')
  });
  const pending = prunePendingLoginCaptures(state.vault.pendingLoginCaptures);
  const duplicate = pending.find((entry) => samePendingLoginCapture(entry, capture));
  if (duplicate) return { detected: false, reason: 'already-pending', captureId: duplicate.id };

  state.vault.pendingLoginCaptures = [...pending, capture].slice(-50);
  await saveUnlockedVault(state.vault, { touch: false });
  await showNewLoginNotification(capture.id);
  return { detected: true, captureId: capture.id };
}

async function queueGenericEmailNotice(kind = 'password-changed') {
  const settings = await getSettings();
  if (!settings.securityEmailNoticeEnabled) return { queued: false, reason: 'disabled' };
  const deviceId = await ensureDeviceId();
  const notice = createGenericSecurityNotice(kind);
  const existing = await chrome.storage.local.get(EMAIL_NOTICE_QUEUE_KEY);
  const queue = Array.isArray(existing[EMAIL_NOTICE_QUEUE_KEY]) ? existing[EMAIL_NOTICE_QUEUE_KEY] : [];
  queue.push({ ...notice, deviceId });
  await chrome.storage.local.set({ [EMAIL_NOTICE_QUEUE_KEY]: queue.slice(-100) });
  return { queued: true, transport: 'pending-license-service' };
}

async function openPasswordReview(itemId = '') {
  const params = new URLSearchParams({ view: 'security' });
  if (itemId) params.set('passwordChange', itemId);
  await chrome.tabs.create({ url: chrome.runtime.getURL(`src/vault/vault.html?${params}`) });
}

async function openNewLoginReview(captureId = '') {
  const params = new URLSearchParams({ view: 'security' });
  if (captureId) params.set('newLogin', captureId);
  await chrome.tabs.create({ url: chrome.runtime.getURL(`src/vault/vault.html?${params}`) });
}

chrome.notifications.onClicked.addListener((notificationId) => {
  if (notificationId.startsWith(PASSWORD_NOTICE_PREFIX)) {
    openPasswordReview(notificationId.slice(PASSWORD_NOTICE_PREFIX.length)).catch(console.error);
  } else if (notificationId.startsWith(NEW_LOGIN_NOTICE_PREFIX)) {
    openNewLoginReview(notificationId.slice(NEW_LOGIN_NOTICE_PREFIX.length)).catch(console.error);
  }
});
chrome.notifications.onButtonClicked.addListener((notificationId) => {
  if (notificationId.startsWith(PASSWORD_NOTICE_PREFIX)) {
    openPasswordReview(notificationId.slice(PASSWORD_NOTICE_PREFIX.length)).catch(console.error);
  } else if (notificationId.startsWith(NEW_LOGIN_NOTICE_PREFIX)) {
    openNewLoginReview(notificationId.slice(NEW_LOGIN_NOTICE_PREFIX.length)).catch(console.error);
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === 'LOCK_VAULT') {
    clearSession().then(() => sendResponse({ ok: true })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'GET_VAULT_STATE') {
    loadUnlockedVault({ touch: false }).then((state) => sendResponse({ ok: true, state: state.state })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'INITIALIZE_VAULT') {
    initializeVault(String(message.masterPassword || '')).then(() => sendResponse({ ok: true })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'UNLOCK_VAULT') {
    queueMasterAuth(() => unlockVault(String(message.masterPassword || ''))).then(() => sendResponse({ ok: true })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'FILL_ACTIVE_TAB_LOGIN') {
    fillActiveTabLogin(message).then((result) => sendResponse({ ok: true, ...result })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'ENABLE_ONDEMAND_HANDLER') {
    if (!trustedExtensionSender(sender)) { sendResponse({ ok: false, error: 'Untrusted handler request.' }); return false; }
    injectOnDemandHandler(message.tabId).then((result) => sendResponse({ ok: true, ...result })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'SYNC_BROWSER_INTEGRATION') {
    syncBrowserIntegration({ injectExisting: Boolean(message.injectExisting) }).then((result) => sendResponse({ ok: true, ...result })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'GET_PAGE_LOGINS') {
    pageLoginState(sender).then(sendResponse).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'GET_ACTIVE_TAB_LOGINS') {
    activeTabLoginState(message).then(sendResponse).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'FILL_PAGE_LOGIN') {
    handlePageFill(message, sender).then((result) => sendResponse({ ok: true, ...result })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'VERIFY_SENSITIVE_ACCESS') {
    queueMasterAuth(() => verifySensitiveAccess(String(message.masterPassword || ''))).then((until) => sendResponse({ ok: true, until })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'SENSITIVE_ACCESS_STATUS') {
    hasSensitiveAccess().then((active) => sendResponse({ ok: true, active })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'GET_SENSITIVE_LOGIN_FIELD') {
    getSensitiveLoginField(message).then((result) => sendResponse({ ok: true, ...result })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'NEW_LOGIN_CANDIDATE') {
    handleNewLoginCandidate(message, sender).then((result) => sendResponse({ ok: true, ...result })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'PASSWORD_CHANGE_CANDIDATE') {
    handlePasswordChangeCandidate(message, sender).then((result) => sendResponse({ ok: true, ...result })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'PASSWORD_CHANGE_CONFIRMED') {
    queueGenericEmailNotice('password-changed').then(async (notice) => {
      await chrome.notifications.create('', {
        type: 'basic',
        iconUrl: 'icons/icon128.png',
        title: 'VaultCove saved the password update',
        message: notice.queued
          ? 'A generic security-email notice is queued. It contains no website, username, account name, old password, or new password.'
          : 'The encrypted login was updated locally. No website, username, account name, old password, or new password was sent anywhere.'
      });
      sendResponse({ ok: true, ...notice });
    }).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'SET_SITE_HANDLER') {
    setSiteHandler(message).then((result) => sendResponse({ ok: true, ...result })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'GET_SITE_HANDLER_STATE') {
    siteHandlerState(message).then((result) => sendResponse({ ok: true, ...result })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'LIST_SITE_HANDLERS') {
    grantedHandlerOrigins().then((origins) => sendResponse({ ok: true, origins })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'REMOVE_ALL_SITE_HANDLERS') {
    removeAllSiteHandlers().then((result) => sendResponse({ ok: true, ...result })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'CHECK_FOR_UPDATES') {
    checkForUpdates({ force: Boolean(message.force) }).then((result) => sendResponse({ ok: true, ...result })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'OPEN_DASHBOARD') {
    chrome.tabs.create({ url: chrome.runtime.getURL('src/vault/vault.html') }).then(() => sendResponse({ ok: true })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  return false;
});

initialize().catch(console.error);
