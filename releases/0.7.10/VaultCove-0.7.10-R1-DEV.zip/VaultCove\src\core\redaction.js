export function maskIdentifier(value) {
  const raw = String(value || '').trim();
  if (!raw) return '(no username)';
  const at = raw.indexOf('@');
  if (at > 0) {
    const local = raw.slice(0, at);
    const domain = raw.slice(at + 1);
    const shown = local.length <= 2 ? local[0] || '•' : local.slice(0, 2);
    return `${shown}${'•'.repeat(Math.max(3, Math.min(8, local.length - shown.length || 3)))}@${domain}`;
  }
  if (raw.length <= 4) return `${raw[0] || '•'}•••`;
  return `${raw.slice(0, 2)}${'•'.repeat(Math.min(8, raw.length - 4))}${raw.slice(-2)}`;
}

export function maskSecret(value, { keepLast = 0, minBullets = 8 } = {}) {
  const raw = String(value || '');
  if (!raw) return '';
  const tail = keepLast > 0 ? raw.slice(-keepLast) : '';
  const bullets = '•'.repeat(Math.max(minBullets, Math.min(16, raw.length - tail.length || minBullets)));
  return `${bullets}${tail}`;
}

export function publicLoginSummary(item) {
  return {
    id: item.id,
    name: item.name,
    usernameMasked: maskIdentifier(item.username),
    hasUsername: Boolean(item.username),
    favorite: Boolean(item.favorite),
    autoLogin: Boolean(item.autoLogin),
    requireReauthBeforeFill: Boolean(item.requireReauthBeforeFill),
    pendingPasswordChange: Boolean(item.pendingPasswordChange)
  };
}
