import { EXPORT_AAD, EXPORT_MAGIC, EXPORT_VERSION } from './constants.js';
import { importAesKey, encryptJson, decryptJson } from './crypto.js';
import { base64UrlToBytes, bytesToBase64Url, randomBytes } from './encoding.js';

export async function createPortableExport(vaultData) {
  const secretBytes = randomBytes(32);
  const exportKey = await importAesKey(secretBytes);
  const encrypted = await encryptJson(exportKey, vaultData, EXPORT_AAD);
  const digest = new Uint8Array(await crypto.subtle.digest('SHA-256', secretBytes));
  const keyId = bytesToBase64Url(digest.subarray(0, 8));
  const payload = {
    magic: EXPORT_MAGIC,
    version: EXPORT_VERSION,
    createdAt: new Date().toISOString(),
    encryption: {
      algorithm: 'AES-256-GCM',
      aad: EXPORT_AAD,
      keyId,
      iv: encrypted.iv,
      ciphertext: encrypted.ciphertext
    }
  };
  return {
    payload,
    secret: `VC1-${bytesToBase64Url(secretBytes)}`
  };
}

export async function decryptPortableExport(payload, secret) {
  if (!payload || payload.magic !== EXPORT_MAGIC || payload.version !== EXPORT_VERSION) {
    throw new Error('This is not a supported VaultCove export.');
  }
  if (typeof secret !== 'string' || !secret.startsWith('VC1-')) {
    throw new Error('Enter the VaultCove export secret beginning with VC1-.');
  }
  const secretBytes = base64UrlToBytes(secret.slice(4).trim());
  if (secretBytes.length !== 32) throw new Error('Invalid export secret.');
  const digest = new Uint8Array(await crypto.subtle.digest('SHA-256', secretBytes));
  const expectedKeyId = bytesToBase64Url(digest.subarray(0, 8));
  if (payload.encryption?.keyId !== expectedKeyId) throw new Error('The export secret does not match this file.');
  const exportKey = await importAesKey(secretBytes);
  try {
    return await decryptJson(exportKey, payload.encryption, EXPORT_AAD);
  } catch {
    throw new Error('Export authentication failed. The secret is wrong or the file was modified.');
  }
}

export function downloadExport(payload, filename = null) {
  const text = JSON.stringify(payload);
  const blob = new Blob([text], { type: 'application/octet-stream' });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename || `VaultCove-${new Date().toISOString().replace(/[:.]/g, '-')}.vcvault`;
  document.body.append(anchor);
  anchor.click();
  anchor.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
