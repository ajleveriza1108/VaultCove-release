const TOOLTIP_TEXT = new Map([
  ['newItem', 'Create a new encrypted vault item.'],
  ['lockButton', 'Lock VaultCove now and clear the unlocked vault-key session.'],
  ['setupSubmit', 'Create the local encrypted VaultCove vault.'],
  ['unlockSubmit', 'Unlock the local encrypted vault with your master password and optional authenticator code.'],
  ['copyExportSecret', 'Copy the one-time export secret. Store it separately from the backup file.'],
  ['closeSecret', 'Close this window after safely storing the export secret.'],
  ['confirmSensitive', 'Freshly verify Sensitive Access before revealing or changing protected data.'],
  ['cancelSensitive', 'Cancel the protected action without revealing a secret.'],
  ['changeMaster', 'Verify the current master password and second factor, then re-wrap the vault key with the new master password.'],
  ['enableAlwaysOn', 'Request optional HTTPS access once so the VaultCove handler can appear automatically on login forms.'],
  ['dashEnableAlwaysOn', 'Enable the optional Always-On Handler so VaultCove login-field icons appear automatically on supported HTTPS sites.'],
  ['disableAlwaysOn', 'Remove broad always-on HTTPS handler access. Per-site permissions remain available.'],
  ['enableSiteIcons', 'Allow VaultCove to display Chrome-cached favicons only for saved sites you have actually visited with VaultCove active.'],
  ['setupVaultTotp', 'Enable a Google Authenticator-compatible local confirmation code for VaultCove. No Google account connection is created.'],
  ['disableVaultTotp', 'Disable VaultCove two-step TOTP protection after verification.'],
  ['createShare', 'Create one recipient-encrypted .vcshare bundle from the selected login cards.'],
  ['importShare', 'Verify, decrypt locally, and import a .vcshare package intended for this VaultCove identity.'],
  ['exportShareIdentity', 'Export only your public sharing identity. It contains no private key.'],
  ['importContact', 'Trust another VaultCove or VaultCore public sharing identity after comparing its fingerprint.'],
  ['exportVault', 'Create a portable encrypted .vcvault backup with a separate random export secret.'],
  ['importVault', 'Restore an encrypted .vcvault backup locally.'],
  ['regenPassword', 'Generate a new cryptographically random password locally.'],
  ['copyGenerated', 'Copy the generated password to the clipboard.'],
  ['checkUpdatesNow', 'Check signed VaultCove developer release metadata now. No vault data is included.']
]);

let tooltip = null;
let hideTimer = null;

function textFor(element) {
  if (element.dataset.tooltip) return element.dataset.tooltip;
  if (element.id && TOOLTIP_TEXT.has(element.id)) return TOOLTIP_TEXT.get(element.id);

  const view = String(element.dataset.view || '').trim();
  const VIEW_TIPS = {
    dashboard: 'Open the VaultCove overview, security health, recent activity, browser integration, and backup status.',
    all: 'Browse every encrypted vault item. Switch between visual Grid and compact List views.',
    favorites: 'Show only vault items you marked as Favorites.',
    login: 'Browse saved website usernames and passwords stored in the encrypted vault.',
    card: 'Browse locally encrypted payment-card records.',
    bank: 'Browse locally encrypted bank-account records.',
    identity: 'Browse locally encrypted identity and address records.',
    note: 'Browse locally encrypted private notes.',
    totp: 'Generate saved website authenticator codes locally after Sensitive Access verification.',
    generator: 'Generate cryptographically random passwords or passphrases locally.',
    security: 'Review weak/reused passwords, detected password changes, and newly submitted login candidates.',
    migration: 'Import supported password-manager CSV exports locally, then encrypt them immediately.',
    shared: 'Create or open recipient-encrypted VaultCove/VaultCore .vcshare bundles.',
    backup: 'Create or restore a portable encrypted .vcvault backup.',
    trash: 'Restore sealed Trash items before their 30-day automatic deletion deadline, or permanently delete them after verification.',
    settings: 'Configure security timing, the browser handler, local website icons, authenticator confirmation, and updates.'
  };
  if (view && VIEW_TIPS[view]) return VIEW_TIPS[view];

  const label = String(element.getAttribute('aria-label') || '').trim();
  if (label) return label;

  if (element.matches('input[type="checkbox"]')) {
    const parent = element.closest('label');
    const parentText = String(parent?.textContent || '').trim().replace(/\s+/g, ' ');
    if (parentText) return `Toggle: ${parentText}`;
  }
  if (element.tagName === 'SELECT') {
    const parent = element.closest('label');
    const parentText = String(parent?.childNodes?.[0]?.textContent || parent?.textContent || '').trim().replace(/\s+/g, ' ');
    if (parentText) return `Choose ${parentText.replace(/:$/, '')}.`;
  }

  const text = String(element.textContent || '').trim().replace(/\s+/g, ' ');
  if (!text) return '';
  const normalized = text.toLowerCase();
  if (normalized.includes('secure login')) return 'Fill the matching credential, submit the login when safe, then clear the injected password field.';
  if (normalized === 'fill') return 'Fill the matching credential without submitting the form.';
  if (normalized.includes('reveal')) return 'Temporarily reveal this protected value after Sensitive Access verification.';
  if (normalized.includes('copy password')) return 'Copy the password after Sensitive Access verification.';
  if (normalized.includes('copy user')) return 'Copy the saved username after Sensitive Access verification.';
  if (normalized.includes('generate')) return 'Generate a strong password locally using the browser cryptographic random-number generator.';
  if (normalized.includes('favorite')) return 'Add or remove this item from Favorites.';
  if (normalized.includes('delete')) return 'Remove this item. Permanent deletion requires Sensitive Access.';
  if (normalized.includes('save')) return 'Save this change inside the encrypted VaultCove vault.';
  if (normalized.includes('import')) return 'Import the selected file locally into VaultCove.';
  if (normalized.includes('export')) return 'Export an encrypted or public-only VaultCove file, depending on this action.';
  if (normalized.includes('grid')) return 'Show vault items as visual website cards with local visited-site icons when available.';
  if (normalized.includes('list')) return 'Show vault items in a compact sortable-style list.';
  return text.length <= 42 ? `VaultCove action: ${text}` : '';
}

function ensureTooltip() {
  if (tooltip?.isConnected) return tooltip;
  tooltip = document.createElement('div');
  tooltip.className = 'vcTooltip';
  tooltip.setAttribute('role', 'tooltip');
  tooltip.hidden = true;
  document.body.append(tooltip);
  return tooltip;
}

function show(element) {
  const text = textFor(element);
  if (!text) return;
  clearTimeout(hideTimer);
  const node = ensureTooltip();
  node.textContent = text;
  node.hidden = false;
  const rect = element.getBoundingClientRect();
  const nodeRect = node.getBoundingClientRect();
  const left = Math.max(8, Math.min(innerWidth - nodeRect.width - 8, rect.left + rect.width / 2 - nodeRect.width / 2));
  const above = rect.top - nodeRect.height - 10;
  const top = above >= 8 ? above : Math.min(innerHeight - nodeRect.height - 8, rect.bottom + 10);
  node.style.left = `${left}px`;
  node.style.top = `${top}px`;
}

function hide() {
  clearTimeout(hideTimer);
  hideTimer = setTimeout(() => { if (tooltip) tooltip.hidden = true; }, 80);
}

export function installTooltips(root = document) {
  const elements = [...root.querySelectorAll('button,[role="button"],input[type="checkbox"],select')];
  for (const element of elements) {
    const text = textFor(element);
    if (!text) continue;
    element.dataset.tooltip = text;
    if (!element.getAttribute('aria-label') && element.tagName === 'BUTTON') element.setAttribute('aria-label', String(element.textContent || '').trim());
    if (element.dataset.vcTooltipWired) continue;
    element.dataset.vcTooltipWired = '1';
    element.addEventListener('mouseenter', () => show(element));
    element.addEventListener('mouseleave', hide);
    element.addEventListener('focus', () => show(element));
    element.addEventListener('blur', hide);
  }
}
