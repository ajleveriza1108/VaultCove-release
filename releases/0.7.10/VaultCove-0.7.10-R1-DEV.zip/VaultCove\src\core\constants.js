export const APP_NAME = 'VaultCove';
export const SCHEMA_VERSION = 1;
export const PBKDF2_ITERATIONS = 600000;
export const MASTER_AAD = 'VaultCove:vault-key:v1';
export const VAULT_AAD = 'VaultCove:vault-data:v1';
export const EXPORT_MAGIC = 'VAULTCOVE-EXPORT';
export const EXPORT_VERSION = 1;
export const EXPORT_AAD = 'VaultCove:portable-export:v1';

export const VAULT_STORAGE_KEY = 'vaultEnvelope';
export const SETTINGS_STORAGE_KEY = 'vaultSettings';
export const LICENSE_STORAGE_KEY = 'licenseState';
export const DEVICE_STORAGE_KEY = 'deviceId';

export const SESSION_KEY = 'unlockedVaultKey';
export const SESSION_EXPIRES_KEY = 'unlockExpiresAt';
export const SESSION_LAST_ACTIVITY_KEY = 'lastActivityAt';
export const SENSITIVE_ACCESS_UNTIL_KEY = 'sensitiveAccessUntil';

export const DEFAULT_LOCK_MINUTES = 5;
export const DEFAULT_SENSITIVE_ACCESS_SECONDS = 30;
export const TESTING_FULL_ACCESS = true;
