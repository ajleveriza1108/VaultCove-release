(() => {
  let firstError = '';
  const remember = (value) => {
    if (firstError) return;
    firstError = String(value || 'VaultCove dashboard module did not finish loading.');
  };
  addEventListener('error', (event) => remember(event?.error?.message || event?.message), true);
  addEventListener('unhandledrejection', (event) => remember(event?.reason?.message || event?.reason), true);
  setTimeout(() => {
    if (document.documentElement.dataset.vcBootReady === '1') return;
    const badge = document.getElementById('licenseBadge');
    if (badge) badge.textContent = 'Startup error';
    const gate = document.getElementById('gate');
    const app = document.getElementById('app');
    if (app) app.classList.add('hidden');
    if (gate) {
      gate.classList.remove('hidden');
      const detail = firstError || (document.documentElement.dataset.vcModuleLoaded === '1'
        ? 'VaultCove loaded its dashboard module but startup did not complete.'
        : 'VaultCove could not parse or load its dashboard module.');
      const card = document.createElement('div');
      card.className = 'gateCard';
      const logo = document.createElement('img');
      logo.src = '../../assets/brand/vaultcove-mark.svg';
      logo.alt = 'VaultCove';
      logo.className = 'gateLogo';
      const title = document.createElement('h1');
      title.textContent = 'VaultCove could not start';
      const help = document.createElement('p');
      help.textContent = 'The dashboard stopped before decrypted data was displayed. Reload VaultCove after applying the current repair.';
      const error = document.createElement('p');
      error.className = 'inlineError';
      error.textContent = detail;
      const retry = document.createElement('button');
      retry.type = 'button';
      retry.textContent = 'Retry startup';
      retry.addEventListener('click', () => location.reload());
      card.append(logo, title, help, error, retry);
      gate.replaceChildren(card);
    }
    console.error('VaultCove startup watchdog:', firstError || 'Dashboard bootstrap timeout.');
  }, 1800);
})();
