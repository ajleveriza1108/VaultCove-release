import { base64UrlToBytes, bytesToBase64Url, bytesToUtf8, randomBytes, utf8ToBytes } from './encoding.js';

export const RECOVERY_MAGIC = 'VAULTCOVE-OFFLINE-RECOVERY';
export const RECOVERY_VERSION = 1;
export const RECOVERY_ITERATIONS = 700000;
const RECOVERY_AAD = 'VaultCove:offline-recovery:v1';

function validateRecoveryPassword(password) {
  const value = String(password || '');
  if (value.length < 16) throw new Error('The Recovery Password must be at least 16 characters long.');
  if (value.length > 1024) throw new Error('The Recovery Password is too long.');
  return value;
}

async function derive(password, salt, iterations = RECOVERY_ITERATIONS) {
  const material = await crypto.subtle.importKey('raw', utf8ToBytes(validateRecoveryPassword(password)), 'PBKDF2', false, ['deriveKey']);
  return crypto.subtle.deriveKey({ name:'PBKDF2', hash:'SHA-256', salt, iterations }, material, { name:'AES-GCM', length:256 }, false, ['encrypt','decrypt']);
}

export async function createRecoveryKit(vault, deviceRecoveryToken, password, options = {}) {
  if (!vault?.sharingIdentity?.encryption?.privateJwk || !vault?.sharingIdentity?.signing?.privateJwk) throw new Error('Create your VaultCove sharing identity before exporting a Recovery Kit.');
  const salt = randomBytes(16), iv = randomBytes(12), key = await derive(password, salt);
  const payload = {
    product:'VaultCove', kind:'offline-recovery', version:RECOVERY_VERSION,
    sharingIdentity:vault.sharingIdentity,
    deviceRecoveryToken:String(deviceRecoveryToken || ''),
    vaultTotp: options.includeAuthenticator ? (vault.security?.vaultTotp || null) : null,
    createdAt:new Date().toISOString()
  };
  const ciphertext = new Uint8Array(await crypto.subtle.encrypt({ name:'AES-GCM', iv, additionalData:utf8ToBytes(RECOVERY_AAD), tagLength:128 }, key, utf8ToBytes(JSON.stringify(payload))));
  return { magic:RECOVERY_MAGIC, version:RECOVERY_VERSION, createdAt:payload.createdAt, kdf:{ name:'PBKDF2-HMAC-SHA-256', iterations:RECOVERY_ITERATIONS, salt:bytesToBase64Url(salt) }, cipher:{ name:'AES-256-GCM', iv:bytesToBase64Url(iv), aad:RECOVERY_AAD, ciphertext:bytesToBase64Url(ciphertext) } };
}

export async function openRecoveryKit(value, password) {
  if (!value || value.magic !== RECOVERY_MAGIC || Number(value.version) !== RECOVERY_VERSION) throw new Error('This is not a supported VaultCove Recovery Kit.');
  const iterations = Number(value.kdf?.iterations || 0); if (iterations < 300000 || iterations > 2000000) throw new Error('Invalid Recovery Kit KDF work factor.');
  const salt=base64UrlToBytes(String(value.kdf?.salt||'')), iv=base64UrlToBytes(String(value.cipher?.iv||''));
  if (salt.length!==16 || iv.length!==12 || !value.cipher?.ciphertext) throw new Error('Recovery Kit is incomplete.');
  const key=await derive(password,salt,iterations); let plain;
  try { plain=new Uint8Array(await crypto.subtle.decrypt({ name:'AES-GCM', iv, additionalData:utf8ToBytes(RECOVERY_AAD), tagLength:128 }, key, base64UrlToBytes(value.cipher.ciphertext))); }
  catch { throw new Error('Incorrect Recovery Password or damaged Recovery Kit.'); }
  const payload=JSON.parse(bytesToUtf8(plain));
  if (payload?.product!=='VaultCove' || payload?.kind!=='offline-recovery' || !payload?.sharingIdentity?.encryption?.privateJwk || !payload?.sharingIdentity?.signing?.privateJwk) throw new Error('Recovery Kit payload is invalid.');
  return payload;
}
