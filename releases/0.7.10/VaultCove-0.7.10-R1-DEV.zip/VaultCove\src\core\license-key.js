// Configure this with the SPKI DER Base64 RSA public key whose private counterpart
// is stored only in Google Apps Script Script Properties. Never commit the private key.
export const LICENSE_LEASE_PUBLIC_KEY_SPKI_BASE64 = 'UNCONFIGURED';
