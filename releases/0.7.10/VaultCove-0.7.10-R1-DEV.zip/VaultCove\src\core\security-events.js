import { randomId } from './encoding.js';

export function createGenericSecurityNotice(kind, occurredAt = new Date().toISOString()) {
  if (!['password-change-detected', 'password-changed'].includes(kind)) throw new Error('Unsupported security notice type.');
  return {
    id: randomId('notice'),
    kind,
    occurredAt,
    privacyClass: 'metadata-only',
    payload: {
      event: kind === 'password-change-detected' ? 'password_change_detected' : 'password_changed'
    }
  };
}

export function securityEmailBody() {
  return [
    'VaultCove security notice',
    '',
    'VaultCove detected a password change event on one of your devices.',
    '',
    'VaultCove did not send the updated password or account details in this email. For privacy, this notice contains no website, username, account name, old password, or new password.',
    '',
    'Open VaultCove on your device to review the local encrypted record.'
  ].join('\n');
}
