import { getLicenseState, featureAllowed } from '../core/license.js';
import { getSettings } from '../core/storage.js';
import { applyTheme } from '../core/themes.js';

const $ = (id) => document.getElementById(id);
const elements = Object.fromEntries([...document.querySelectorAll('[id]')].map((el) => [el.id, el]));
let activeTab = null;
let licenseState = null;
let pageState = null;
let pendingSensitiveAction = null;
let unlockBusy = false;
let sensitiveVerifyBusy = false;
let settingsState = null;

function show(id) {
  for (const target of ['setupView', 'lockedView', 'unlockedView']) elements[target].classList.toggle('hidden', target !== id);
}

function message(text, error = false) {
  elements.message.textContent = text;
  elements.message.style.color = error ? '#ff879d' : '#f4c969';
}

async function runtimeMessage(payload) {
  const response = await chrome.runtime.sendMessage(payload);
  if (!response?.ok) throw new Error(response?.error || 'VaultCove request failed.');
  return response;
}

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab || null;
}

function hostFromUrl(value) {
  try {
    const url = new URL(value);
    return url.protocol === 'https:' ? url.hostname.toLowerCase() : '';
  } catch { return ''; }
}

async function getPageState() {
  if (!activeTab?.id) return { enabled: false, matches: [], supported: false };
  return runtimeMessage({ type: 'GET_ACTIVE_TAB_LOGINS', tabId: activeTab.id });
}

async function handlerEnabled() {
  return Boolean(pageState?.handlerEnabled);
}

function currentSiteOrigin() {
  const host = hostFromUrl(activeTab?.url || '');
  return host ? `https://${host}/*` : '';
}


async function attachOnDemandHandler() {
  if (pageState?.handlerEnabled || pageState?.siteDisabled) return false;
  if (!activeTab?.id || !hostFromUrl(activeTab.url)) return false;
  try {
    const result = await runtimeMessage({ type: 'ENABLE_ONDEMAND_HANDLER', tabId: activeTab.id });
    return Boolean(result.enabled);
  } catch {
    return false;
  }
}

async function ensureSensitiveAccess(reason, action) {
  const status = await runtimeMessage({ type: 'SENSITIVE_ACCESS_STATUS' });
  if (status.active) return action();
  pendingSensitiveAction = action;
  elements.sensitiveReason.textContent = reason;
  elements.sensitivePassword.value = '';
  elements.sensitiveTotp.value = '';
  elements.sensitiveTotp.classList.toggle('hidden', !settingsState?.vaultTotpEnabled);
  if (elements.sensitiveInlineError) { elements.sensitiveInlineError.textContent = ''; elements.sensitiveInlineError.classList.add('hidden'); }
  elements.sensitivePrompt.classList.remove('hidden');
  elements.sensitivePassword.focus();
}

function closeSensitivePrompt() {
  elements.sensitivePrompt.classList.add('hidden');
  elements.sensitivePassword.value = '';
  elements.sensitiveTotp.value = '';
  if (elements.sensitiveInlineError) { elements.sensitiveInlineError.textContent = ''; elements.sensitiveInlineError.classList.add('hidden'); }
  pendingSensitiveAction = null;
}

async function getSensitiveField(itemId, field) {
  const result = await runtimeMessage({ type: 'GET_SENSITIVE_LOGIN_FIELD', tabId: activeTab.id, itemId, field });
  return result.value || '';
}

async function copySensitiveField(itemId, field) {
  await ensureSensitiveAccess(`Re-enter your master password to copy the saved ${field}.`, async () => {
    const value = await getSensitiveField(itemId, field);
    await navigator.clipboard.writeText(value);
    message(`${field === 'username' ? 'Username' : 'Password'} copied. Clipboard contents can be read by other local apps; clear it when finished.`);
  });
}

async function revealCredential(item, mount) {
  await ensureSensitiveAccess('Re-enter your master password to reveal this username and password for 10 seconds.', async () => {
    const [username, password] = await Promise.all([
      getSensitiveField(item.id, 'username'),
      getSensitiveField(item.id, 'password')
    ]);
    mount.textContent = '';
    const userLine = document.createElement('div');
    const passLine = document.createElement('div');
    const ub = document.createElement('b'); ub.textContent = 'Username: ';
    const pb = document.createElement('b'); pb.textContent = 'Password: ';
    userLine.append(ub, document.createTextNode(username || '(empty)'));
    passLine.append(pb, document.createTextNode(password || '(empty)'));
    mount.append(userLine, passLine);
    mount.classList.remove('hidden');
    setTimeout(() => { mount.textContent = ''; mount.classList.add('hidden'); }, 10000);
  });
}

async function runFill(item, submit) {
  const perform = async () => {
    if (!featureAllowed(licenseState, 'autofill')) throw new Error('License required.');
    if (!activeTab?.id || !hostFromUrl(activeTab.url)) throw new Error('VaultCove fills credentials only on HTTPS pages.');
    const result = await runtimeMessage({ type: 'FILL_ACTIVE_TAB_LOGIN', tabId: activeTab.id, itemId: item.id, submit });
    message(submit ? (result.submitted ? 'Secure Login submitted. The password field will be cleared shortly if the page has not navigated.' : 'Filled; no safe submit control was detected.') : 'Filled on this page.');
  };
  try {
    if (item.requireReauthBeforeFill) {
      await ensureSensitiveAccess('This credential requires your master password before filling.', perform);
    } else {
      await perform();
    }
  } catch (error) { message(error.message, true); }
}

function renderMatches(query = '') {
  const host = hostFromUrl(activeTab?.url || '');
  const q = query.trim().toLowerCase();
  const matches = (pageState?.matches || []).filter((item) => !q || `${item.name} ${item.usernameMasked}`.toLowerCase().includes(q));

  elements.siteInfo.replaceChildren();
  const siteWrap = document.createElement('div'); siteWrap.className = 'siteStatus';
  const siteStrong = document.createElement('strong'); siteStrong.textContent = host || 'No HTTPS site';
  const siteState = document.createElement('span'); siteState.textContent = host ? `${matches.length} matching account${matches.length === 1 ? '' : 's'} - trusted site check` : 'Open an HTTPS page';
  siteWrap.append(siteStrong, siteState); elements.siteInfo.append(siteWrap);

  elements.matches.replaceChildren();
  if (!matches.length) {
    const empty = document.createElement('div');
    empty.className = 'empty';
    empty.textContent = host ? 'No trusted login matches this website. VaultCove will not offer credentials from unrelated sites.' : 'No login available.';
    elements.matches.append(empty);
    return;
  }

  for (const item of matches.slice(0, 30)) {
    const card = document.createElement('div'); card.className = 'item';
    const top = document.createElement('div'); top.className = 'top';
    const info = document.createElement('div');
    const name = document.createElement('div'); name.className = 'name'; name.textContent = item.name;
    const meta = document.createElement('div'); meta.className = 'meta'; meta.textContent = item.usernameMasked || '(no username)';
    info.append(name, meta); top.append(info);
    const badges = document.createElement('div');
    if (item.pendingPasswordChange) { const badge = document.createElement('span'); badge.className = 'pendingBadge'; badge.textContent = 'CHANGE'; badges.append(badge); }
    if (item.requireReauthBeforeFill) { const badge = document.createElement('span'); badge.className = 'protectedBadge'; badge.textContent = 'MASTER CHECK'; badges.append(badge); }
    if (badges.childElementCount) top.append(badges);

    const actions = document.createElement('div'); actions.className = 'actions';
    const fill = document.createElement('button'); fill.type = 'button'; fill.className = 'primaryAction'; fill.textContent = 'Fill'; fill.addEventListener('click', () => runFill(item, false));
    const login = document.createElement('button'); login.type = 'button'; login.className = 'primaryAction'; login.textContent = 'Secure Login'; login.addEventListener('click', () => runFill(item, true));
    const more = document.createElement('button'); more.type = 'button'; more.className = 'moreButton'; more.textContent = '⋮'; more.title = 'More credential actions';
    actions.append(fill, login, more);

    const accountMenu = document.createElement('div'); accountMenu.className = 'accountMenu hidden';
    const reveal = document.createElement('button'); reveal.type = 'button'; reveal.textContent = 'Reveal';
    const revealMount = document.createElement('div'); revealMount.className = 'credentialReveal hidden';
    reveal.addEventListener('click', () => revealCredential(item, revealMount).catch((error) => message(error.message, true)));
    const copyUser = document.createElement('button'); copyUser.type = 'button'; copyUser.textContent = 'Copy user'; copyUser.addEventListener('click', () => copySensitiveField(item.id, 'username').catch((error) => message(error.message, true)));
    const copyPass = document.createElement('button'); copyPass.type = 'button'; copyPass.textContent = 'Copy password'; copyPass.addEventListener('click', () => copySensitiveField(item.id, 'password').catch((error) => message(error.message, true)));
    const edit = document.createElement('button'); edit.type = 'button'; edit.textContent = 'Edit in dashboard'; edit.addEventListener('click', () => chrome.tabs.create({ url: chrome.runtime.getURL(`src/vault/vault.html?view=login&item=${encodeURIComponent(item.id)}`) }));
    accountMenu.append(reveal, copyUser, copyPass, edit);
    more.addEventListener('click', () => accountMenu.classList.toggle('hidden'));
    card.append(top, actions, accountMenu, revealMount);
    elements.matches.append(card);
  }
}

async function refresh() {
  [licenseState, settingsState] = await Promise.all([getLicenseState(), getSettings()]);
  applyTheme(settingsState?.theme || 'midnight');
  elements.statusBadge.textContent = licenseState.mode === 'testing' ? 'Testing - Full access' : licenseState.status;
  activeTab = await getActiveTab();
  const vaultState = await runtimeMessage({ type: 'GET_VAULT_STATE' });
  if (vaultState.state === 'setup') return show('setupView');
  if (vaultState.state === 'locked') { elements.unlockTotpLabel.classList.toggle('hidden', !settingsState?.vaultTotpEnabled); return show('lockedView'); }

  show('unlockedView');
  if (licenseState.status === 'expired') {
    elements.search.classList.add('hidden');
    elements.matches.replaceChildren();
    const notice = document.createElement('div'); notice.className = 'empty'; notice.textContent = 'Production license access is unavailable. Open VaultCove to manage licensing or create an encrypted export of your data.';
    elements.matches.append(notice); elements.siteInfo.textContent = 'Export access only'; elements.addCurrentSite.classList.add('hidden'); elements.handlerBanner.classList.add('hidden');
    return;
  }

  elements.search.classList.remove('hidden');
  elements.addCurrentSite.classList.remove('hidden');
  pageState = await getPageState();
  await attachOnDemandHandler();
  pageState = await getPageState();
  const currentHost = hostFromUrl(activeTab?.url || '');
  if (pageState?.siteDisabled && currentHost) {
    elements.handlerBanner.classList.remove('hidden');
    elements.handlerBannerTitle.textContent = 'Always-On Handler is off for this website';
    elements.handlerBannerText.textContent = `VaultCove is disabled on ${currentHost}. Turn it back on to show the handler automatically here.`;
    elements.enableHandler.textContent = 'Turn on for this website';
    elements.enableHandler.dataset.mode = 'site-exception';
  } else if (await handlerEnabled()) {
    elements.handlerBanner.classList.add('hidden');
    elements.enableHandler.dataset.mode = '';
  } else {
    elements.handlerBanner.classList.remove('hidden');
    elements.handlerBannerTitle.textContent = 'Always-On Handler needs website access';
    elements.handlerBannerText.textContent = 'Enable HTTPS website access so VaultCove can appear automatically on supported login forms.';
    elements.enableHandler.textContent = 'Enable always-on';
    elements.enableHandler.dataset.mode = 'permission';
  }
  renderMatches();
}

elements.createVault.addEventListener('click', async () => {
  try {
    const password = elements.setupPassword.value;
    if (password.length < 14) throw new Error('Use a master password of at least 14 characters.');
    if (password !== elements.setupConfirm.value) throw new Error('Master passwords do not match.');
    await runtimeMessage({ type: 'INITIALIZE_VAULT', masterPassword: password });
    elements.setupPassword.value = ''; elements.setupConfirm.value = '';
    await refresh();
  } catch (error) { message(error.message, true); }
});

elements.unlockVault.addEventListener('click', async () => {
  if (unlockBusy) return;
  const password = elements.unlockPassword.value;
  unlockBusy = true;
  elements.unlockVault.disabled = true;
  elements.unlockVault.classList.add('busy');
  elements.unlockPassword.disabled = true;
  if (elements.unlockInlineError) { elements.unlockInlineError.textContent = ''; elements.unlockInlineError.classList.add('hidden'); }
  try {
    await runtimeMessage({ type: 'UNLOCK_VAULT', masterPassword: password, secondFactor: String(elements.unlockTotp.value || '') });
    elements.unlockPassword.value = ''; elements.unlockTotp.value = '';
    await refresh();
  } catch (error) {
    elements.unlockPassword.value = ''; elements.unlockTotp.value = '';
    if (elements.unlockInlineError) { elements.unlockInlineError.textContent = error.message; elements.unlockInlineError.classList.remove('hidden'); }
    message(error.message, true);
  } finally {
    unlockBusy = false;
    elements.unlockVault.disabled = false;
    elements.unlockVault.classList.remove('busy');
    elements.unlockPassword.disabled = false;
    if (!pageState?.unlocked) setTimeout(() => elements.unlockPassword.focus(), 0);
  }
});

elements.unlockPassword.addEventListener('input', () => { if (elements.unlockInlineError) { elements.unlockInlineError.textContent = ''; elements.unlockInlineError.classList.add('hidden'); } });
elements.unlockPassword.addEventListener('keydown', (event) => { if (event.key === 'Enter') { event.preventDefault(); elements.unlockVault.click(); } });
elements.unlockTotp.addEventListener('keydown', (event) => { if (event.key === 'Enter') { event.preventDefault(); elements.unlockVault.click(); } });
elements.search.addEventListener('input', () => renderMatches(elements.search.value));
elements.lockNow.addEventListener('click', async () => { await runtimeMessage({ type: 'LOCK_VAULT' }); await refresh(); });
elements.openVault.addEventListener('click', () => chrome.tabs.create({ url: chrome.runtime.getURL('src/vault/vault.html') }));
elements.addCurrentSite.addEventListener('click', () => {
  const params = new URLSearchParams({ action: 'new-login' });
  if (activeTab?.url?.startsWith('http')) params.set('url', activeTab.url);
  chrome.tabs.create({ url: chrome.runtime.getURL(`src/vault/vault.html?${params}`) });
});

elements.enableHandler.addEventListener('click', async () => {
  try {
    const host = hostFromUrl(activeTab?.url || '');
    if (elements.enableHandler.dataset.mode === 'site-exception' && host) {
      await runtimeMessage({ type: 'SET_HANDLER_SITE_EXCEPTION', hostname: host, disabled: false });
      message(`Always-On Handler is on again for ${host}.`);
      await refresh();
      return;
    }
    const granted = await chrome.permissions.request({ origins: ['https://*/*'] });
    if (!granted) throw new Error('Always-On Handler permission was not granted. On-demand Fill still works when you click VaultCove.');
    await runtimeMessage({ type: 'SYNC_ALWAYS_ON_HANDLER', injectExisting: true });
    message('Always-On Handler enabled. VaultCove can now appear automatically on supported HTTPS login forms.');
    await refresh();
  } catch (error) { message(error.message, true); }
});

elements.confirmSensitive.addEventListener('click', async () => {
  if (sensitiveVerifyBusy) return;
  const action = pendingSensitiveAction;
  const password = elements.sensitivePassword.value;
  if (!action) return closeSensitivePrompt();
  sensitiveVerifyBusy = true;
  elements.confirmSensitive.disabled = true;
  elements.confirmSensitive.classList.add('busy');
  elements.sensitivePassword.disabled = true;
  if (elements.sensitiveInlineError) { elements.sensitiveInlineError.textContent = ''; elements.sensitiveInlineError.classList.add('hidden'); }
  try {
    await runtimeMessage({ type: 'VERIFY_SENSITIVE_ACCESS', masterPassword: password, secondFactor: String(elements.sensitiveTotp.value || '') });
    elements.sensitivePrompt.classList.add('hidden');
    elements.sensitivePassword.value = '';
    pendingSensitiveAction = null;
    if (action) await action();
  } catch (error) {
    elements.sensitivePassword.value = '';
    if (elements.sensitiveInlineError) { elements.sensitiveInlineError.textContent = error.message; elements.sensitiveInlineError.classList.remove('hidden'); }
    message(error.message, true);
  } finally {
    sensitiveVerifyBusy = false;
    elements.confirmSensitive.disabled = false;
    elements.confirmSensitive.classList.remove('busy');
    elements.sensitivePassword.disabled = false;
    if (!elements.sensitivePrompt.classList.contains('hidden')) setTimeout(() => elements.sensitivePassword.focus(), 0);
  }
});
elements.sensitivePassword.addEventListener('keydown', (event) => { if (event.key === 'Enter') elements.confirmSensitive.click(); });
elements.cancelSensitive.addEventListener('click', closeSensitivePrompt);

refresh().catch((error) => message(error.message, true));
