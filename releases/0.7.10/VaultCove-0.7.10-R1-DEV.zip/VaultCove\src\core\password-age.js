const DAY_MS = 24 * 60 * 60 * 1000;

export const PASSWORD_AGE_THRESHOLDS = Object.freeze({
  aging: 60,
  review: 90,
  highPriority: 180
});

export function parseTrustedPasswordChangeDate(value) {
  const text = String(value || '').trim();
  if (!text) return null;
  const timestamp = Date.parse(text);
  if (!Number.isFinite(timestamp)) return null;
  const now = Date.now();
  if (timestamp > now + DAY_MS) return null;
  if (timestamp < Date.UTC(1990, 0, 1)) return null;
  return new Date(timestamp).toISOString();
}

export function passwordAgeState(item, now = Date.now()) {
  if (!item || item.type !== 'login') return { state: 'not-applicable', days: null, label: '', shortLabel: '', needsReview: false };
  const changedAt = Date.parse(item.lastPasswordChangeAt || '');
  if (!Number.isFinite(changedAt) || changedAt > now) {
    return { state: 'unknown', days: null, label: 'Password age unknown', shortLabel: 'Age unknown', needsReview: false };
  }
  const days = Math.max(0, Math.floor((now - changedAt) / DAY_MS));
  if (days >= PASSWORD_AGE_THRESHOLDS.highPriority) {
    return { state: 'high', days, label: `Password unchanged for ${days} days`, shortLabel: `${days} days`, needsReview: true };
  }
  if (days >= PASSWORD_AGE_THRESHOLDS.review) {
    return { state: 'review', days, label: `Password unchanged for ${days} days`, shortLabel: `${days} days`, needsReview: true };
  }
  if (days >= PASSWORD_AGE_THRESHOLDS.aging) {
    return { state: 'aging', days, label: `Password changed ${days} days ago`, shortLabel: `${days} days`, needsReview: false };
  }
  return { state: 'current', days, label: `Password changed ${days} days ago`, shortLabel: `${days} days`, needsReview: false };
}

export function passwordAgeSummary(items, now = Date.now()) {
  const result = { total: 0, current: 0, aging: 0, review: 0, high: 0, unknown: 0 };
  for (const item of items || []) {
    if (!item || item.deletedAt || item.type !== 'login') continue;
    result.total += 1;
    const age = passwordAgeState(item, now);
    if (Object.prototype.hasOwnProperty.call(result, age.state)) result[age.state] += 1;
  }
  result.over90 = result.review + result.high;
  return result;
}
