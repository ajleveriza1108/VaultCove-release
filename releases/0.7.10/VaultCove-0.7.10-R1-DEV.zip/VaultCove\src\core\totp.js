function normalizeBase32(value) {
  return String(value || '').toUpperCase().replace(/[^A-Z2-7]/g, '');
}

function decodeBase32(value) {
  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
  const input = normalizeBase32(value);
  let bits = '';
  for (const char of input) {
    const index = alphabet.indexOf(char);
    if (index < 0) throw new Error('Invalid Base32 TOTP secret.');
    bits += index.toString(2).padStart(5, '0');
  }
  const bytes = [];
  for (let i = 0; i + 8 <= bits.length; i += 8) bytes.push(parseInt(bits.slice(i, i + 8), 2));
  return new Uint8Array(bytes);
}

function encodeBase32(bytes) {
  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
  let bits = '';
  for (const byte of bytes) bits += byte.toString(2).padStart(8, '0');
  let out = '';
  for (let i = 0; i < bits.length; i += 5) {
    const chunk = bits.slice(i, i + 5).padEnd(5, '0');
    out += alphabet[parseInt(chunk, 2)];
  }
  return out;
}

function randomBytes(length) {
  const bytes = new Uint8Array(length);
  crypto.getRandomValues(bytes);
  return bytes;
}

export function generateTotpSecret(bytes = 20) {
  return encodeBase32(randomBytes(Math.max(16, Math.min(64, Number(bytes) || 20))));
}

export function buildTotpUri(secret, account = 'Local Vault', issuer = 'VaultCove') {
  const label = `${issuer}:${account}`;
  const params = new URLSearchParams({ secret: normalizeBase32(secret), issuer, algorithm: 'SHA1', digits: '6', period: '30' });
  return `otpauth://totp/${encodeURIComponent(label)}?${params}`;
}

export async function generateTotp(secret, timestamp = Date.now(), period = 30, digits = 6) {
  const keyBytes = decodeBase32(secret);
  if (!keyBytes.length) throw new Error('TOTP secret is empty.');
  const counter = Math.floor(timestamp / 1000 / period);
  const buffer = new ArrayBuffer(8);
  const view = new DataView(buffer);
  view.setUint32(0, Math.floor(counter / 2 ** 32));
  view.setUint32(4, counter >>> 0);
  const key = await crypto.subtle.importKey('raw', keyBytes, { name: 'HMAC', hash: 'SHA-1' }, false, ['sign']);
  const digest = new Uint8Array(await crypto.subtle.sign('HMAC', key, buffer));
  const offset = digest[digest.length - 1] & 0x0f;
  const code = (((digest[offset] & 0x7f) << 24) |
    ((digest[offset + 1] & 0xff) << 16) |
    ((digest[offset + 2] & 0xff) << 8) |
    (digest[offset + 3] & 0xff)) % 10 ** digits;
  return { code: String(code).padStart(digits, '0'), remaining: period - (Math.floor(timestamp / 1000) % period) };
}

export async function verifyTotp(secret, candidate, timestamp = Date.now(), window = 1) {
  const input = String(candidate || '').replace(/\s+/g, '');
  if (!/^\d{6}$/.test(input)) return false;
  for (let offset = -Math.max(0, window); offset <= Math.max(0, window); offset += 1) {
    const { code } = await generateTotp(secret, timestamp + offset * 30_000);
    if (code === input) return true;
  }
  return false;
}

function recoveryAlphabet() { return 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; }

export function generateRecoveryCodes(count = 10) {
  const alphabet = recoveryAlphabet();
  return Array.from({ length: Math.max(5, Math.min(20, Number(count) || 10)) }, () => {
    const bytes = randomBytes(10);
    let raw = '';
    for (let i = 0; i < 10; i += 1) raw += alphabet[bytes[i] % alphabet.length];
    return `VC-${raw.slice(0, 5)}-${raw.slice(5)}`;
  });
}

export async function hashRecoveryCode(code) {
  const normalized = String(code || '').trim().toUpperCase().replace(/\s+/g, '');
  const bytes = new TextEncoder().encode(`VaultCove:Recovery:v1:${normalized}`);
  const digest = new Uint8Array(await crypto.subtle.digest('SHA-256', bytes));
  return [...digest].map((byte) => byte.toString(16).padStart(2, '0')).join('');
}

export async function hashRecoveryCodes(codes) {
  return Promise.all((codes || []).map(hashRecoveryCode));
}

export async function verifyRecoveryCode(code, hashes) {
  const digest = await hashRecoveryCode(code);
  const index = (hashes || []).indexOf(digest);
  return { valid: index >= 0, index };
}
