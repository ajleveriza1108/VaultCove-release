# VaultCove 0.7.8 R1

## VaultCove 0.7.10 R1
Vault Settings now includes searchable login-to-folder organization. Vault cards use a smaller Secure Login action with a dedicated Trash button. Trash is now a locked 30-day recovery area: deleted items are sealed inside a second authenticated encryption envelope and cannot be opened or used unless explicitly restored.


VaultCove is an offline-first Manifest V3 password and private-record vault. The canonical Windows development root is:

`D:\Windows Projects\VaultCove`

The current build is a **Testing - Full Access** build. Trial expiration and feature lockout are not enforced while VaultCove is under active development.


> 0.7.9 baseline recovery: the updater accepts a verified 0.7.7 installation and upgrades it directly; 0.7.8 does not need to have completed.

## 0.7.8 testing focus

VaultCove 0.7.8 is based on the accepted 0.7.6 source. The rejected 0.7.7 package is not a required baseline. This release fixes the lock screen so setup/unlock stays mathematically centered at every supported window size and Compact setting, and adds a live background/content-script acknowledgement so a website handler immediately recognizes a successful VaultCove unlock without reloading the website.

The Vault now has encrypted folder organization. Open **Vault > Vault Settings**, create folders, select one or multiple saved logins, choose a destination folder, and move them. A login can also be assigned to a folder from its encrypted item editor. Deleting a folder never deletes credentials; those items return to **No Folder**.

Encrypted `.vckey` files keep their existing separate `.vckey` file password. Converting a `.vckey` to readable TXT is blocked until Google Authenticator-compatible TOTP protection is enabled. Conversion then requires fresh VaultCove Sensitive Access (master password + authenticator/recovery code) and the `.vckey` file password. VaultCove does not create a third memorized TXT-conversion password. The TXT contains only the public sharing identity, never saved credentials, TOTP secrets, or private sharing keys.

## 0.7.1 R1 highlights

- Always-On Developer handler with duplicate dynamic-script registration repair. Supported HTTPS login fields can receive VaultCove without first clicking the extension icon.
- Search inside the website handler for sites with many saved accounts. Only masked summaries enter the page handler.
- Inline local password generation on signup, new-password, and password-change forms.
- New-login and password-change detection remain separate encrypted review flows. VaultCove does not silently overwrite credentials.
- Grid and List Vault browsing. Clicking a saved login can open its saved HTTPS site and perform a one-time Secure Login for that exact credential.
- Password-encrypted `.vckey` public sharing identities with a file password separate from the VaultCove master password.
- Multi-account VCShare v2 bundles for up to 50 selected login records.
- Encrypted offline `.vcrecovery` Recovery Kits for the private sharing identity, optional VaultCove authenticator configuration, and a random device-recovery token. Website passwords are not placed in the Recovery Kit.
- Six built-in themes: VaultCove Midnight, AMOLED Black, Graphite, Ocean, Warm Ivory, and Light Gray.
- Compact responsive UI, global tooltips, and removal of decorative special-character controls from the main interface.
- Google Authenticator-compatible local TOTP protection for VaultCove. Google never receives or stores VaultCove website passwords.
- Apps Script licensing reference architecture with email-bound serials, Standard 7-device licenses, Admin 20-device licenses, signed leases, and Release, Revoke, Retain, and Restore device actions.
- Device recovery uses a random VaultCove recovery token, not a MAC address, Windows serial, IMEI, or hidden hardware fingerprint.
- Platform-neutral `.vcvault`, `.vcshare`, `.vckey`, `.vcrecovery`, license, and device-recovery formats are intended for Chrome and Android first, with iPhone/iOS compatibility planned later. License identity and activation must not depend on Windows-, Chrome-, Android-, or iOS-only hardware identifiers.

## Recovery model

VaultCove does not upload a recovery copy of the private sharing identity to a cloud service. If the only device that contains the private sharing identity is destroyed and no separate recovery copy exists, that same private identity cannot be recreated.

For one-device users, create an encrypted `.vcrecovery` file and keep at least one copy on offline media stored separately from the device. The Recovery Password must be different from the VaultCove master password.

A future Android companion can use the same recovery material and device protocol for direct device-to-device recovery. Until that app exists, `.vcrecovery` is the supported offline transfer/recovery format.

## Security boundaries

The encrypted vault uses a random 256-bit vault key protected by the master password. AES-256-GCM protects vault confidentiality and integrity. The master password is not transmitted to the Apps Script licensing service.

A destination website must temporarily receive a password when the user explicitly fills or securely logs in. Secure Login verifies the trusted HTTPS destination, releases only the selected credential, submits promptly, and clears the password field after a guarded fallback when safe.

Local TOTP is an application access-confirmation gate. It is not a separate cloud-held encryption key against a fully compromised local computer.

## Developer testing

Run:

`node tests\core-tests.mjs`

`node tests\static-security-checks.mjs`

Then reload the unpacked extension in `chrome://extensions` from exactly:

`D:\Windows Projects\VaultCove`

Use dummy accounts for browser-handler testing before relying on a development build for critical financial accounts.
