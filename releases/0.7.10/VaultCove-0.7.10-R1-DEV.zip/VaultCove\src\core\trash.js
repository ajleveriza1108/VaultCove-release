import { decryptJson, encryptJson, importAesKey } from './crypto.js';
import { base64UrlToBytes, bytesToBase64Url, randomBytes } from './encoding.js';

export const TRASH_RETENTION_DAYS = 30;
export const TRASH_RETENTION_MS = TRASH_RETENTION_DAYS * 24 * 60 * 60 * 1000;
const TRASH_FORMAT_VERSION = 1;
const TRASH_KEY_AAD_PREFIX = 'VaultCove trash key v1:';
const TRASH_PAYLOAD_AAD_PREFIX = 'VaultCove trash payload v1:';

function isoFrom(value) {
  const ms = value instanceof Date ? value.getTime() : Number(value);
  return new Date(ms).toISOString();
}

function deletedAtMs(item, fallbackMs = Date.now()) {
  const parsed = Date.parse(item?.deletedAt || '');
  return Number.isFinite(parsed) ? parsed : fallbackMs;
}

export function trashPurgeAt(item) {
  const explicit = Date.parse(item?.purgeAt || '');
  if (Number.isFinite(explicit)) return explicit;
  if (!item?.deletedAt) return 0;
  return deletedAtMs(item) + TRASH_RETENTION_MS;
}

export function trashDaysRemaining(item, nowMs = Date.now()) {
  const purgeAt = trashPurgeAt(item);
  if (!purgeAt) return 0;
  return Math.max(0, Math.ceil((purgeAt - nowMs) / (24 * 60 * 60 * 1000)));
}

export function isSealedTrashItem(item) {
  return Boolean(
    item?.deletedAt &&
    item?.trashSealed === true &&
    item?.trashEnvelope?.version === TRASH_FORMAT_VERSION &&
    item?.trashEnvelope?.keyWrap?.iv &&
    item?.trashEnvelope?.keyWrap?.ciphertext &&
    item?.trashEnvelope?.payload?.iv &&
    item?.trashEnvelope?.payload?.ciphertext
  );
}

function activePayloadFromItem(item) {
  const {
    trashSealed,
    trashEnvelope,
    purgeAt,
    deletedAt,
    ...payload
  } = item || {};
  return {
    ...payload,
    deletedAt: null
  };
}

export async function sealItemForTrash(item, vaultKey, { deletedAt = null } = {}) {
  if (!item?.id) throw new Error('Vault item is missing an id.');
  if (!vaultKey) throw new Error('Vault key is required to seal Trash.');
  if (isSealedTrashItem(item)) return item;

  const deletedMs = deletedAt ? deletedAtMs({ deletedAt }, Date.now()) : Date.now();
  const deletedIso = new Date(deletedMs).toISOString();
  const purgeIso = isoFrom(deletedMs + TRASH_RETENTION_MS);
  const rawTrashKey = randomBytes(32);
  const trashKey = await importAesKey(rawTrashKey, false);
  const payload = activePayloadFromItem(item);
  const sealedPayload = await encryptJson(trashKey, payload, `${TRASH_PAYLOAD_AAD_PREFIX}${item.id}`);
  const wrappedKey = await encryptJson(
    vaultKey,
    { key: bytesToBase64Url(rawTrashKey) },
    `${TRASH_KEY_AAD_PREFIX}${item.id}`
  );

  return {
    id: item.id,
    type: item.type,
    name: String(item.name || 'Locked item'),
    createdAt: item.createdAt || deletedIso,
    updatedAt: deletedIso,
    deletedAt: deletedIso,
    purgeAt: purgeIso,
    trashSealed: true,
    trashEnvelope: {
      version: TRASH_FORMAT_VERSION,
      algorithm: 'AES-256-GCM',
      keyWrap: { algorithm: 'AES-256-GCM', ...wrappedKey },
      payload: { algorithm: 'AES-256-GCM', ...sealedPayload }
    }
  };
}

export async function restoreSealedTrashItem(item, vaultKey) {
  if (!isSealedTrashItem(item)) throw new Error('Trash item is not sealed.');
  if (!vaultKey) throw new Error('Vault key is required to restore Trash.');

  let wrapped;
  try {
    wrapped = await decryptJson(vaultKey, item.trashEnvelope.keyWrap, `${TRASH_KEY_AAD_PREFIX}${item.id}`);
  } catch {
    throw new Error('Trash key authentication failed. The sealed item may be damaged.');
  }
  const rawTrashKey = base64UrlToBytes(String(wrapped?.key || ''));
  if (rawTrashKey.length !== 32) throw new Error('Trash key is invalid.');
  const trashKey = await importAesKey(rawTrashKey, false);

  let payload;
  try {
    payload = await decryptJson(trashKey, item.trashEnvelope.payload, `${TRASH_PAYLOAD_AAD_PREFIX}${item.id}`);
  } catch {
    throw new Error('Trash payload authentication failed. The sealed item may be damaged.');
  }
  if (!payload || payload.id !== item.id || payload.type !== item.type) {
    throw new Error('Trash item identity check failed.');
  }

  const {
    trashSealed,
    trashEnvelope,
    purgeAt,
    deletedAt,
    ...restored
  } = payload;
  return {
    ...restored,
    id: item.id,
    type: item.type,
    name: payload.name || item.name,
    deletedAt: null,
    updatedAt: new Date().toISOString()
  };
}

export async function moveVaultItemToTrash(vault, itemId, vaultKey, nowMs = Date.now()) {
  const index = (vault?.items || []).findIndex((candidate) => candidate.id === itemId);
  if (index < 0) return false;
  const item = vault.items[index];
  if (item.deletedAt) return false;
  vault.items[index] = await sealItemForTrash(item, vaultKey, { deletedAt: new Date(nowMs).toISOString() });
  vault.updatedAt = new Date(nowMs).toISOString();
  return true;
}

export async function restoreVaultItemFromTrash(vault, itemId, vaultKey) {
  const index = (vault?.items || []).findIndex((candidate) => candidate.id === itemId);
  if (index < 0) return false;
  const item = vault.items[index];
  if (!item.deletedAt) return false;
  if (!isSealedTrashItem(item)) throw new Error('This legacy Trash item must be sealed before it can be restored.');
  vault.items[index] = await restoreSealedTrashItem(item, vaultKey);
  vault.updatedAt = vault.items[index].updatedAt;
  return true;
}

export async function hardenAndExpireTrash(vault, vaultKey, nowMs = Date.now()) {
  if (!vault?.items || !vaultKey) return { changed: false, sealed: 0, purged: 0 };
  const next = [];
  let sealed = 0;
  let purged = 0;

  for (const item of vault.items) {
    if (!item?.deletedAt) {
      next.push(item);
      continue;
    }
    const purgeAt = trashPurgeAt(item);
    if (purgeAt && nowMs >= purgeAt) {
      purged += 1;
      continue;
    }
    if (isSealedTrashItem(item)) {
      next.push(item);
      continue;
    }
    next.push(await sealItemForTrash(item, vaultKey, { deletedAt: item.deletedAt }));
    sealed += 1;
  }

  if (sealed || purged) {
    vault.items = next;
    vault.updatedAt = new Date(nowMs).toISOString();
  }
  return { changed: Boolean(sealed || purged), sealed, purged };
}
