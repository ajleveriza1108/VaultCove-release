export const THEMES = Object.freeze({
  midnight: 'VaultCove Midnight', amoled: 'AMOLED Black', graphite: 'Graphite', ocean: 'Ocean', ivory: 'Warm Ivory', light: 'Light Gray'
});
export function normalizeTheme(value) { return Object.prototype.hasOwnProperty.call(THEMES, value) ? value : 'midnight'; }
export function applyTheme(value, target = document.documentElement) { const theme = normalizeTheme(value); target.dataset.theme = theme; return theme; }
