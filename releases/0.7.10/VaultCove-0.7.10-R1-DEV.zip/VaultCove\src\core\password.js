const LOWER = 'abcdefghijklmnopqrstuvwxyz';
const UPPER = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
const DIGITS = '0123456789';
const SYMBOLS = '!@#$%^&*()-_=+[]{};:,.?/';

function randomIndex(max) {
  if (max <= 0 || max > 256) throw new Error('Invalid random range.');
  const limit = Math.floor(256 / max) * max;
  const array = new Uint8Array(1);
  do crypto.getRandomValues(array); while (array[0] >= limit);
  return array[0] % max;
}

export function generatePassword(options = {}) {
  const length = Math.min(128, Math.max(12, Number(options.length || 20)));
  const sets = [];
  if (options.lower !== false) sets.push(LOWER);
  if (options.upper !== false) sets.push(UPPER);
  if (options.digits !== false) sets.push(DIGITS);
  if (options.symbols !== false) sets.push(SYMBOLS);
  if (!sets.length) throw new Error('Choose at least one character set.');

  const password = [];
  for (const set of sets) password.push(set[randomIndex(set.length)]);
  const combined = sets.join('');
  while (password.length < length) password.push(combined[randomIndex(combined.length)]);

  for (let i = password.length - 1; i > 0; i -= 1) {
    const j = randomIndex(i + 1);
    [password[i], password[j]] = [password[j], password[i]];
  }
  return password.join('');
}

export function assessPassword(password) {
  if (!password) return { score: 0, label: 'Empty', issues: ['No password saved'] };
  let pool = 0;
  if (/[a-z]/.test(password)) pool += 26;
  if (/[A-Z]/.test(password)) pool += 26;
  if (/\d/.test(password)) pool += 10;
  if (/[^A-Za-z0-9]/.test(password)) pool += 32;
  const entropy = pool ? Math.log2(pool) * password.length : 0;
  const issues = [];
  if (password.length < 12) issues.push('Shorter than 12 characters');
  if (!/[a-z]/.test(password) || !/[A-Z]/.test(password)) issues.push('Limited letter variety');
  if (!/\d/.test(password)) issues.push('No number');
  if (!/[^A-Za-z0-9]/.test(password)) issues.push('No symbol');
  if (/(.)\1{2,}/.test(password)) issues.push('Repeated characters');
  let score = 1;
  if (entropy >= 50) score = 2;
  if (entropy >= 70) score = 3;
  if (entropy >= 90) score = 4;
  return { score, label: ['Empty', 'Weak', 'Fair', 'Strong', 'Very strong'][score], entropy: Math.round(entropy), issues };
}

export function vaultHealth(items) {
  const logins = items.filter((item) => item.type === 'login' && !item.deletedAt);
  const groups = new Map();
  for (const item of logins) {
    if (!item.password) continue;
    if (!groups.has(item.password)) groups.set(item.password, []);
    groups.get(item.password).push(item.id);
  }
  const reusedIds = new Set([...groups.values()].filter((ids) => ids.length > 1).flat());
  let weak = 0;
  let strong = 0;
  for (const item of logins) {
    const assessment = assessPassword(item.password);
    if (assessment.score < 3) weak += 1;
    else strong += 1;
  }
  return {
    total: logins.length,
    weak,
    reused: reusedIds.size,
    strong,
    score: logins.length ? Math.max(0, Math.round(((strong - reusedIds.size * 0.5) / logins.length) * 100)) : 100
  };
}
