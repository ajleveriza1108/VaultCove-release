import { TESTING_FULL_ACCESS } from './constants.js';
import { ensureDeviceId } from './storage.js';
import { getLicenseClientState } from './license-service.js';

function leaseIsUsable(client, deviceId) {
  const lease = client?.lease;
  if (!lease || String(lease.product || '') !== 'VaultCove') return false;
  if (String(lease.installationId || '') !== String(deviceId || '')) return false;
  if (String(lease.status || '').toLowerCase() !== 'active') return false;
  const expiresAt = Date.parse(lease.expiresAt || '');
  if (!Number.isFinite(expiresAt) || expiresAt <= Date.now()) return false;
  return Boolean(client.leaseVerified);
}

export async function getLicenseState() {
  const deviceId = await ensureDeviceId();
  const client = await getLicenseClientState();

  if (TESTING_FULL_ACCESS) {
    return {
      mode: 'testing',
      status: 'full',
      deviceId,
      licensedDevices: Number(client.lease?.usedDevices ?? client.lease?.activeDevices ?? 0) || null,
      maxDevices: Number(client.lease?.maxDevices || 7) || 7,
      activationPresent: Boolean(client.refreshToken),
      emailMasked: String(client.emailMasked || ''),
      licenseType: String(client.lease?.licenseType || 'testing'),
      message: client.refreshToken
        ? 'Testing build: all features are enabled; licensing and device management are available for testing.'
        : 'Testing build: all features are enabled. Production licensing is not enforced yet.'
    };
  }

  if (leaseIsUsable(client, deviceId)) {
    return {
      mode: 'production',
      status: 'full',
      deviceId,
      maxDevices: Number(client.lease.maxDevices || 7) || 7,
      licensedDevices: Number(client.lease.usedDevices ?? client.lease.activeDevices ?? 0),
      emailMasked: String(client.lease.emailMasked || ''),
      leaseExpiresAt: client.lease.expiresAt,
      message: 'VaultCove license active.'
    };
  }

  return {
    mode: 'production',
    status: client.refreshToken ? 'expired' : 'unconfigured',
    deviceId,
    maxDevices: 7,
    message: client.refreshToken
      ? 'The signed license lease is missing, expired, or invalid. Refresh or reactivate from License & Devices.'
      : 'Activate VaultCove from License & Devices. Encrypted export remains available if normal access expires.'
  };
}

export function featureAllowed(licenseState, feature) {
  if (licenseState.status === 'full') return true;
  if (licenseState.status === 'expired') return feature === 'export' || feature === 'license';
  return feature === 'license';
}

