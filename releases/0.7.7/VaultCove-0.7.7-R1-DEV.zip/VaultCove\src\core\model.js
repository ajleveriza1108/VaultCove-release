import { randomId } from './encoding.js';

export function createEmptyVault() {
  return {
    dataVersion: 1,
    items: [],
    folders: [],
    sharingIdentity: null,
    trustedShareContacts: [],
    shareHistory: [],
    recovery: { lastRecoveryKitAt: null },
    pendingLoginCaptures: [],
    security: { vaultTotp: { enabled: false, secret: '', recoveryCodeHashes: [], enabledAt: null } },
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
}

export function createFolder(name, fields = {}) {
  const now = new Date().toISOString();
  const cleanName = String(name ?? fields.name ?? '').trim().replace(/\s+/g, ' ').slice(0, 80);
  if (!cleanName) throw new Error('Folder name is required.');
  return {
    id: fields.id || randomId('folder'),
    name: cleanName,
    createdAt: fields.createdAt || now,
    updatedAt: now
  };
}

export function upsertFolder(vault, folder) {
  const normalized = createFolder(folder?.name, folder || {});
  const duplicate = (vault.folders || []).find((candidate) => candidate.id !== normalized.id && String(candidate.name || '').trim().toLowerCase() === normalized.name.toLowerCase());
  if (duplicate) throw new Error('A folder with that name already exists.');
  const index = (vault.folders || []).findIndex((candidate) => candidate.id === normalized.id);
  if (index === -1) vault.folders.push(normalized);
  else vault.folders[index] = normalized;
  vault.updatedAt = normalized.updatedAt;
  return normalized;
}

export function deleteFolder(vault, folderId) {
  const before = (vault.folders || []).length;
  vault.folders = (vault.folders || []).filter((folder) => folder.id !== folderId);
  if (vault.folders.length === before) return false;
  const now = new Date().toISOString();
  for (const item of vault.items || []) {
    if (item.folderId === folderId) { item.folderId = null; item.updatedAt = now; }
  }
  vault.updatedAt = now;
  return true;
}

export function createItem(type, fields = {}) {
  const now = new Date().toISOString();
  return {
    id: randomId('item'),
    type,
    name: fields.name?.trim() || defaultName(type),
    favorite: Boolean(fields.favorite),
    folderId: fields.folderId || null,
    tags: Array.isArray(fields.tags) ? fields.tags : [],
    notes: fields.notes || '',
    createdAt: now,
    updatedAt: now,
    deletedAt: null,
    ...defaultFields(type),
    ...fields
  };
}

export function defaultFields(type) {
  switch (type) {
    case 'login':
      return { username: '', password: '', urls: [], trustedHosts: [], totpSecret: '', autoLogin: false, requireReauthBeforeFill: false, customFields: [], passwordHistory: [], pendingPasswordChange: null, lastPasswordChangeAt: null, importedAt: null, siteVisual: null };
    case 'card':
      return { cardholder: '', number: '', brand: '', expMonth: '', expYear: '', securityCode: '', billingAddress: '' };
    case 'bank':
      return { bankName: '', accountHolder: '', accountType: '', accountNumber: '', routingNumber: '', iban: '', swiftBic: '', branch: '', pin: '' };
    case 'identity':
      return { firstName: '', middleName: '', lastName: '', company: '', email: '', phone: '', address1: '', address2: '', city: '', state: '', postalCode: '', country: '', governmentId: '' };
    case 'note':
      return { text: '' };
    default:
      throw new Error(`Unsupported item type: ${type}`);
  }
}

export function defaultName(type) {
  return ({ login: 'New Login', card: 'New Card', bank: 'New Bank Account', identity: 'New Identity', note: 'Secure Note' })[type] || 'New Item';
}

export function normalizeVault(vault) {
  return {
    dataVersion: 1,
    items: Array.isArray(vault?.items) ? vault.items : [],
    folders: Array.isArray(vault?.folders) ? vault.folders.map((folder) => {
      try { return createFolder(folder?.name, folder); } catch { return null; }
    }).filter(Boolean) : [],
    sharingIdentity: vault?.sharingIdentity || null,
    trustedShareContacts: Array.isArray(vault?.trustedShareContacts) ? vault.trustedShareContacts : [],
    shareHistory: Array.isArray(vault?.shareHistory) ? vault.shareHistory : [],
    recovery: { lastRecoveryKitAt: null, ...(vault?.recovery || {}) },
    pendingLoginCaptures: Array.isArray(vault?.pendingLoginCaptures) ? vault.pendingLoginCaptures : [],
    security: {
      ...(vault?.security || {}),
      vaultTotp: { enabled: false, secret: '', recoveryCodeHashes: [], enabledAt: null, ...(vault?.security?.vaultTotp || {}) }
    },
    createdAt: vault?.createdAt || new Date().toISOString(),
    updatedAt: vault?.updatedAt || new Date().toISOString()
  };
}

export function upsertItem(vault, item) {
  const now = new Date().toISOString();
  const normalized = { ...item, updatedAt: now };
  const index = vault.items.findIndex((candidate) => candidate.id === item.id);
  if (index === -1) vault.items.push(normalized);
  else vault.items[index] = normalized;
  vault.updatedAt = now;
  return normalized;
}

export function softDeleteItem(vault, id) {
  const item = vault.items.find((candidate) => candidate.id === id);
  if (!item) return false;
  item.deletedAt = new Date().toISOString();
  item.updatedAt = item.deletedAt;
  vault.updatedAt = item.deletedAt;
  return true;
}

export function restoreItem(vault, id) {
  const item = vault.items.find((candidate) => candidate.id === id);
  if (!item) return false;
  item.deletedAt = null;
  item.updatedAt = new Date().toISOString();
  vault.updatedAt = item.updatedAt;
  return true;
}

export function purgeItem(vault, id) {
  const before = vault.items.length;
  vault.items = vault.items.filter((candidate) => candidate.id !== id);
  if (vault.items.length !== before) vault.updatedAt = new Date().toISOString();
  return before !== vault.items.length;
}
