import { createItem } from './model.js';
import { normalizeImportedLoginUrl } from './site-match.js';
import { parseTrustedPasswordChangeDate } from './password-age.js';

function normalizedHeader(value) {
  return String(value ?? '').replace(/^\uFEFF/, '').trim().toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
}

function csvRows(text, delimiter = ',') {
  const rows = [];
  let row = [];
  let field = '';
  let quoted = false;
  const source = String(text ?? '').replace(/^\uFEFF/, '');
  for (let i = 0; i < source.length; i += 1) {
    const ch = source[i];
    if (quoted) {
      if (ch === '"') {
        if (source[i + 1] === '"') { field += '"'; i += 1; }
        else quoted = false;
      } else field += ch;
      continue;
    }
    if (ch === '"') quoted = true;
    else if (ch === delimiter) { row.push(field); field = ''; }
    else if (ch === '\n') { row.push(field.replace(/\r$/, '')); rows.push(row); row = []; field = ''; }
    else field += ch;
  }
  if (field.length || row.length) { row.push(field.replace(/\r$/, '')); rows.push(row); }
  return rows.filter((candidate) => candidate.some((value) => String(value).trim() !== ''));
}

export function parseCsv(text) {
  const source = String(text ?? '').replace(/^\uFEFF/, '');
  const firstLine = source.split(/\r?\n/, 1)[0] || '';
  const delimiter = ['\t',';',','].map((candidate) => ({ candidate, count:(firstLine.match(new RegExp(candidate === '\t' ? '\t' : `\\${candidate}`, 'g')) || []).length })).sort((a,b)=>b.count-a.count)[0]?.candidate || ',';
  const rows = csvRows(source, delimiter);
  if (rows.length < 2) throw new Error('The CSV does not contain any data rows.');
  const originalHeaders = rows[0].map((header, index) => String(header || `Column ${index + 1}`).replace(/^\uFEFF/, '').trim());
  const headers = originalHeaders.map(normalizedHeader);
  const records = rows.slice(1).map((values) => {
    const record = { __headers: originalHeaders };
    headers.forEach((header, index) => { record[header || `column ${index + 1}`] = String(values[index] ?? ''); });
    return record;
  }).filter((record) => headers.some((header) => String(record[header] ?? '').trim() !== ''));
  return { headers, originalHeaders, records };
}

function valueOf(row, ...aliases) {
  for (const alias of aliases) {
    const key = normalizedHeader(alias);
    if (Object.prototype.hasOwnProperty.call(row, key) && String(row[key]).trim() !== '') return String(row[key]).trim();
  }
  return '';
}

function boolValue(value) {
  return /^(1|true|yes|y|favorite|fav)$/i.test(String(value ?? '').trim());
}

function safeUrl(value) {
  const text = String(value ?? '').trim();
  if (!text || /^http:\/\/sn\/?$/i.test(text)) return '';
  return text;
}

function extractTotpSecret(value) {
  const raw = String(value ?? '').trim();
  if (!raw || /^\d{6,8}$/.test(raw)) return '';
  if (/^otpauth:\/\//i.test(raw)) {
    try { return new URL(raw).searchParams.get('secret')?.replace(/[\s-]/g, '').toUpperCase() || ''; } catch { return ''; }
  }
  const compact = raw.replace(/[\s-]/g, '').toUpperCase();
  return /^[A-Z2-7]+=*$/.test(compact) && compact.length >= 16 ? compact.replace(/=+$/, '') : '';
}

function sourceTags(tags, source) {
  const out = ['Imported', source];
  for (const tag of tags || []) if (tag && !out.includes(tag)) out.push(tag);
  return out.slice(0, 20);
}

function appendUnmappedFields(row, usedHeaders, notes = '') {
  const extras = [];
  const used = new Set([...usedHeaders].map(normalizedHeader));
  for (const header of row.__headers || []) {
    const key = normalizedHeader(header);
    const value = String(row[key] ?? '').trim();
    if (value && !used.has(key)) extras.push(`${header}: ${value}`);
  }
  if (!extras.length) return notes;
  return [notes, 'Imported fields:', ...extras].filter(Boolean).join('\n');
}

const KNOWN_MANAGER_HINTS = [
  [/1password|1pux|1pif/, '1Password'], [/bitwarden/, 'Bitwarden'], [/lastpass/, 'LastPass'], [/dashlane/, 'Dashlane'],
  [/keeper/, 'Keeper'], [/nordpass/, 'NordPass'], [/proton/, 'Proton Pass'], [/roboform/, 'RoboForm'], [/enpass/, 'Enpass'], [/zoho/, 'Zoho Vault'],
  [/google.*password|chrome/, 'Google Password Manager / Chrome'], [/microsoft.*edge|(?:^|[^a-z])edge(?:[^a-z]|$)/, 'Microsoft Edge'], [/brave/, 'Brave'],
  [/firefox|mozilla/, 'Firefox'], [/apple.*password|safari/, 'Apple Passwords / Safari'], [/opera/, 'Opera'], [/vivaldi/, 'Vivaldi'],
  [/keepassxc|keepass/, 'KeePass / KeePassXC'], [/ascendo|datavault/, 'Ascendo DataVault'], [/avast/, 'Avast Passwords'], [/avira/, 'Avira'],
  [/blackberry.*password|password.*keeper/, 'BlackBerry Password Keeper'], [/blur/, 'Blur'], [/buttercup/, 'Buttercup'], [/clipperz/, 'Clipperz'], [/codebook/, 'Codebook'],
  [/delinea|secret.?server/, 'Delinea Secret Server'], [/encryptr/, 'Encryptr'], [/f.?secure/, 'F-Secure KEY'], [/seahorse|gnome.*password/, 'GNOME Passwords and Keys / Seahorse'],
  [/kaspersky/, 'Kaspersky Password Manager'], [/logmeonce/, 'LogMeOnce'], [/meldium/, 'Meldium'], [/msecure/, 'mSecure'], [/myki/, 'Myki'], [/netwrix/, 'Netwrix Password Secure'],
  [/padlock/, 'Padlock'], [/passbolt/, 'Passbolt'], [/passkeep/, 'PassKeep'], [/passky/, 'Passky'], [/passman/, 'Passman'], [/passpack/, 'Passpack'],
  [/password.?agent/, 'Password Agent'], [/password.?boss/, 'Password Boss'], [/password.?dragon/, 'Password Dragon'], [/password.?depot/, 'Password Depot'],
  [/password.?safe/, 'Password Safe'], [/password.?wallet/, 'PasswordWallet'], [/password.?xp/, 'PasswordXP'], [/psono/, 'Psono'], [/remembear/, 'RememBear'],
  [/safeincloud/, 'SafeInCloud'], [/saferpass/, 'SaferPass'], [/securesafe/, 'SecureSafe'], [/splashid/, 'SplashID'], [/sticky.*password/, 'Sticky Password'],
  [/true.?key/, 'True Key'], [/universal.*password.*manager|upm/, 'Universal Password Manager'], [/yoti/, 'Yoti']
];

function sourceHintFromFileName(fileName = '') {
  const lower = String(fileName || '').toLowerCase();
  return KNOWN_MANAGER_HINTS.find(([pattern]) => pattern.test(lower))?.[1] || '';
}

const CSV_SIGNATURES = [
  { format:'lastpass', source:'LastPass', test:(h)=>['url','username','password','extra','name'].filter((k)=>h.has(k)).length >= 4 },
  { format:'bitwarden', source:'Bitwarden', test:(h)=>h.has('login uri') && h.has('login username') && h.has('login password') },
  { format:'1password', source:'1Password', test:(h)=>h.has('title') && h.has('website') && h.has('username') && h.has('password') },
  { format:'firefox', source:'Firefox', test:(h)=>h.has('url') && h.has('username') && h.has('password') && (h.has('httprealm') || h.has('formactionorigin') || h.has('timepasswordchanged')) },
  { format:'keeper', source:'Keeper', test:(h)=>h.has('title') && h.has('login') && h.has('password') && (h.has('website address') || h.has('shared folder')) },
  { format:'dashlane', source:'Dashlane', test:(h)=>h.has('title') && h.has('password') && h.has('url') && (h.has('username2') || h.has('otpsecret') || h.has('category')) },
  { format:'nordpass', source:'NordPass', test:(h)=>h.has('name') && h.has('url') && h.has('username') && h.has('password') && (h.has('folder') || h.has('type') || h.has('custom fields')) },
  { format:'roboform', source:'RoboForm', test:(h)=>h.has('name') && (h.has('url') || h.has('website')) && (h.has('login') || h.has('username')) && (h.has('pwd') || h.has('password')) },
  { format:'zoho', source:'Zoho Vault', test:(h)=>h.has('password name') || h.has('password url') || (h.has('username') && h.has('password') && h.has('category')) },
  { format:'browser', source:'Browser password manager', test:(h)=>h.has('name') && h.has('url') && h.has('username') && h.has('password') },
  { format:'generic', source:'Generic password CSV', test:(h)=>h.has('password') && (h.has('username') || h.has('login') || h.has('email')) && (h.has('url') || h.has('website') || h.has('site')) }
];

export function detectMigrationFormat(csv) {
  const h = new Set(csv.headers);
  return (CSV_SIGNATURES.find((entry) => entry.test(h)) || { format:'generic' }).format;
}

function sourceForCsv(csv, fileName = '') {
  const h = new Set(csv.headers);
  const hint = sourceHintFromFileName(fileName);
  const match = CSV_SIGNATURES.find((entry) => entry.test(h));
  if (hint) {
    const browserNames = ['Google Password Manager / Chrome','Microsoft Edge','Brave','Firefox','Apple Passwords / Safari','Opera','Vivaldi'];
    return { format:browserNames.includes(hint) ? 'browser' : (match?.format || 'generic'), source:hint };
  }
  return match || { format:'generic', source:'Generic password CSV' };
}

function genericLoginItem(row, source) {
  const name = valueOf(row, 'name','title','password name','item name','account','label') || valueOf(row,'url','website','website address','site') || `Imported ${source} login`;
  const rawUrl = safeUrl(valueOf(row, 'url','website','website url','website address','password url','login uri','login_url','site','uri','origin'));
  const url = normalizeImportedLoginUrl(rawUrl, name);
  const username = valueOf(row, 'username','user name','login','email','login username','login_username','user');
  const password = valueOf(row, 'password','pwd','login password','login_password','pass');
  const folder = valueOf(row, 'folder','folder name','group','grouping','vault','category');
  const favorite = boolValue(valueOf(row, 'favorite','fav','favourite'));
  const rawTotp = valueOf(row, 'totp','one time password','one-time password','otp secret','otpsecret','login totp','login_totp');
  const totpSecret = extractTotpSecret(rawTotp);
  const notes = valueOf(row, 'notes','note','extra','description','comments');
  const lastPasswordChangeAt = parseTrustedPasswordChangeDate(valueOf(row, 'password changed at','password changed','last password change','password modified','password updated','timepasswordchanged'));
  const used = ['name','title','password name','item name','account','label','url','website','website url','website address','password url','login uri','login_url','site','uri','origin','username','user name','login','email','login username','login_username','user','password','pwd','login password','login_password','pass','folder','folder name','group','grouping','vault','category','favorite','fav','favourite','totp','one time password','one-time password','otp secret','otpsecret','login totp','login_totp','notes','note','extra','description','comments','password changed at','password changed','last password change','password modified','password updated','timepasswordchanged'];
  return createItem('login', {
    name, username, password, urls:url?[url]:[], totpSecret, favorite,
    notes:appendUnmappedFields(row, used, notes), lastPasswordChangeAt, importedAt:new Date().toISOString(),
    tags:sourceTags([], source), importFolderName:folder || ''
  });
}

export function importLastPassCsv(text) {
  const csv = parseCsv(text);
  if (['url','username','password','extra','name'].filter((key) => csv.headers.includes(key)).length < 4) throw new Error('This does not look like a LastPass CSV export.');
  const warnings = [];
  const items = [];
  for (const row of csv.records) {
    const name = valueOf(row, 'name') || 'Imported LastPass item';
    const rawUrl = safeUrl(valueOf(row, 'url'));
    const url = normalizeImportedLoginUrl(rawUrl, name);
    const username = valueOf(row, 'username');
    const password = valueOf(row, 'password');
    const extra = valueOf(row, 'extra');
    const grouping = valueOf(row, 'grouping');
    const favorite = boolValue(valueOf(row, 'fav'));
    const lastPasswordChangeAt = parseTrustedPasswordChangeDate(valueOf(row, 'password changed at', 'password changed', 'last password change', 'password modified', 'password updated'));
    const rawTotp = valueOf(row, 'totp');
    const totpSecret = extractTotpSecret(rawTotp);
    const isNote = /^http:\/\/sn\/?$/i.test(valueOf(row, 'url')) || (!url && !username && !password && Boolean(extra));
    if (isNote) {
      items.push(createItem('note', { name, text:extra, favorite, tags:sourceTags([], 'LastPass'), importFolderName:grouping || '' }));
      continue;
    }
    let notes = extra;
    if (rawTotp && !totpSecret) {
      notes = [notes, 'LastPass TOTP field was preserved but not activated because it was not a recognizable secret:', rawTotp].filter(Boolean).join('\n');
      warnings.push(`TOTP for “${name}” could not be safely recognized as a secret and was kept in Notes.`);
    }
    items.push(createItem('login', { name, username, password, urls:url?[url]:[], totpSecret, notes, favorite, lastPasswordChangeAt, importedAt:new Date().toISOString(), tags:sourceTags([], 'LastPass'), importFolderName:grouping || '' }));
  }
  return { source:'LastPass CSV', format:'lastpass', items, warnings };
}

function zohoCategory(row) { return valueOf(row, 'category','password category','type','secret type').toLowerCase(); }
function zohoItem(row) {
  const category = zohoCategory(row);
  const name = valueOf(row, 'password name','name','title','secret name') || 'Imported Zoho Vault item';
  const folder = valueOf(row, 'folder','folder name');
  const favorite = boolValue(valueOf(row, 'favorite','fav'));
  const tags = sourceTags(valueOf(row, 'tags').split(/[;,]/).map((v)=>v.trim()).filter(Boolean), 'Zoho Vault');
  const noteText = valueOf(row, 'notes','note','description','secure note','comments');
  const common = { favorite, tags, importFolderName:folder || '' };
  if (/bank|financial/.test(category)) return createItem('bank', { ...common, name, bankName:valueOf(row,'bank name','bank'), accountHolder:valueOf(row,'account holder','account holder name'), accountType:valueOf(row,'account type'), accountNumber:valueOf(row,'account number'), routingNumber:valueOf(row,'routing number','aba routing number'), iban:valueOf(row,'iban'), swiftBic:valueOf(row,'swift','swift bic','bic'), branch:valueOf(row,'branch'), pin:valueOf(row,'pin'), notes:noteText });
  if (/card|payment/.test(category)) return createItem('card', { ...common, name, cardholder:valueOf(row,'cardholder','card holder','name on card'), brand:valueOf(row,'brand','card type'), number:valueOf(row,'card number','number'), securityCode:valueOf(row,'security code','cvv','cvc'), expMonth:valueOf(row,'expiry month','expiration month','exp month'), expYear:valueOf(row,'expiry year','expiration year','exp year'), billingAddress:valueOf(row,'billing address'), notes:noteText });
  if (/address|identity|personal/.test(category)) return createItem('identity', { ...common, name, firstName:valueOf(row,'first name'), middleName:valueOf(row,'middle name'), lastName:valueOf(row,'last name'), company:valueOf(row,'company'), email:valueOf(row,'email'), phone:valueOf(row,'phone','telephone'), address1:valueOf(row,'address 1','address line 1'), address2:valueOf(row,'address 2','address line 2'), city:valueOf(row,'city'), state:valueOf(row,'state','province'), postalCode:valueOf(row,'postal code','zip'), country:valueOf(row,'country'), governmentId:valueOf(row,'government id','id number'), notes:noteText });
  if (/note/.test(category)) return createItem('note', { ...common, name, text:noteText });
  return genericLoginItem(row, 'Zoho Vault');
}

export function importZohoVaultCsv(text) {
  const csv = parseCsv(text);
  const looksZoho = csv.headers.includes('password name') || csv.headers.includes('password url') || (csv.headers.includes('username') && csv.headers.includes('password'));
  if (!looksZoho) throw new Error('This does not look like a Zoho Vault CSV export.');
  return { source:'Zoho Vault CSV', format:'zoho', items:csv.records.map(zohoItem), warnings:[] };
}

export function importMigrationCsv(text, requestedFormat = 'auto', fileName = '') {
  const csv = parseCsv(text);
  const detected = sourceForCsv(csv, fileName);
  const format = requestedFormat === 'auto' ? detected.format : requestedFormat;
  if (format === 'lastpass') return importLastPassCsv(text);
  if (format === 'zoho') return importZohoVaultCsv(text);
  const source = detected.source || format;
  const items = csv.records.map((row) => genericLoginItem(row, source)).filter((item) => item.password || item.username || item.urls?.length || item.notes);
  if (!items.length) throw new Error('VaultCove recognized the file structure but found no importable login records.');
  return { source:`${source} CSV`, format, items, warnings:[] };
}

function flattenJsonRecords(value, out = []) {
  if (!value || typeof value !== 'object') return out;
  if (Array.isArray(value)) { for (const item of value) flattenJsonRecords(item, out); return out; }
  const keys = Object.keys(value).map(normalizedHeader);
  if (keys.some((key)=>['password','login password','login_password'].includes(key)) && keys.some((key)=>['username','login','email','login username','login_username'].includes(key))) out.push(value);
  for (const child of Object.values(value)) if (child && typeof child === 'object') flattenJsonRecords(child, out);
  return out;
}

function objectToRow(object) {
  const row = { __headers:[] };
  for (const [key, value] of Object.entries(object || {})) {
    if (value && typeof value === 'object') continue;
    const normalized = normalizedHeader(key);
    row.__headers.push(key);
    row[normalized] = value == null ? '' : String(value);
  }
  return row;
}

function importBitwardenJson(json) {
  const items = [];
  for (const record of json?.items || []) {
    if (Number(record?.type) !== 1 || !record?.login) continue;
    items.push(createItem('login', {
      name:record.name || 'Imported Bitwarden login', username:record.login.username || '', password:record.login.password || '',
      urls:(record.login.uris || []).map((entry)=>entry?.uri).filter(Boolean).slice(0,20), totpSecret:extractTotpSecret(record.login.totp || ''),
      favorite:Boolean(record.favorite), notes:record.notes || '', importedAt:new Date().toISOString(), tags:sourceTags([], 'Bitwarden'), importFolderName:''
    }));
  }
  return { source:'Bitwarden JSON', format:'bitwarden-json', items, warnings:[] };
}

function import1PasswordJson(json) {
  const items = [];
  for (const account of json?.accounts || []) for (const vault of account?.vaults || []) for (const record of vault?.items || []) {
    if (record?.state === 'archived') continue;
    const fields = record?.details?.loginFields || [];
    const username = fields.find((field)=>field?.designation === 'username')?.value || '';
    const password = fields.find((field)=>field?.designation === 'password')?.value || '';
    const urls = (record?.overview?.urls || []).map((entry)=>entry?.url).filter(Boolean);
    if (record?.overview?.url && !urls.includes(record.overview.url)) urls.unshift(record.overview.url);
    if (!username && !password && !urls.length) continue;
    const sections = record?.details?.sections || [];
    let totpSecret = '';
    for (const section of sections) for (const field of section?.fields || []) {
      const val = field?.value;
      const raw = typeof val === 'string' ? val : (val?.concealed || val?.string || val?.totp || '');
      if (!totpSecret && /one.?time|otp|totp/i.test(`${field?.title || ''} ${field?.id || ''}`)) totpSecret = extractTotpSecret(raw);
    }
    items.push(createItem('login', {
      name:record?.overview?.title || 'Imported 1Password login', username, password, urls:urls.slice(0,20), totpSecret,
      favorite:Number(record?.favIndex || 0) > 0, notes:record?.details?.notesPlain || '', importedAt:new Date().toISOString(),
      tags:sourceTags(record?.overview?.tags || [], '1Password'), importFolderName:vault?.attrs?.name || ''
    }));
  }
  return { source:'1Password 1PUX', format:'1pux', items, warnings:[] };
}

function importGenericJson(json, fileName='') {
  if (Array.isArray(json?.items) && json.items.some((item)=>item?.login && Number(item?.type) === 1)) return importBitwardenJson(json);
  if (Array.isArray(json?.accounts) && json.accounts.some((account)=>Array.isArray(account?.vaults))) return import1PasswordJson(json);
  const source = sourceHintFromFileName(fileName) || 'JSON password export';
  const records = flattenJsonRecords(json);
  const items = records.map((record)=>genericLoginItem(objectToRow(record), source)).filter((item)=>item.password || item.username || item.urls?.length || item.notes);
  if (!items.length) throw new Error('VaultCove recognized JSON, but the structure does not expose importable password records.');
  return { source, format:'json', items, warnings:[] };
}

async function inflateRaw(bytes) {
  if (typeof DecompressionStream === 'undefined') throw new Error('This browser cannot decompress ZIP migration files. Export CSV or JSON instead.');
  const stream = new Blob([bytes]).stream().pipeThrough(new DecompressionStream('deflate-raw'));
  return new Uint8Array(await new Response(stream).arrayBuffer());
}

async function readZipEntries(buffer) {
  const bytes = new Uint8Array(buffer);
  const view = new DataView(buffer);
  let eocd = -1;
  for (let i = Math.max(0, bytes.length - 65557); i <= bytes.length - 22; i += 1) if (view.getUint32(i, true) === 0x06054b50) eocd = i;
  if (eocd < 0) throw new Error('The ZIP migration file is damaged or unsupported.');
  const count = view.getUint16(eocd + 10, true);
  const cdOffset = view.getUint32(eocd + 16, true);
  let offset = cdOffset;
  const entries = new Map();
  const decoder = new TextDecoder();
  for (let n = 0; n < count; n += 1) {
    if (view.getUint32(offset, true) !== 0x02014b50) throw new Error('The ZIP central directory is invalid.');
    const method = view.getUint16(offset + 10, true);
    const compressedSize = view.getUint32(offset + 20, true);
    const fileNameLength = view.getUint16(offset + 28, true);
    const extraLength = view.getUint16(offset + 30, true);
    const commentLength = view.getUint16(offset + 32, true);
    const localOffset = view.getUint32(offset + 42, true);
    const name = decoder.decode(bytes.slice(offset + 46, offset + 46 + fileNameLength));
    if (view.getUint32(localOffset, true) !== 0x04034b50) throw new Error('The ZIP local header is invalid.');
    const localNameLength = view.getUint16(localOffset + 26, true);
    const localExtraLength = view.getUint16(localOffset + 28, true);
    const dataStart = localOffset + 30 + localNameLength + localExtraLength;
    const compressed = bytes.slice(dataStart, dataStart + compressedSize);
    let data;
    if (method === 0) data = compressed;
    else if (method === 8) data = await inflateRaw(compressed);
    else throw new Error(`ZIP compression method ${method} is not supported. Export CSV or JSON instead.`);
    entries.set(name, data);
    offset += 46 + fileNameLength + extraLength + commentLength;
  }
  return entries;
}

async function importZipFile(file) {
  const entries = await readZipEntries(await file.arrayBuffer());
  const decoder = new TextDecoder();
  const exportData = [...entries.entries()].find(([name])=>/(^|\/)export\.data$/i.test(name));
  if (exportData) return import1PasswordJson(JSON.parse(decoder.decode(exportData[1])));
  const csvEntries = [...entries.entries()].filter(([name])=>/\.csv$/i.test(name));
  if (csvEntries.length) {
    const credential = csvEntries.find(([name])=>/credentials|password|login/i.test(name)) || csvEntries[0];
    const result = importMigrationCsv(decoder.decode(credential[1]), 'auto', credential[0]);
    if (csvEntries.length > 1) result.warnings.push(`This archive contains ${csvEntries.length} CSV files. VaultCove imported the credential-oriented file “${credential[0]}”; review other exported categories separately if needed.`);
    return result;
  }
  const jsonEntry = [...entries.entries()].find(([name])=>/\.json$/i.test(name));
  if (jsonEntry) return importGenericJson(JSON.parse(decoder.decode(jsonEntry[1])), jsonEntry[0]);
  throw new Error('VaultCove recognized this ZIP but found no supported password export inside it.');
}

export async function importMigrationFile(file, requestedFormat = 'auto') {
  if (!file) throw new Error('Choose a password-manager export file first.');
  const name = String(file.name || '').toLowerCase();
  if (/\.(1pux|zip)$/.test(name)) return importZipFile(file);
  if (/\.json$/.test(name)) return importGenericJson(JSON.parse(await file.text()), file.name || '');
  if (/\.(csv|txt)$/.test(name) || !name.includes('.')) return importMigrationCsv(await file.text(), requestedFormat, file.name || '');
  const sourceHint = sourceHintFromFileName(file.name || name);
  if (/\.kdbx$/.test(name)) throw new Error('KeePass/KeePassXC .kdbx was recognized. Export the database as XML or CSV first; VaultCove will not ask for or process the native database master key in the browser extension.');
  if (/\.(xml|fsk|html|1pif|sv)$/.test(name)) throw new Error(`${sourceHint || 'This password manager'} export was recognized, but this container is not opened directly in this release. Export CSV or JSON when available; VaultCove will keep the migration local and will not guess at an unsupported structure.`);
  if (sourceHint) throw new Error(`${sourceHint} was recognized from the file name, but this export container is not supported yet. Use that manager’s CSV, JSON, ZIP, or 1PUX export when available.`);
  throw new Error('VaultCove could not recognize this migration file type. Use the original manager’s CSV, JSON, ZIP, or 1PUX export when available.');
}

function duplicateKey(item) {
  const url = item.type === 'login' ? String(item.urls?.[0] || '').toLowerCase() : '';
  const username = item.type === 'login' ? String(item.username || '').toLowerCase() : '';
  return [item.type, String(item.name || '').trim().toLowerCase(), username, url].join('|');
}

export function mergeImportedItems(existingItems, importedItems, { skipDuplicates = true } = {}) {
  const keys = new Set((existingItems || []).filter((item) => !item.deletedAt).map(duplicateKey));
  const accepted = [];
  let skipped = 0;
  for (const item of importedItems || []) {
    const key = duplicateKey(item);
    if (skipDuplicates && keys.has(key)) { skipped += 1; continue; }
    keys.add(key); accepted.push(item);
  }
  return { accepted, skipped };
}
