# VaultCove Security Model - 0.7.1 R1

## Encrypted vault

VaultCove generates a random 256-bit vault key. The master password derives a wrapping key with PBKDF2-HMAC-SHA-256. AES-256-GCM protects the encrypted vault payload and detects tampering.

Encrypted vault data includes usernames, passwords, URLs, notes, TOTP secrets, private VCShare keys, pending new-login/password-change candidates, visited-site visual metadata, and Recovery Kit history metadata.

## Sensitive Access and master-password changes

Unlock and secret disclosure are separate. Reveal, Copy, Edit, export, restore, sharing, protected filling, and master-password changes can require fresh master-password verification. Sensitive Access expires after a short configurable window.

Changing the master password requires the current master password, a strong and different replacement, confirmation, the exact confirmation phrase `CHANGE MASTER PASSWORD`, and the VaultCove authenticator/recovery code when enabled. VaultCove verifies the new wrapped vault key before committing it and locks immediately after success.

## Website handler and Secure Login

The Developer build runs the HTTPS handler automatically for testing. The Chrome Web Store preflight removes mandatory website access and keeps broad HTTPS access optional.

The page handler receives masked login summaries only. It does not receive stored passwords. The service worker validates the actual HTTPS sender and trusted-site relationship before releasing one selected credential.

Handler account search is performed in the trusted extension background. Search does not expose the complete unmasked username or password to the website.

Clicking a login card or List action creates a short-lived one-time Secure Login selection for that exact credential. VaultCove arms the selection before navigating to the saved HTTPS URL so a fast-loading page cannot race ahead of the selected-item state.

Secure Login does not use the system clipboard. It fills only the chosen credential, submits promptly, and clears the injected page password after a guarded fallback when safe. Once a legitimate destination receives the password, that page can potentially read it; traditional password autofill cannot guarantee otherwise.

## New logins, password changes, and password generation

Signup and password-change detection create encrypted pending candidates. VaultCove asks the user before permanently saving a new login or replacing an existing password. The inline generator uses browser cryptographic randomness and can fill matching New Password and Confirm Password fields.

## VaultCove Authenticator protection

VaultCove can enroll a standard TOTP secret compatible with Google Authenticator and other TOTP apps. The authenticator app does not receive, store, or synchronize website passwords from VaultCove. Recovery codes are generated locally and only their hashes remain in the encrypted vault after setup.

Because verification is local, TOTP is an additional local access-confirmation gate, not a separate cloud-held encryption key.

## VCKey and VCShare

`.vckey` v2 exports only the public sharing identity. It is encrypted with a separate file password using PBKDF2-HMAC-SHA-256 at 600,000 iterations and AES-256-GCM. VaultCove requires fresh master verification for reveal/export/import and rejects a `.vckey` password that is the same as the current master password.

VCShare v2 can bundle up to 50 login records. It uses P-256 ECDH plus HKDF-SHA-256 to derive recipient encryption material, AES-256-GCM for payload protection, and ECDSA P-256 sender signatures. Recipient private keys remain in the encrypted vault.

Revoking a share cannot make a recipient forget a password already decrypted. Change the website password when true access revocation is required.

## Offline Recovery Kit

`.vcrecovery` uses PBKDF2-HMAC-SHA-256 at 700,000 iterations and AES-256-GCM. It can contain the private sharing identity, a random device-recovery token, and optionally the local VaultCove authenticator configuration. It deliberately does not contain website passwords.

The Recovery Password must be separate from the VaultCove master password. Keep the file offline and separate from the only device being protected.

If the sole copy of a private key is destroyed and no Recovery Kit or second authorized device exists, VaultCove cannot recreate that same key. This is an intentional cryptographic limitation, not a recoverable cloud backup.

## Licensing privacy and device recovery

The Apps Script reference backend may receive a serial during activation, verified license email, random installation ID, random device-recovery token, user-provided device label, platform/app version, OTP responses, and random license/session tokens.

The server stores a keyed hash of the device-recovery token rather than the raw token in the Devices sheet. A restored Recovery Kit can help reclaim the same known device record after a reset. Email OTP is still required; the recovery token alone is not sufficient to activate a license.

Standard licenses allow 7 used device slots. Admin licenses allow 20. Retained devices continue to reserve a slot and can continue a valid signed session. Release and Revoke clear the server-side refresh-token hash. Restore makes the record eligible again, but a cleared device session must reactivate.

VaultCove does not use MAC addresses, Windows serial numbers, IMEI values, or hidden hardware fingerprints for device licensing.

## Update distribution

Developer update metadata is fetched only from the official public VaultCove release source and is digitally verified. The Store build removes the developer GitHub update path. Remote executable JavaScript, remote WASM, `eval`, and `new Function` are not used.

## Out of scope

No browser extension can guarantee secrecy if malware controls the operating system, Chrome process memory, DevTools, screen/accessibility capture, the keyboard, or the user's master password. Endpoint security remains necessary.
