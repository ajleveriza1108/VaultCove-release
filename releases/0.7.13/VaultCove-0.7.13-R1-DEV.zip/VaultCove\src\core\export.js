import { EXPORT_AAD, EXPORT_MAGIC, EXPORT_VERSION } from './constants.js';
import { importAesKey, encryptJson, decryptJson } from './crypto.js';
import { base64UrlToBytes, bytesToBase64Url, randomBytes } from './encoding.js';
import { saveBlob } from './file-save.js';

function createProductNeutralSecretBytes() {
  // Avoid a visible product marker at the beginning of new backup secrets.
  // This only makes the token less self-identifying; the actual security is the
  // full 256 bits of randomness plus authenticated AES-GCM encryption.
  for (;;) {
    const bytes = randomBytes(32);
    const encoded = bytesToBase64Url(bytes);
    if (!/^vc/i.test(encoded)) return { bytes, encoded };
  }
}

export async function createPortableExport(vaultData) {
  const generated = createProductNeutralSecretBytes();
  const secretBytes = generated.bytes;
  const exportKey = await importAesKey(secretBytes);
  const encrypted = await encryptJson(exportKey, vaultData, EXPORT_AAD);
  const digest = new Uint8Array(await crypto.subtle.digest('SHA-256', secretBytes));
  const keyId = bytesToBase64Url(digest.subarray(0, 8));
  const payload = {
    magic: EXPORT_MAGIC,
    version: EXPORT_VERSION,
    createdAt: new Date().toISOString(),
    encryption: {
      algorithm: 'AES-256-GCM',
      aad: EXPORT_AAD,
      keyId,
      iv: encrypted.iv,
      ciphertext: encrypted.ciphertext
    }
  };
  return { payload, secret: generated.encoded };
}

export async function decryptPortableExport(payload, secret) {
  if (!payload || payload.magic !== EXPORT_MAGIC || payload.version !== EXPORT_VERSION) {
    throw new Error('This is not a supported VaultCove export.');
  }
  if (typeof secret !== 'string' || !secret.trim()) {
    throw new Error('Enter the matching backup secret.');
  }
  const normalizedSecret = secret.trim();
  // Backward compatibility: VaultCove 0.7.11 and earlier used a VC1- marker.
  // New secrets are deliberately prefixless and look like ordinary random tokens.
  const encodedSecret = normalizedSecret.startsWith('VC1-') ? normalizedSecret.slice(4) : normalizedSecret;
  const secretBytes = base64UrlToBytes(encodedSecret);
  if (secretBytes.length !== 32) throw new Error('Invalid export secret.');
  const digest = new Uint8Array(await crypto.subtle.digest('SHA-256', secretBytes));
  const expectedKeyId = bytesToBase64Url(digest.subarray(0, 8));
  if (payload.encryption?.keyId !== expectedKeyId) throw new Error('The export secret does not match this file.');
  const exportKey = await importAesKey(secretBytes);
  try {
    return await decryptJson(exportKey, payload.encryption, EXPORT_AAD);
  } catch {
    throw new Error('Export authentication failed. The secret is wrong or the file was modified.');
  }
}

export async function downloadExport(payload, filename = null) {
  const text = JSON.stringify(payload);
  const blob = new Blob([text], { type: 'application/octet-stream' });
  return saveBlob(blob, filename || `VaultCove-${new Date().toISOString().replace(/[:.]/g, '-')}.vcvault`, { description: 'VaultCove encrypted vault backup', mime: 'application/octet-stream' });
}
