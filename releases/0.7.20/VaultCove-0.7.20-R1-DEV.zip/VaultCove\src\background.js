import {
  clearSession,
  ensureDeviceId,
  getSessionExpiry,
  getSettings,
  hardenStorageAccess,
  hasSensitiveAccess,
  setSettings,
  touchSession
} from './core/storage.js';
import { initializeVault, loadUnlockedVault, matchesCurrentMasterPassword, saveUnlockedVault, unlockVault, verifySensitiveAccess } from './core/vault.js';
import { featureAllowed, getLicenseState } from './core/license.js';
import { publicLoginSummary } from './core/redaction.js';
import { createGenericSecurityNotice } from './core/security-events.js';
import { canonicalHostname, loginMatchesTrustedHost, permissionOriginForHost, resolveLoginHttpsTarget, secureLoginMatchesUrl } from './core/site-match.js';
import { checkForUpdates } from './core/updates.js';
import { createPendingLoginCapture, findExistingLoginForCapture, prunePendingLoginCaptures, samePendingLoginCapture } from './core/login-capture.js';
import { sealCaptureWhileLocked } from './core/capture-inbox.js';
import { getLicenseClientState, refreshLicenseLease } from './core/license-service.js';
import { BUILD_CHANNEL } from './core/build.js';
import { isUseOnlySharedLogin, openSharedLoginForFill, sharedAccessIsExpired } from './core/shared-access.js';

const AUTO_LOCK_ALARM = 'vaultcove-auto-lock';

let masterAuthQueue = Promise.resolve();
function queueMasterAuth(operation) {
  const run = masterAuthQueue.then(operation, operation);
  masterAuthQueue = run.catch(() => undefined);
  return run;
}

let browserIntegrationQueue = Promise.resolve();
function queueBrowserIntegration(operation) {
  const run = browserIntegrationQueue.then(operation, operation);
  browserIntegrationQueue = run.catch(() => undefined);
  return run;
}
const UPDATE_CHECK_ALARM = 'vaultcove-update-check';
const LICENSE_REFRESH_ALARM = 'vaultcove-license-refresh';
const HANDLER_SCRIPT_ID = 'vaultcove-inline-handler';
const LEGACY_BROAD_HANDLER_ORIGIN = 'https://*/*';
const HTTP_BROAD_HANDLER_ORIGIN = 'http://*/*';
const DEV_HANDLER_ORIGINS = Object.freeze([LEGACY_BROAD_HANDLER_ORIGIN, HTTP_BROAD_HANDLER_ORIGIN]);
const UPDATE_METADATA_ORIGIN = 'https://raw.githubusercontent.com/*';
const EMAIL_NOTICE_QUEUE_KEY = 'securityEmailNoticeQueue';
const PASSWORD_NOTICE_PREFIX = 'vaultcove-password-change:';
const NEW_LOGIN_NOTICE_PREFIX = 'vaultcove-new-login:';
const ON_DEMAND_HANDLER_TABS_KEY = 'onDemandHandlerTabs';
const PENDING_SECURE_LAUNCH_KEY = 'pendingSecureLaunches';
const HANDLER_UNLOCK_FLOW = 'handler-unlock';
const ON_DEMAND_HANDLER_TTL_MS = 30 * 60 * 1000;



function trustedExtensionSender(sender) {
  const base = chrome.runtime.getURL('');
  return typeof sender?.url === 'string' && sender.url.startsWith(base);
}

async function getPendingSecureLaunches() {
  const result = await chrome.storage.session.get(PENDING_SECURE_LAUNCH_KEY);
  return result[PENDING_SECURE_LAUNCH_KEY] || {};
}
async function savePendingSecureLaunches(value) { await chrome.storage.session.set({ [PENDING_SECURE_LAUNCH_KEY]: value }); }
async function clearPendingSecureLaunch(tabId) {
  const all = await getPendingSecureLaunches();
  if (String(tabId) in all) { delete all[String(tabId)]; await savePendingSecureLaunches(all); }
}
async function pendingSecureLaunch(tabId) {
  const all = await getPendingSecureLaunches(); const record = all[String(tabId)];
  if (!record) return null;
  if (Date.now() > Number(record.expiresAt || 0)) { await clearPendingSecureLaunch(tabId); return null; }
  return record;
}

async function getOnDemandHandlerTabs() {
  const result = await chrome.storage.session.get(ON_DEMAND_HANDLER_TABS_KEY);
  const raw = result[ON_DEMAND_HANDLER_TABS_KEY];
  return raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : {};
}

async function saveOnDemandHandlerTabs(value) {
  const entries = Object.fromEntries(Object.entries(value || {}).filter(([, record]) => Number(record?.expiresAt || 0) > Date.now()));
  await chrome.storage.session.set({ [ON_DEMAND_HANDLER_TABS_KEY]: entries });
}

async function markOnDemandHandlerTab(tabId, pageUrl) {
  if (!Number.isInteger(tabId) || !pageUrl) return;
  const tabs = await getOnDemandHandlerTabs();
  tabs[String(tabId)] = {
    origin: pageUrl.origin,
    expiresAt: Date.now() + ON_DEMAND_HANDLER_TTL_MS
  };
  await saveOnDemandHandlerTabs(tabs);
}

async function clearOnDemandHandlerTab(tabId) {
  if (!Number.isInteger(tabId)) return;
  const tabs = await getOnDemandHandlerTabs();
  if (!(String(tabId) in tabs)) return;
  delete tabs[String(tabId)];
  await saveOnDemandHandlerTabs(tabs);
}

async function isOnDemandHandlerTab(tabId, pageUrl) {
  if (!Number.isInteger(tabId) || !pageUrl) return false;
  const tabs = await getOnDemandHandlerTabs();
  const record = tabs[String(tabId)];
  if (!record || Number(record.expiresAt || 0) <= Date.now()) {
    if (record) await clearOnDemandHandlerTab(tabId);
    return false;
  }
  return record.origin === pageUrl.origin;
}

async function injectOnDemandHandler(tabId) {
  if (!Number.isInteger(tabId)) throw new Error('No active tab is available.');
  const tab = await chrome.tabs.get(tabId);
  const pageUrl = parseWebUrl(tab?.url || '');
  if (!pageUrl) return { enabled: false, reason: 'unsupported-page' };

  if (BUILD_CHANNEL === 'dev') {
    // The Developer build already has one manifest-declared handler on every
    // HTTPS page. Do not mark this tab for later script injection; just tell
    // the existing handler to refresh its locked/unlocked state.
    try { await chrome.tabs.sendMessage(tabId, { type: 'VAULTCOVE_SESSION_CHANGED' }); } catch {}
    return { enabled: true, mode: 'manifest', origin: pageUrl.origin };
  }

  await markOnDemandHandlerTab(tabId, pageUrl);
  try {
    try {
      await chrome.scripting.executeScript({
        target: { tabId, allFrames: true },
        files: ['src/content/handler.js']
      });
    } catch {
      // activeTab may not cover cross-origin child frames. The top frame is still
      // useful and keeps the on-demand path permission-minimal. Persistent mode
      // can cover additional HTTPS frames after the user grants optional access.
      await chrome.scripting.executeScript({
        target: { tabId, frameIds: [0] },
        files: ['src/content/handler.js']
      });
    }
    return { enabled: true, mode: 'activeTab', origin: pageUrl.origin };
  } catch (error) {
    await clearOnDemandHandlerTab(tabId);
    throw new Error(`VaultCove could not attach the on-demand login handler to this page: ${error?.message || error}`);
  }
}

function parseWebUrl(value) {
  try {
    const url = new URL(value);
    return ['https:', 'http:'].includes(url.protocol) ? url : null;
  } catch {
    return null;
  }
}

function parseHttpsUrl(value) {
  const url = parseWebUrl(value);
  return url?.protocol === 'https:' ? url : null;
}

function handlerPermissionOriginForUrl(pageUrl) {
  if (!pageUrl || !['https:', 'http:'].includes(pageUrl.protocol)) throw new Error('A valid HTTP or HTTPS page is required.');
  return `${pageUrl.protocol}//${pageUrl.hostname}/*`;
}

function loginMatchesSite(item, hostname) {
  return loginMatchesTrustedHost(item, hostname);
}

function frameUrlFromSender(sender) {
  return parseWebUrl(sender?.url || sender?.tab?.url || '');
}

async function grantedHandlerOrigins() {
  const all = await chrome.permissions.getAll();
  return (all.origins || []).filter((origin) => (origin.startsWith('https://') || origin.startsWith('http://')) && origin !== UPDATE_METADATA_ORIGIN);
}

async function hasHandlerPermissionForUrl(pageUrl) {
  if (!pageUrl) return false;
  try {
    const broadOrigin = pageUrl.protocol === 'http:' ? HTTP_BROAD_HANDLER_ORIGIN : LEGACY_BROAD_HANDLER_ORIGIN;
    if (await chrome.permissions.contains({ origins: [broadOrigin] })) return true;
    return chrome.permissions.contains({ origins: [handlerPermissionOriginForUrl(pageUrl)] });
  } catch {
    return false;
  }
}

async function notifyHandlerTabSession(tabId, state = 'unknown', retries = 5) {
  if (!Number.isInteger(tabId)) return false;
  for (let attempt = 0; attempt < Math.max(1, retries); attempt += 1) {
    try {
      const response = await chrome.tabs.sendMessage(
        tabId,
        { type: 'VAULTCOVE_SESSION_CHANGED', state },
        { frameId: 0 }
      );
      if (response?.ok && (state !== 'unlocked' || response.unlocked === true)) return true;
    } catch {}
    await new Promise((resolve) => setTimeout(resolve, 120 + attempt * 80));
  }
  return false;
}

async function broadcastHandlerSessionChanged(state = 'unknown') {
  let tabs = [];
  try { tabs = await chrome.tabs.query({ url: [...DEV_HANDLER_ORIGINS] }); } catch { return; }
  await Promise.allSettled(
    tabs
      .filter((tab) => Number.isInteger(tab.id))
      .map((tab) => notifyHandlerTabSession(tab.id, state, 2))
  );
}

async function injectHandlerIntoOpenTabs(origins) {
  if (!origins?.length) return;
  try {
    const tabs = await chrome.tabs.query({ url: origins });
    await Promise.allSettled(tabs.filter((tab) => Number.isInteger(tab.id)).map((tab) =>
      chrome.tabs.sendMessage(tab.id, { type: 'VAULTCOVE_SESSION_CHANGED' })
    ));
  } catch {}
}

async function safeRegisteredHandler() {
  try { return await chrome.scripting.getRegisteredContentScripts({ ids: [HANDLER_SCRIPT_ID] }); }
  catch { return []; }
}

async function removeLegacyDynamicHandlerRegistration() {
  const registered = await safeRegisteredHandler();
  if (!registered.length) return false;
  try { await chrome.scripting.unregisterContentScripts({ ids: [HANDLER_SCRIPT_ID] }); }
  catch (error) {
    // Another extension worker may have removed it between the read and unregister.
    const message = String(error?.message || error || '');
    if (!/not found|no script|does not exist/i.test(message)) throw error;
  }
  return true;
}

async function syncBrowserIntegration({ injectExisting = false } = {}) {
  return queueBrowserIntegration(async () => {
    // Clean any registration created by VaultCove 0.6.x/0.7.0. The Developer
    // build never calls registerContentScripts; its handler is declared once in
    // manifest.json and Chrome owns that lifecycle.
    await removeLegacyDynamicHandlerRegistration();

    if (BUILD_CHANNEL === 'dev') {
      if (injectExisting) {
        try {
          const tabs = await chrome.tabs.query({ url: [...DEV_HANDLER_ORIGINS] });
          await Promise.allSettled(tabs.filter((tab) => Number.isInteger(tab.id)).map((tab) =>
            chrome.tabs.sendMessage(tab.id, { type: 'VAULTCOVE_SESSION_CHANGED' })
          ));
        } catch {}
      }
      return { enabled: true, origins: [...DEV_HANDLER_ORIGINS], mode: 'manifest' };
    }

    // Store-preflight intentionally remains permission-minimal while this repair
    // is being validated. User-invoked Strict Secure Login continues to work. A
    // future audited Store release can re-introduce optional persistent dynamic
    // registration after browser-level regression coverage is in place.
    const origins = await grantedHandlerOrigins();
    return { enabled: false, origins, mode: 'on-demand' };
  });
}

async function syncAlwaysOnHandlerSetting() {
  const broad = BUILD_CHANNEL === 'dev'
    ? true
    : await chrome.permissions.contains({ origins: [LEGACY_BROAD_HANDLER_ORIGIN] });
  await setSettings({ alwaysOnHandlerEnabled: Boolean(broad), inlineHandlerEnabled: Boolean(broad) });
  return broad;
}

let initializePromise = null;
async function initialize() {
  if (initializePromise) return initializePromise;
  initializePromise = (async () => {
    await hardenStorageAccess();
    await ensureDeviceId();
    const premiumSettings = await getSettings();
    if (!premiumSettings.websiteIconsPremiumDefaultApplied) {
      await setSettings({ websiteIconsEnabled: true, websiteIconsPremiumDefaultApplied: true });
    }
    await syncAlwaysOnHandlerSetting();
    chrome.alarms.create(AUTO_LOCK_ALARM, { periodInMinutes: 1 });
    chrome.alarms.create(UPDATE_CHECK_ALARM, { periodInMinutes: 24 * 60 });
    chrome.alarms.create(LICENSE_REFRESH_ALARM, { periodInMinutes: 12 * 60 });
    await syncBrowserIntegration();
  })();
  try { await initializePromise; } finally { initializePromise = null; }
}

chrome.runtime.onInstalled.addListener(() => initialize().catch(console.error));
chrome.runtime.onStartup.addListener(() => initialize().catch(console.error));
chrome.permissions.onAdded.addListener(() => { syncAlwaysOnHandlerSetting().then(() => syncBrowserIntegration({ injectExisting: true })).catch(console.error); });
chrome.permissions.onRemoved.addListener(() => { syncAlwaysOnHandlerSetting().then(() => syncBrowserIntegration()).catch(console.error); });
chrome.tabs.onRemoved.addListener((tabId) => { clearOnDemandHandlerTab(tabId).catch(() => {}); clearPendingSecureLaunch(tabId).catch(() => {}); });
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  (async () => {
    const tabs = await getOnDemandHandlerTabs();
    const record = tabs[String(tabId)];
    if (!record) return;
    if (changeInfo.url) {
      const pageUrl = parseWebUrl(changeInfo.url);
      if (!pageUrl || pageUrl.origin !== record.origin) { await clearOnDemandHandlerTab(tabId); return; }
    }
    if (changeInfo.status === 'complete') {
      const pageUrl = parseWebUrl(tab?.url || '');
      if (pageUrl?.origin === record.origin) {
        try {
          await chrome.scripting.executeScript({ target: { tabId, frameIds: [0] }, files: ['src/content/handler.js'] });
        } catch {}
      }
    }
  })().catch(() => {});
});

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === AUTO_LOCK_ALARM) {
    const expiresAt = await getSessionExpiry();
    if (expiresAt && Date.now() >= expiresAt) {
      await clearSession();
      await broadcastHandlerSessionChanged('locked');
    }
    return;
  }
  if (alarm.name === UPDATE_CHECK_ALARM) {
    const settings = await getSettings();
    if (settings.updateChecksEnabled) checkForUpdates().catch(() => {});
    return;
  }
  if (alarm.name === LICENSE_REFRESH_ALARM) {
    const client = await getLicenseClientState();
    if (client.endpoint && client.refreshToken) refreshLicenseLease().catch(() => {});
  }
});

async function openLoginItem(message, sender) {
  if (!trustedExtensionSender(sender)) throw new Error('Untrusted open-login request.');
  const state = await loadUnlockedVault({ touch: true });
  if (state.state !== 'unlocked') throw new Error('Unlock VaultCove before opening a saved login.');
  const item = state.vault.items.find((candidate) => candidate.id === String(message.itemId || '') && candidate.type === 'login' && !candidate.deletedAt);
  if (!item) throw new Error('Saved login was not found.');
  if (isUseOnlySharedLogin(item) && sharedAccessIsExpired(item)) throw new Error('This shared login access has expired. Ask the sender to create a new package.');
  if (item.requireReauthBeforeFill && !(await hasSensitiveAccess())) throw new Error('This login requires a fresh master-password check before Secure Login.');
  const target = resolveLoginHttpsTarget(item);
  if (!target) throw new Error('VaultCove could not determine a safe HTTPS website for this login. Edit the login and add its website domain.');
  // Arm the one-time credential selection before navigation so an extremely fast
  // page cannot query the handler before the selected item is recorded.
  const tab = await chrome.tabs.create({ url: 'about:blank', active: true });
  if (!Number.isInteger(tab.id)) throw new Error('Chrome did not create the login tab.');
  const all = await getPendingSecureLaunches();
  all[String(tab.id)] = { itemId:item.id, expectedHostname:target.hostname, createdAt:Date.now(), expiresAt:Date.now()+120000 };
  await savePendingSecureLaunches(all);
  await chrome.tabs.update(tab.id, { url: target.toString(), active: true });
  return { tabId:tab.id, hostname:target.hostname };
}

function handlerDisabledForHost(settings, hostname) {
  const host = canonicalHostname(hostname);
  const disabled = Array.isArray(settings?.handlerDisabledHosts) ? settings.handlerDisabledHosts : [];
  return Boolean(host && disabled.some((value) => canonicalHostname(value) === host));
}

async function setHandlerSiteException(hostname, disabled) {
  const host = canonicalHostname(hostname);
  if (!host) throw new Error('Enter a valid website hostname.');
  const settings = await getSettings();
  const current = new Set((settings.handlerDisabledHosts || []).map(canonicalHostname).filter(Boolean));
  if (disabled) current.add(host);
  else current.delete(host);
  const handlerDisabledHosts = [...current].sort();
  await setSettings({ handlerDisabledHosts, alwaysOnHandlerEnabled: true, inlineHandlerEnabled: true });
  await injectHandlerIntoOpenTabs([`https://${host}/*`, `https://www.${host}/*`]);
  return { hostname: host, disabled: Boolean(disabled), handlerDisabledHosts };
}

async function buildPageLoginState(pageUrl, { handlerRequest = false, tabId = null, query = '' } = {}) {
  if (!pageUrl) return { ok: true, supported: false, unlocked: false, matches: [], handlerEnabled: false };

  const [settings, licenseState, state, permission] = await Promise.all([
    getSettings(),
    getLicenseState(),
    loadUnlockedVault({ touch: false }),
    hasHandlerPermissionForUrl(pageUrl)
  ]);
  const siteDisabled = handlerDisabledForHost(settings, pageUrl.hostname);
  const isHttps = pageUrl.protocol === 'https:';
  const persistentHandlerEnabled = Boolean(permission && !siteDisabled);
  const onDemandHandlerEnabled = handlerRequest ? await isOnDemandHandlerTab(tabId, pageUrl) : false;
  const handlerEnabled = persistentHandlerEnabled || onDemandHandlerEnabled;

  if (!featureAllowed(licenseState, 'autofill')) {
    return {
      ok: true,
      supported: true,
      unlocked: state.state === 'unlocked',
      enabled: handlerRequest ? handlerEnabled : true,
      handlerEnabled: persistentHandlerEnabled,
      siteDisabled,
      handlerMode: onDemandHandlerEnabled ? 'activeTab' : persistentHandlerEnabled ? 'persistent' : 'off',
      matches: [],
      secureLoginAllowed: isHttps,
      passwordChangeDetectionEnabled: Boolean(settings.passwordChangeDetectionEnabled),
      newLoginCaptureEnabled: Boolean(settings.newLoginCaptureEnabled)
    };
  }
  if (state.state !== 'unlocked') {
    return {
      ok: true,
      supported: true,
      unlocked: false,
      enabled: handlerRequest ? handlerEnabled : true,
      handlerEnabled: persistentHandlerEnabled,
      siteDisabled,
      handlerMode: onDemandHandlerEnabled ? 'activeTab' : persistentHandlerEnabled ? 'persistent' : 'off',
      matches: [],
      secureLoginAllowed: isHttps,
      passwordChangeDetectionEnabled: Boolean(settings.passwordChangeDetectionEnabled),
      newLoginCaptureEnabled: Boolean(settings.newLoginCaptureEnabled)
    };
  }

  const freshCaptures = prunePendingLoginCaptures(state.vault.pendingLoginCaptures);
  if (freshCaptures.length !== (state.vault.pendingLoginCaptures || []).length) {
    state.vault.pendingLoginCaptures = freshCaptures;
    await saveUnlockedVault(state.vault, { touch: false });
  }

  const siteMatchedItems = state.vault.items
    .filter((item) => loginMatchesSite(item, pageUrl.hostname))
    .sort((a, b) => Number(Boolean(b.favorite)) - Number(Boolean(a.favorite)) || String(a.name).localeCompare(String(b.name)));

  const search = String(query || '').trim().toLowerCase().slice(0, 160);
  const matchedItems = search
    ? siteMatchedItems.filter((item) => {
        const haystack = [
          item.name,
          item.username,
          ...(item.tags || []),
          ...(item.urls || [])
        ].map((value) => String(value || '').toLowerCase()).join('\n');
        return haystack.includes(search);
      })
    : siteMatchedItems;

  // Site visuals are recorded only for a saved-login host that VaultCove actually
  // handled. This is encrypted with the vault and is not a general browsing-history log.
  const now = Date.now();
  let visualDirty = false;
  for (const item of siteMatchedItems) {
    const previous = Date.parse(item.siteVisual?.visitedAt || 0);
    if (item.siteVisual?.host !== pageUrl.hostname || !previous || now - previous > 24 * 60 * 60 * 1000) {
      item.siteVisual = { host: pageUrl.hostname, visitedAt: new Date(now).toISOString() };
      visualDirty = true;
    }
  }
  if (visualDirty) await saveUnlockedVault(state.vault, { touch: false });

  const matches = matchedItems.slice(0, 50).map(publicLoginSummary);
  const autoCandidates = isHttps && persistentHandlerEnabled && settings.autoLoginEnabled ? matches.filter((item) => item.autoLogin) : [];
  const launch = Number.isInteger(tabId) ? await pendingSecureLaunch(tabId) : null;
  const launchItem = launch && (!launch.expectedHostname || loginMatchesTrustedHost({ type:'login', urls:[`https://${launch.expectedHostname}/`] }, pageUrl.hostname))
    ? state.vault.items.find((item) => item.id === launch.itemId && loginMatchesSite(item, pageUrl.hostname))
    : null;
  const explicitSecureLoginItemId = launchItem?.id || null;
  return {
    ok: true,
    supported: true,
    unlocked: true,
    enabled: handlerRequest ? handlerEnabled : true,
    handlerEnabled: persistentHandlerEnabled,
    siteDisabled,
    handlerMode: onDemandHandlerEnabled ? 'activeTab' : persistentHandlerEnabled ? 'persistent' : 'off',
    hostname: pageUrl.hostname,
    matchCount: siteMatchedItems.length,
    filteredMatchCount: matchedItems.length,
    matches,
    autoLoginItemId: explicitSecureLoginItemId || (autoCandidates.length === 1 ? autoCandidates[0].id : null),
    explicitSecureLogin: Boolean(explicitSecureLoginItemId),
    secureLoginAllowed: isHttps,
    autoLoginEnabled: Boolean(isHttps && persistentHandlerEnabled && settings.autoLoginEnabled),
    passwordChangeDetectionEnabled: Boolean(settings.passwordChangeDetectionEnabled),
    newLoginCaptureEnabled: Boolean(settings.newLoginCaptureEnabled)
  };
}
async function pageLoginState(message, sender) {
  if ((sender?.frameId ?? 0) !== 0) {
    return { ok: true, supported: false, unlocked: false, enabled: false, handlerEnabled: false, matches: [], strictSecureLogin: true };
  }
  return buildPageLoginState(frameUrlFromSender(sender), {
    handlerRequest: true,
    tabId: sender?.tab?.id ?? null,
    query: String(message?.query || '')
  });
}

async function activeTabLoginState(message) {
  if (!Number.isInteger(message.tabId)) throw new Error('No active web tab is available.');
  const tab = await chrome.tabs.get(message.tabId);
  return buildPageLoginState(parseHttpsUrl(tab?.url || ''), { handlerRequest: false, tabId: message.tabId });
}

async function markVisitedSavedSite(sender) {
  const pageUrl = frameUrlFromSender(sender);
  if (!pageUrl) return { marked: 0 };
  if (!(await hasHandlerPermissionForUrl(pageUrl)) && !(await isOnDemandHandlerTab(sender?.tab?.id ?? null, pageUrl))) return { marked: 0 };
  const state = await loadUnlockedVault({ touch: false });
  if (state.state !== 'unlocked') return { marked: 0 };

  const now = Date.now();
  let marked = 0;
  for (const item of state.vault.items || []) {
    if (!loginMatchesSite(item, pageUrl.hostname)) continue;
    const previous = Date.parse(item.siteVisual?.visitedAt || 0);
    if (item.siteVisual?.host === pageUrl.hostname && previous && now - previous <= 24 * 60 * 60 * 1000) continue;
    item.siteVisual = { host: pageUrl.hostname, visitedAt: new Date(now).toISOString() };
    marked += 1;
  }
  if (marked) await saveUnlockedVault(state.vault, { touch: false });
  return { marked };
}


async function fillCredentialIntoFrame(tabId, frameId, item, { clearAfterMs = 1200 } = {}) {
  if (Number.isInteger(frameId) && frameId !== 0) throw new Error('Strict Secure Login is blocked inside frames. Open the trusted login page in the top-level tab.');
  const target = { tabId, frameIds: [0] };
  const results = await chrome.scripting.executeScript({
    target,
    world: 'ISOLATED',
    func: (username, password, clearDelayMs) => {
      function visible(el) {
        const rect = el.getBoundingClientRect();
        const style = getComputedStyle(el);
        return rect.width > 0 && rect.height > 0 && style.visibility !== 'hidden' && style.display !== 'none' && !el.disabled && !el.readOnly;
      }
      function setNativeValue(input, value, dispatchEvents) {
        const prototype = input instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
        const descriptor = Object.getOwnPropertyDescriptor(prototype, 'value');
        descriptor?.set?.call(input, value);
        if (dispatchEvents) {
          input.dispatchEvent(new Event('input', { bubbles: true, composed: true }));
          input.dispatchEvent(new Event('change', { bubbles: true, composed: true }));
        }
      }
      function token(el) {
        return `${el.type || ''} ${el.name || ''} ${el.id || ''} ${el.autocomplete || ''} ${el.placeholder || ''} ${el.getAttribute('aria-label') || ''}`.toLowerCase();
      }
      function openRoots() {
        const roots = [document];
        for (let index = 0; index < roots.length && index < 64; index += 1) {
          for (const node of roots[index].querySelectorAll('*')) {
            if (node.shadowRoot && !roots.includes(node.shadowRoot)) roots.push(node.shadowRoot);
          }
        }
        return roots;
      }
      function queryAll(selector) {
        return openRoots().flatMap((root) => [...root.querySelectorAll(selector)]);
      }
      function findUsername(inputs, passwordInput) {
        const candidates = inputs.filter((el) => el !== passwordInput && ['text', 'email', 'tel', ''].includes((el.type || '').toLowerCase()));
        return candidates.find((el) => {
          const type = (el.type || '').toLowerCase();
          const autocomplete = String(el.autocomplete || '').toLowerCase();
          return type === 'email' || ['username', 'email'].includes(autocomplete) || /(user(?:name)?|e[-_\s]*mail|mail|login|account|identifier|member|phone|mobile)/.test(token(el));
        }) || (() => {
          const passwordIndex = inputs.indexOf(passwordInput);
          return passwordIndex > 0 ? [...inputs.slice(0, passwordIndex)].reverse().find((el) => candidates.includes(el)) : candidates[0];
        })();
      }
      function submitFrom(field) {
        const form = field?.form || field?.closest?.('form');
        if (form?.requestSubmit) {
          form.requestSubmit();
          return true;
        }
        const candidates = queryAll('button,input[type="submit"],input[type="button"],a[role="button"]').filter(visible);
        const button = candidates.find((el) => {
          const label = `${el.textContent || ''} ${el.value || ''} ${el.getAttribute('aria-label') || ''}`.toLowerCase();
          return /(log\s*in|sign\s*in|continue|next|submit)/.test(label);
        });
        if (button) { button.click(); return true; }
        return false;
      }

      const inputs = queryAll('input').filter(visible);
      const passwordInput = inputs.find((el) => (el.type || '').toLowerCase() === 'password');
      const usernameInput = findUsername(inputs, passwordInput);
      if (!passwordInput && !usernameInput) return { ok: false, reason: 'No supported visible login field was found.' };

      if (usernameInput && username) setNativeValue(usernameInput, username, true);
      if (passwordInput) setNativeValue(passwordInput, password || '', false);
      const focusTarget = passwordInput || usernameInput;
      focusTarget?.focus();

      const submitted = submitFrom(focusTarget);
      if (!submitted) {
        if (passwordInput) setNativeValue(passwordInput, '', false);
        return { ok: false, reason: 'Strict Secure Login could not find a safe submit control. The password was cleared instead of being left in the page.' };
      }

      if (passwordInput && password) {
        const injectedPassword = password;
        const clear = () => {
          try {
            if (passwordInput.isConnected && passwordInput.value === injectedPassword) setNativeValue(passwordInput, '', false);
          } catch {}
        };
        document.addEventListener('visibilitychange', () => { if (document.visibilityState !== 'visible') clear(); }, { once: true });
        addEventListener('pagehide', clear, { once: true });
        setTimeout(clear, Math.max(150, Math.min(3000, Number(clearDelayMs) || 650)));
      }
      return {
        ok: true,
        usernameFilled: Boolean(usernameInput && username),
        passwordInjectedForSubmit: Boolean(passwordInput),
        submitted: true,
        strict: true
      };
    },
    args: [item.username || '', item.password || '', clearAfterMs]
  });
  return results?.[0]?.result || { ok: false, reason: 'Strict Secure Login did not return a result.' };
}

async function handlePageFill(message, sender) {
  const pageUrl = frameUrlFromSender(sender);
  if (!pageUrl || !sender?.tab?.id || pageUrl.protocol !== 'https:') throw new Error('VaultCove Secure Login works only on HTTPS web pages. HTTP pages can be detected and captured, but passwords are never submitted over an unencrypted connection.');
  if ((sender?.frameId ?? 0) !== 0) throw new Error('Strict Secure Login is blocked inside frames.');
  if (!Boolean(message.submit)) throw new Error('Password Fill was removed. Use Secure Login so the credential is injected only for immediate submission.');

  const [licenseState, settings, state] = await Promise.all([
    getLicenseState(),
    getSettings(),
    loadUnlockedVault({ touch: false })
  ]);
  if (!featureAllowed(licenseState, 'autofill')) throw new Error('Secure Login is unavailable for this license state.');
  if (state.state !== 'unlocked') throw new Error('VaultCove is locked.');

  const item = state.vault.items.find((candidate) => candidate.id === message.itemId && !candidate.deletedAt);
  if (!item || !secureLoginMatchesUrl(item, pageUrl)) {
    throw new Error('Blocked: the saved login is not trusted for this exact HTTPS origin.');
  }

  const automatic = Boolean(message.automatic);
  if (item.requireReauthBeforeFill && !(await hasSensitiveAccess())) {
    throw new Error('Sensitive Access required before Secure Login for this protected credential. Open VaultCove and verify your master password.');
  }
  if (automatic) {
    if (!settings.autoLoginEnabled || !item.autoLogin) throw new Error('Automatic login is not enabled for this item.');
    if (!(await hasHandlerPermissionForUrl(pageUrl))) throw new Error('Persistent access is not enabled for this website.');
    const stage = message.stage === 'password' ? 'password' : 'username';
    const guardKey = `autoLoginGuard:${sender.tab.id}:${sender.frameId ?? 0}:${pageUrl.hostname}:${pageUrl.pathname}:${stage}`;
    const guard = await chrome.storage.session.get(guardKey);
    if (Date.now() - Number(guard[guardKey] || 0) < 20000) throw new Error('Automatic login was already attempted on this page recently.');
    await chrome.storage.session.set({ [guardKey]: Date.now() });
  }

  const credential = isUseOnlySharedLogin(item) ? await openSharedLoginForFill(item, state.vaultKey) : item;
  const result = await fillCredentialIntoFrame(sender.tab.id, sender.frameId, credential, { clearAfterMs: settings.secureLoginClearMs });
  if (!automatic) await touchSession();
  return result;
}


async function fillActiveTabLogin(message) {
  if (!Boolean(message.submit)) throw new Error('Password Fill was removed. Use Secure Login.');
  if (!Number.isInteger(message.tabId)) throw new Error('No active tab is available.');
  const tab = await chrome.tabs.get(message.tabId);
  const pageUrl = parseHttpsUrl(tab?.url || '');
  if (!pageUrl) throw new Error('Strict Secure Login works only on HTTPS pages.');
  const [licenseState, settings, state] = await Promise.all([getLicenseState(), getSettings(), loadUnlockedVault({ touch: false })]);
  if (!featureAllowed(licenseState, 'autofill')) throw new Error('Secure Login is unavailable for this license state.');
  if (state.state !== 'unlocked') throw new Error('VaultCove is locked.');
  const item = state.vault.items.find((candidate) => candidate.id === message.itemId && !candidate.deletedAt);
  if (!item || !secureLoginMatchesUrl(item, pageUrl)) throw new Error('Blocked: the saved login is not trusted for this exact HTTPS origin.');
  if (item.requireReauthBeforeFill && !(await hasSensitiveAccess())) throw new Error('Sensitive Access required before Secure Login for this protected credential.');
  const credential = isUseOnlySharedLogin(item) ? await openSharedLoginForFill(item, state.vaultKey) : item;
  const result = await fillCredentialIntoFrame(message.tabId, 0, credential, { clearAfterMs: settings.secureLoginClearMs });
  await touchSession();
  return result;
}

async function getSensitiveLoginField(message) {
  if (!(await hasSensitiveAccess())) throw new Error('Sensitive Access expired. Re-enter your master password.');
  if (!Number.isInteger(message.tabId)) throw new Error('No active tab is available.');
  const tab = await chrome.tabs.get(message.tabId);
  const pageUrl = parseHttpsUrl(tab?.url || '');
  if (!pageUrl) throw new Error('Sensitive login values are available only for HTTPS pages.');

  const state = await loadUnlockedVault({ touch: false });
  if (state.state !== 'unlocked') throw new Error('VaultCove is locked.');
  const item = state.vault.items.find((candidate) => candidate.id === message.itemId && !candidate.deletedAt);
  if (!item || !loginMatchesSite(item, pageUrl.hostname)) throw new Error('Blocked: this login is not trusted for the active HTTPS hostname.');
  if (isUseOnlySharedLogin(item)) throw new Error('This shared credential is use-only. It can sign in through Secure Login but cannot be revealed or copied.');
  if (!['username', 'password'].includes(message.field)) throw new Error('Unsupported sensitive field.');
  await touchSession();
  return { value: String(item[message.field] || '') };
}

async function setSiteHandler(message) {
  if (!Number.isInteger(message.tabId)) throw new Error('No active tab is available.');
  const tab = await chrome.tabs.get(message.tabId);
  const pageUrl = parseHttpsUrl(tab?.url || '');
  if (!pageUrl) throw new Error('Persistent VaultCove access is available only for HTTPS websites.');
  const origin = permissionOriginForHost(pageUrl.hostname);
  if (!message.enabled) {
    await chrome.permissions.remove({ origins: [origin] });
    await syncBrowserIntegration();
    return { enabled: false, origin };
  }
  const granted = await chrome.permissions.contains({ origins: [origin] });
  if (!granted) throw new Error('Website permission must be granted by the user from the VaultCove popup.');
  await syncBrowserIntegration({ injectExisting: true });
  return { enabled: true, origin };
}

async function siteHandlerState(message) {
  if (!Number.isInteger(message.tabId)) return { enabled: false, supported: false };
  const tab = await chrome.tabs.get(message.tabId);
  const pageUrl = parseHttpsUrl(tab?.url || '');
  if (!pageUrl) return { enabled: false, supported: false };
  const settings = await getSettings();
  const siteDisabled = handlerDisabledForHost(settings, pageUrl.hostname);
  return { enabled: (await hasHandlerPermissionForUrl(pageUrl)) && !siteDisabled, siteDisabled, supported: true, origin: permissionOriginForHost(pageUrl.hostname), hostname: pageUrl.hostname };
}

async function removeAllSiteHandlers() {
  const origins = await grantedHandlerOrigins();
  if (origins.length) await chrome.permissions.remove({ origins });
  await setSettings({ autoLoginEnabled: false });
  await syncBrowserIntegration();
  return { removed: origins.length };
}

function normalizeUsername(value) {
  return String(value || '').trim().toLowerCase();
}

async function showPasswordChangeNotification(itemId) {
  await chrome.notifications.create(`${PASSWORD_NOTICE_PREFIX}${itemId}`, {
    type: 'basic',
    iconUrl: 'icons/icon128.png',
    title: 'VaultCove password change detected',
    message: 'A saved login appears to have a new password. Review it in VaultCove. No password or account details are sent by email.',
    buttons: [{ title: 'Review in VaultCove' }],
    priority: 2
  });
}

async function handlePasswordChangeCandidate(message, sender) {
  const pageUrl = frameUrlFromSender(sender);
  if (!pageUrl || !sender?.tab?.id) return { detected: false };
  const settings = await getSettings();
  const persistentHandlerEnabled = Boolean((await hasHandlerPermissionForUrl(pageUrl)) && !handlerDisabledForHost(settings, pageUrl.hostname));
  const onDemandHandlerEnabled = await isOnDemandHandlerTab(sender.tab.id, pageUrl);
  if (!settings.passwordChangeDetectionEnabled || (!persistentHandlerEnabled && !onDemandHandlerEnabled)) return { detected: false };

  const password = String(message.password || '');
  const confidence = String(message.confidence || '');
  if (password.length < 4 || password.length > 4096 || !['high', 'submitted-login'].includes(confidence)) return { detected: false };

  const state = await loadUnlockedVault({ touch: false });
  if (state.state !== 'unlocked') return { detected: false };
  let matches = state.vault.items.filter((item) => loginMatchesSite(item, pageUrl.hostname) && !isUseOnlySharedLogin(item));
  const username = normalizeUsername(message.username);
  let usernameMatches = [];
  if (username) {
    usernameMatches = matches.filter((item) => normalizeUsername(item.username) === username);
    if (usernameMatches.length) matches = usernameMatches;
  }
  if (confidence === 'submitted-login' && (!username || usernameMatches.length !== 1)) return { detected: false };
  if (matches.length !== 1) return { detected: false };

  const item = matches[0];
  if (item.password === password || item.pendingPasswordChange?.password === password) return { detected: false };
  item.pendingPasswordChange = {
    password,
    detectedAt: new Date().toISOString(),
    hostname: pageUrl.hostname,
    source: String(message.reason || 'password-form').slice(0, 80),
    confidence
  };
  await saveUnlockedVault(state.vault, { touch: false });
  await showPasswordChangeNotification(item.id);
  return { detected: true, itemId: item.id };
}

async function showNewLoginNotification(captureId) {
  await chrome.notifications.create(`${NEW_LOGIN_NOTICE_PREFIX}${captureId}`, {
    type: 'basic',
    iconUrl: 'icons/icon128.png',
    title: 'VaultCove new login detected',
    message: 'A submitted login is not yet saved in VaultCove. Review it before adding it to your encrypted vault.',
    buttons: [{ title: 'Review in VaultCove' }],
    priority: 1
  });
}

async function handleNewLoginCandidate(message, sender) {
  const pageUrl = frameUrlFromSender(sender);
  if (!pageUrl || !sender?.tab?.id) return { detected: false };
  const settings = await getSettings();
  const persistentHandlerEnabled = Boolean((await hasHandlerPermissionForUrl(pageUrl)) && !handlerDisabledForHost(settings, pageUrl.hostname));
  const onDemandHandlerEnabled = await isOnDemandHandlerTab(sender.tab.id, pageUrl);
  if (!settings.newLoginCaptureEnabled || (!persistentHandlerEnabled && !onDemandHandlerEnabled)) return { detected: false };

  const username = String(message.username || '').trim();
  const password = String(message.password || '');
  if (!username || username.length > 512 || password.length < 4 || password.length > 4096) return { detected: false };

  const state = await loadUnlockedVault({ touch: false });
  if (state.state !== 'unlocked') {
    const capture = createPendingLoginCapture({
      hostname: pageUrl.hostname,
      origin: pageUrl.origin,
      username,
      password,
      name: String(message.pageTitle || pageUrl.hostname),
      source: String(message.reason || 'submitted-credential')
    });
    const queued = await sealCaptureWhileLocked(capture);
    if (!queued.queued) return { detected: false, reason: queued.reason || 'locked-capture-unavailable' };
    await showNewLoginNotification(capture.id);
    return { detected: true, captureId: capture.id, queuedWhileLocked: true };
  }
  const sharedMatches = state.vault.items.filter((item) => isUseOnlySharedLogin(item) && loginMatchesSite(item, pageUrl.hostname));
  for (const sharedItem of sharedMatches) {
    try {
      const credential = await openSharedLoginForFill(sharedItem, state.vaultKey);
      if (normalizeUsername(credential.username) === normalizeUsername(username) && String(credential.password || '') === password) {
        return { detected: false, reason: 'shared-use-only-login' };
      }
    } catch {}
  }
  if (findExistingLoginForCapture(state.vault.items.filter((item) => !isUseOnlySharedLogin(item)), pageUrl.hostname, username)) {
    return { detected: false, reason: 'existing-login' };
  }

  const capture = createPendingLoginCapture({
    hostname: pageUrl.hostname,
    origin: pageUrl.origin,
    username,
    password,
    name: String(message.pageTitle || pageUrl.hostname),
    source: String(message.reason || 'submitted-credential')
  });
  const pending = prunePendingLoginCaptures(state.vault.pendingLoginCaptures);
  const duplicate = pending.find((entry) => samePendingLoginCapture(entry, capture));
  if (duplicate) return { detected: false, reason: 'already-pending', captureId: duplicate.id };

  state.vault.pendingLoginCaptures = [...pending, capture].slice(-50);
  await saveUnlockedVault(state.vault, { touch: false });
  await showNewLoginNotification(capture.id);
  return { detected: true, captureId: capture.id };
}

async function queueGenericEmailNotice(kind = 'password-changed') {
  const settings = await getSettings();
  if (!settings.securityEmailNoticeEnabled) return { queued: false, reason: 'disabled' };
  const recipientEmail = String(settings.securityNoticeEmail || '').trim();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(recipientEmail) || recipientEmail.length > 254) {
    return { queued: false, reason: 'email-not-configured' };
  }
  const deviceId = await ensureDeviceId();
  const notice = createGenericSecurityNotice(kind);
  const existing = await chrome.storage.local.get(EMAIL_NOTICE_QUEUE_KEY);
  const queue = Array.isArray(existing[EMAIL_NOTICE_QUEUE_KEY]) ? existing[EMAIL_NOTICE_QUEUE_KEY] : [];
  queue.push({ ...notice, deviceId, recipientEmail });
  await chrome.storage.local.set({ [EMAIL_NOTICE_QUEUE_KEY]: queue.slice(-100) });
  return { queued: true, transport: 'pending-license-service' };
}

async function openPasswordReview(itemId = '') {
  const params = new URLSearchParams({ view: 'security' });
  if (itemId) params.set('passwordChange', itemId);
  await chrome.tabs.create({ url: chrome.runtime.getURL(`src/vault/vault.html?${params}`) });
}

async function openNewLoginReview(captureId = '') {
  const params = new URLSearchParams({ view: 'security' });
  if (captureId) params.set('newLogin', captureId);
  await chrome.tabs.create({ url: chrome.runtime.getURL(`src/vault/vault.html?${params}`) });
}

chrome.notifications.onClicked.addListener((notificationId) => {
  if (notificationId.startsWith(PASSWORD_NOTICE_PREFIX)) {
    openPasswordReview(notificationId.slice(PASSWORD_NOTICE_PREFIX.length)).catch(console.error);
  } else if (notificationId.startsWith(NEW_LOGIN_NOTICE_PREFIX)) {
    openNewLoginReview(notificationId.slice(NEW_LOGIN_NOTICE_PREFIX.length)).catch(console.error);
  }
});
chrome.notifications.onButtonClicked.addListener((notificationId) => {
  if (notificationId.startsWith(PASSWORD_NOTICE_PREFIX)) {
    openPasswordReview(notificationId.slice(PASSWORD_NOTICE_PREFIX.length)).catch(console.error);
  } else if (notificationId.startsWith(NEW_LOGIN_NOTICE_PREFIX)) {
    openNewLoginReview(notificationId.slice(NEW_LOGIN_NOTICE_PREFIX.length)).catch(console.error);
  }
});


async function openHandlerUnlock(sender) {
  const sourceTabId = sender?.tab?.id;
  const sourceUrl = frameUrlFromSender(sender);
  if (!Number.isInteger(sourceTabId) || !sourceUrl) throw new Error('VaultCove could not identify the login tab requesting unlock.');
  const url = new URL(chrome.runtime.getURL('src/vault/vault.html'));
  url.searchParams.set('flow', HANDLER_UNLOCK_FLOW);
  url.searchParams.set('sourceTab', String(sourceTabId));
  url.searchParams.set('sourceOrigin', sourceUrl.origin);
  const tab = await chrome.tabs.create({ url: url.toString(), active: true });
  return { opened: true, tabId: tab.id };
}

async function completeHandlerUnlock(message, sender) {
  if (!trustedExtensionSender(sender)) throw new Error('Untrusted handler unlock completion request.');
  const sourceTabId = Number(message?.sourceTabId);
  const expectedOrigin = String(message?.sourceOrigin || '');
  if (!Number.isInteger(sourceTabId)) throw new Error('The original login tab is unavailable.');
  const sourceTab = await chrome.tabs.get(sourceTabId);
  const sourceUrl = parseHttpsUrl(sourceTab?.url || '');
  if (!sourceUrl || (expectedOrigin && sourceUrl.origin !== expectedOrigin)) throw new Error('The original login page changed before VaultCove was unlocked.');
  let acknowledged = await notifyHandlerTabSession(sourceTabId, 'unlocked', 6);
  if (!acknowledged) {
    // If Chrome suspended/reloaded the content script while the unlock tab was
    // open, re-attach the guarded handler once and require a fresh handshake.
    try {
      await chrome.scripting.executeScript({ target: { tabId: sourceTabId, frameIds: [0] }, files: ['src/content/handler.js'] });
    } catch {}
    acknowledged = await notifyHandlerTabSession(sourceTabId, 'unlocked', 4);
  }
  if (!acknowledged) throw new Error('VaultCove unlocked, but the original login page did not acknowledge the new session. Keep this tab open and try again.');
  const unlockTabId = sender?.tab?.id;
  if (Number.isInteger(unlockTabId) && unlockTabId !== sourceTabId) {
    setTimeout(() => chrome.tabs.remove(unlockTabId).catch(() => {}), 80);
  }
  return { completed: true, sourceTabId, handlerAcknowledged: true };
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === 'LOCK_VAULT') {
    clearSession()
      .then(() => broadcastHandlerSessionChanged('locked'))
      .then(() => sendResponse({ ok: true }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'GET_VAULT_STATE') {
    loadUnlockedVault({ touch: false }).then((state) => sendResponse({ ok: true, state: state.state })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'INITIALIZE_VAULT') {
    initializeVault(String(message.masterPassword || ''))
      .then(async () => {
        await setSettings({
          firstRunSecurityComplete: false,
          lockMinutes: 5,
          alwaysOnHandlerEnabled: true,
          newLoginCaptureEnabled: true,
          passwordChangeDetectionEnabled: true,
          securityEmailNoticeEnabled: true,
          securityNoticeEmail: '',
          websiteIconsEnabled: true,
          websiteIconsPremiumDefaultApplied: true
        });
        sendResponse({ ok: true, firstRunSecurityRequired: true });
      })
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'UNLOCK_VAULT') {
    queueMasterAuth(async () => {
      await unlockVault(String(message.masterPassword || ''), String(message.secondFactor || ''));
      await broadcastHandlerSessionChanged('unlocked');
    }).then(() => sendResponse({ ok: true })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'FILL_ACTIVE_TAB_LOGIN') {
    fillActiveTabLogin(message).then((result) => sendResponse({ ok: true, ...result })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'ENABLE_ONDEMAND_HANDLER') {
    if (!trustedExtensionSender(sender)) { sendResponse({ ok: false, error: 'Untrusted handler request.' }); return false; }
    injectOnDemandHandler(message.tabId).then((result) => sendResponse({ ok: true, ...result })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'SYNC_BROWSER_INTEGRATION') {
    syncBrowserIntegration({ injectExisting: Boolean(message.injectExisting) }).then((result) => sendResponse({ ok: true, ...result })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'MARK_VISITED_SAVED_SITE') {
    markVisitedSavedSite(sender).then((result) => sendResponse({ ok: true, ...result })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'GET_PAGE_LOGINS') {
    pageLoginState(message, sender).then(sendResponse).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'GET_ACTIVE_TAB_LOGINS') {
    activeTabLoginState(message).then(sendResponse).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'FILL_PAGE_LOGIN') {
    handlePageFill(message, sender).then((result) => sendResponse({ ok: true, ...result })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'VERIFY_SENSITIVE_ACCESS') {
    queueMasterAuth(() => verifySensitiveAccess(String(message.masterPassword || ''), null, String(message.secondFactor || ''))).then((until) => sendResponse({ ok: true, until })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'CHECK_MASTER_PASSWORD_MATCH') {
    if (!trustedExtensionSender(sender)) { sendResponse({ ok: false, error: 'Untrusted master-password comparison request.' }); return false; }
    queueMasterAuth(() => matchesCurrentMasterPassword(String(message.candidate || ''))).then((matches) => sendResponse({ ok: true, matches })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'SENSITIVE_ACCESS_STATUS') {
    hasSensitiveAccess().then((active) => sendResponse({ ok: true, active })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'GET_SENSITIVE_LOGIN_FIELD') {
    getSensitiveLoginField(message).then((result) => sendResponse({ ok: true, ...result })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'NEW_LOGIN_CANDIDATE') {
    handleNewLoginCandidate(message, sender).then((result) => sendResponse({ ok: true, ...result })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'PASSWORD_CHANGE_CANDIDATE') {
    handlePasswordChangeCandidate(message, sender).then((result) => sendResponse({ ok: true, ...result })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'PASSWORD_CHANGE_CONFIRMED') {
    queueGenericEmailNotice('password-changed').then(async (notice) => {
      await chrome.notifications.create('', {
        type: 'basic',
        iconUrl: 'icons/icon128.png',
        title: 'VaultCove saved the password update',
        message: notice.queued
          ? 'A generic security-email notice is queued. It contains no website, username, account name, old password, or new password.'
          : 'The encrypted login was updated locally. No website, username, account name, old password, or new password was sent anywhere.'
      });
      sendResponse({ ok: true, ...notice });
    }).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'SET_SITE_HANDLER') {
    setSiteHandler(message).then((result) => sendResponse({ ok: true, ...result })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'GET_SITE_HANDLER_STATE') {
    siteHandlerState(message).then((result) => sendResponse({ ok: true, ...result })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'LIST_SITE_HANDLERS') {
    grantedHandlerOrigins().then((origins) => sendResponse({ ok: true, origins })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'REMOVE_ALL_SITE_HANDLERS') {
    removeAllSiteHandlers().then((result) => sendResponse({ ok: true, ...result })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'SYNC_ALWAYS_ON_HANDLER') {
    syncAlwaysOnHandlerSetting().then(async (enabled) => {
      const result = await syncBrowserIntegration({ injectExisting: Boolean(message.injectExisting) });
      sendResponse({ ok: true, enabled, ...result });
    }).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'SET_HANDLER_SITE_EXCEPTION') {
    setHandlerSiteException(String(message.hostname || ''), Boolean(message.disabled))
      .then((result) => sendResponse({ ok: true, ...result }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'LIST_HANDLER_SITE_EXCEPTIONS') {
    getSettings().then((settings) => sendResponse({ ok: true, handlerDisabledHosts: settings.handlerDisabledHosts || [] }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'CHECK_FOR_UPDATES') {
    checkForUpdates({ force: Boolean(message.force) }).then((result) => sendResponse({ ok: true, ...result })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'OPEN_LOGIN_ITEM') {
    openLoginItem(message, sender).then((result) => sendResponse({ ok: true, ...result })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'OPEN_HANDLER_UNLOCK') {
    openHandlerUnlock(sender).then((result) => sendResponse({ ok: true, ...result })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'COMPLETE_HANDLER_UNLOCK') {
    completeHandlerUnlock(message, sender).then((result) => sendResponse({ ok: true, ...result })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'OPEN_DASHBOARD') {
    chrome.tabs.create({ url: chrome.runtime.getURL('src/vault/vault.html') }).then(() => sendResponse({ ok: true })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  return false;
});

initialize().catch(console.error);
