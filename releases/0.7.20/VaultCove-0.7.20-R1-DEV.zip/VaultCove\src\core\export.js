import { EXPORT_AAD, EXPORT_MAGIC, EXPORT_VERSION } from './constants.js';
import { importAesKey, encryptJson, decryptJson } from './crypto.js';
import { base64UrlToBytes, bytesToBase64Url, randomBytes } from './encoding.js';
import { normalizeVault } from './model.js';
import { isSealedTrashItem, restoreSealedTrashItem, sealItemForTrash, trashPurgeAt } from './trash.js';
import { saveBlob } from './file-save.js';

export const BACKUP_SNAPSHOT_MAGIC = 'VAULTCOVE-BACKUP-SNAPSHOT';
export const BACKUP_SNAPSHOT_VERSION = 2;

export const BACKUP_COMPONENTS = Object.freeze({
  logins: 'Login credentials',
  folders: 'Folders',
  cards: 'Cards',
  banks: 'Bank accounts',
  identities: 'Identities',
  notes: 'Secure notes',
  totpCodes: 'TOTP codes',
  trash: 'Trash',
  favorites: 'Favorites',
  settings: 'Other settings'
});

const ITEM_COMPONENT_TYPES = Object.freeze({
  logins: 'login',
  cards: 'card',
  banks: 'bank',
  identities: 'identity',
  notes: 'note'
});

const PORTABLE_SETTING_KEYS = Object.freeze([
  'lockMinutes',
  'sensitiveAccessSeconds',
  'requireReauthForSecrets',
  'clipboardWarning',
  'revealTimeoutSeconds',
  'secureLoginClearMs',
  'profileName',
  'inlineHandlerEnabled',
  'alwaysOnHandlerEnabled',
  'handlerDisabledHosts',
  'autoLoginEnabled',
  'websiteIconsEnabled',
  'vaultViewMode',
  'theme',
  'compactUi',
  'updateChecksEnabled',
  'passwordChangeDetectionEnabled',
  'newLoginCaptureEnabled',
  'securityEmailNoticeEnabled',
  'securityNoticeEmail',
  'firstRunSecurityComplete'
]);

function cloneJson(value) {
  return value == null ? value : JSON.parse(JSON.stringify(value));
}

function createProductNeutralSecretBytes() {
  // Avoid a visible product marker at the beginning of new backup secrets.
  // This only makes the token less self-identifying; the actual security is the
  // full 256 bits of randomness plus authenticated AES-GCM encryption.
  for (;;) {
    const bytes = randomBytes(32);
    const encoded = bytesToBase64Url(bytes);
    if (!/^vc/i.test(encoded)) return { bytes, encoded };
  }
}

export function defaultBackupSelection() {
  return {
    logins: true,
    folders: false,
    cards: false,
    banks: false,
    identities: false,
    notes: false,
    totpCodes: false,
    trash: false,
    favorites: false,
    settings: false
  };
}

export function normalizeBackupSelection(selection = {}) {
  const defaults = defaultBackupSelection();
  const normalized = {};
  for (const key of Object.keys(BACKUP_COMPONENTS)) normalized[key] = Boolean(selection[key] ?? defaults[key]);
  // Login credentials are the non-optional core of every .vcvault backup.
  normalized.logins = true;
  return normalized;
}

export function selectedBackupComponents(selection = {}) {
  const normalized = normalizeBackupSelection(selection);
  return Object.entries(BACKUP_COMPONENTS)
    .filter(([key]) => normalized[key])
    .map(([key, label]) => ({ key, label }));
}

function portableSettingsSnapshot(settings = {}) {
  const snapshot = {};
  for (const key of PORTABLE_SETTING_KEYS) {
    if (Object.prototype.hasOwnProperty.call(settings, key)) snapshot[key] = cloneJson(settings[key]);
  }
  return snapshot;
}

function restorePortableSettings(settings = {}) {
  return portableSettingsSnapshot(settings);
}

function activeItemsByType(vault, type) {
  return (vault.items || []).filter((item) => !item.deletedAt && item.type === type && item.sharedAccess?.mode !== 'use-only');
}

function backupItemCopy(item) {
  const copy = cloneJson(item);
  copy.favorite = false;
  copy.folderId = null;
  if (copy.type === 'login') copy.totpSecret = '';
  return copy;
}

function loginMatchAnchor(item) {
  return {
    id: String(item?.id || ''),
    name: String(item?.name || ''),
    username: String(item?.username || ''),
    url: String(item?.urls?.[0] || '')
  };
}

function findLoginByAnchor(vault, anchor) {
  const activeLogins = activeItemsByType(vault, 'login');
  const exact = activeLogins.find((item) => item.id === anchor?.id);
  if (exact) return exact;
  const name = String(anchor?.name || '').trim().toLowerCase();
  const username = String(anchor?.username || '').trim().toLowerCase();
  const url = String(anchor?.url || '').trim().toLowerCase();
  return activeLogins.find((item) =>
    String(item.name || '').trim().toLowerCase() === name &&
    String(item.username || '').trim().toLowerCase() === username &&
    String(item.urls?.[0] || '').trim().toLowerCase() === url
  ) || null;
}

export async function createBackupSnapshot(vaultData, settings = {}, selection = {}, { vaultKey = null } = {}) {
  const vault = normalizeVault(vaultData);
  const chosen = normalizeBackupSelection(selection);
  const items = [];

  for (const [component, type] of Object.entries(ITEM_COMPONENT_TYPES)) {
    if (!chosen[component]) continue;
    items.push(...activeItemsByType(vault, type).map(backupItemCopy));
  }

  let skippedUseOnly = 0;
  if (chosen.trash) {
    if (!vaultKey) throw new Error('The unlocked vault key is required to create a portable Trash backup.');
    for (const item of (vault.items || []).filter((candidate) => candidate.deletedAt)) {
      let portable = cloneJson(item);
      if (isSealedTrashItem(item)) portable = await restoreSealedTrashItem(item, vaultKey);
      if (portable.sharedAccess?.mode === 'use-only') { skippedUseOnly += 1; continue; }
      portable.deletedAt = item.deletedAt;
      portable.purgeAt = item.purgeAt || new Date(trashPurgeAt(item)).toISOString();
      portable.portableTrash = true;
      items.push(portable);
    }
  }

  const snapshot = {
    magic: BACKUP_SNAPSHOT_MAGIC,
    version: BACKUP_SNAPSHOT_VERSION,
    createdAt: new Date().toISOString(),
    selection: chosen,
    vault: {
      dataVersion: 1,
      items,
      folders: chosen.folders ? cloneJson(vault.folders || []) : [],
      createdAt: vault.createdAt,
      updatedAt: vault.updatedAt
    },
    overlays: {
      folderAssignments: chosen.folders
        ? (vault.items || []).filter((item) => !item.deletedAt && item.sharedAccess?.mode !== 'use-only' && item.folderId).map((item) => ({ itemId: item.id, folderId: item.folderId }))
        : [],
      favorites: chosen.favorites
        ? (vault.items || []).filter((item) => !item.deletedAt && item.sharedAccess?.mode !== 'use-only' && item.favorite).map((item) => item.id)
        : [],
      totpCodes: chosen.totpCodes
        ? activeItemsByType(vault, 'login').filter((item) => item.totpSecret).map((item) => ({ ...loginMatchAnchor(item), secret: item.totpSecret }))
        : []
    },
    settings: chosen.settings ? portableSettingsSnapshot(settings) : null,
    exclusions: { useOnlySharedLogins: (vault.items || []).filter((item) => !item.deletedAt && item.sharedAccess?.mode === 'use-only').length + skippedUseOnly }
  };
  return snapshot;
}

export function isComponentBackupSnapshot(value) {
  return Boolean(value && value.magic === BACKUP_SNAPSHOT_MAGIC && Number(value.version) === BACKUP_SNAPSHOT_VERSION);
}

export async function restoreBackupSnapshot(currentVaultData, backupSnapshot, { vaultKey = null, nowMs = Date.now() } = {}) {
  if (!isComponentBackupSnapshot(backupSnapshot)) {
    return { vault: normalizeVault(backupSnapshot), settings: null, selection: null, legacy: true, skippedTotp: 0 };
  }

  const current = normalizeVault(cloneJson(currentVaultData));
  const chosen = normalizeBackupSelection(backupSnapshot.selection || {});
  const backedVault = normalizeVault(cloneJson(backupSnapshot.vault || {}));
  const backedItems = Array.isArray(backedVault.items) ? backedVault.items : [];

  for (const [component, type] of Object.entries(ITEM_COMPONENT_TYPES)) {
    if (!chosen[component]) continue;
    const existing = current.items.filter((item) => !item.deletedAt && item.type === type && item.sharedAccess?.mode !== 'use-only');
    const replacements = backedItems
      .filter((item) => !item.deletedAt && item.type === type && item.sharedAccess?.mode !== 'use-only')
      .map((item) => {
        const copy = cloneJson(item);
        const prior = existing.find((candidate) => candidate.id === copy.id) || (type === 'login' ? findLoginByAnchor({ items: existing }, loginMatchAnchor(copy)) : null);
        if (prior && !chosen.folders) copy.folderId = prior.folderId || null;
        if (prior && !chosen.favorites) copy.favorite = Boolean(prior.favorite);
        if (prior && type === 'login' && !chosen.totpCodes) copy.totpSecret = String(prior.totpSecret || '');
        return copy;
      });
    current.items = current.items.filter((item) => item.deletedAt || item.type !== type || item.sharedAccess?.mode === 'use-only');
    current.items.push(...replacements);
  }

  let expiredTrashSkipped = 0;
  if (chosen.trash) {
    if (!vaultKey) throw new Error('The unlocked vault key is required to restore portable Trash items.');
    current.items = current.items.filter((item) => !item.deletedAt);
    for (const item of backedItems.filter((candidate) => candidate.deletedAt)) {
      const purgeAt = trashPurgeAt(item);
      if (purgeAt && nowMs >= purgeAt) { expiredTrashSkipped += 1; continue; }
      const portable = cloneJson(item);
      delete portable.portableTrash;
      delete portable.purgeAt;
      const sealed = await sealItemForTrash(portable, vaultKey, { deletedAt: item.deletedAt });
      current.items.push(sealed);
    }
  }

  if (chosen.folders) {
    current.folders = cloneJson(backedVault.folders || []);
    for (const item of current.items) if (!item.deletedAt && item.sharedAccess?.mode !== 'use-only') item.folderId = null;
    const validFolders = new Set(current.folders.map((folder) => folder.id));
    for (const assignment of backupSnapshot.overlays?.folderAssignments || []) {
      const item = current.items.find((candidate) => !candidate.deletedAt && candidate.sharedAccess?.mode !== 'use-only' && candidate.id === assignment.itemId);
      if (item && validFolders.has(assignment.folderId)) item.folderId = assignment.folderId;
    }
  }

  if (chosen.favorites) {
    for (const item of current.items) if (!item.deletedAt && item.sharedAccess?.mode !== 'use-only') item.favorite = false;
    const favoriteIds = new Set((backupSnapshot.overlays?.favorites || []).map(String));
    for (const item of current.items) if (!item.deletedAt && item.sharedAccess?.mode !== 'use-only' && favoriteIds.has(String(item.id))) item.favorite = true;
  }

  let skippedTotp = 0;
  if (chosen.totpCodes) {
    for (const item of current.items) if (!item.deletedAt && item.type === 'login' && item.sharedAccess?.mode !== 'use-only') item.totpSecret = '';
    for (const entry of backupSnapshot.overlays?.totpCodes || []) {
      const item = findLoginByAnchor(current, entry);
      if (!item) { skippedTotp += 1; continue; }
      item.totpSecret = String(entry.secret || '');
    }
  }

  current.updatedAt = new Date().toISOString();
  return {
    vault: normalizeVault(current),
    settings: chosen.settings ? restorePortableSettings(backupSnapshot.settings || {}) : null,
    selection: chosen,
    legacy: false,
    skippedTotp,
    expiredTrashSkipped,
    excludedUseOnly: Number(backupSnapshot.exclusions?.useOnlySharedLogins || 0)
  };
}

export async function createPortableExport(vaultData) {
  const generated = createProductNeutralSecretBytes();
  const secretBytes = generated.bytes;
  const exportKey = await importAesKey(secretBytes);
  const encrypted = await encryptJson(exportKey, vaultData, EXPORT_AAD);
  const digest = new Uint8Array(await crypto.subtle.digest('SHA-256', secretBytes));
  const keyId = bytesToBase64Url(digest.subarray(0, 8));
  const payload = {
    magic: EXPORT_MAGIC,
    version: EXPORT_VERSION,
    createdAt: new Date().toISOString(),
    encryption: {
      algorithm: 'AES-256-GCM',
      aad: EXPORT_AAD,
      keyId,
      iv: encrypted.iv,
      ciphertext: encrypted.ciphertext
    }
  };
  return { payload, secret: generated.encoded };
}

export async function decryptPortableExport(payload, secret) {
  if (!payload || payload.magic !== EXPORT_MAGIC || payload.version !== EXPORT_VERSION) {
    throw new Error('This is not a supported VaultCove export.');
  }
  if (typeof secret !== 'string' || !secret.trim()) {
    throw new Error('Enter the matching backup secret.');
  }
  const normalizedSecret = secret.trim();
  // Backward compatibility: VaultCove 0.7.11 and earlier used a VC1- marker.
  // New secrets are deliberately prefixless and look like ordinary random tokens.
  const encodedSecret = normalizedSecret.startsWith('VC1-') ? normalizedSecret.slice(4) : normalizedSecret;
  const secretBytes = base64UrlToBytes(encodedSecret);
  if (secretBytes.length !== 32) throw new Error('Invalid export secret.');
  const digest = new Uint8Array(await crypto.subtle.digest('SHA-256', secretBytes));
  const expectedKeyId = bytesToBase64Url(digest.subarray(0, 8));
  if (payload.encryption?.keyId !== expectedKeyId) throw new Error('The export secret does not match this file.');
  const exportKey = await importAesKey(secretBytes);
  try {
    return await decryptJson(exportKey, payload.encryption, EXPORT_AAD);
  } catch {
    throw new Error('Export authentication failed. The secret is wrong or the file was modified.');
  }
}

export async function downloadExport(payload, filename = null) {
  const text = JSON.stringify(payload);
  const blob = new Blob([text], { type: 'application/octet-stream' });
  return saveBlob(blob, filename || `VaultCove-${new Date().toISOString().replace(/[:.]/g, '-')}.vcvault`, { description: 'VaultCove encrypted vault backup', mime: 'application/octet-stream' });
}
