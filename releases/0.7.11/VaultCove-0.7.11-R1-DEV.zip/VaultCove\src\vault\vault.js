import { assignItemsToFolder, createFolder, createItem, deleteFolder, normalizeVault, purgeItem, renameFolder, upsertItem } from '../core/model.js';
import { initializeVault, loadUnlockedVault, rotateMasterPasswordVerified, saveUnlockedVault } from '../core/vault.js';
import { createPortableExport, decryptPortableExport, downloadExport } from '../core/export.js';
import { assessPassword, generatePassword, vaultHealth } from '../core/password.js';
import { buildTotpUri, generateRecoveryCodes, generateTotp, generateTotpSecret, hashRecoveryCodes, verifyRecoveryCode, verifyTotp } from '../core/totp.js';
import { getLicenseState, featureAllowed } from '../core/license.js';
import { clearSensitiveAccess, ensureDeviceRecoveryToken, getSessionExpiry, getSettings, hasSensitiveAccess, setDeviceRecoveryToken, setSettings, touchSession } from '../core/storage.js';
import { importMigrationCsv, mergeImportedItems } from '../core/migration.js';
import { maskIdentifier } from '../core/redaction.js';
import {
  addTrustedShareContact,
  createSecureShare,
  downloadJsonFile,
  ensureSharingIdentity,
  openSecureShare,
  recordShareHistory
} from '../core/share.js';
import { createEncryptedVckey, maskedFingerprint, maskedShareId, openEncryptedVckey } from '../core/share-key.js';
import { createRecoveryKit, openRecoveryKit } from '../core/recovery.js';
import { isSealedTrashItem, moveVaultItemToTrash, restoreVaultItemFromTrash, trashDaysRemaining, trashPurgeAt, TRASH_RETENTION_DAYS } from '../core/trash.js';
import { THEMES, applyTheme } from '../core/themes.js';
import { passwordAgeState, passwordAgeSummary } from '../core/password-age.js';
import {
  beginDeviceManagement,
  beginLicenseActivation,
  changeLicensedDevice,
  completeDeviceManagement,
  completeLicenseActivation,
  completeRetainedDeviceRecovery,
  ensureLicenseServicePermission,
  getLicenseClientState,
  licensePrivacyContract,
  listLicensedDevices,
  refreshLicenseLease,
  releaseCurrentDevice,
  setLicenseServiceUrl
} from '../core/license-service.js';
import { installTooltips } from './tooltip.js';
import { BUILD_CHANNEL } from '../core/build.js';
import { uiIcon } from './icons.js';
import { saveBlob, chooseSaveHandle, writeBlobToSaveTarget } from '../core/file-save.js';

document.documentElement.dataset.vcModuleLoaded = '1';

const $ = (id) => document.getElementById(id);
const els = Object.fromEntries([...document.querySelectorAll('[id]')].map((el) => [el.id, el]));
let vault = null;
let currentView = 'dashboard';
let licenseState = null;
let totpTimer = null;
let generatedPassword = '';
let settingsState = null;
let pendingMigration = null;
let pendingSensitiveAction = null;
let handlerPermissionState = [];
let selectedItemId = null;
let unlockBusy = false;
let sensitiveVerifyBusy = false;
let tooltipObserver = null;
let pendingTotpSetup = null;
let pendingVckeyOperation = null;
let pendingLicenseOtp = null;
let pendingLicenseReclaim = null;
let pendingRecoveryOperation = null;
let licenseManagementToken = '';
let activeFolderId = 'all';
let firstRunRecoveryCreated = false;
const isDeveloperBuild = BUILD_CHANNEL === 'dev';

const viewNames = {
  dashboard: 'Vault Overview', all: 'Vault', favorites: 'Favorites', login: 'Logins', card: 'Cards', bank: 'Bank Accounts',
  identity: 'Identities', note: 'Secure Notes', totp: 'TOTP Codes', generator: 'Password Generator', security: 'Security Center',
  migration: 'Migration Center', shared: 'Shared', license: 'License and Devices', backup: 'Backup and Restore', trash: 'Trash', settings: 'Settings'
};

const viewSubtitles = {
  dashboard: 'Everything stays on your device. You are in control.',
  all: 'Browse every encrypted item stored in this local vault.',
  favorites: 'Add or remove Favorites directly while keeping every item encrypted in the local vault.',
  login: 'Passwords and usernames remain encrypted until the vault is unlocked.',
  card: 'Payment-card fields are stored inside the encrypted vault payload.',
  bank: 'Bank details remain local and encrypted on this device.',
  identity: 'Keep identity and address records inside your offline vault.',
  note: 'Store private text without sending it to a cloud service.',
  totp: 'Authenticator codes are generated locally from encrypted TOTP secrets.',
  generator: 'Generate cryptographically random passwords entirely on this device.',
  security: 'Password health is calculated locally after you unlock the vault.',
  migration: 'Import LastPass or Zoho Vault CSV exports locally, then immediately re-encrypt them into VaultCove.',
  shared: 'Share selected logins with another VaultCove or VaultCore user using recipient-key encryption.',
  license: 'Activate VaultCove, bind your serial to your email, and monitor Standard or Admin device slots.',
  backup: 'Create or restore encrypted vault backups and offline Recovery Kits.',
  trash: `Removed items are sealed in a second encrypted envelope, cannot be opened, and are automatically deleted after ${TRASH_RETENTION_DAYS} days unless restored.`,
  settings: 'Control appearance, auto-lock, browser handling, master password, recovery, and privacy.'
};

function toast(text, isError = false) {
  els.toast.textContent = text;
  els.toast.style.borderColor = isError ? '#8f3650' : '#3d6d94';
  els.toast.classList.add('show');
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => els.toast.classList.remove('show'), 3500);
}

function showGate(panel) {
  document.documentElement.dataset.vcBootReady = '1';
  document.documentElement.classList.add('vaultLocked');
  document.body.classList.add('lockedState');
  els.gate.classList.remove('hidden');
  els.app.classList.add('hidden');
  els.setupPanel.classList.add('hidden');
  els.securitySetupPanel?.classList.add('hidden');
  els.unlockPanel.classList.add('hidden');
  els[panel].classList.remove('hidden');
  if (panel === 'unlockPanel' && els.unlockTotpLabel) els.unlockTotpLabel.classList.toggle('hidden', !settingsState?.vaultTotpEnabled);
}

function showApp() {
  document.documentElement.dataset.vcBootReady = '1';
  document.documentElement.classList.remove('vaultLocked');
  document.body.classList.remove('lockedState');
  els.gate.classList.add('hidden');
  els.app.classList.remove('hidden');
}

function applyCurrentTheme() { return applyTheme(settingsState?.theme || 'midnight'); }
function applyCurrentDensity() { document.documentElement.classList.toggle('compactUi', settingsState?.compactUi !== false); }
function applyCurrentAppearance() { applyCurrentTheme(); applyCurrentDensity(); }


function validSecurityEmail(value) {
  const email = String(value || '').trim();
  return email.length <= 254 && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function updateFirstRunSecurityStatus() {
  if (!els.securitySetupPanel) return;
  const protection = vaultTotpProtection();
  if (els.firstRunAuthenticatorStatus) {
    els.firstRunAuthenticatorStatus.textContent = protection.enabled
      ? 'Enabled — save the recovery codes outside VaultCove'
      : 'Recommended before storing important logins';
  }
  if (els.firstRunAuthenticator) {
    els.firstRunAuthenticator.textContent = protection.enabled ? 'Authenticator enabled' : 'Set up now';
    els.firstRunAuthenticator.disabled = Boolean(protection.enabled);
  }
  const recoveryReady = Boolean(firstRunRecoveryCreated || vault?.recovery?.lastRecoveryKitAt);
  if (els.firstRunRecoveryStatus) els.firstRunRecoveryStatus.textContent = recoveryReady ? 'Recovery Kit created — keep it on separate media' : 'Recommended for identity and device recovery';
  if (els.firstRunRecovery) els.firstRunRecovery.textContent = recoveryReady ? 'Create another copy' : 'Create now';
}

function showFirstRunSecuritySetup() {
  if (!vault) return;
  showGate('securitySetupPanel');
  els.firstRunSecurityEmail.value = settingsState?.securityNoticeEmail || '';
  els.firstRunEmailNotice.checked = settingsState?.securityEmailNoticeEnabled !== false;
  els.firstRunLockMinutes.value = String(Math.max(1, Math.min(120, Number(settingsState?.lockMinutes) || 5)));
  els.firstRunMasterAck.checked = false;
  els.firstRunSecurityError.textContent = '';
  els.firstRunSecurityError.classList.add('hidden');
  updateFirstRunSecurityStatus();
}

async function createFirstRunRecoveryKit() {
  const password = await requestRecoveryPassword('export');
  const comparison = await runtimeMessage({ type: 'CHECK_MASTER_PASSWORD_MATCH', candidate: password });
  if (comparison.matches) throw new Error('The Recovery Password must be different from your VaultCove master password.');
  await ensureSharingIdentity(vault);
  const token = await ensureDeviceRecoveryToken();
  const kit = await createRecoveryKit(vault, token, password, { includeAuthenticator: vaultTotpProtection().enabled });
  const saveResult = await downloadJsonFile(kit, 'VaultCove-Recovery.vcrecovery', 'application/json');
  if (saveResult?.cancelled) return false;
  vault.recovery = { ...(vault.recovery || {}), lastRecoveryKitAt: new Date().toISOString() };
  await saveUnlockedVault(vault);
  firstRunRecoveryCreated = true;
  updateFirstRunSecurityStatus();
  toast('Encrypted offline Recovery Kit created. Store it separately from this device.');
  return true;
}

function installNavigationIcons() {
  const icons = { dashboard:'dashboard', all:'vault', favorites:'favorite', login:'login', card:'card', bank:'bank', identity:'identity', note:'note', totp:'totp', generator:'generator', security:'security', migration:'migration', shared:'shared', license:'devices', backup:'backup', trash:'trash', settings:'settings' };
  document.querySelectorAll('nav button[data-view]').forEach((button) => {
    const mount = button.querySelector('.navIcon');
    if (mount) mount.innerHTML = uiIcon(icons[button.dataset.view] || 'vault', 16);
  });
}

installNavigationIcons();

function escapeHtml(value) {
  return String(value ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#039;');
}

async function downloadTextFile(text, filename) {
  const blob = new Blob([String(text || '')], { type: 'text/plain;charset=utf-8' });
  return saveBlob(blob, filename, { description: 'VaultCove public identity text', mime: 'text/plain' });
}

function publicIdentityText(identity) {
  return [
    'VaultCove Public Sharing Identity',
    '================================',
    '',
    `Display Name: ${identity.displayName || 'VaultCove User'}`,
    `Share ID: ${identity.shareId}`,
    `Fingerprint: ${identity.fingerprint}`,
    `Exported/Converted: ${new Date().toISOString()}`,
    '',
    'Encryption Public Key (JWK)',
    JSON.stringify(identity.encryptionPublicJwk, null, 2),
    '',
    'Signing Public Key (JWK)',
    JSON.stringify(identity.signingPublicJwk, null, 2),
    '',
    'SECURITY NOTE',
    'This TXT contains public sharing identity data only. It does not contain the VaultCove master password, .vckey password, saved website credentials, TOTP secrets, or private sharing keys.'
  ].join('\n');
}

async function runtimeMessage(payload) {
  const response = await chrome.runtime.sendMessage(payload);
  if (!response?.ok) throw new Error(response?.error || 'VaultCove request failed.');
  return response;
}

function closeSensitiveDialog() {
  els.sensitivePassword.value = '';
  if (els.sensitiveTotp) els.sensitiveTotp.value = '';
  if (els.sensitiveError) { els.sensitiveError.textContent = ''; els.sensitiveError.classList.add('hidden'); }
  pendingSensitiveAction = null;
  if (els.sensitiveDialog.open) els.sensitiveDialog.close();
}

async function ensureSensitiveAccess(reason, action) {
  if (await hasSensitiveAccess()) return action();
  pendingSensitiveAction = action;
  els.sensitiveReason.textContent = reason;
  els.sensitivePassword.value = '';
  if (els.sensitiveTotp) els.sensitiveTotp.value = '';
  if (els.sensitiveTotpLabel) els.sensitiveTotpLabel.classList.toggle('hidden', !settingsState?.vaultTotpEnabled);
  if (els.sensitiveError) { els.sensitiveError.textContent = ''; els.sensitiveError.classList.add('hidden'); }
  els.sensitiveDialog.showModal();
  setTimeout(() => els.sensitivePassword.focus(), 0);
  return undefined;
}


async function ensureFreshSensitiveAccess(reason, action) {
  // Some identity/key operations intentionally require a new master-password
  // verification every time rather than inheriting the short Sensitive Access window.
  await clearSensitiveAccess();
  return ensureSensitiveAccess(reason, action);
}


function closeVckeyDialog(error = null) {
  const pending = pendingVckeyOperation;
  pendingVckeyOperation = null;
  if ($('vckeyPassword')) $('vckeyPassword').value = '';
  if ($('vckeyPasswordConfirm')) $('vckeyPasswordConfirm').value = '';
  if ($('vckeyError')) { $('vckeyError').textContent = ''; $('vckeyError').classList.add('hidden'); }
  if (els.vckeyDialog?.open) els.vckeyDialog.close();
  if (pending && error) pending.reject(error);
}

function requestVckeyPassword(mode) {
  if (pendingVckeyOperation) return Promise.reject(new Error('Another .vckey password operation is already open.'));
  return new Promise((resolve, reject) => {
    pendingVckeyOperation = { mode, resolve, reject };
    $('vckeyDialogTitle').textContent = mode === 'export' ? 'Protect exported .vckey' : mode === 'convert' ? 'Decrypt .vckey for TXT conversion' : 'Unlock imported .vckey';
    $('vckeyDialogSubtitle').textContent = mode === 'export'
      ? 'Create a password only for this .vckey file. It must be different from and is never a replacement for your VaultCove master password.'
      : mode === 'convert'
        ? 'Enter the separate password that protects this .vckey file. Google Authenticator authorization is checked separately before VaultCove permits plaintext conversion.'
        : "Enter the separate password chosen when this .vckey was exported. Your VaultCove master password is not used to decrypt another person's .vckey.";
    $('vckeyConfirmLabel').classList.toggle('hidden', mode !== 'export');
    $('vckeyPassword').value = '';
    $('vckeyPasswordConfirm').value = '';
    $('vckeyError').textContent = '';
    $('vckeyError').classList.add('hidden');
    els.vckeyDialog.showModal();
    setTimeout(() => $('vckeyPassword').focus(), 0);
  });
}
function closeRecoveryDialog() {
  if ($('recoveryPassword')) $('recoveryPassword').value='';
  if ($('recoveryPasswordConfirm')) $('recoveryPasswordConfirm').value='';
  if ($('recoveryError')) { $('recoveryError').textContent=''; $('recoveryError').classList.add('hidden'); }
  if (els.recoveryDialog?.open) els.recoveryDialog.close();
  const pending=pendingRecoveryOperation; pendingRecoveryOperation=null; return pending;
}
function requestRecoveryPassword(mode) {
  if (pendingRecoveryOperation) return Promise.reject(new Error('Another Recovery Password operation is already open.'));
  return new Promise((resolve,reject)=>{
    pendingRecoveryOperation={mode,resolve,reject};
    $('recoveryDialogTitle').textContent=mode==='export'?'Protect Recovery Kit':'Unlock Recovery Kit';
    $('recoveryDialogSubtitle').textContent=mode==='export'?'Create a separate Recovery Password for this offline disaster-recovery file.':'Enter the Recovery Password used when this offline kit was created.';
    $('recoveryConfirmLabel').classList.toggle('hidden',mode!=='export');
    $('recoveryTotpOption').classList.toggle('hidden',mode!=='export');
    $('recoveryPassword').value=''; $('recoveryPasswordConfirm').value=''; $('recoveryError').classList.add('hidden');
    els.recoveryDialog.showModal(); setTimeout(()=>$('recoveryPassword').focus(),0);
  });
}

function closeLicenseOtpDialog(error = null) {
  const pending = pendingLicenseOtp;
  pendingLicenseOtp = null;
  $('licenseOtpCode').value = '';
  $('licenseOtpError').textContent = '';
  $('licenseOtpError').classList.add('hidden');
  if (els.licenseOtpDialog?.open) els.licenseOtpDialog.close();
  if (pending && error) pending.reject(error);
}

function requestLicenseOtp({ title, subtitle, onVerify }) {
  if (pendingLicenseOtp) return Promise.reject(new Error('A license verification prompt is already open.'));
  return new Promise((resolve, reject) => {
    pendingLicenseOtp = { resolve, reject, onVerify };
    $('licenseOtpTitle').textContent = title;
    $('licenseOtpSubtitle').textContent = subtitle;
    $('licenseOtpCode').value = '';
    $('licenseOtpError').textContent = '';
    $('licenseOtpError').classList.add('hidden');
    els.licenseOtpDialog.showModal();
    setTimeout(() => $('licenseOtpCode').focus(), 0);
  });
}


function closeLicenseReclaimDialog(error = null) {
  const pending = pendingLicenseReclaim;
  pendingLicenseReclaim = null;
  if ($('licenseReclaimError')) { $('licenseReclaimError').textContent = ''; $('licenseReclaimError').classList.add('hidden'); }
  if (els.licenseReclaimDialog?.open) els.licenseReclaimDialog.close();
  if (pending && error) pending.reject(error);
}
function requestLicenseReclaim(result, deviceLabel, serialHint) {
  if (pendingLicenseReclaim) return Promise.reject(new Error('A device recovery selection is already open.'));
  const candidates = Array.isArray(result?.reclaimCandidates) ? result.reclaimCandidates : [];
  return new Promise((resolve, reject) => {
    pendingLicenseReclaim = { resolve, reject, result, deviceLabel, serialHint };
    const select = $('licenseReclaimSelect');
    select.innerHTML = candidates.map((device) => {
      const last = device.lastSeenAt ? new Date(device.lastSeenAt).toLocaleString() : 'unknown';
      return `<option value="${escapeHtml(device.installationId)}">Reclaim ${escapeHtml(device.deviceLabel || 'VaultCove device')} - ${escapeHtml(device.platform || 'unknown platform')} - last seen ${escapeHtml(last)}</option>`;
    }).join('') + (Number(result.usedDevices || 0) < Number(result.maxDevices || 0) ? '<option value="__new__">Use a new device slot instead</option>' : '');
    $('licenseReclaimError').textContent = '';
    $('licenseReclaimError').classList.add('hidden');
    els.licenseReclaimDialog.showModal();
    setTimeout(() => select.focus(), 0);
  });
}

async function refreshHandlerPermissions() {
  const result = await runtimeMessage({ type: 'LIST_SITE_HANDLERS' });
  handlerPermissionState = Array.isArray(result.origins) ? result.origins : [];
  return handlerPermissionState;
}

async function refreshUpdateBanner({ force = false } = {}) {
  const mount = $('updateBanner');
  if (!mount || !settingsState?.updateChecksEnabled) return;
  try {
    const result = await runtimeMessage({ type: 'CHECK_FOR_UPDATES', force });
    if (!result.enabled) return;
    if (result.updateAvailable) {
      mount.innerHTML = `<div class="updateNotice ${result.critical ? 'critical' : ''}"><div><strong>${result.critical ? 'Security update available' : 'VaultCove update available'} - ${escapeHtml(result.version)}</strong><span>${escapeHtml(result.summary || 'A newer verified developer release is available from the official VaultCove release repository.')}</span></div><div><button id="updateNotes" class="outline">View release</button><button id="updateDownload">Download update</button></div></div>`;
      $('updateNotes')?.addEventListener('click', () => { if (result.notesUrl) chrome.tabs.create({ url: result.notesUrl }); });
      $('updateDownload')?.addEventListener('click', () => { if (result.downloadUrl) chrome.tabs.create({ url: result.downloadUrl }); });
    } else {
      mount.innerHTML = `<div class="updateCurrent"><span>Developer update check: VaultCove ${escapeHtml(result.currentVersion || '')} is current</span><button id="manualUpdateCheck" class="linkButton">Check again</button></div>`;
      $('manualUpdateCheck')?.addEventListener('click', () => refreshUpdateBanner({ force: true }));
    }
  } catch (error) {
    mount.innerHTML = `<div class="updateCurrent mutedUpdate"><span>Update check unavailable. VaultCove continues fully offline.</span><button id="manualUpdateCheck" class="linkButton">Retry</button></div>`;
    $('manualUpdateCheck')?.addEventListener('click', () => refreshUpdateBanner({ force: true }));
  }
}

function clearDecryptedUi() {
  vault = null;
  clearInterval(totpTimer);
  els.content.replaceChildren();
  els.search.value = '';
  els.itemId.value = '';
  els.itemName.value = '';
  els.itemNotes.value = '';
  els.itemTags.value = '';
  els.dynamicFields.replaceChildren();
  els.exportSecret.textContent = '';
  if (els.itemDialog.open) els.itemDialog.close();
  if (els.secretDialog.open) els.secretDialog.close();
  if (els.sensitiveDialog.open) els.sensitiveDialog.close();
}

async function enforceUiAutoLock() {
  if (!vault) return;
  const expiresAt = await getSessionExpiry();
  if (!expiresAt || Date.now() >= expiresAt) {
    await runtimeMessage({ type: 'LOCK_VAULT' });
    clearDecryptedUi();
    showGate('unlockPanel');
    toast('Vault auto-locked.');
  }
}

async function enforceSensitiveUiExpiry() {
  if (!vault || !els.itemDialog.open || !els.itemId.value) return;
  if (await hasSensitiveAccess()) return;
  els.itemDialog.close();
  els.dynamicFields.replaceChildren();
  els.itemId.value = '';
  toast('Sensitive Access expired. Decrypted item fields were closed; unsaved changes were discarded.');
}

let lastActivityTouch = 0;
function markVaultActivity() {
  if (!vault) return;
  const now = Date.now();
  if (now - lastActivityTouch < 10000) return;
  lastActivityTouch = now;
  touchSession().catch(() => {});
}

function activeItems() { return vault.items.filter((item) => !item.deletedAt); }
function countType(type) { return activeItems().filter((item) => item.type === type).length; }

function itemMeta(item) {
  if (item.type === 'login') return item.username ? maskIdentifier(item.username) : ((item.urls || [])[0] || 'Login');
  if (item.type === 'card') return item.number ? `•••• ${item.number.replace(/\D/g,'').slice(-4)}` : item.cardholder || 'Payment card';
  if (item.type === 'bank') return item.accountNumber ? `•••• ${item.accountNumber.replace(/\s/g,'').slice(-4)}` : item.bankName || 'Bank account';
  if (item.type === 'identity') {
    const displayName = [item.firstName,item.lastName].filter(Boolean).join(' ');
    return displayName || (item.email ? maskIdentifier(item.email) : 'Identity');
  }
  return 'Encrypted secure note';
}

function itemTypeLabel(item) {
  return ({login:'Login',card:'Card',bank:'Bank Account',identity:'Identity',note:'Note'})[item.type] || 'Item';
}

function itemIconName(itemOrType) {
  const type = typeof itemOrType === 'string' ? itemOrType : itemOrType?.type;
  return ({ login:'login', card:'card', bank:'bank', identity:'identity', note:'note', totp:'totp' })[type] || 'vault';
}

function passwordAgeBadge(item, { compact = false, showUnknown = true } = {}) {
  if (item?.type !== 'login') return '';
  const age = passwordAgeState(item);
  if (age.state === 'unknown' && !showUnknown) return '';
  const label = age.state === 'unknown' ? 'Password age unknown' : age.label;
  const text = age.state === 'unknown' ? 'Age unknown' : age.needsReview ? `Review ${age.shortLabel}` : compact ? age.shortLabel : age.label;
  return `<span class="passwordAgeBadge age-${escapeHtml(age.state)}" data-tooltip="${escapeHtml(label)}">${uiIcon(age.needsReview ? 'warningClock' : 'clock', 14)}<span>${escapeHtml(text)}</span></span>`;
}

function safeHostname(value) {
  try {
    const source = /^https?:/i.test(String(value || '')) ? String(value) : `https://${String(value || '')}`;
    return new URL(source).hostname.toLowerCase().replace(/^www\./, '');
  } catch { return ''; }
}

function visualHost(item) {
  if (item?.type !== 'login') return '';
  return safeHostname(item.siteVisual?.host || (item.urls || [])[0] || '');
}

function faviconUrl(item, size = 64) {
  if (!settingsState?.websiteIconsEnabled || !item?.siteVisual?.visitedAt) return '';
  const host = visualHost(item);
  if (!host) return '';
  const url = new URL(chrome.runtime.getURL('/_favicon/'));
  url.searchParams.set('pageUrl', `https://${host}/`);
  url.searchParams.set('size', String(size));
  return url.toString();
}

function siteCardVisual(item) {
  const host = visualHost(item);
  const icon = faviconUrl(item);
  const initials = (host || item.name || 'VC').replace(/[^a-z0-9]/gi, '').slice(0, 2).toUpperCase() || 'VC';
  return `<div class="siteCardVisual"><div class="siteFallback">${uiIcon('lock', 28, 'siteFallbackIcon')}<b>${escapeHtml(initials)}</b></div>${icon ? `<img data-vc-favicon src="${escapeHtml(icon)}" alt="">` : ''}</div>`;
}

function wireFaviconFallbacks(root = document) {
  root.querySelectorAll('[data-vc-favicon]').forEach((img) => {
    img.addEventListener('error', () => img.remove(), { once: true });
  });
}

function vaultTotpProtection() {
  return vault?.security?.vaultTotp || { enabled: false, secret: '', recoveryCodeHashes: [] };
}

function secondFactorLabelText() {
  return settingsState?.vaultTotpEnabled ? 'Authenticator or recovery code' : '';
}

function relativeTime(iso) {
  const value = Date.parse(iso || '');
  if (!Number.isFinite(value)) return '';
  const seconds = Math.max(0, Math.floor((Date.now() - value) / 1000));
  if (seconds < 60) return `${seconds}s ago`;
  const minutes = Math.floor(seconds / 60); if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60); if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24); if (days < 30) return `${days}d ago`;
  return new Date(value).toLocaleDateString();
}


function folderById(folderId) {
  return (vault?.folders || []).find((folder) => folder.id === folderId) || null;
}

function folderOptionsMarkup(selectedId = null, { includeAll = false } = {}) {
  const folders = [...(vault?.folders || [])].sort((a, b) => String(a.name || '').localeCompare(String(b.name || '')));
  const options = [];
  if (includeAll) options.push(`<option value="all"${selectedId === 'all' ? ' selected' : ''}>All folders</option>`);
  options.push(`<option value=""${!selectedId || selectedId === '' ? ' selected' : ''}>No Folder</option>`);
  for (const folder of folders) {
    options.push(`<option value="${escapeHtml(folder.id)}"${selectedId === folder.id ? ' selected' : ''}>${escapeHtml(folder.name)}</option>`);
  }
  return options.join('');
}

function folderChip(item) {
  const folder = item?.folderId ? folderById(item.folderId) : null;
  return folder ? `<span class="chip folderChip">${uiIcon('folder', 13)} ${escapeHtml(folder.name)}</span>` : '';
}

function vaultFolderToolbarMarkup() {
  if (currentView === 'totp' || currentView === 'trash') return '';
  if (activeFolderId !== 'all' && !folderById(activeFolderId)) activeFolderId = 'all';
  return `<div class="vaultFolderToolbar">
    <label>Folder<select id="vaultFolderFilter">${folderOptionsMarkup(activeFolderId, { includeAll: true })}</select></label>
    <button id="openVaultSettings" type="button" class="outline">${uiIcon('settings', 15)} Vault Settings</button>
  </div>`;
}

function wireVaultFolderToolbar() {
  $('vaultFolderFilter')?.addEventListener('change', () => {
    activeFolderId = $('vaultFolderFilter').value || '';
    selectedItemId = null;
    renderItems();
  });
  $('openVaultSettings')?.addEventListener('click', openVaultSettingsDialog);
}

function vaultSettingsFolderRows() {
  const folders = [...(vault?.folders || [])].sort((a, b) => String(a.name || '').localeCompare(String(b.name || '')));
  if (!folders.length) return '<div class="emptyState compactEmpty">No folders yet. Create one below.</div>';
  return folders.map((folder) => {
    const count = (vault.items || []).filter((item) => !item.deletedAt && item.folderId === folder.id).length;
    return `<div class="folderSettingsRow" data-folder-row="${escapeHtml(folder.id)}">
      <input data-folder-name="${escapeHtml(folder.id)}" value="${escapeHtml(folder.name)}" maxlength="80" aria-label="Folder name">
      <span>${count} item${count === 1 ? '' : 's'}</span>
      <button type="button" class="outline" data-rename-folder="${escapeHtml(folder.id)}">Rename</button>
      <button type="button" class="danger" data-delete-folder="${escapeHtml(folder.id)}">Delete</button>
    </div>`;
  }).join('');
}

function vaultSettingsLoginRows() {
  const logins = (vault.items || []).filter((item) => item.type === 'login' && !item.deletedAt)
    .sort((a, b) => String(a.name || '').localeCompare(String(b.name || '')));
  if (!logins.length) return '<div class="emptyState compactEmpty">No saved logins are available to organize.</div>';
  return logins.map((item) => {
    const folder = item.folderId ? folderById(item.folderId) : null;
    const searchText = [item.name, item.username, itemMeta(item), folder?.name || 'No Folder']
      .map((value) => String(value || '').toLowerCase())
      .join(' ');
    return `<label class="folderLoginRow" data-folder-login-row data-folder-search="${escapeHtml(searchText)}">
      <input type="checkbox" name="folderLoginIds" value="${escapeHtml(item.id)}">
      <span><strong>${escapeHtml(item.name)}</strong><small>${escapeHtml(itemMeta(item))}</small></span>
      <em>${escapeHtml(folder?.name || 'No Folder')}</em>
    </label>`;
  }).join('');
}

function renderVaultSettingsDialog() {
  const mount = $('vaultSettingsMount');
  if (!mount) return;
  mount.innerHTML = `
    <section class="vaultSettingsSection">
      <div class="vaultSettingsSectionHead"><div><h3>Folders</h3><p>Create folders for encrypted vault organization. Deleting a folder never deletes its items; they return to No Folder.</p></div></div>
      <div id="folderSettingsRows" class="folderSettingsRows">${vaultSettingsFolderRows()}</div>
      <div class="createFolderRow"><input id="newFolderName" maxlength="80" placeholder="New folder name"><button id="createFolderButton" type="button">Create folder</button></div>
    </section>
    <section class="vaultSettingsSection">
      <div class="vaultSettingsSectionHead"><div><h3>Put logins in a folder</h3><p>Search, select one or more saved logins, choose a folder, then move them. Login passwords are never shown or searched in this organizer.</p></div><strong id="folderSelectedCount">0 selected</strong></div>
      <div class="folderLoginSearchWrap"><input id="folderLoginSearch" type="search" autocomplete="off" placeholder="Search logins by website, username, or folder" aria-label="Search saved logins"><span id="folderSearchCount"></span></div>
      <div class="folderBulkToolbar"><select id="folderTarget">${folderOptionsMarkup(null)}</select><button id="folderSelectAll" type="button" class="outline">Select visible</button><button id="folderClearSelection" type="button" class="outline">Clear</button><button id="moveSelectedToFolder" type="button" disabled>Move selected</button></div>
      <div id="folderLoginRows" class="folderLoginRows">${vaultSettingsLoginRows()}</div>
    </section>`;

  const selectedLoginIds = () => [...document.querySelectorAll('input[name="folderLoginIds"]:checked')].map((input) => input.value);
  const visibleFolderRows = () => [...document.querySelectorAll('[data-folder-login-row]')].filter((row) => !row.classList.contains('hidden'));
  const updateSelection = () => {
    const count = selectedLoginIds().length;
    if ($('folderSelectedCount')) $('folderSelectedCount').textContent = `${count} selected`;
    if ($('moveSelectedToFolder')) $('moveSelectedToFolder').disabled = count === 0;
  };
  const filterFolderLogins = () => {
    const query = String($('folderLoginSearch')?.value || '').trim().toLowerCase();
    let shown = 0;
    document.querySelectorAll('[data-folder-login-row]').forEach((row) => {
      const matches = !query || String(row.dataset.folderSearch || '').includes(query);
      row.classList.toggle('hidden', !matches);
      if (matches) shown += 1;
    });
    if ($('folderSearchCount')) $('folderSearchCount').textContent = query ? `${shown} shown` : `${shown} logins`;
  };
  document.querySelectorAll('input[name="folderLoginIds"]').forEach((input) => input.addEventListener('change', updateSelection));
  $('folderLoginSearch')?.addEventListener('input', filterFolderLogins);
  $('folderSelectAll')?.addEventListener('click', () => {
    visibleFolderRows().forEach((row) => {
      const input = row.querySelector('input[name="folderLoginIds"]');
      if (input) input.checked = true;
    });
    updateSelection();
  });
  $('folderClearSelection')?.addEventListener('click', () => { document.querySelectorAll('input[name="folderLoginIds"]').forEach((input) => { input.checked = false; }); updateSelection(); });
  filterFolderLogins();

  $('createFolderButton')?.addEventListener('click', async () => {
    try {
      createFolder(vault, $('newFolderName')?.value || '');
      await saveUnlockedVault(vault);
      renderVaultSettingsDialog();
      renderItems();
      toast('Encrypted vault folder created.');
    } catch (error) { toast(error.message, true); }
  });

  document.querySelectorAll('[data-rename-folder]').forEach((button) => button.addEventListener('click', async () => {
    try {
      const folderId = button.dataset.renameFolder;
      const input = document.querySelector(`[data-folder-name="${CSS.escape(folderId)}"]`);
      renameFolder(vault, folderId, input?.value || '');
      await saveUnlockedVault(vault);
      renderVaultSettingsDialog();
      renderItems();
      toast('Folder renamed.');
    } catch (error) { toast(error.message, true); }
  }));

  document.querySelectorAll('[data-delete-folder]').forEach((button) => button.addEventListener('click', async () => {
    const folderId = button.dataset.deleteFolder;
    const folder = folderById(folderId);
    if (!folder || !confirm(`Delete the folder "${folder.name}"? Its vault items will move to No Folder.`)) return;
    deleteFolder(vault, folderId);
    if (activeFolderId === folderId) activeFolderId = 'all';
    await saveUnlockedVault(vault);
    renderVaultSettingsDialog();
    renderItems();
    toast('Folder deleted. Its items were moved to No Folder.');
  }));

  $('moveSelectedToFolder')?.addEventListener('click', async () => {
    try {
      const ids = selectedLoginIds();
      const target = $('folderTarget')?.value || null;
      const moved = assignItemsToFolder(vault, ids, target || null);
      await saveUnlockedVault(vault);
      renderVaultSettingsDialog();
      renderItems();
      toast(`${moved} login${moved === 1 ? '' : 's'} moved.`);
    } catch (error) { toast(error.message, true); }
  });
}

function openVaultSettingsDialog() {
  if (!vault) return;
  renderVaultSettingsDialog();
  els.vaultSettingsDialog?.showModal();
}

async function vaultKeyForTrash() {
  const state = await loadUnlockedVault({ touch: false });
  if (state.state !== 'unlocked' || !state.vaultKey) throw new Error('VaultCove is locked.');
  return state.vaultKey;
}

async function moveItemToTrashWithConfirmation(itemId) {
  const item = (vault?.items || []).find((candidate) => candidate.id === itemId && !candidate.deletedAt);
  if (!item) return false;
  const confirmed = confirm(`Move "${item.name}" to Trash?\n\nIt will be locked immediately, sealed inside a second encrypted envelope, and automatically deleted after ${TRASH_RETENTION_DAYS} days unless you restore it.`);
  if (!confirmed) return false;
  const vaultKey = await vaultKeyForTrash();
  const moved = await moveVaultItemToTrash(vault, itemId, vaultKey);
  if (!moved) return false;
  if (selectedItemId === itemId) selectedItemId = null;
  await saveUnlockedVault(vault);
  render();
  toast(`Moved to Trash. It is locked and scheduled for deletion in ${TRASH_RETENTION_DAYS} days.`);
  return true;
}

async function restoreTrashItem(itemId) {
  const vaultKey = await vaultKeyForTrash();
  const restored = await restoreVaultItemFromTrash(vault, itemId, vaultKey);
  if (!restored) return false;
  await saveUnlockedVault(vault);
  render();
  toast('Item restored and decrypted back into the active vault.');
  return true;
}

function trashRetentionLabel(item) {
  const purgeAt = trashPurgeAt(item);
  const days = trashDaysRemaining(item);
  if (!purgeAt) return `Auto-delete after ${TRASH_RETENTION_DAYS} days`;
  if (days <= 0) return 'Scheduled for automatic deletion';
  return `${days} day${days === 1 ? '' : 's'} until automatic deletion`;
}

function visibleItems() {
  const q = els.search.value.trim().toLowerCase();
  return vault.items.filter((item) => {
    const deleted = Boolean(item.deletedAt);
    if (currentView === 'trash') {
      if (!deleted) return false;
    } else if (deleted) return false;
    if (['login','card','bank','identity','note'].includes(currentView) && item.type !== currentView) return false;
    if (currentView === 'totp' && !(item.type === 'login' && item.totpSecret)) return false;
    if (currentView === 'favorites' && !item.favorite) return false;
    if (!['trash', 'totp'].includes(currentView) && activeFolderId !== 'all') {
      if (activeFolderId === '') {
        if (item.folderId) return false;
      } else if (item.folderId !== activeFolderId) return false;
    }
    if (q) {
      const haystack = JSON.stringify({name:item.name,username:item.username,urls:item.urls,tags:item.tags,bankName:item.bankName,cardholder:item.cardholder,email:item.email}).toLowerCase();
      if (!haystack.includes(q)) return false;
    }
    return true;
  }).sort((a,b) => Number(Boolean(b.favorite))-Number(Boolean(a.favorite)) || a.name.localeCompare(b.name));
}

function pageHead(title = viewNames[currentView], subtitle = viewSubtitles[currentView], withStatus = false) {
  const status = withStatus ? `<div class="statusPills"><span class="pill good">Offline Only</span><span class="pill">Local Encrypted Storage</span><span class="pill">No Cloud Sync</span></div>` : '';
  return `<div class="pageHead"><div><h1>${escapeHtml(title)}</h1><p>${escapeHtml(subtitle)}</p></div>${status}</div>`;
}

function render() {
  clearInterval(totpTimer);
  els.search.classList.toggle('hidden', ['generator','security','migration','shared','license','backup','settings'].includes(currentView));
  els.newItem.classList.toggle('hidden', ['security','settings','trash','migration','shared','license','backup','generator'].includes(currentView));
  document.querySelectorAll('nav button[data-view]').forEach((button) => button.classList.toggle('active', button.dataset.view === currentView));
  if (currentView === 'dashboard') return renderDashboard();
  if (currentView === 'security') return renderSecurity();
  if (currentView === 'settings') return renderSettings();
  if (currentView === 'migration') return renderMigration();
  if (currentView === 'backup') return renderBackup();
  if (currentView === 'shared') return renderShared();
  if (currentView === 'license') return renderLicense();
  if (currentView === 'generator') return renderGenerator();
  return renderItems();
}

function renderDashboard() {
  const items = activeItems();
  const handlerOn = isDeveloperBuild || (Array.isArray(handlerPermissionState) && handlerPermissionState.length > 0);
  const alwaysOn = isDeveloperBuild || (Array.isArray(handlerPermissionState) && handlerPermissionState.includes('https://*/*'));
  const autoLoginOn = Boolean(settingsState?.autoLoginEnabled);
  const health = vaultHealth(items);
  const ageSummary = passwordAgeSummary(items);
  const recent = [...items].sort((a,b) => Date.parse(b.updatedAt || b.createdAt || 0) - Date.parse(a.updatedAt || a.createdAt || 0)).slice(0,5);
  const scoreLabel = health.score >= 90 ? 'Excellent' : health.score >= 75 ? 'Good' : health.score >= 50 ? 'Needs attention' : 'At risk';
  const recentRows = recent.length ? recent.map((item) => `
    <button class="recentRow" data-open-id="${escapeHtml(item.id)}">
      <span class="recentIcon">${uiIcon(itemIconName(item), 18)}</span>
      <span class="recentMain"><strong>${escapeHtml(item.name)}</strong><small>${escapeHtml(itemMeta(item))}</small></span>
      <span class="typeBadge">${escapeHtml(itemTypeLabel(item))}</span>
      <span class="recentTime">${escapeHtml(activityLabel(item))}</span>
    </button>`).join('') : '<div class="emptyState compactEmpty">No recent vault activity yet.</div>';

  els.content.innerHTML = `
    ${pageHead('Vault Overview','Everything stays on your device. You are in control.',true)}
    <div id="updateBanner"></div>
    <div class="summaryGrid">
      ${summaryCard('login','login','Logins',countType('login'),'saved logins')}
      ${summaryCard('card','card','Cards',countType('card'),'payment cards')}
      ${summaryCard('bank','bank','Bank Accounts',countType('bank'),'bank records')}
      ${summaryCard('note','note','Secure Notes',countType('note'),'secure notes')}
      ${summaryCard('identity','identity','Identities',countType('identity'),'identity records')}
      ${summaryCard('totp','totp','TOTP Codes',items.filter((item)=>item.type==='login'&&item.totpSecret).length,'protected accounts')}
    </div>
    <div class="dashboardGrid">
      <section class="panel securityPanel">
        <div class="panelTitle"><h2>Security Health</h2><button id="openSecurity" class="linkButton">View details</button></div>
        <div class="healthBody">
          <div class="scoreRing" style="--score:${Math.max(0,Math.min(360,health.score*3.6))}deg"><div><strong>${health.score}</strong><span>${escapeHtml(scoreLabel)}</span></div></div>
          <div class="healthMetrics">
            <div class="healthMetric"><i>${uiIcon('weak', 17)}</i><div><b>Weak Passwords</b><small>Needs stronger credentials</small></div><em>${health.weak}</em></div>
            <div class="healthMetric"><i>${uiIcon('reused', 17)}</i><div><b>Reused Passwords</b><small>Same password on multiple logins</small></div><em>${health.reused}</em></div>
            <div class="healthMetric"><i>${uiIcon('warningClock', 17)}</i><div><b>Password Age Review</b><small>Unchanged for at least 90 days</small></div><em>${ageSummary.over90}</em></div>
          </div>
        </div>
      </section>
      <section class="panel recentPanel">
        <div class="panelTitle"><h2>Recent Activity</h2><button id="viewAllItems" class="linkButton">View all</button></div>
        <div class="recentList">${recentRows}</div>
      </section>
      <section class="panel quickPanel">
        <div class="panelTitle"><h2>Quick Actions</h2></div>
        <div class="quickGrid">
          <button id="dashAddLogin"><span class="quickActionIcon">${uiIcon('add',18)}</span><span><strong>Add Login</strong><small>Create an encrypted login</small></span></button>
          <button id="dashGenerate"><span class="quickActionIcon">${uiIcon('generator',18)}</span><span><strong>Generate Password</strong><small>Create a strong password</small></span></button>
          <button id="dashExport"><span class="quickActionIcon">${uiIcon('export',18)}</span><span><strong>Export Backup</strong><small>Create an encrypted vault backup</small></span></button>
          <button id="dashImport"><span class="quickActionIcon">${uiIcon('import',18)}</span><span><strong>Import Backup</strong><small>Restore a VaultCove backup</small></span></button>
          <button id="dashMaster"><span class="quickActionIcon">${uiIcon('master',18)}</span><span><strong>Master Password</strong><small>Review password protection</small></span></button>
          <button id="dashLock" class="dangerQuick"><span class="quickActionIcon">${uiIcon('lock',18)}</span><span><strong>Lock Vault</strong><small>Clear the unlocked session</small></span></button>
        </div>
      </section>
    </div>
    <div class="lowerGrid">
      <section class="panel backupPanel">
        <div class="panelTitle"><h2>Backup and Recovery</h2>${uiIcon('backup',18)}</div>
        <p class="mutedText">Keep an encrypted portable copy of your vault and recovery material.</p>
        <div class="backupNote"><strong>Keep the export secret separate.</strong><span>The .vcvault file and its export secret are both required for restore.</span></div>
        <div class="backupActions"><button id="dashExport2">${uiIcon('export',16)}<span>Export Encrypted Backup</span></button><button id="dashBackupPage" class="outline">Open Backup and Restore</button></div>
      </section>
      <section class="panel browserPanel">
        <div class="panelTitle"><h2>Browser Integration</h2><span class="pill good">Ready</span></div>
        <div class="browserRows">
          <div class="browserRow"><i>${uiIcon('browser',18)}</i><div><strong>Website Handler</strong><b>${alwaysOn ? 'Always-On Handler enabled' : handlerOn ? 'Individual site access enabled' : 'On-demand only'}</b><small>${alwaysOn ? 'VaultCove appears automatically on supported HTTPS login and password forms. Per-site exclusions can be managed in Settings.' : 'Enable website access to show VaultCove automatically on supported HTTPS login forms.'}</small></div></div>
          <div class="browserRow"><i>${uiIcon('autologin',18)}</i><div><strong>Automatic Login</strong><b>${autoLoginOn ? 'Enabled for opted-in entries' : 'Off by default'}</b><small>Only trusted HTTPS entries explicitly marked Auto-login can be submitted automatically.</small></div></div>
          <div class="browserRow"><i>${uiIcon('match',18)}</i><div><strong>Domain Matching</strong><b>Trusted HTTPS matching</b><small>Legacy imported URLs are normalized to HTTPS while unrelated or suspicious hostnames remain blocked.</small></div></div>
        </div>
      </section>
    </div>`;

  $('openSecurity').addEventListener('click', () => switchView('security'));
  $('viewAllItems').addEventListener('click', () => switchView('all'));
  $('dashAddLogin').addEventListener('click', () => openItemDialog(null,'login'));
  $('dashGenerate').addEventListener('click', () => switchView('generator'));
  $('dashExport').addEventListener('click', exportVault);
  $('dashExport2').addEventListener('click', exportVault);
  $('dashImport').addEventListener('click', () => switchView('backup'));
  $('dashBackupPage').addEventListener('click', () => switchView('backup'));
  $('dashMaster').addEventListener('click', () => switchView('settings'));
  $('dashLock').addEventListener('click', lockFromUi);
  document.querySelectorAll('[data-open-id]').forEach((row) => row.addEventListener('click', () => {
    const item = vault.items.find((candidate) => candidate.id === row.dataset.openId); if (item) openItemDialog(item);
  }));
  wireSummaryCards();
  refreshUpdateBanner().catch(() => {});
}

function summaryCard(view, icon, label, count, unit) {
  return `<button class="summaryCard" data-summary-view="${escapeHtml(view)}"><span class="summaryIcon">${uiIcon(icon, 18)}</span><span class="summaryCopy"><span>${escapeHtml(label)}</span><strong>${count}</strong><small>${escapeHtml(unit)}</small></span></button>`;
}

function wireSummaryCards() {
  document.querySelectorAll('[data-summary-view]').forEach((button) => button.addEventListener('click', () => switchView(button.dataset.summaryView)));
}

function emptyStateMarkup() {
  const byView = {
    trash: ['trash', 'Trash is empty', `Items moved to Trash are locked, sealed in a second encrypted envelope, and automatically deleted after ${TRASH_RETENTION_DAYS} days unless restored.`, ''],
    totp: ['totp', 'No TOTP codes yet', 'Add a compatible TOTP secret to a saved login to generate authenticator codes locally.', ''],
    card: ['card', 'No payment cards yet', 'Store card details locally inside your encrypted VaultCove vault.', 'Add Card'],
    bank: ['bank', 'No bank accounts yet', 'Keep bank records encrypted locally and protected by Sensitive Access.', 'Add Bank Account'],
    identity: ['identity', 'No identities yet', 'Keep identity and address records inside your offline encrypted vault.', 'Add Identity'],
    note: ['note', 'No secure notes yet', 'Store private text without uploading it to a cloud service.', 'Add Secure Note'],
    favorites: ['favorite', 'No favorites yet', 'Use the star button on any vault item to add or remove it from Favorites.', ''],
    login: ['login', 'No matching logins', 'Add a login or adjust your search. Imported LastPass records remain encrypted here.', 'Add Login'],
    all: ['vault', 'No vault items yet', 'Use Quick Add to create your first encrypted record.', 'Add Login']
  };
  const [icon, title, text, action] = byView[currentView] || byView.all;
  return `<div class="emptyState richEmpty"><div class="emptyIcon">${uiIcon(icon, 28)}</div><strong>${escapeHtml(title)}</strong><p>${escapeHtml(text)}</p>${action ? `<button id="emptyAdd">${escapeHtml(action)}</button>` : ''}</div>`;
}

function activityLabel(item) {
  const imported = item.importedAt ? Date.parse(item.importedAt) : 0;
  const updated = Date.parse(item.updatedAt || item.createdAt || 0);
  if (imported && Math.abs(updated - imported) < 5000) return `Imported ${relativeTime(item.importedAt)}`;
  if (item.lastPasswordChangeAt && Math.abs(updated - Date.parse(item.lastPasswordChangeAt)) < 5000) return `Password changed ${relativeTime(item.lastPasswordChangeAt)}`;
  return `Updated ${relativeTime(item.updatedAt || item.createdAt)}`;
}

function viewModeControls() {
  const mode = settingsState?.vaultViewMode === 'list' ? 'list' : 'grid';
  return `<div class="viewModeSwitch" role="group" aria-label="Vault view"><button data-vault-view="grid" class="${mode === 'grid' ? 'active' : ''}" data-tooltip="Show visual website cards. Site icons appear only after that saved site has been visited with VaultCove active.">Grid</button><button data-vault-view="list" class="${mode === 'list' ? 'active' : ''}" data-tooltip="Show a compact list for quickly scanning large vaults.">List</button></div>`;
}

function vaultCardMarkup(item) {
  const login = item.type === 'login';
  const status = login && item.pendingPasswordChange ? 'Password change pending' : activityLabel(item);
  const visual = login ? siteCardVisual(item) : `<div class="siteCardVisual genericVisual"><div class="siteFallback">${uiIcon(itemIconName(item), 28)}</div></div>`;
  const primary = login
    ? `<button class="siteCardOpen" data-open-login="${escapeHtml(item.id)}" data-tooltip="Open the saved HTTPS website and use this exact credential for Secure Login.">Open and Secure Login</button>`
    : `<button class="siteCardOpen" data-details-id="${escapeHtml(item.id)}">Open details</button>`;
  const age = login ? passwordAgeBadge(item, { compact: true, showUnknown: false }) : '';
  return `<article class="siteVaultCard ${item.id === selectedItemId ? 'selected' : ''}">
    <button class="favoriteToggle ${item.favorite ? 'active' : ''}" data-favorite-id="${escapeHtml(item.id)}" aria-label="${item.favorite ? 'Remove from Favorites' : 'Add to Favorites'}" data-tooltip="${item.favorite ? 'Remove this item from Favorites.' : 'Add this item to Favorites.'}">${uiIcon('favorite', 16)}</button>
    ${visual}
    <div class="siteCardBody">
      <div class="siteCardTitle"><strong>${escapeHtml(item.name)}</strong><span>${escapeHtml(itemTypeLabel(item))}</span></div>
      <small>${escapeHtml(itemMeta(item))}</small>
      <div class="siteCardBadges">${folderChip(item)}${age}${login && item.requireReauthBeforeFill ? '<span class="securityBadge">Master check</span>' : ''}</div>
      <div class="siteCardFooter"><span>${escapeHtml(status)}</span></div>
      <div class="siteCardActions">${primary}<button class="siteCardDetails" data-details-id="${escapeHtml(item.id)}">Details</button><button class="siteCardTrash" data-trash-id="${escapeHtml(item.id)}" aria-label="Move ${escapeHtml(item.name)} to Trash" data-tooltip="Move this item to Trash. VaultCove confirms first, then seals it and schedules automatic deletion after 30 days.">${uiIcon('trash', 15)}</button></div>
    </div>
  </article>`;
}

function renderSelectedDrawer(item) {
  if (!item) return '<aside class="itemDrawer emptyDrawer"><strong>Select an item</strong><p>Choose a vault item to see protected details and available actions.</p></aside>';
  const chips = [...(item.tags || [])].slice(0, 5).map((tag) => `<span class="chip">${escapeHtml(tag)}</span>`).join('');
  const protectedFill = item.type === 'login' && item.requireReauthBeforeFill ? '<span class="chip secureChip">Master check before fill</span>' : '';
  const auto = item.type === 'login' && item.autoLogin ? '<span class="chip autoChip">Auto-login</span>' : '';
  const age = item.type === 'login' ? passwordAgeBadge(item) : '';
  const ageAction = item.type === 'login' ? '<button data-mark-password-changed class="outline" data-tooltip="Set the password-change date to today without changing the stored password. Use this only when you know the password was changed outside VaultCove.">Mark changed today</button>' : '';
  return `<aside class="itemDrawer" data-drawer-id="${escapeHtml(item.id)}">
    <div class="drawerType">${escapeHtml(itemTypeLabel(item))}</div>
    <h2>${escapeHtml(item.name)}</h2>
    <p class="drawerMeta">${escapeHtml(itemMeta(item))}</p>
    <div class="chips">${folderChip(item)}${protectedFill}${auto}${chips}</div>
    ${age ? `<div class="drawerAge">${age}</div>` : ''}
    ${item.type === 'login' ? `<div class="drawerSecurity"><strong>Credential protection</strong><span>Username and password remain hidden here. Reveal, Copy and Edit require Sensitive Access.</span></div>` : ''}
    <div class="drawerActions"><button data-edit-selected>Open or Edit</button><button data-favorite-selected class="outline">${item.favorite ? 'Remove from Favorites' : 'Add to Favorites'}</button>${ageAction}</div>
    <small class="drawerActivity">${escapeHtml(activityLabel(item))}</small>
  </aside>`;
}

function renderItems() {
  const items = visibleItems();
  els.content.innerHTML = `${pageHead()}${vaultFolderToolbarMarkup()}<div id="itemsMount"></div>`;
  wireVaultFolderToolbar();
  const mount = $('itemsMount');
  if (!items.length) {
    mount.innerHTML = emptyStateMarkup();
    $('emptyAdd')?.addEventListener('click', () => openItemDialog(null, ['login','card','bank','identity','note'].includes(currentView) ? currentView : 'login'));
    return;
  }

  if (currentView === 'totp' || currentView === 'trash') {
    const grid = document.createElement('div'); grid.className = 'itemGrid';
    for (const item of items) {
      const node = document.createElement('article'); node.className = 'vaultItem';
      node.innerHTML = `<div class="type">${escapeHtml(itemTypeLabel(item))}</div><div class="name">${escapeHtml(`${item.favorite ? 'Favorite: ' : ''}${item.name}`)}</div><div class="meta">${escapeHtml(itemMeta(item))}</div>`;
      if (currentView === 'totp' && item.totpSecret) {
        const code=document.createElement('div'); code.className='totpCode'; code.dataset.totpId=item.id; code.textContent='••• •••'; node.append(code);
      }
      if (currentView === 'trash') {
        node.classList.add('trashLockedItem');
        const sealed = isSealedTrashItem(item);
        node.innerHTML = `<div class="trashLockedHead"><span class="trashLockIcon">${uiIcon('lock', 18)}</span><div><div class="type">${escapeHtml(itemTypeLabel(item))}</div><div class="name">${escapeHtml(item.name || 'Locked item')}</div></div></div><div class="meta">${escapeHtml(sealed ? 'Locked in Trash - contents cannot be opened' : 'Securing legacy Trash item...')}</div><div class="trashRetention">${escapeHtml(trashRetentionLabel(item))}</div>`;
        const actions=document.createElement('div'); actions.className='trashActions';
        const restore=document.createElement('button'); restore.textContent='Restore'; restore.disabled=!sealed; restore.addEventListener('click', async(e)=>{e.stopPropagation();try{await restoreTrashItem(item.id);}catch(error){toast(error.message,true);}});
        const purge=document.createElement('button'); purge.textContent='Delete now'; purge.className='danger'; purge.addEventListener('click', async(event)=>{event.stopPropagation();try{await ensureSensitiveAccess('Re-enter your master password before permanently deleting this sealed Trash item.',async()=>{if(!confirm('Permanently delete this item now? This cannot be undone and bypasses the remaining 30-day Trash period.'))return;purgeItem(vault,item.id);await saveUnlockedVault(vault);render();toast('Item permanently deleted.');});}catch(error){toast(error.message,true);}});
        actions.append(restore,purge); node.append(actions);
      } else node.addEventListener('click', () => openItemDialog(item));
      grid.append(node);
    }
    if (currentView === 'totp') {
      const accessBar=document.createElement('div');accessBar.className='totpAccessBar';
      const copy=document.createElement('div');copy.innerHTML='<strong>Protected authenticator codes</strong><small>TOTP values stay hidden until you freshly verify the master password. The short Sensitive Access window then expires automatically.</small>';
      const button=document.createElement('button');button.type='button';button.textContent='Verify and show codes';button.addEventListener('click',()=>ensureSensitiveAccess('Re-enter your master password before displaying live TOTP authenticator codes.',()=>refreshTotpCodes()).catch((error)=>toast(error.message,true)));
      accessBar.append(copy,button);mount.append(accessBar);
    }
    mount.append(grid); refreshTotpCodes(); return;
  }

  if (!items.some((item) => item.id === selectedItemId)) selectedItemId = items[0]?.id || null;
  const selected = items.find((item) => item.id === selectedItemId) || null;
  const mode = settingsState?.vaultViewMode === 'list' ? 'list' : 'grid';
  let browser;
  if (mode === 'grid') {
    browser = `<div class="vaultCardGrid">${items.map(vaultCardMarkup).join('')}</div>`;
  } else {
    const rows = items.map((item) => {
      const status = item.type === 'login' && item.pendingPasswordChange ? 'Password change pending' : activityLabel(item);
      return `<div class="vaultListRow ${item.id === selectedItemId ? 'selected' : ''}"><button class="favoriteToggle listFavorite ${item.favorite ? 'active' : ''}" data-favorite-id="${escapeHtml(item.id)}" aria-label="${item.favorite ? 'Remove from Favorites' : 'Add to Favorites'}">${uiIcon('favorite', 15)}</button><span class="listTypeIcon">${uiIcon(itemIconName(item), 16)}</span><span class="listMain"><strong>${escapeHtml(item.name)}</strong><small>${escapeHtml(itemMeta(item))}</small></span>${item.type === 'login' ? passwordAgeBadge(item, { compact: true, showUnknown: false }) : ''}<span class="listStatus">${escapeHtml(status)}</span>${item.type === 'login' ? `<button class="miniAction" data-open-login="${escapeHtml(item.id)}">Secure Login</button>` : ''}<button class="miniAction outline" data-details-id="${escapeHtml(item.id)}">Details</button><button class="miniAction listTrashAction" data-trash-id="${escapeHtml(item.id)}" aria-label="Move ${escapeHtml(item.name)} to Trash">${uiIcon('trash', 14)}</button></div>`;
    }).join('');
    browser = `<div class="vaultList">${rows}</div>`;
  }
  mount.innerHTML = `<div class="vaultBrowseToolbar"><span>${items.length} item${items.length === 1 ? '' : 's'}</span>${viewModeControls()}</div><div class="vaultListLayout"><div>${browser}</div>${renderSelectedDrawer(selected)}</div>`;
  wireFaviconFallbacks(mount);
  document.querySelectorAll('[data-details-id]').forEach((button) => button.addEventListener('click', (event) => { event.stopPropagation(); selectedItemId = button.dataset.detailsId; renderItems(); }));
  document.querySelectorAll('[data-trash-id]').forEach((button) => button.addEventListener('click', async (event) => {
    event.stopPropagation();
    try { await moveItemToTrashWithConfirmation(button.dataset.trashId); }
    catch (error) { toast(error.message, true); }
  }));
  document.querySelectorAll('[data-open-login]').forEach((button) => button.addEventListener('click', async (event) => { event.stopPropagation(); const item = vault.items.find((candidate) => candidate.id === button.dataset.openLogin && !candidate.deletedAt); if (!item) return; try { const run=()=>runtimeMessage({ type:'OPEN_LOGIN_ITEM', itemId:item.id }); if (item.requireReauthBeforeFill) await ensureSensitiveAccess('Re-enter your master password before opening and signing in with this protected credential.', run); else await run(); toast('Opening the saved website for Secure Login.'); } catch(error) { toast(error.message,true); } }));
  document.querySelectorAll('[data-favorite-id]').forEach((button) => button.addEventListener('click', async (event) => {
    event.stopPropagation();
    const item = vault.items.find((candidate) => candidate.id === button.dataset.favoriteId);
    if (!item) return;
    item.favorite = !item.favorite;
    upsertItem(vault, item);
    await saveUnlockedVault(vault);
    renderItems();
    toast(item.favorite ? 'Added to Favorites.' : 'Removed from Favorites.');
  }));
  document.querySelectorAll('[data-vault-view]').forEach((button) => button.addEventListener('click', async () => {
    settingsState.vaultViewMode = button.dataset.vaultView === 'list' ? 'list' : 'grid';
    await setSettings({ vaultViewMode: settingsState.vaultViewMode });
    renderItems();
  }));
  $('[data-edit-selected]')?.addEventListener('click', () => selected && openItemDialog(selected));
  $('[data-favorite-selected]')?.addEventListener('click', async () => {
    if (!selected) return;
    selected.favorite = !selected.favorite; upsertItem(vault, selected); await saveUnlockedVault(vault); renderItems(); toast(selected.favorite ? 'Added to Favorites.' : 'Removed from Favorites.');
  });
  $('[data-mark-password-changed]')?.addEventListener('click', async () => {
    if (!selected || selected.type !== 'login') return;
    selected.lastPasswordChangeAt = new Date().toISOString();
    upsertItem(vault, selected);
    await saveUnlockedVault(vault);
    renderItems();
    toast('Password age marked as changed today.');
  });
}

function renderSecurity() {
  const health = vaultHealth(vault.items);
  const ageSummary = passwordAgeSummary(vault.items);
  const ageReviewItems = vault.items.filter((item) => item.type === 'login' && !item.deletedAt).map((item) => ({ item, age: passwordAgeState(item) })).filter(({ age }) => age.state === 'review' || age.state === 'high' || age.state === 'unknown').sort((a, b) => {
    const rank = { high: 0, review: 1, unknown: 2 };
    return (rank[a.age.state] ?? 9) - (rank[b.age.state] ?? 9) || (b.age.days ?? -1) - (a.age.days ?? -1) || a.item.name.localeCompare(b.item.name);
  });
  const pending = vault.items.filter((item) => item.type === 'login' && !item.deletedAt && item.pendingPasswordChange?.password);
  const newLoginCaptures = Array.isArray(vault.pendingLoginCaptures) ? vault.pendingLoginCaptures : [];
  const ageHtml = ageReviewItems.length ? ageReviewItems.slice(0, 50).map(({ item, age }) => `<div class="passwordAgeRow age-${escapeHtml(age.state)}">
    <span class="passwordAgeRowIcon">${uiIcon(age.needsReview ? 'warningClock' : 'clock', 18)}</span>
    <span class="passwordAgeRowMain"><strong>${escapeHtml(item.name)}</strong><small>${escapeHtml(itemMeta(item))}</small></span>
    ${passwordAgeBadge(item, { compact: true })}
    <button class="miniAction outline" data-age-details="${escapeHtml(item.id)}">Details</button>
    <button class="miniAction" data-age-mark-today="${escapeHtml(item.id)}">Mark changed today</button>
  </div>`).join('') : '<div class="emptyState compactEmpty">No passwords currently need an age review.</div>';

  const pendingHtml = pending.length ? pending.map((item) => {
    const change = item.pendingPasswordChange;
    const detectionLabel = change.confidence === 'submitted-login' ? 'Different password submitted on login form' : 'Password-change form detected';
    return `<div class="passwordChangeCard" data-change-id="${escapeHtml(item.id)}">
      <div><strong>${escapeHtml(item.name)}</strong><small>${escapeHtml(detectionLabel)} - ${escapeHtml(change.hostname || 'Saved HTTPS login')} - ${escapeHtml(relativeTime(change.detectedAt))}</small><p>A possible password update was captured locally and stored only inside the encrypted vault. It is not displayed here and is never applied until you approve it. A different password submitted on a login form may simply be a typo, so review before updating.</p></div>
      <div class="passwordChangeActions"><button data-approve-change="${escapeHtml(item.id)}">Update saved password</button><button data-ignore-change="${escapeHtml(item.id)}" class="outline">Ignore</button></div>
    </div>`;
  }).join('') : '<div class="emptyState">No pending password changes.</div>';

  const newLoginHtml = newLoginCaptures.length ? newLoginCaptures.map((capture) => `<div class="passwordChangeCard" data-new-login-id="${escapeHtml(capture.id)}">
    <div><strong>${escapeHtml(capture.name || capture.hostname || 'New login')}</strong><small>${escapeHtml(capture.hostname || 'HTTPS website')} - ${escapeHtml(maskIdentifier(capture.username || ''))} - ${escapeHtml(relativeTime(capture.detectedAt))}</small><p>VaultCove detected a submitted account that is not currently saved for this website and identifier. The password remains hidden and is stored only inside the encrypted vault candidate until you save or ignore it.</p></div>
    <div class="passwordChangeActions"><button data-save-new-login="${escapeHtml(capture.id)}">Save login</button><button data-ignore-new-login="${escapeHtml(capture.id)}" class="outline">Ignore</button></div>
  </div>`).join('') : '<div class="emptyState">No pending new logins.</div>';

  els.content.innerHTML = `${pageHead()}<div class="stats"></div>
    <section class="settingsCard"><h3>Local vault health</h3><p>VaultCove checks saved login passwords only after you unlock the vault. No password, password hash, domain or score is sent anywhere.</p><div class="healthBar"><div style="width:${health.score}%"></div></div><p>${health.strong} strong - ${health.weak} weak - ${health.reused} reused</p></section>
    <section class="settingsCard"><div class="panelTitle"><h3>Password age review</h3><span class="pill ${ageSummary.over90 ? 'warningPill' : 'good'}">${ageSummary.over90} over 90 days</span></div><p>VaultCove warns when a known password-change date is at least 90 days old. Imported credentials without a trustworthy password-change timestamp are shown as Age unknown instead of using the import date.</p><div class="passwordAgeList">${ageHtml}</div></section>
    <section class="settingsCard"><h3>New-login review</h3><p>When an enabled VaultCove handler sees a submitted login that is not already saved for that site and account identifier, it stores a review candidate only inside the encrypted vault. VaultCove does not silently add it.</p><div class="passwordChangeList">${newLoginHtml}</div></section>
    <section class="settingsCard"><h3>Password-change review</h3><p>The optional login handler looks only for high-confidence password-change forms. A detected candidate is kept inside the encrypted vault until you approve or discard it.</p><div class="passwordChangeList">${pendingHtml}</div></section>`;
  const stats = els.content.querySelector('.stats');
  for (const [label, value] of [['Security score', `${health.score}%`], ['Login items', health.total], ['Weak passwords', health.weak], ['Reused passwords', health.reused], ['90+ day passwords', ageSummary.over90], ['Age unknown', ageSummary.unknown]]) {
    const node = document.createElement('div'); node.className = 'stat'; const strong = document.createElement('strong'); strong.textContent = value; const span = document.createElement('span'); span.textContent = label; node.append(strong, span); stats.append(node);
  }

  document.querySelectorAll('[data-age-details]').forEach((button) => button.addEventListener('click', () => {
    const item = vault.items.find((candidate) => candidate.id === button.dataset.ageDetails);
    if (item) openItemDialog(item);
  }));
  document.querySelectorAll('[data-age-mark-today]').forEach((button) => button.addEventListener('click', async () => {
    const item = vault.items.find((candidate) => candidate.id === button.dataset.ageMarkToday);
    if (!item || item.type !== 'login') return;
    item.lastPasswordChangeAt = new Date().toISOString();
    upsertItem(vault, item);
    await saveUnlockedVault(vault);
    renderSecurity();
    toast('Password age marked as changed today.');
  }));

  document.querySelectorAll('[data-approve-change]').forEach((button) => button.addEventListener('click', () => {
    const id = button.dataset.approveChange;
    ensureSensitiveAccess('Re-enter your master password before replacing a saved password.', async () => {
      const item = vault.items.find((candidate) => candidate.id === id);
      const pendingChange = item?.pendingPasswordChange;
      if (!item || !pendingChange?.password) throw new Error('This password change is no longer pending.');
      if (item.password && item.password !== pendingChange.password) {
        item.passwordHistory = [...(item.passwordHistory || []), { password: item.password, changedAt: pendingChange.detectedAt || new Date().toISOString() }].slice(-10);
      }
      item.password = pendingChange.password;
      item.lastPasswordChangeAt = new Date().toISOString();
      item.pendingPasswordChange = null;
      upsertItem(vault, item);
      await saveUnlockedVault(vault);
      await runtimeMessage({ type: 'PASSWORD_CHANGE_CONFIRMED', itemId: item.id });
      renderSecurity();
      toast('Saved password updated inside the encrypted vault.');
    }).catch((error) => toast(error.message, true));
  }));
  document.querySelectorAll('[data-ignore-change]').forEach((button) => button.addEventListener('click', () => {
    const id = button.dataset.ignoreChange;
    ensureSensitiveAccess('Re-enter your master password before discarding a captured password-change candidate.', async () => {
      const item = vault.items.find((candidate) => candidate.id === id);
      if (!item) throw new Error('Login no longer exists.');
      item.pendingPasswordChange = null;
      upsertItem(vault, item);
      await saveUnlockedVault(vault);
      renderSecurity();
      toast('Password-change candidate discarded.');
    }).catch((error) => toast(error.message, true));
  }));

  document.querySelectorAll('[data-save-new-login]').forEach((button) => button.addEventListener('click', () => {
    const id = button.dataset.saveNewLogin;
    ensureSensitiveAccess('Re-enter your master password before promoting a captured website credential into the permanent vault.', async () => {
      const capture = (vault.pendingLoginCaptures || []).find((candidate) => candidate.id === id);
      if (!capture?.password || !capture?.username) throw new Error('This new-login candidate is no longer pending.');
      const duplicate = vault.items.find((item) => item.type === 'login' && !item.deletedAt && (item.urls || []).some((url) => {
        try { return new URL(url).hostname.replace(/^www\./, '') === String(capture.hostname || '').replace(/^www\./, ''); } catch { return false; }
      }) && String(item.username || '').trim().toLowerCase() === String(capture.username || '').trim().toLowerCase());
      if (duplicate) throw new Error('This website/account is already saved in VaultCove. Review the existing login instead.');
      const item = createItem('login', {
        name: capture.name || capture.hostname || 'New Login',
        username: capture.username,
        password: capture.password,
        urls: [capture.origin || `https://${capture.hostname}`],
        autoLogin: false,
        requireReauthBeforeFill: false,
        lastPasswordChangeAt: new Date().toISOString()
      });
      upsertItem(vault, item);
      vault.pendingLoginCaptures = (vault.pendingLoginCaptures || []).filter((candidate) => candidate.id !== id);
      await saveUnlockedVault(vault);
      selectedItemId = item.id;
      renderSecurity();
      toast('New login encrypted and saved to VaultCove.');
    }).catch((error) => toast(error.message, true));
  }));
  document.querySelectorAll('[data-ignore-new-login]').forEach((button) => button.addEventListener('click', async () => {
    const id = button.dataset.ignoreNewLogin;
    vault.pendingLoginCaptures = (vault.pendingLoginCaptures || []).filter((candidate) => candidate.id !== id);
    await saveUnlockedVault(vault);
    renderSecurity();
    toast('New-login candidate ignored.');
  }));

  const newLoginHighlight = new URLSearchParams(location.search).get('newLogin');
  if (newLoginHighlight) document.querySelector(`[data-new-login-id="${CSS.escape(newLoginHighlight)}"]`)?.scrollIntoView({ block: 'center', behavior: 'smooth' });

  const highlight = new URLSearchParams(location.search).get('passwordChange');
  if (highlight) document.querySelector(`[data-change-id="${CSS.escape(highlight)}"]`)?.scrollIntoView({ block: 'center', behavior: 'smooth' });
}

function renderGenerator() {
  generatedPassword = generatedPassword || generatePassword({length:20});
  els.content.innerHTML = `${pageHead()}<section class="settingsCard generatorShell"><h3>Local Password Generator</h3><p>Generation uses the browser cryptographic random-number generator. Nothing is transmitted.</p><div class="generatorOutput"><input id="generatedPassword" value="${escapeHtml(generatedPassword)}" readonly><button id="copyGenerated">Copy</button><button id="regenPassword" class="outline">Regenerate</button></div><div class="generatorOptions"><label class="rangeRow"><span>Length</span><input id="generatorLength" type="range" min="12" max="64" value="20"><b id="generatorLengthValue">20</b></label><label><input id="genLower" type="checkbox" checked> Lowercase</label><label><input id="genUpper" type="checkbox" checked> Uppercase</label><label><input id="genDigits" type="checkbox" checked> Numbers</label><label><input id="genSymbols" type="checkbox" checked> Symbols</label></div></section>`;
  const regenerate = () => {
    try {
      const length=Number($('generatorLength').value); $('generatorLengthValue').textContent=String(length);
      generatedPassword=generatePassword({length,lower:$('genLower').checked,upper:$('genUpper').checked,digits:$('genDigits').checked,symbols:$('genSymbols').checked});
      $('generatedPassword').value=generatedPassword;
    } catch (error) { toast(error.message,true); }
  };
  $('regenPassword').addEventListener('click',regenerate);
  $('generatorLength').addEventListener('input',regenerate);
  for (const id of ['genLower','genUpper','genDigits','genSymbols']) $(id).addEventListener('change',regenerate);
  $('copyGenerated').addEventListener('click',async()=>{await navigator.clipboard.writeText($('generatedPassword').value);toast('Generated password copied.');});
}

async function renderMigration() {
  if (licenseState.status === 'expired') return renderBackup();
  pendingMigration = null;
  els.content.innerHTML = `${pageHead()}<div class="settingsGrid migrationGrid">
    <section class="settingsCard">
      <h3>Import from another password manager</h3>
      <p>VaultCove reads the export only inside this extension. Nothing is uploaded. After import, records are stored inside the encrypted VaultCove vault.</p>
      <label>Source format<select id="migrationFormat"><option value="auto">Detect automatically</option><option value="lastpass">LastPass CSV</option><option value="zoho">Zoho Vault CSV</option></select></label>
      <label>Export file<input id="migrationFile" type="file" accept=".csv,text/csv,text/plain"></label>
      <label class="check"><input id="migrationSkipDuplicates" type="checkbox" checked> Skip likely duplicate items already in VaultCove</label>
      <div class="migrationActions"><button id="migrationPreview">Preview locally</button><button id="migrationImport" class="outline" disabled>Import and encrypt</button></div>
      <div class="migrationWarning"><strong>Important:</strong> LastPass and Zoho CSV exports are plaintext. Delete the source CSV securely after you verify the VaultCove import and encrypted backup.</div>
    </section>
    <section class="settingsCard">
      <h3>Migration preview</h3>
      <div id="migrationPreviewMount" class="migrationPreview"><p>Select an export file to inspect it locally. Password values are never displayed in this preview.</p></div>
    </section>
    <section class="settingsCard">
      <h3>Supported today</h3>
      <p><strong>LastPass:</strong> CSV exports containing URL, username, password, name, notes/grouping and compatible TOTP values.</p>
      <p><strong>Zoho Vault:</strong> General/Zoho Vault CSV exports. VaultCove maps web logins and preserves recognized bank/card/identity/note fields when present.</p>
      <p>Encrypted vendor-specific backup containers are not decrypted by VaultCove. Export a supported CSV from the source manager first.</p>
    </section>
  </div>`;

  const mount = $('migrationPreviewMount');
  const previewButton = $('migrationPreview');
  const importButton = $('migrationImport');
  previewButton.addEventListener('click', async () => {
    try {
      const file = $('migrationFile').files?.[0];
      if (!file) throw new Error('Choose a LastPass or Zoho Vault CSV first.');
      if (file.size > 25 * 1024 * 1024) throw new Error('For safety, migration files are limited to 25 MB in this build.');
      const text = await file.text();
      pendingMigration = importMigrationCsv(text, $('migrationFormat').value);
      const counts = pendingMigration.items.reduce((out, item) => { out[item.type] = (out[item.type] || 0) + 1; return out; }, {});
      const sample = pendingMigration.items.slice(0, 8).map((item) => `<div class="migrationRow"><strong>${escapeHtml(item.name)}</strong><span>${escapeHtml(itemTypeLabel(item))}</span><small>${escapeHtml(item.type === 'login' ? (item.username || '(no username)') : itemMeta(item))}</small></div>`).join('');
      const warnings = pendingMigration.warnings?.length ? `<div class="migrationWarning">${pendingMigration.warnings.slice(0, 8).map(escapeHtml).join('<br>')}</div>` : '';
      mount.innerHTML = `<div class="migrationSummary"><strong>${pendingMigration.items.length}</strong><span>items detected from ${escapeHtml(pendingMigration.source)}</span></div><p>${Object.entries(counts).map(([type,count]) => `${escapeHtml(type)}: ${count}`).join(' - ')}</p>${warnings}<div class="migrationRows">${sample}</div>`;
      importButton.disabled = pendingMigration.items.length === 0;
    } catch (error) {
      pendingMigration = null; importButton.disabled = true; mount.textContent = error.message; toast(error.message, true);
    }
  });
  importButton.addEventListener('click', async () => {
    try {
      if (!pendingMigration) throw new Error('Preview the migration file first.');
      if (!featureAllowed(licenseState, 'edit')) throw new Error('A production license is required to import when licensing enforcement is enabled.');
      const merged = mergeImportedItems(vault.items, pendingMigration.items, { skipDuplicates: $('migrationSkipDuplicates').checked });
      if (!merged.accepted.length) throw new Error('No new items remain after duplicate filtering.');
      vault.items.push(...merged.accepted);
      await saveUnlockedVault(vault);
      const imported = merged.accepted.length;
      const skipped = merged.skipped;
      pendingMigration = null;
      $('migrationFile').value = '';
      importButton.disabled = true;
      mount.innerHTML = `<div class="migrationSummary"><strong>${imported}</strong><span>items imported and encrypted</span></div><p>${skipped} likely duplicate item(s) skipped.</p>`;
      toast(`${imported} imported item(s) encrypted into VaultCove.`);
    } catch (error) { toast(error.message, true); }
  });
}

function shareSelectorCard(item) {
  return `<label class="shareLoginCard" data-share-card="${escapeHtml(item.id)}"><input type="checkbox" name="shareLoginIds" value="${escapeHtml(item.id)}">${siteCardVisual(item)}<div class="shareLoginBody"><strong>${escapeHtml(item.name)}</strong><small>${escapeHtml(itemMeta(item))}</small><span>${item.siteVisual?.visitedAt ? 'Visited site visual available' : 'Fallback card until site is visited'}</span></div></label>`;
}

async function renderShared() {
  if (licenseState.status === 'expired') return renderBackup();
  const hadIdentity = Boolean(vault.sharingIdentity?.shareId);
  const identity = await ensureSharingIdentity(vault);
  if (!hadIdentity) await saveUnlockedVault(vault);
  const contacts = vault.trustedShareContacts || [];
  const logins = activeItems().filter((item) => item.type === 'login');
  const history = (vault.shareHistory || []).slice(0, 20);
  const vckeyTextAllowed = Boolean(vaultTotpProtection().enabled && settingsState?.vaultTotpEnabled);
  const contactOptions = contacts.map((contact) => `<option value="${escapeHtml(contact.shareId)}">${escapeHtml(contact.displayName || contact.shareId)} - ${escapeHtml(maskedShareId(contact.shareId))}</option>`).join('');
  const historyHtml = history.length ? history.map((entry) => `<div class="shareHistoryRow"><strong>${escapeHtml(entry.direction === 'out' ? 'Shared by me' : 'Shared with me')}</strong><span>${escapeHtml(entry.itemName || 'Login')}</span><small>${escapeHtml(entry.peerName || maskedShareId(entry.peerShareId || ''))} - ${escapeHtml(relativeTime(entry.occurredAt))}</small></div>`).join('') : '<div class="emptyState compactEmpty">No secure-share history yet.</div>';

  els.content.innerHTML = `${pageHead()}<div class="shareGrid">
    <section class="settingsCard shareIdentityCard">
      <h3>Your VaultCove Sharing Identity</h3>
      <p>Your public sharing identity is masked in the dashboard. Revealing it requires Sensitive Access. Your private sharing keys never leave the encrypted vault.</p>
      <div class="shareIdBox protectedShareIdentity"><strong id="visibleShareId">${escapeHtml(maskedShareId(identity.shareId))}</strong><span id="visibleShareFingerprint">${escapeHtml(maskedFingerprint(identity.fingerprint))}</span></div>
      <div class="identityActions"><button id="revealShareIdentity" class="outline">Reveal identity</button><button id="exportShareIdentity">Export encrypted .vckey</button></div>
      <p class="settingHint">The exported <code>.vckey</code> is encrypted with a separate file password that is not your VaultCove master password. It contains public recipient keys only—not your private keys or vault credentials.</p>
    </section>
    <section class="settingsCard">
      <h3>Trusted recipients</h3>
      <p>Import another user's encrypted <code>.vckey</code>. VaultCove asks for that file's separate password locally before the identity can be reviewed and trusted.</p>
      <label>Encrypted recipient identity<input id="contactFile" type="file" accept=".vckey,application/json"></label>
      <button id="importContact" class="outline">Unlock and trust encrypted .vckey</button>
      <div class="trustedContacts">${contacts.length ? contacts.map((contact) => `<div><strong>${escapeHtml(contact.displayName || 'VaultCove recipient')}</strong><small>${escapeHtml(maskedShareId(contact.shareId))} - ${escapeHtml(maskedFingerprint(contact.fingerprint))}</small></div>`).join('') : '<p>No trusted recipients yet.</p>'}</div>
    </section>
    <section class="settingsCard vckeyTextCard">
      <h3>Convert encrypted .vckey to TXT</h3>
      <p>This intentionally creates a readable public-identity text file. VaultCove requires Google Authenticator-compatible protection to be enabled, then requires a fresh master-password + authenticator verification and the separate <code>.vckey</code> file password.</p>
      <div class="integrationStatus"><strong>${vckeyTextAllowed ? 'Authenticator gate ready' : 'Authenticator setup required'}</strong><span>${vckeyTextAllowed ? 'The conversion gate is enabled. A recovery code may be used only as the emergency authenticator fallback.' : 'Go to Settings and set up Google Authenticator-compatible protection before plaintext conversion is permitted.'}</span></div>
      <label>Encrypted .vckey file<input id="vckeyTextFile" type="file" accept=".vckey,application/json"></label>
      <button id="convertVckeyToText" ${vckeyTextAllowed ? '' : 'disabled'}>Verify and convert to TXT</button>
      ${vckeyTextAllowed ? '' : '<button id="openAuthenticatorSettings" class="outline" type="button">Open Authenticator Settings</button>'}
      <div class="migrationWarning"><strong>Warning:</strong> TXT is plaintext. Anyone who can read the TXT can see the public Share ID, fingerprint, and public keys. VaultCove never writes the master password, .vckey password, saved logins, TOTP secrets, or private sharing keys into this TXT.</div>
    </section>
    <section class="settingsCard shareBundleCard">
      <div class="shareBundleHead"><div><h3>Create encrypted .vcshare bundle</h3><p>Select one or many login cards. VCShare v2 packages are recipient-key encrypted and sender-signed for VaultCove and compatible VaultCore/Android clients.</p></div><strong id="shareSelectedCount">0 selected</strong></div>
      <div class="shareSelectToolbar"><input id="shareSearch" type="search" placeholder="Search logins to share"><button id="shareSelectAll" class="outline" type="button">Select visible</button><button id="shareClear" class="outline" type="button">Clear</button></div>
      <div id="shareLoginGrid" class="shareLoginGrid">${logins.length ? logins.map(shareSelectorCard).join('') : '<div class="emptyState compactEmpty">No login available.</div>'}</div>
      <label>Recipient<select id="shareRecipient">${contactOptions || '<option value="">Import a recipient first</option>'}</select></label>
      <div class="shareChecks"><label class="check"><input id="shareUsername" type="checkbox" checked> Username</label><label class="check"><input id="sharePassword" type="checkbox" checked> Password</label><label class="check"><input id="shareNotes" type="checkbox"> Notes</label><label class="check"><input id="shareTotp" type="checkbox"> TOTP secret (extra warning)</label></div>
      <label>Expire package after<select id="shareExpiry"><option value="7">7 days</option><option value="1">1 day</option><option value="30">30 days</option><option value="0">Never</option></select></label>
      <button id="createShare" disabled>Create encrypted .vcshare bundle</button>
      <div class="migrationWarning"><strong>Important:</strong> a password already decrypted by a recipient cannot be remotely erased. To revoke actual access after receipt, change the website password.</div>
    </section>
    <section class="settingsCard"><h3>Receive secure share</h3><p>VaultCove verifies the sender signature and recipient identity before decrypting. Received items are immediately re-encrypted under your own vault key.</p><label>Secure share file<input id="shareFile" type="file" accept=".vcshare,application/json"></label><button id="importShare" class="outline">Verify and import share</button></section>
    <section class="settingsCard shareHistoryCard"><h3>Local share history</h3><p>History is stored only inside your encrypted vault and contains metadata, never the shared passwords.</p><div class="shareHistory">${historyHtml}</div></section>
  </div>`;
  wireFaviconFallbacks(els.content);

  const selectedIds = () => [...document.querySelectorAll('input[name="shareLoginIds"]:checked')].map((input) => input.value);
  const updateShareSelection = () => {
    const count = selectedIds().length;
    $('shareSelectedCount').textContent = `${count} selected`;
    $('createShare').disabled = !(count && contacts.length && $('shareRecipient').value);
    document.querySelectorAll('.shareLoginCard').forEach((card) => card.classList.toggle('selected', card.querySelector('input')?.checked));
  };
  document.querySelectorAll('input[name="shareLoginIds"]').forEach((input) => input.addEventListener('change', updateShareSelection));
  $('shareRecipient')?.addEventListener('change', updateShareSelection);
  $('shareSearch')?.addEventListener('input', () => {
    const q = $('shareSearch').value.trim().toLowerCase();
    document.querySelectorAll('.shareLoginCard').forEach((card) => {
      const item = logins.find((candidate) => candidate.id === card.dataset.shareCard);
      const haystack = `${item?.name || ''} ${item?.username || ''} ${(item?.urls || []).join(' ')}`.toLowerCase();
      card.classList.toggle('hidden', Boolean(q && !haystack.includes(q)));
    });
  });
  $('shareSelectAll')?.addEventListener('click', () => { document.querySelectorAll('.shareLoginCard:not(.hidden) input[name="shareLoginIds"]').forEach((input) => { input.checked = true; }); updateShareSelection(); });
  $('shareClear')?.addEventListener('click', () => { document.querySelectorAll('input[name="shareLoginIds"]').forEach((input) => { input.checked = false; }); updateShareSelection(); });

  $('revealShareIdentity').addEventListener('click', () => ensureFreshSensitiveAccess('Re-enter your master password before revealing your VaultCove sharing identity and fingerprint.', async () => {
    $('visibleShareId').textContent = identity.shareId;
    $('visibleShareFingerprint').textContent = identity.fingerprint;
    $('revealShareIdentity').textContent = 'Hide identity';
    const timeout = Math.max(5, Math.min(60, Number(settingsState.revealTimeoutSeconds || 10))) * 1000;
    setTimeout(() => {
      if (!$('visibleShareId')) return;
      $('visibleShareId').textContent = maskedShareId(identity.shareId);
      $('visibleShareFingerprint').textContent = maskedFingerprint(identity.fingerprint);
      if ($('revealShareIdentity')) $('revealShareIdentity').textContent = 'Reveal identity';
    }, timeout);
  }).catch((error) => toast(error.message, true)));

  $('exportShareIdentity').addEventListener('click', async () => {
    // Open Chrome's save picker directly from the user's click so Windows keeps a normal visible pointer.
    // The file is not written until Sensitive Access and the separate .vckey password both succeed.
    const saveTarget = await chooseSaveHandle('VaultCove-Sharing-Key.vckey', { description: 'VaultCove encrypted sharing key', mime: 'application/json' });
    if (saveTarget.method === 'cancelled') return;
    ensureFreshSensitiveAccess('Re-enter your master password before exporting your sharing identity.', async () => {
      const password = await requestVckeyPassword('export');
      const encryptedIdentity = await createEncryptedVckey(vault, password, 'VaultCove User');
      const blob = new Blob([JSON.stringify(encryptedIdentity, null, 2)], { type: 'application/json' });
      const result = await writeBlobToSaveTarget(saveTarget, blob);
      if (!result.saved) return;
      toast('Encrypted .vckey exported. Its separate file password is required to import it.');
    }).catch((error) => { if (error?.message !== 'Cancelled.') toast(error.message, true); });
  });

  $('importContact').addEventListener('click', async () => {
    try {
      const input = $('contactFile');
      const file = input?.files?.[0];
      if (!file) throw new Error('Choose an encrypted .vckey file first.');
      // Snapshot the selected file before opening any authentication dialog so a re-render cannot null the input.
      const wrapper = JSON.parse(await file.text());
      await ensureFreshSensitiveAccess('Re-enter your master password before importing and trusting another VaultCove sharing identity.', async () => {
        const password = await requestVckeyPassword('import');
        const contact = await openEncryptedVckey(wrapper, password);
        const approved = confirm(`Trust this VaultCove recipient?\n\n${contact.displayName}\n${contact.shareId}\nFingerprint: ${contact.fingerprint}\n\nCompare the fingerprint with the recipient through a separate trusted channel.`);
        if (!approved) return;
        addTrustedShareContact(vault, contact); await saveUnlockedVault(vault); toast('Trusted recipient saved inside the encrypted vault.'); await renderShared();
      });
    } catch (error) { if (error?.message !== 'Cancelled.') toast(error.message, true); }
  });

  $('openAuthenticatorSettings')?.addEventListener('click', () => switchView('settings'));

  $('convertVckeyToText')?.addEventListener('click', () => {
    if (!vckeyTextAllowed) {
      toast('Set up Google Authenticator-compatible protection in Settings before converting .vckey to TXT.', true);
      return;
    }
    ensureFreshSensitiveAccess(
      'Re-enter your master password and verify Google Authenticator before VaultCove can create a plaintext TXT from an encrypted .vckey.',
      async () => {
        const file = $('vckeyTextFile')?.files?.[0];
        if (!file) throw new Error('Choose an encrypted .vckey file first.');
        if (!confirm('Convert this encrypted .vckey to a readable TXT file?\n\nThe TXT is plaintext. Anyone with access to the TXT can read the public sharing identity. Vault passwords and private keys are never included.')) return;
        const wrapper = JSON.parse(await file.text());
        const password = await requestVckeyPassword('convert');
        const identityText = await openEncryptedVckey(wrapper, password);
        const safeId = String(identityText.shareId || 'VaultCove').replace(/[^a-z0-9._-]+/gi, '-');
        await downloadTextFile(publicIdentityText(identityText), `VaultCove-${safeId}-PUBLIC-IDENTITY.txt`);
        toast('Plaintext public-identity TXT created. Store or delete it carefully.');
      }
    ).catch((error) => { if (error?.message !== 'Cancelled.') toast(error.message, true); });
  });

  $('createShare').addEventListener('click', () => ensureSensitiveAccess('Re-enter your master password and second factor before creating a decrypted credential share.', async () => {
    const ids = selectedIds();
    const items = ids.map((id) => vault.items.find((candidate) => candidate.id === id && candidate.type === 'login' && !candidate.deletedAt)).filter(Boolean);
    const contact = contacts.find((candidate) => candidate.shareId === $('shareRecipient').value);
    if (!items.length || !contact) throw new Error('Select at least one login and a trusted recipient.');
    if (items.length > 50) throw new Error('Select at most 50 logins per secure share.');
    if ($('shareTotp').checked && !confirm('Sharing TOTP secrets can let the recipient generate authentication codes for every selected account that has one. Continue?')) return;
    const days = Number($('shareExpiry').value) || 0;
    const expiresAt = days > 0 ? new Date(Date.now() + days * 86400000).toISOString() : null;
    const pkg = await createSecureShare(vault, { magic:'VAULTCOVE-PUBLIC-IDENTITY', version:2, ...contact }, items, { expiresAt, include: { username:$('shareUsername').checked, password:$('sharePassword').checked, notes:$('shareNotes').checked, totp:$('shareTotp').checked } });
    const filename = items.length === 1 ? `${items[0].name.replace(/[^a-z0-9._-]+/gi,'-').replace(/^-+|-+$/g,'') || 'VaultCove'}.vcshare` : `VaultCove-${items.length}-logins.vcshare`;
    await downloadJsonFile(pkg, filename);
    recordShareHistory(vault, { direction:'out', itemName:items.length === 1 ? items[0].name : `${items.length} login bundle`, itemCount:items.length, peerName:contact.displayName, peerShareId:contact.shareId, expiresAt }); await saveUnlockedVault(vault);
    toast(`Encrypted VCShare bundle created for ${items.length} login${items.length === 1 ? '' : 's'}.`); await renderShared();
  }).catch((error) => toast(error.message, true)));

  $('importShare').addEventListener('click', () => ensureSensitiveAccess('Re-enter your master password and second factor before decrypting and importing a secure share.', async () => {
    const file = $('shareFile').files?.[0]; if (!file) throw new Error('Choose a .vcshare file first.');
    const opened = await openSecureShare(vault, JSON.parse(await file.text()));
    if (!opened.sender.trusted && !confirm(`The package signature is valid, but sender ${opened.sender.shareId} is not in your trusted recipients.\nFingerprint: ${opened.sender.fingerprint}\n\nImport anyway?`)) return;
    vault.items.push(...opened.items);
    recordShareHistory(vault, { direction:'in', itemName:opened.items.length === 1 ? opened.items[0].name : `${opened.items.length} login bundle`, itemCount:opened.items.length, peerName:opened.sender.displayName, peerShareId:opened.sender.shareId });
    await saveUnlockedVault(vault);
    toast(`${opened.items.length} secure-share login${opened.items.length === 1 ? '' : 's'} verified and imported.`); currentView='login'; selectedItemId=opened.items[0]?.id || null; render();
  }).catch((error) => toast(error.message, true)));
  updateShareSelection();
}


function licenseStatusCard(client) {
  const lease = client.lease || null;
  if (!lease) return `<div class="licenseStateCard"><strong>Not activated on this device</strong><span>Enter your serial and the email associated with it. First activation securely binds an unassigned serial to the verified email.</span></div>`;
  const expiry = lease.expiresAt ? new Date(lease.expiresAt).toLocaleString() : 'Unknown';
  return `<div class="licenseStateCard goodLicense"><strong>${escapeHtml(String(lease.licenseType || 'standard').toUpperCase())} ${escapeHtml(String(lease.status || 'active').toUpperCase())} - ${escapeHtml(client.emailMasked || lease.emailMasked || '')}</strong><span>${escapeHtml(String(lease.activeDevices || 0))} of ${escapeHtml(String(lease.maxDevices || 7))} device slots active - signed lease expires ${escapeHtml(expiry)}</span></div>`;
}

function licensedDeviceRows(devices, currentInstallationId) {
  if (!Array.isArray(devices) || !devices.length) return '<div class="emptyState compactEmpty">No licensed devices returned.</div>';
  return devices.map((device) => {
    const current = device.installationId === currentInstallationId;
    const status = String(device.status || 'active');
    const actions = status === 'active'
      ? `<button class="outline miniAction" data-license-action="retain" data-installation="${escapeHtml(device.installationId)}">Retain</button><button class="outline miniAction" data-license-action="release" data-installation="${escapeHtml(device.installationId)}">Release</button><button class="danger miniAction" data-license-action="revoke" data-installation="${escapeHtml(device.installationId)}">Revoke</button>`
      : status === 'revoked'
        ? `<button class="outline miniAction" data-license-action="restore" data-installation="${escapeHtml(device.installationId)}">Restore</button>`
        : status === 'retained'
          ? `<button class="outline miniAction" data-license-action="restore" data-installation="${escapeHtml(device.installationId)}">Restore</button><button class="outline miniAction" data-license-action="release" data-installation="${escapeHtml(device.installationId)}">Release</button>`
          : status === 'released'
            ? `<button class="outline miniAction" data-license-action="restore" data-installation="${escapeHtml(device.installationId)}">Restore</button>`
            : '';
    return `<div class="licensedDeviceRow ${current ? 'currentDevice' : ''}">
      <div class="deviceIcon">VC</div>
      <div class="deviceMain"><strong>${escapeHtml(device.deviceLabel || 'VaultCove device')}${current ? ' - This device' : ''}</strong><span>${escapeHtml(device.platform || 'Unknown platform')} - VaultCove ${escapeHtml(device.appVersion || '')}</span><small>First seen ${escapeHtml(device.firstSeenAt ? new Date(device.firstSeenAt).toLocaleString() : 'unknown')} - Last seen ${escapeHtml(device.lastSeenAt ? new Date(device.lastSeenAt).toLocaleString() : 'unknown')}</small></div>
      <div class="deviceState"><b>${escapeHtml(status)}</b><div>${actions}</div></div>
    </div>`;
  }).join('');
}

async function renderLicense() {
  const client = await getLicenseClientState();
  const privacy = licensePrivacyContract();
  const installationId = licenseState?.deviceId || '';
  const devicesHtml = licenseManagementToken
    ? `<div id="licensedDevices" class="licensedDevices"><div class="emptyState compactEmpty">Loading licensed devices...</div></div>`
    : '<div class="emptyState compactEmpty">Verify the license email before viewing or changing device slots.</div>';

  els.content.innerHTML = `${pageHead()}
    <div class="licenseLayout">
      <section class="settingsCard licenseActivationCard">
        <h3>Serial + email activation</h3>
        <p>One VaultCove serial is associated with one verified email and uses the device limit assigned by Apps Script. Standard serials allow <strong>7 devices</strong>; Admin serials allow <strong>20 devices</strong>. If a new serial has no email yet, the first successful email-code verification binds it to that email.</p>
        ${licenseStatusCard(client)}
        <label>Apps Script license-service URL<input id="licenseEndpoint" type="url" value="${escapeHtml(client.endpoint || '')}" placeholder="https://script.google.com/macros/s/.../exec"></label>
        <div class="fieldGrid"><label>VaultCove serial<input id="licenseSerial" autocomplete="off" placeholder="VC-..."></label><label>License email<input id="licenseEmail" type="email" autocomplete="email" value="${escapeHtml(settingsState?.securityNoticeEmail || '')}" placeholder="you@example.com"></label></div>
        <label>This device name<input id="licenseDeviceLabel" maxlength="80" value="${escapeHtml(navigator.platform || 'Chrome device')}" placeholder="Home laptop, Android phone, Office PC..."></label>
        <div class="licenseActions"><button id="activateLicense">Verify and activate this device</button>${client.refreshToken ? '<button id="refreshLicense" class="outline">Refresh signed license</button><button id="releaseThisDevice" class="outline">Release this device slot</button>' : ''}</div>
        <div class="migrationWarning"><strong>Testing build:</strong> licensing does not disable features yet. Production will use signed server leases. VaultCove never sends vault records to the licensing service.</div>
      </section>

      <section class="settingsCard deviceManagerCard">
        <div class="shareBundleHead"><div><h3>Licensed devices</h3><p>Monitor device slots. Retain keeps a known device record reserved for recovery, Release frees its slot, Revoke blocks a suspicious installation, and Restore reactivates an allowed record.</p></div><button id="manageDevices" ${client.refreshToken ? '' : 'disabled'}>Verify email and manage</button></div>
        ${devicesHtml}
        <p class="settingHint">Device identity uses a random VaultCove installation ID—not a MAC address, Windows serial number, IMEI, hardware fingerprint, or browsing history.</p>
      </section>

      <section class="settingsCard licensePrivacyCard">
        <h3>Licensing privacy boundary</h3>
        <p><strong>May be sent:</strong> ${escapeHtml(privacy.sent.join('; '))}.</p>
        <p><strong>Never sent:</strong> ${escapeHtml(privacy.neverSent.join('; '))}.</p>
        <p>The future Android VaultCove app can use the same license/device protocol, encrypted <code>.vckey</code>, <code>.vcshare</code>, <code>.vcvault</code>, and <code>.vcrecovery</code> schemas without making the Chrome vault a cloud-synced password database.</p>
      </section>
    </div>`;

  async function saveEndpointAndPermission() {
    const endpoint = $('licenseEndpoint').value.trim();
    await setLicenseServiceUrl(endpoint);
    const granted = await ensureLicenseServicePermission();
    if (!granted) throw new Error('VaultCove license-service permission was not granted.');
  }

  $('activateLicense').addEventListener('click', async () => {
    try {
      await saveEndpointAndPermission();
      const serial = $('licenseSerial').value.trim();
      const result = await beginLicenseActivation({
        serial,
        email: $('licenseEmail').value,
        deviceLabel: $('licenseDeviceLabel').value
      });
      const challengeId = String(result.challengeId || '');
      if (!challengeId) throw new Error('License service did not return a verification challenge.');
      let activationResult = await requestLicenseOtp({
        title: result.emailWasBoundNow ? 'Confirm first license email' : 'Verify license email',
        subtitle: `Enter the 6-digit code sent to ${result.emailMasked || 'the license email'}.`,
        onVerify: async (code) => completeLicenseActivation({ challengeId, code, serialHint: serial.slice(-4) })
      });
      if (activationResult?.reclaimRequired) activationResult = await requestLicenseReclaim(activationResult, $('licenseDeviceLabel').value, serial.slice(-4));
      licenseState = await getLicenseState();
      toast('VaultCove license activated on this device.');
      await renderLicense();
    } catch (error) { if (error?.message !== 'Cancelled.') toast(error.message, true); }
  });

  $('refreshLicense')?.addEventListener('click', async () => {
    try {
      await ensureLicenseServicePermission();
      await refreshLicenseLease();
      licenseState = await getLicenseState();
      toast('Signed license lease refreshed.');
      await renderLicense();
    } catch (error) { toast(error.message, true); }
  });

  $('releaseThisDevice')?.addEventListener('click', async () => {
    if (!confirm('Release this VaultCove installation from the license? This frees the device slot assigned to this installation. Your encrypted local vault is not deleted.')) return;
    try {
      await ensureLicenseServicePermission();
      await releaseCurrentDevice();
      licenseManagementToken = '';
      licenseState = await getLicenseState();
      toast('This device slot was released. Local encrypted vault data was not deleted.');
      await renderLicense();
    } catch (error) { toast(error.message, true); }
  });

  $('manageDevices').addEventListener('click', async () => {
    try {
      await saveEndpointAndPermission();
      const start = await beginDeviceManagement();
      const challengeId = String(start.challengeId || '');
      if (!challengeId) throw new Error('License service did not return a device-management challenge.');
      const result = await requestLicenseOtp({
        title: 'Verify email to manage devices',
        subtitle: `Enter the 6-digit code sent to ${start.emailMasked || 'the license email'}.`,
        onVerify: async (code) => completeDeviceManagement(challengeId, code)
      });
      licenseManagementToken = String(result.managementToken || '');
      if (!licenseManagementToken) throw new Error('Device-management token was not returned.');
      await loadLicensedDevices();
    } catch (error) { if (error?.message !== 'Cancelled.') toast(error.message, true); }
  });

  async function loadLicensedDevices() {
    const mount = $('licensedDevices');
    if (!mount || !licenseManagementToken) return;
    const result = await listLicensedDevices(licenseManagementToken);
    const used = Number(result.activeDevices || 0) + Number(result.retainedDevices || 0);
    mount.innerHTML = `<div class="deviceSlotSummary"><strong>${escapeHtml(String(result.licenseType || 'standard'))} license</strong><span>${used} of ${Number(result.maxDevices || 0)} slots in use - ${Number(result.activeDevices || 0)} active - ${Number(result.retainedDevices || 0)} retained</span></div>${licensedDeviceRows(result.devices || [], installationId)}`;
    mount.querySelectorAll('[data-license-action]').forEach((button) => button.addEventListener('click', async () => {
      const action = button.dataset.licenseAction;
      const target = button.dataset.installation;
      const label = action === 'revoke' ? 'REVOKE' : action === 'release' ? 'release' : action === 'retain' ? 'retain' : 'restore';
      if (!confirm(`${label} this licensed device?`)) return;
      try {
        await changeLicensedDevice(licenseManagementToken, target, action);
        const actionMessages = { retain:'Device retained and its license slot remains reserved.', release:'Device released and its license slot is now available.', revoke:'Device revoked and blocked until an authorized restore and reactivation.', restore:'Device record restored. The device must reactivate if its prior session was cleared.' };
        toast(actionMessages[action] || 'Device action completed.');
        await loadLicensedDevices();
      } catch (error) { toast(error.message, true); }
    }));
  }

  if (licenseManagementToken) loadLicensedDevices().catch((error) => toast(error.message, true));
}

async function renderBackup() {
  els.content.innerHTML = `${pageHead()}<div class="settingsGrid backupGrid">
    <section class="settingsCard"><h3>Encrypted vault backup</h3><p>Create a portable encrypted .vcvault file. Keep its export secret separately.</p><button id="backupExportVault">Create encrypted vault backup</button></section>
    <section class="settingsCard"><h3>Restore encrypted vault</h3><p>Restore a .vcvault backup with its matching export secret.</p><label>Backup file<input id="restoreFile" type="file" accept=".vcvault,application/json"></label><label>Export secret<input id="restoreSecret" autocomplete="off"></label><button id="restoreVaultButton" class="outline">Restore into this vault</button></section>
    <section class="settingsCard recoveryCard"><h3>Offline Recovery Kit</h3><p>Create an encrypted .vcrecovery file for disaster recovery. It stores your private sharing identity and device recovery token, not your website passwords. Keep it offline on separate media.</p><button id="exportRecoveryKit">Create offline Recovery Kit</button><p class="settingHint">If this is your only device and it is destroyed without another VaultCove device or an offline Recovery Kit, the same private sharing identity cannot be recovered.</p></section>
    <section class="settingsCard recoveryCard"><h3>Restore Recovery Kit</h3><p>Use this after a PC reset or when moving recovery material from a trusted VaultCove Android or desktop device.</p><label>Recovery Kit file<input id="recoveryFile" type="file" accept=".vcrecovery,application/json"></label><button id="importRecoveryKit" class="outline">Restore offline recovery identity</button></section>
  </div>`;
  $('backupExportVault').addEventListener('click', exportVault);
  $('restoreVaultButton').addEventListener('click', importVault);
  $('exportRecoveryKit').addEventListener('click', () => ensureFreshSensitiveAccess('Re-enter your master password before exporting your encrypted offline Recovery Kit.', async () => {
    const password = await requestRecoveryPassword('export');
    const comparison = await runtimeMessage({ type:'CHECK_MASTER_PASSWORD_MATCH', candidate:password });
    if (comparison.matches) throw new Error('The Recovery Password must be different from your VaultCove master password.');
    const token = await ensureDeviceRecoveryToken();
    const kit = await createRecoveryKit(vault, token, password, { includeAuthenticator:$('recoveryIncludeAuthenticator')?.checked });
    vault.recovery = { ...(vault.recovery || {}), lastRecoveryKitAt:new Date().toISOString() }; await saveUnlockedVault(vault);
    await downloadJsonFile(kit, 'VaultCove-Recovery.vcrecovery', 'application/json'); toast('Encrypted offline Recovery Kit created. Store it separately from this device.');
  }).catch((error)=>toast(error.message,true)));
  $('importRecoveryKit').addEventListener('click', async () => {
    try {
      const fileInput = $('recoveryFile');
      const file = fileInput?.files?.[0];
      if (!file) throw new Error('Choose a .vcrecovery file first.');
      const kitText = await file.text();
      const kitEnvelope = JSON.parse(kitText);
      await ensureFreshSensitiveAccess('Re-enter your master password before restoring private recovery material.', async () => {
        const password = await requestRecoveryPassword('import');
        const payload = await openRecoveryKit(kitEnvelope, password);
        if (vault.sharingIdentity && !confirm('Replace the current VaultCove sharing identity with the identity from this Recovery Kit?')) return;
        vault.sharingIdentity = payload.sharingIdentity;
        if (payload.vaultTotp && confirm('Restore the VaultCove authenticator configuration from this Recovery Kit?')) { vault.security=vault.security||{}; vault.security.vaultTotp=payload.vaultTotp; await setSettings({ vaultTotpEnabled:Boolean(payload.vaultTotp.enabled) }); }
        if (payload.deviceRecoveryToken) await setDeviceRecoveryToken(payload.deviceRecoveryToken);
        await saveUnlockedVault(vault);
        toast('Recovery identity restored. The license service can use the restored recovery token to reclaim the known device record.');
      });
    } catch (error) { toast(error.message, true); }
  });
}

async function renderSettings() {
  settingsState = await getSettings();
  if (licenseState.status === 'expired') return renderBackup();
  await refreshHandlerPermissions();
  const origins = handlerPermissionState;
  const broadOrigin = 'https://*/*';
  const broadGranted = await chrome.permissions.contains({ origins: [broadOrigin] });
  const faviconGranted = await chrome.permissions.contains({ permissions: ['favicon'] });
  const perSiteOrigins = origins.filter((origin) => origin !== broadOrigin);
  const disabledHandlerHosts = Array.isArray(settingsState.handlerDisabledHosts) ? settingsState.handlerDisabledHosts : [];
  const siteRows = disabledHandlerHosts.length
    ? disabledHandlerHosts.map((host) => `<div class="permissionRow"><strong>${escapeHtml(host)}</strong><button type="button" class="miniAction enableHandlerHost" data-host="${attr(host)}">Turn on</button></div>`).join('')
    : '<div class="emptyState compactEmpty">Always-On Handler is active on every HTTPS website.</div>';
  const protection = vaultTotpProtection();
  const strength = assessPassword('');

  els.content.innerHTML = `${pageHead()}<div class="settingsGrid settingsPageGrid">
    <section class="settingsCard"><h3>Appearance</h3><p>Choose a compact VaultCove theme. Theme changes are local to this installation.</p><label>Theme<select id="themeSetting">${Object.entries(THEMES).map(([value,label])=>`<option value="${escapeHtml(value)}" ${settingsState.theme===value?'selected':''}>${escapeHtml(label)}</option>`).join('')}</select></label><label class="check"><input id="compactUiSetting" type="checkbox" ${settingsState.compactUi!==false?'checked':''}> Compact interface</label></section>
    <section class="settingsCard"><h3>Auto-lock and Sensitive Access</h3><p>Vault unlock controls normal use. Viewing, copying, editing, exporting, sharing, or protected filling gets a fresh Sensitive Access check.</p><label>Lock vault after inactivity (minutes)<input id="lockMinutesSetting" type="number" min="1" max="120" value="${settingsState.lockMinutes}"></label><label>Sensitive Access window (seconds)<input id="sensitiveSecondsSetting" type="number" min="5" max="300" value="${settingsState.sensitiveAccessSeconds}"></label><label>Secure Login field-clear fallback (milliseconds)<input id="clearDelaySetting" type="number" min="250" max="5000" step="50" value="${settingsState.secureLoginClearMs || 1200}"></label><p class="settingHint">Secure Login submits first, then clears the injected password field if it is still present and unchanged.</p><button id="saveSettings">Save security timing</button></section>

    <section class="settingsCard alwaysOnCard"><h3>Always-On Login Handler</h3><p>Always-On Handler is enabled by default on HTTPS websites. Add only the websites where you do not want VaultCove to show its login handler.</p><div class="integrationStatus"><strong>Always-On Handler enabled by default</strong><span>The Developer build loads the isolated handler automatically on HTTPS pages. A website on the exception list receives no VaultCove handler UI and no automatic login handling.</span></div><div class="handlerExceptionEditor"><input id="handlerOffHost" type="text" placeholder="example.com" autocomplete="off"><button id="addHandlerOffHost" type="button" class="outline">Turn off for website</button></div><p class="settingHint">Enter only a hostname, such as 9gag.com. You can turn the handler back on at any time.</p><div class="permissionList">${siteRows}</div><label class="check"><input id="autoLoginSetting" type="checkbox" ${settingsState.autoLoginEnabled ? 'checked' : ''}> Enable automatic login only for entries individually marked Auto-login</label><label class="check"><input id="newLoginCaptureSetting" type="checkbox" ${settingsState.newLoginCaptureEnabled ? 'checked' : ''}> Detect submitted new logins locally and ask before saving them</label><label class="check"><input id="passwordChangeSetting" type="checkbox" ${settingsState.passwordChangeDetectionEnabled ? 'checked' : ''}> Detect password changes and offer the inline strong-password generator</label></section>

    <section class="settingsCard"><h3>Website thumbnails</h3><p>The visual Vault can use Chrome's local favicon cache. VaultCove shows an icon only after that saved login has actually been visited while VaultCove was active; otherwise it keeps the private lock-card fallback.</p><div class="integrationStatus"><strong>${faviconGranted && settingsState.websiteIconsEnabled ? 'Local website icons enabled' : 'Private fallback cards enabled'}</strong><span>No third-party icon service is contacted and no domain list is uploaded.</span></div>${faviconGranted && settingsState.websiteIconsEnabled ? '<button id="disableSiteIcons" class="outline">Use fallback cards only</button>' : '<button id="enableSiteIcons">Enable local website icons</button>'}</section>

    <section class="settingsCard"><h3>VaultCove authenticator confirmation</h3><p>${protection.enabled ? 'A standard TOTP authenticator code is required with the master password for unlock and Sensitive Access. It also authorizes .vckey-to-TXT conversion.' : 'Set up a standard TOTP authenticator such as Google Authenticator. VaultCove requires it before any encrypted .vckey can be converted to readable TXT.'}</p><div class="integrationStatus"><strong>${protection.enabled ? 'Authenticator protection enabled' : 'Authenticator protection disabled'}</strong><span>Google Authenticator does not receive, sync, store, or have access to your VaultCove passwords. VaultCove verifies a standard TOTP code locally. .vckey-to-TXT conversion still requires that file's separate .vckey password; VaultCove does not create a third TXT-conversion password.</span></div>${protection.enabled ? `<p class="settingHint">${(protection.recoveryCodeHashes || []).length} unused recovery code(s) remain.</p><button id="disableVaultTotp" class="outline">Disable authenticator protection</button>` : '<button id="setupVaultTotp">Set up Google Authenticator-compatible protection</button>'}</section>

    <section class="settingsCard masterPasswordCard"><h3>Change master password</h3><p>VaultCove verifies the current password${protection.enabled ? ' and authenticator code' : ''}, checks the new password strength, atomically re-wraps the same random vault key, then locks the vault so the new password must be used immediately.</p><label>Current master password<input id="currentMaster" type="password" autocomplete="current-password"></label>${protection.enabled ? '<label>Authenticator or recovery code<input id="masterTotp" autocomplete="one-time-code" inputmode="numeric"></label>' : ''}<label>New master password<input id="newMaster" type="password" autocomplete="new-password"></label><div class="masterStrength"><span>Strength</span><strong id="masterStrengthLabel">${escapeHtml(strength.label)}</strong><div><i id="masterStrengthBar"></i></div></div><label>Confirm new password<input id="newMasterConfirm" type="password" autocomplete="new-password"></label><label>Type <code>CHANGE MASTER PASSWORD</code> to confirm<input id="masterConfirmPhrase" autocomplete="off"></label><div class="migrationWarning"><strong>Before changing it:</strong> keep a current encrypted <code>.vcvault</code> backup and its export secret. VaultCove cannot recover a forgotten master password or lost authenticator setup.</div><button id="changeMaster" class="danger">Change master password and lock VaultCove</button></section>

    <section class="settingsCard"><h3>Developer updates</h3><p>This Developer Mode build checks only the official public <code>VaultCove-release</code> metadata once per day. No vault, username, password, website list, security score, or browsing data is added to the request.</p><label class="check"><input id="updateCheckSetting" type="checkbox" ${settingsState.updateChecksEnabled ? 'checked' : ''}> Check official developer release metadata daily</label><button id="checkUpdatesNow" class="outline">Check for updates now</button><p class="settingHint">The Chrome Web Store build removes the GitHub updater permission and uses Chrome's official extension update mechanism.</p></section>
    <section class="settingsCard"><h3>Email security notice</h3><p>This preference is collected during first-run security setup and can be changed here. A generic notice never includes the website, username, account title, old password, or new password.</p><label>Security notice email<input id="securityNoticeEmail" type="email" autocomplete="email" value="${escapeHtml(settingsState.securityNoticeEmail || '')}" placeholder="you@example.com"></label><label class="check"><input id="emailNoticeSetting" type="checkbox" ${settingsState.securityEmailNoticeEnabled ? 'checked' : ''}> Prepare generic email notice after an approved password update</label><button id="saveEmailNoticeSettings" type="button" class="outline">Save security notice setup</button><div class="migrationWarning"><strong>Testing build:</strong> the address and preference are stored locally. No email is sent until the license-service transport is connected.</div></section>
    <section class="settingsCard"><h3>Privacy model</h3><p>No cloud vault, analytics, advertising or telemetry. Autofill secrets are released only for a verified matching HTTPS destination. Website icons use Chrome's local favicon cache only when explicitly enabled.</p><p><strong>${escapeHtml(licenseState.message)}</strong></p></section>
    <section class="settingsCard"><h3>What encryption can and cannot protect</h3><p>A stolen Chrome profile sees only the encrypted vault. Once a credential is deliberately filled into a destination page, that page can read it; Secure Login therefore validates the destination, injects at the last practical moment, submits promptly and clears the field after submission when safe.</p></section>
  </div>`;

  $('saveSettings').addEventListener('click', async () => {
    const minutes = Math.max(1, Math.min(120, Number($('lockMinutesSetting').value) || 5));
    const sensitiveAccessSeconds = Math.max(5, Math.min(300, Number($('sensitiveSecondsSetting').value) || 30));
    const secureLoginClearMs = Math.max(250, Math.min(5000, Number($('clearDelaySetting').value) || 1200));
    await setSettings({ lockMinutes: minutes, sensitiveAccessSeconds, secureLoginClearMs });
    settingsState = await getSettings(); toast('Security timing saved.');
  });

  $('addHandlerOffHost')?.addEventListener('click', async () => {
    const hostname = String($('handlerOffHost')?.value || '').trim().toLowerCase();
    if (!hostname) return toast('Enter a website hostname first.', true);
    try {
      await runtimeMessage({ type: 'SET_HANDLER_SITE_EXCEPTION', hostname, disabled: true });
      settingsState = await getSettings();
      toast(`Always-On Handler is off for ${hostname}.`);
      await renderSettings();
    } catch (error) { toast(error.message, true); }
  });
  document.querySelectorAll('.enableHandlerHost').forEach((button) => button.addEventListener('click', async () => {
    const hostname = button.dataset.host || '';
    try {
      await runtimeMessage({ type: 'SET_HANDLER_SITE_EXCEPTION', hostname, disabled: false });
      settingsState = await getSettings();
      toast(`Always-On Handler is on for ${hostname}.`);
      await renderSettings();
    } catch (error) { toast(error.message, true); }
  }));

  $('enableSiteIcons')?.addEventListener('click', async () => {
    try {
      const granted = faviconGranted || await chrome.permissions.request({ permissions: ['favicon'] });
      if (!granted) return toast('Website icon permission was not granted.', true);
      await setSettings({ websiteIconsEnabled: true }); settingsState = await getSettings(); toast('Local visited-site icons enabled.'); await renderSettings();
    } catch (error) { toast(error.message, true); }
  });
  $('disableSiteIcons')?.addEventListener('click', async () => { await setSettings({ websiteIconsEnabled: false }); settingsState = await getSettings(); toast('Vault will use private fallback cards.'); await renderSettings(); });

  $('setupVaultTotp')?.addEventListener('click', () => ensureSensitiveAccess('Re-enter your master password before adding a second factor to VaultCove.', beginVaultTotpSetup).catch((error) => toast(error.message, true)));
  $('disableVaultTotp')?.addEventListener('click', () => ensureSensitiveAccess('Verify your master password and authenticator code before disabling VaultCove authenticator confirmation.', async () => {
    vault.security = vault.security || {};
    vault.security.vaultTotp = { enabled:false, secret:'', recoveryCodeHashes:[], enabledAt:null };
    await saveUnlockedVault(vault); await setSettings({ vaultTotpEnabled:false }); settingsState = await getSettings(); toast('VaultCove authenticator protection disabled.'); await renderSettings();
  }).catch((error) => toast(error.message, true)));

  $('newMaster')?.addEventListener('input', updateMasterStrength);
  $('changeMaster').addEventListener('click', changeMaster);
  $('autoLoginSetting').addEventListener('change', async () => { await setSettings({ autoLoginEnabled:$('autoLoginSetting').checked }); settingsState=await getSettings(); toast($('autoLoginSetting').checked ? 'Automatic login enabled only for opted-in credentials.' : 'Automatic login disabled.'); });
  $('newLoginCaptureSetting').addEventListener('change', async () => { await setSettings({ newLoginCaptureEnabled:$('newLoginCaptureSetting').checked }); settingsState=await getSettings(); toast($('newLoginCaptureSetting').checked ? 'New-login capture enabled.' : 'New-login capture disabled.'); });
  $('passwordChangeSetting').addEventListener('change', async () => { await setSettings({ passwordChangeDetectionEnabled:$('passwordChangeSetting').checked }); settingsState=await getSettings(); toast($('passwordChangeSetting').checked ? 'Password-change detection and inline generator enabled.' : 'Password-change detection disabled.'); });
  $('saveEmailNoticeSettings')?.addEventListener('click', async () => {
    try {
      const enabled = Boolean($('emailNoticeSetting')?.checked);
      const email = String($('securityNoticeEmail')?.value || '').trim();
      if (enabled && !validSecurityEmail(email)) throw new Error('Enter a valid security notice email or turn email notices off.');
      await setSettings({ securityEmailNoticeEnabled:enabled, securityNoticeEmail:email });
      settingsState=await getSettings();
      toast('Security notice setup saved locally.');
    } catch (error) { toast(error.message, true); }
  });
  $('updateCheckSetting')?.addEventListener('change', async () => { await setSettings({ updateChecksEnabled:$('updateCheckSetting').checked }); settingsState=await getSettings(); toast($('updateCheckSetting').checked ? 'Daily developer update checks enabled.' : 'Automatic update checks disabled.'); });
  $('checkUpdatesNow')?.addEventListener('click', async () => { try { const result=await runtimeMessage({type:'CHECK_FOR_UPDATES',force:true}); toast(result.updateAvailable ? `VaultCove ${result.version} is available.` : `VaultCove ${result.currentVersion} is up to date.`); } catch(error){ toast(error.message,true); } });
  $('themeSetting')?.addEventListener('change', async()=>{
    const theme = $('themeSetting').value;
    await setSettings({ theme });
    settingsState = { ...settingsState, theme };
    applyCurrentTheme();
    toast('Theme updated.');
  });
  $('compactUiSetting')?.addEventListener('change', async()=>{
    const compactUi = $('compactUiSetting').checked;
    await setSettings({ compactUi });
    settingsState = { ...settingsState, compactUi };
    applyCurrentDensity();
    toast('Interface density updated.');
  });
  updateMasterStrength();
}

function updateMasterStrength() {
  const input = $('newMaster'); if (!input || !$('masterStrengthLabel') || !$('masterStrengthBar')) return;
  const result = assessPassword(input.value);
  $('masterStrengthLabel').textContent = result.label;
  $('masterStrengthBar').style.width = `${Math.max(0, Math.min(100, result.score * 25))}%`;
  $('masterStrengthBar').dataset.score = String(result.score);
}

async function beginVaultTotpSetup() {
  const secret = generateTotpSecret();
  const recoveryCodes = generateRecoveryCodes(10);
  pendingTotpSetup = { secret, recoveryCodes };
  $('totpSetupSecret').value = secret;
  $('totpSetupUri').value = buildTotpUri(secret, 'Local Vault', 'VaultCove');
  $('totpSetupCode').value = '';
  $('totpRecoveryPanel').classList.add('hidden');
  $('totpRecoveryCodes').textContent = '';
  els.totpSetupDialog.showModal();
  setTimeout(() => $('totpSetupCode').focus(), 0);
}

async function exportVaultNow() {
  const { payload, secret } = await createPortableExport(normalizeVault(vault));
  await downloadExport(payload);
  els.exportSecret.textContent = secret;
  els.secretDialog.showModal();
}

async function exportVault() {
  try {
    if (!featureAllowed(licenseState, 'export')) throw new Error('Export is unavailable.');
    await ensureSensitiveAccess(
      'Re-enter your master password before exporting the complete decrypted vault. The exported file is encrypted, but creating it exposes every vault record to this trusted extension context.',
      exportVaultNow
    );
  } catch (error) { toast(error.message, true); }
}

async function importVaultNow(payloadText, exportSecret) {
  const payload = JSON.parse(payloadText);
  const restored = normalizeVault(await decryptPortableExport(payload, exportSecret));
  if (!confirm(`Replace the current vault with ${restored.items.length} restored items?`)) return;
  vault = restored;
  await saveUnlockedVault(vault);
  render();
  toast('Encrypted backup restored.');
}

async function importVault() {
  try {
    if (!featureAllowed(licenseState, 'import')) throw new Error('A production license is required to restore when licensing enforcement is enabled.');
    const fileInput = $('restoreFile');
    const secretInput = $('restoreSecret');
    const file = fileInput?.files?.[0];
    const exportSecret = String(secretInput?.value || '').trim();
    if (!file) throw new Error('Choose a .vcvault file first.');
    if (!exportSecret) throw new Error('Enter the matching VaultCove export secret.');
    // Read and snapshot both values before the Sensitive Access dialog. This prevents stale/null DOM references after modal focus or a view refresh.
    const payloadText = await file.text();
    await ensureSensitiveAccess(
      'Re-enter your master password before replacing the current encrypted vault with a backup.',
      () => importVaultNow(payloadText, exportSecret)
    );
  } catch (error) { toast(error.message, true); }
}

async function changeMaster() {
  try {
    const current = String($('currentMaster')?.value || '');
    const password = String($('newMaster')?.value || '');
    const confirmPassword = String($('newMasterConfirm')?.value || '');
    const secondFactor = String($('masterTotp')?.value || '');
    const phrase = String($('masterConfirmPhrase')?.value || '').trim();
    const strength = assessPassword(password);
    if (!current) throw new Error('Enter the current master password.');
    if (password.length < 16 || strength.score < 3) throw new Error('Use a new master password of at least 16 characters with Strong or Very strong strength.');
    if (password !== confirmPassword) throw new Error('New master passwords do not match.');
    if (current === password) throw new Error('Choose a new master password that is different from the current one.');
    if (phrase !== 'CHANGE MASTER PASSWORD') throw new Error('Type CHANGE MASTER PASSWORD exactly to confirm this security change.');
    if (settingsState?.vaultTotpEnabled && !secondFactor) throw new Error('Enter the current authenticator or recovery code.');
    if (!confirm('Change the VaultCove master password now? The vault will immediately lock and require the new password.')) return;
    await rotateMasterPasswordVerified(current, password, secondFactor);
    await clearSensitiveAccess();
    for (const id of ['currentMaster','newMaster','newMasterConfirm','masterTotp','masterConfirmPhrase']) if ($(id)) $(id).value = '';
    vault = null;
    showGate('unlockPanel');
    els.unlockTotpLabel.classList.toggle('hidden', !settingsState?.vaultTotpEnabled);
    toast('Master password changed safely. VaultCove is locked; unlock again with the new password.');
  } catch (error) { toast(error.message, true); }
}

function fieldsForType(type, item = {}) {
  const attr = (value) => String(value ?? '').replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;');
  const field = (id, label, typeAttr = 'text', value = '') => `<label>${label}<input id="${id}" type="${typeAttr}" value="${attr(value)}"></label>`;
  const protectedField = (id, label, typeAttr = 'password', value = '', { allowReveal = true } = {}) => `<label class="protectedField">${label}<div class="protectedInput"><input id="${id}" type="${typeAttr}" value="${attr(value)}">${allowReveal && typeAttr === 'password' ? `<button type="button" class="fieldAction" data-reveal-field="${id}">Reveal</button>` : ''}<button type="button" class="fieldAction" data-copy-field="${id}">Copy</button></div></label>`;
  if (type === 'login') return `<div class="fieldGrid">${protectedField('fUsername','Username / email','text',item.username,{allowReveal:false})}${protectedField('fPassword','Password','password',item.password)}</div>${field('fUrl','Website URL','url',(item.urls||[])[0]||'')}<label>Additional trusted hosts (optional)<input id="fTrustedHosts" value="${attr((item.trustedHosts||[]).join(', '))}" placeholder="login.example.com, account.example.com"></label><p class="fieldHint">Only explicitly listed hosts plus the safe www/non-www alias may use this credential. Other subdomains never inherit access automatically.</p><div class="fieldGrid">${protectedField('fTotp','TOTP secret (Base32)','password',item.totpSecret)}<label>Password generator<button id="generatePasswordBtn" type="button" class="outline">Generate 20-character password</button></label></div><label class="check autoLoginCheck"><input id="fReauthFill" type="checkbox" ${item.requireReauthBeforeFill ? 'checked' : ''}> Require master password before filling this credential</label><label class="check autoLoginCheck"><input id="fAutoLogin" type="checkbox" ${item.autoLogin ? 'checked' : ''} ${item.requireReauthBeforeFill ? 'disabled' : ''}> Auto-login when this item is opted in and the current HTTPS site has persistent VaultCove access</label><p class="fieldHint">Protected credentials cannot auto-login. Use this for banking and other high-risk accounts. Imported logins start with Auto-login off.</p>`;
  if (type === 'card') return `<div class="fieldGrid">${field('fCardholder','Cardholder','text',item.cardholder)}${field('fBrand','Brand','text',item.brand)}${protectedField('fNumber','Card number','password',item.number)}${protectedField('fSecurityCode','Security code','password',item.securityCode)}${field('fExpMonth','Expiry month','text',item.expMonth)}${field('fExpYear','Expiry year','text',item.expYear)}</div><label>Billing address<textarea id="fBillingAddress" rows="3">${escapeHtml(item.billingAddress)}</textarea></label>`;
  if (type === 'bank') return `<div class="fieldGrid">${field('fBankName','Bank name','text',item.bankName)}${field('fAccountHolder','Account holder','text',item.accountHolder)}${field('fAccountType','Account type','text',item.accountType)}${protectedField('fAccountNumber','Account number','password',item.accountNumber)}${protectedField('fRouting','Routing number','password',item.routingNumber)}${field('fSwift','SWIFT / BIC','text',item.swiftBic)}${protectedField('fIban','IBAN','password',item.iban)}${field('fBranch','Branch','text',item.branch)}${protectedField('fPin','PIN (optional)','password',item.pin)}</div>`;
  if (type === 'identity') return `<div class="fieldGrid">${field('fFirstName','First name','text',item.firstName)}${field('fMiddleName','Middle name','text',item.middleName)}${field('fLastName','Last name','text',item.lastName)}${field('fCompany','Company','text',item.company)}${protectedField('fEmail','Email','email',item.email,{allowReveal:false})}${protectedField('fPhone','Phone','tel',item.phone,{allowReveal:false})}${field('fAddress1','Address line 1','text',item.address1)}${field('fAddress2','Address line 2','text',item.address2)}${field('fCity','City','text',item.city)}${field('fState','State / Province','text',item.state)}${field('fPostal','Postal code','text',item.postalCode)}${field('fCountry','Country','text',item.country)}${protectedField('fGovernmentId','Government ID (optional)','password',item.governmentId)}</div>`;
  return `<label>Secure text<textarea id="fText" rows="10">${escapeHtml(item.text)}</textarea></label>`;
}

function openItemDialogNow(item = null, type = 'login', prefill = {}) {
  const source = item || createItem(type, prefill);
  els.itemId.value = item?.id || '';
  els.itemType.value = source.type;
  els.itemType.disabled = Boolean(item);
  els.itemName.value = source.name || '';
  if (els.itemFolder) {
    els.itemFolder.innerHTML = folderOptionsMarkup(source.folderId || null);
    els.itemFolder.value = source.folderId || '';
  }
  els.itemNotes.value = source.notes || '';
  els.itemTags.value = (source.tags || []).join(', ');
  els.itemFavorite.checked = Boolean(source.favorite);
  els.dialogTitle.textContent = item ? `Edit ${source.name}` : 'New encrypted item';
  els.deleteItem.classList.toggle('hidden', !item);
  els.dynamicFields.innerHTML = fieldsForType(source.type, source);
  wireDynamicFields(source.type);
  els.itemDialog.showModal();
}

function openItemDialog(item = null, type = 'login', prefill = {}) {
  if (!featureAllowed(licenseState, 'edit')) { toast('A production license is required when licensing enforcement is enabled.', true); return; }
  if (!item) return openItemDialogNow(null, type, prefill);
  return ensureSensitiveAccess('Re-enter your master password before viewing or editing decrypted vault fields.', () => openItemDialogNow(item, type, prefill)).catch((error) => toast(error.message, true));
}

function wireDynamicFields(type) {
  if (type === 'login') $('generatePasswordBtn')?.addEventListener('click', () => {
    $('fPassword').value = generatePassword({ length: 20 });
    $('fPassword').type = 'text';
    setTimeout(() => { if ($('fPassword')) $('fPassword').type = 'password'; }, 10000);
  });

  if (type === 'login') $('fReauthFill')?.addEventListener('change', () => { const auto=$('fAutoLogin'); if (!auto) return; auto.disabled=$('fReauthFill').checked; if (auto.disabled) auto.checked=false; });

  document.querySelectorAll('[data-reveal-field]').forEach((button) => button.addEventListener('click', () => {
    const action = () => {
      const input = $(button.dataset.revealField);
      if (!input) return;
      const showing = input.type === 'text';
      input.type = showing ? 'password' : 'text';
      button.textContent = showing ? 'Reveal' : 'Hide';
      if (!showing) setTimeout(() => { if (input?.isConnected) { input.type = 'password'; button.textContent = 'Reveal'; } }, Math.max(5, Number(settingsState?.revealTimeoutSeconds) || 10) * 1000);
    };
    if (els.itemId.value) ensureSensitiveAccess('Re-enter your master password before revealing this secret.', action).catch((error) => toast(error.message, true)); else action();
  }));

  document.querySelectorAll('[data-copy-field]').forEach((button) => button.addEventListener('click', () => {
    const action = async () => {
      const input = $(button.dataset.copyField);
      if (!input) return;
      await navigator.clipboard.writeText(input.value || '');
      toast('Sensitive value copied. Other local apps may read your clipboard; clear it when finished.');
    };
    if (els.itemId.value) ensureSensitiveAccess('Re-enter your master password before copying this secret.', action).catch((error) => toast(error.message, true)); else action().catch((error) => toast(error.message, true));
  }));
}

function readDialogItem(existing) {
  const type = els.itemType.value;
  const item = existing ? { ...existing } : createItem(type);
  item.name = els.itemName.value.trim() || item.name;
  item.notes = els.itemNotes.value;
  item.tags = els.itemTags.value.split(',').map((v) => v.trim()).filter(Boolean).slice(0, 20);
  item.favorite = els.itemFavorite.checked;
  item.folderId = els.itemFolder?.value || null;
  if (type === 'login') {
    const newPassword = $('fPassword').value;
    if (existing?.password && newPassword !== existing.password) {
      item.passwordHistory = [...(existing.passwordHistory || []), { password: existing.password, changedAt: new Date().toISOString() }].slice(-10);
      item.lastPasswordChangeAt = new Date().toISOString();
    } else if (!existing && newPassword) {
      item.lastPasswordChangeAt = new Date().toISOString();
    }
    item.username = $('fUsername').value; item.password = newPassword; item.urls = [$('fUrl').value.trim()].filter(Boolean); item.trustedHosts = ($('fTrustedHosts')?.value || '').split(',').map((value)=>value.trim()).filter(Boolean).slice(0,20); item.totpSecret = $('fTotp').value.trim(); item.requireReauthBeforeFill = Boolean($('fReauthFill')?.checked); item.autoLogin = item.requireReauthBeforeFill ? false : Boolean($('fAutoLogin')?.checked);
    if (existing?.pendingPasswordChange?.password === newPassword) item.pendingPasswordChange = null;
  }
  if (type === 'card') Object.assign(item, { cardholder: $('fCardholder').value, brand: $('fBrand').value, number: $('fNumber').value, securityCode: $('fSecurityCode').value, expMonth: $('fExpMonth').value, expYear: $('fExpYear').value, billingAddress: $('fBillingAddress').value });
  if (type === 'bank') Object.assign(item, { bankName: $('fBankName').value, accountHolder: $('fAccountHolder').value, accountType: $('fAccountType').value, accountNumber: $('fAccountNumber').value, routingNumber: $('fRouting').value, swiftBic: $('fSwift').value, iban: $('fIban').value, branch: $('fBranch').value, pin: $('fPin').value });
  if (type === 'identity') Object.assign(item, { firstName: $('fFirstName').value, middleName: $('fMiddleName').value, lastName: $('fLastName').value, company: $('fCompany').value, email: $('fEmail').value, phone: $('fPhone').value, address1: $('fAddress1').value, address2: $('fAddress2').value, city: $('fCity').value, state: $('fState').value, postalCode: $('fPostal').value, country: $('fCountry').value, governmentId: $('fGovernmentId').value });
  if (type === 'note') item.text = $('fText').value;
  return item;
}

async function performSaveDialog() {
  const existing = vault.items.find((item) => item.id === els.itemId.value) || null;
  const item = readDialogItem(existing);
  upsertItem(vault, item);
  await saveUnlockedVault(vault);
  els.itemDialog.close();
  render();
  toast('Encrypted item saved.');
}

async function saveDialog(event) {
  event.preventDefault();
  try {
    const existing = vault.items.find((item) => item.id === els.itemId.value) || null;
    if (existing) {
      await ensureSensitiveAccess('Re-enter your master password before saving changes to decrypted sensitive fields.', performSaveDialog);
      return;
    }
    await performSaveDialog();
  } catch (error) { toast(error.message, true); }
}

async function refreshTotpCodes() {
  const logins = visibleItems().filter((item) => item.type === 'login' && item.totpSecret);
  if (!logins.length) return;

  if (!(await hasSensitiveAccess())) {
    document.querySelectorAll('[data-totp-id]').forEach((node) => { node.textContent = '••• ••• - verify master password'; });
    return;
  }

  async function tick() {
    if (!(await hasSensitiveAccess())) {
      clearInterval(totpTimer);
      document.querySelectorAll('[data-totp-id]').forEach((node) => { node.textContent = '••• ••• - Sensitive Access expired'; });
      return;
    }
    for (const item of logins) {
      try {
        const result = await generateTotp(item.totpSecret);
        const direct = document.querySelector(`[data-totp-id="${CSS.escape(item.id)}"]`);
        if (direct) {
          direct.textContent = `${result.code.slice(0, 3)} ${result.code.slice(3)} - ${result.remaining}s`;
          continue;
        }
        const nodes = [...document.querySelectorAll('.vaultItem')];
        const node = nodes.find((candidate) => candidate.querySelector('.name')?.textContent.includes(item.name));
        if (!node) continue;
        let chip = node.querySelector('.totpChip');
        if (!chip) {
          chip = document.createElement('div');
          chip.className = 'chip totpChip';
          node.querySelector('.chips')?.append(chip) || (node.append(Object.assign(document.createElement('div'), { className: 'chips' })), node.querySelector('.chips').append(chip));
        }
        chip.textContent = `TOTP ${result.code} - ${result.remaining}s`;
      } catch {}
    }
  }
  await tick();
  totpTimer = setInterval(tick, 1000);
}

function switchView(view) {
  currentView = view; els.search.value = ''; render(); if (view === 'dashboard') wireSummaryCards();
}

async function lockFromUi() {
  await runtimeMessage({ type: 'LOCK_VAULT' });
  clearDecryptedUi();
  showGate('unlockPanel');
  toast('Vault locked.');
}


function handlerUnlockContext() {
  const params = new URLSearchParams(location.search);
  if (params.get('flow') !== 'handler-unlock') return null;
  const sourceTabId = Number(params.get('sourceTab'));
  const sourceOrigin = String(params.get('sourceOrigin') || '');
  if (!Number.isInteger(sourceTabId) || !sourceOrigin.startsWith('https://')) return null;
  return { sourceTabId, sourceOrigin };
}

async function finishHandlerUnlockIfNeeded() {
  const context = handlerUnlockContext();
  if (!context) return false;
  await runtimeMessage({ type: 'COMPLETE_HANDLER_UNLOCK', sourceTabId: context.sourceTabId, sourceOrigin: context.sourceOrigin });
  return true;
}

function showBootstrapFailure(error) {
  document.documentElement.dataset.vcBootReady = '1';
  const message = String(error?.message || error || 'Unknown startup error');
  if (els.licenseBadge) els.licenseBadge.textContent = 'Startup error';
  document.documentElement.classList.add('vaultLocked');
  document.body.classList.add('lockedState');
  els.app.classList.add('hidden');
  els.gate.classList.remove('hidden');
  els.gate.innerHTML = `<div class="gateCard"><img src="../../assets/brand/vaultcove-mark.svg" alt="VaultCove" class="gateLogo"><h1>VaultCove could not start</h1><p>VaultCove stopped before showing decrypted data. Reload the extension after reviewing the error below.</p><p class="inlineError">${escapeHtml(message)}</p><div class="dialogActions"><button id="retryBootstrap" type="button">Retry startup</button></div></div>`;
  $('retryBootstrap')?.addEventListener('click', () => location.reload());
  console.error('VaultCove startup failed:', error);
}

async function bootstrap() {
  const params = new URLSearchParams(location.search);
  const requestedView = params.get('view');
  if (requestedView && Object.hasOwn(viewNames, requestedView)) currentView = requestedView;

  [licenseState, settingsState] = await Promise.all([
    getLicenseState(),
    getSettings()
  ]);
  applyCurrentAppearance();
  try { await refreshHandlerPermissions(); } catch (error) { handlerPermissionState = []; console.warn('VaultCove handler-permission status was unavailable during startup:', error); }
  if (els.unlockTotpLabel) els.unlockTotpLabel.classList.toggle('hidden', !settingsState?.vaultTotpEnabled);
  if (els.sensitiveTotpLabel) els.sensitiveTotpLabel.classList.toggle('hidden', !settingsState?.vaultTotpEnabled);
  els.licenseBadge.textContent = licenseState.mode === 'testing' ? 'Testing - Full access' : licenseState.status;

  const state = await loadUnlockedVault();
  if (state.state === 'setup') return showGate('setupPanel');
  if (state.state === 'locked') return showGate('unlockPanel');
  vault = state.vault;
  if (settingsState?.firstRunSecurityComplete === false) { showFirstRunSecuritySetup(); return; }
  if (await finishHandlerUnlockIfNeeded()) return;
  showApp();

  if (licenseState.status === 'expired') {
    currentView = 'backup';
    document.querySelectorAll('nav button[data-view]').forEach((button) => { button.classList.toggle('hidden', !['backup', 'settings', 'license'].includes(button.dataset.view)); });
  }

  render();
  if (currentView === 'dashboard') wireSummaryCards();
  if (licenseState.status !== 'expired') applyUrlAction();
}

function applyUrlAction() {
  const params=new URLSearchParams(location.search); if(params.get('action')==='new-login'){const url=params.get('url')||'';let name='New Login';try{name=new URL(url).hostname.replace(/^www\./,'');}catch{}openItemDialog(null,'login',{name,urls:url?[url]:[]});history.replaceState({},'',location.pathname);}
}

document.querySelectorAll('nav button[data-view]').forEach(button=>button.addEventListener('click',()=>switchView(button.dataset.view)));
els.search.addEventListener('input',()=>{if(currentView==='dashboard'&&els.search.value.trim())currentView='all';render();});
els.newItem.addEventListener('click',()=>openItemDialog(null,['login','card','bank','identity','note'].includes(currentView)?currentView:'login'));
els.itemType.addEventListener('change',()=>{els.dynamicFields.innerHTML=fieldsForType(els.itemType.value,{});wireDynamicFields(els.itemType.value);});
els.itemForm.addEventListener('submit',saveDialog);
els.cancelItem.addEventListener('click',()=>els.itemDialog.close());
els.dialogClose.addEventListener('click',()=>els.itemDialog.close());
els.closeVaultSettings?.addEventListener('click',()=>els.vaultSettingsDialog?.close());
els.doneVaultSettings?.addEventListener('click',()=>els.vaultSettingsDialog?.close());
els.deleteItem.addEventListener('click', async () => {
  const id = els.itemId.value;
  if (!id) return;
  try {
    const moved = await moveItemToTrashWithConfirmation(id);
    if (moved) els.itemDialog.close();
  } catch (error) { toast(error.message, true); }
});
els.setupSubmit.addEventListener('click',async()=>{
  try {
    const p=els.setupPassword.value;
    if(p.length<14)throw new Error('Use at least 14 characters for the master password.');
    if(p!==els.setupConfirm.value)throw new Error('Master passwords do not match.');
    vault=await initializeVault(p);
    await setSettings({
      firstRunSecurityComplete:false,
      lockMinutes:5,
      alwaysOnHandlerEnabled:true,
      newLoginCaptureEnabled:true,
      passwordChangeDetectionEnabled:true,
      securityEmailNoticeEnabled:true,
      securityNoticeEmail:''
    });
    settingsState=await getSettings();
    els.setupPassword.value='';
    els.setupConfirm.value='';
    currentView='dashboard';
    firstRunRecoveryCreated=false;
    showFirstRunSecuritySetup();
  }catch(e){toast(e.message,true);}
});

els.firstRunAuthenticator?.addEventListener('click', async () => {
  try {
    beginVaultTotpSetup();
  } catch (error) { toast(error.message, true); }
});

els.firstRunRecovery?.addEventListener('click', async () => {
  try { await createFirstRunRecoveryKit(); } catch (error) { if (!/cancelled/i.test(error.message || '')) toast(error.message, true); }
});

els.firstRunFinish?.addEventListener('click', async () => {
  try {
    const emailEnabled = Boolean(els.firstRunEmailNotice.checked);
    const email = String(els.firstRunSecurityEmail.value || '').trim();
    const lockMinutes = Number(els.firstRunLockMinutes.value) || 5;
    if (emailEnabled && !validSecurityEmail(email)) throw new Error('Enter a valid security notice email or turn email notices off.');
    if (!els.firstRunMasterAck.checked) throw new Error('Confirm that you understand VaultCove cannot recover a forgotten master password.');
    await setSettings({
      firstRunSecurityComplete:true,
      securityEmailNoticeEnabled:emailEnabled,
      securityNoticeEmail:email,
      lockMinutes:Math.max(1,Math.min(120,lockMinutes)),
      alwaysOnHandlerEnabled:true,
      newLoginCaptureEnabled:true,
      passwordChangeDetectionEnabled:true
    });
    settingsState=await getSettings();
    showApp();
    render();
    wireSummaryCards();
    const missing=[];
    if(!vaultTotpProtection().enabled)missing.push('Authenticator');
    if(!(firstRunRecoveryCreated||vault?.recovery?.lastRecoveryKitAt))missing.push('Recovery Kit');
    toast(missing.length ? `Security setup finished. Recommended next: ${missing.join(' and ')}.` : 'Security essentials are configured.');
  } catch(error) {
    els.firstRunSecurityError.textContent=error.message;
    els.firstRunSecurityError.classList.remove('hidden');
    toast(error.message,true);
  }
});

els.unlockSubmit.addEventListener('click',async()=>{
  if (unlockBusy) return;
  const password = els.unlockPassword.value;
  unlockBusy = true;
  els.unlockSubmit.disabled = true;
  els.unlockSubmit.classList.add('busy');
  els.unlockPassword.disabled = true;
  if (els.unlockError) { els.unlockError.textContent = ''; els.unlockError.classList.add('hidden'); }
  try {
    await runtimeMessage({ type: 'UNLOCK_VAULT', masterPassword: password, secondFactor: String(els.unlockTotp?.value || '') });
    const unlockedState = await loadUnlockedVault();
    if (unlockedState.state !== 'unlocked' || !unlockedState.vault) throw new Error('VaultCove unlocked, but the local vault session could not be loaded.');
    vault = unlockedState.vault;
    els.unlockPassword.value = '';
    if (els.unlockTotp) els.unlockTotp.value = '';
    currentView = licenseState?.status === 'expired' ? 'backup' : 'dashboard';
    if (settingsState?.firstRunSecurityComplete === false) { showFirstRunSecuritySetup(); return; }
    if (await finishHandlerUnlockIfNeeded()) return;
    showApp(); render(); if (currentView === 'dashboard') wireSummaryCards(); applyUrlAction();
  } catch (e) {
    els.unlockPassword.value = '';
    if (els.unlockTotp) els.unlockTotp.value = '';
    if (els.unlockError) { els.unlockError.textContent = e.message; els.unlockError.classList.remove('hidden'); }
    toast(e.message, true);
  } finally {
    unlockBusy = false;
    els.unlockSubmit.disabled = false;
    els.unlockSubmit.classList.remove('busy');
    els.unlockPassword.disabled = false;
    if (!vault) setTimeout(() => els.unlockPassword.focus(), 0);
  }
});
els.unlockPassword.addEventListener('input',()=>{if(els.unlockError){els.unlockError.textContent='';els.unlockError.classList.add('hidden');}});
els.unlockPassword.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();els.unlockSubmit.click();}});
els.unlockTotp?.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();els.unlockSubmit.click();}});
els.lockButton.addEventListener('click',lockFromUi);
els.copyExportSecret.addEventListener('click',async()=>{await navigator.clipboard.writeText(els.exportSecret.textContent);toast('Export secret copied. Store it separately from the export file.');});
els.closeSecret.addEventListener('click',()=>els.secretDialog.close());
els.cancelSensitive.addEventListener('click', closeSensitiveDialog);
els.confirmSensitive.addEventListener('click', async () => {
  if (sensitiveVerifyBusy) return;
  const action = pendingSensitiveAction;
  const password = els.sensitivePassword.value;
  if (!action) return closeSensitiveDialog();
  sensitiveVerifyBusy = true;
  els.confirmSensitive.disabled = true;
  els.confirmSensitive.classList.add('busy');
  els.sensitivePassword.disabled = true;
  if (els.sensitiveError) { els.sensitiveError.textContent = ''; els.sensitiveError.classList.add('hidden'); }
  try {
    await runtimeMessage({ type: 'VERIFY_SENSITIVE_ACCESS', masterPassword: password, secondFactor: String(els.sensitiveTotp?.value || '') });
    pendingSensitiveAction = null;
    els.sensitivePassword.value = '';
    if (els.sensitiveTotp) els.sensitiveTotp.value = '';
    if (els.sensitiveDialog.open) els.sensitiveDialog.close();
    await action();
    if (currentView === 'totp') refreshTotpCodes().catch(() => {});
  } catch (error) {
    els.sensitivePassword.value = '';
    if (els.sensitiveTotp) els.sensitiveTotp.value = '';
    if (els.sensitiveError) { els.sensitiveError.textContent = error.message; els.sensitiveError.classList.remove('hidden'); }
    toast(error.message, true);
  } finally {
    sensitiveVerifyBusy = false;
    els.confirmSensitive.disabled = false;
    els.confirmSensitive.classList.remove('busy');
    els.sensitivePassword.disabled = false;
    if (els.sensitiveDialog.open) setTimeout(() => els.sensitivePassword.focus(), 0);
  }
});
els.sensitivePassword.addEventListener('keydown', (event) => {
  if (event.key === 'Enter') {
    event.preventDefault();
    els.confirmSensitive.click();
  }
});
els.sensitiveTotp?.addEventListener('keydown', (event) => { if (event.key === 'Enter') { event.preventDefault(); els.confirmSensitive.click(); } });


els.closeVckeyDialog?.addEventListener('click', () => closeVckeyDialog(new Error('Cancelled.')));
els.cancelVckey?.addEventListener('click', () => closeVckeyDialog(new Error('Cancelled.')));
els.confirmVckey?.addEventListener('click', async () => {
  const pending = pendingVckeyOperation;
  if (!pending) return closeVckeyDialog();
  const password = $('vckeyPassword').value;
  const confirmPassword = $('vckeyPasswordConfirm').value;
  try {
    if (password.length < 12) throw new Error('Use at least 12 characters for the separate .vckey password.');
    if (pending.mode === 'export' && password !== confirmPassword) throw new Error('.vckey passwords do not match.');
    if (pending.mode === 'export') {
      const comparison = await runtimeMessage({ type: 'CHECK_MASTER_PASSWORD_MATCH', candidate: password });
      if (comparison.matches) throw new Error('The .vckey password must be different from your VaultCove master password.');
    }
    const resolve = pending.resolve;
    pendingVckeyOperation = null;
    $('vckeyPassword').value = '';
    $('vckeyPasswordConfirm').value = '';
    if (els.vckeyDialog.open) els.vckeyDialog.close();
    resolve(password);
  } catch (error) {
    $('vckeyError').textContent = error.message;
    $('vckeyError').classList.remove('hidden');
  }
});
els.vckeyPassword?.addEventListener('keydown', (event) => { if (event.key === 'Enter') { event.preventDefault(); els.confirmVckey.click(); } });
els.vckeyPasswordConfirm?.addEventListener('keydown', (event) => { if (event.key === 'Enter') { event.preventDefault(); els.confirmVckey.click(); } });

els.closeRecoveryDialog?.addEventListener('click',()=>{ const pending=closeRecoveryDialog(); pending?.reject?.(new Error('Recovery operation cancelled.')); });
els.cancelRecovery?.addEventListener('click',()=>{ const pending=closeRecoveryDialog(); pending?.reject?.(new Error('Recovery operation cancelled.')); });
els.confirmRecovery?.addEventListener('click', async()=>{
  const pending=pendingRecoveryOperation; if(!pending) return;
  try { const password=$('recoveryPassword').value; const confirmPassword=$('recoveryPasswordConfirm').value; if(password.length<16) throw new Error('Use at least 16 characters for the Recovery Password.'); if(pending.mode==='export' && password!==confirmPassword) throw new Error('Recovery Passwords do not match.'); const done=closeRecoveryDialog(); done.resolve(password); } catch(error){ $('recoveryError').textContent=error.message; $('recoveryError').classList.remove('hidden'); }
});
els.recoveryPassword?.addEventListener('keydown',(event)=>{if(event.key==='Enter'){event.preventDefault();els.confirmRecovery.click();}});
els.recoveryPasswordConfirm?.addEventListener('keydown',(event)=>{if(event.key==='Enter'){event.preventDefault();els.confirmRecovery.click();}});



els.closeLicenseReclaim?.addEventListener('click', () => closeLicenseReclaimDialog(new Error('Cancelled.')));
els.cancelLicenseReclaim?.addEventListener('click', () => closeLicenseReclaimDialog(new Error('Cancelled.')));
els.confirmLicenseReclaim?.addEventListener('click', async () => {
  const pending = pendingLicenseReclaim;
  if (!pending) return closeLicenseReclaimDialog();
  const targetInstallationId = $('licenseReclaimSelect').value;
  if (!targetInstallationId) {
    $('licenseReclaimError').textContent = 'Choose a retained device record or a new device slot.';
    $('licenseReclaimError').classList.remove('hidden');
    return;
  }
  els.confirmLicenseReclaim.disabled = true;
  try {
    const result = await completeRetainedDeviceRecovery({
      reclaimToken: pending.result.reclaimToken,
      targetInstallationId,
      deviceLabel: pending.deviceLabel,
      serialHint: pending.serialHint
    });
    const resolve = pending.resolve;
    pendingLicenseReclaim = null;
    if (els.licenseReclaimDialog.open) els.licenseReclaimDialog.close();
    resolve(result);
  } catch (error) {
    $('licenseReclaimError').textContent = error.message;
    $('licenseReclaimError').classList.remove('hidden');
  } finally {
    els.confirmLicenseReclaim.disabled = false;
  }
});

els.closeLicenseOtp?.addEventListener('click', () => closeLicenseOtpDialog(new Error('Cancelled.')));
els.cancelLicenseOtp?.addEventListener('click', () => closeLicenseOtpDialog(new Error('Cancelled.')));
els.confirmLicenseOtp?.addEventListener('click', async () => {
  const pending = pendingLicenseOtp;
  if (!pending) return closeLicenseOtpDialog();
  const code = $('licenseOtpCode').value.replace(/\D/g, '').slice(0, 6);
  if (code.length !== 6) {
    $('licenseOtpError').textContent = 'Enter the complete 6-digit email verification code.';
    $('licenseOtpError').classList.remove('hidden');
    return;
  }
  els.confirmLicenseOtp.disabled = true;
  try {
    const result = await pending.onVerify(code);
    const resolve = pending.resolve;
    pendingLicenseOtp = null;
    $('licenseOtpCode').value = '';
    if (els.licenseOtpDialog.open) els.licenseOtpDialog.close();
    resolve(result);
  } catch (error) {
    $('licenseOtpError').textContent = error.message;
    $('licenseOtpError').classList.remove('hidden');
  } finally {
    els.confirmLicenseOtp.disabled = false;
  }
});
els.licenseOtpCode?.addEventListener('keydown', (event) => { if (event.key === 'Enter') { event.preventDefault(); els.confirmLicenseOtp.click(); } });

els.closeTotpSetup?.addEventListener('click', () => { pendingTotpSetup = null; if (els.totpSetupDialog.open) els.totpSetupDialog.close(); });
els.copyTotpSecret?.addEventListener('click', async () => { await navigator.clipboard.writeText($('totpSetupSecret').value); toast('Authenticator setup key copied.'); });
els.copyTotpUri?.addEventListener('click', async () => { await navigator.clipboard.writeText($('totpSetupUri').value); toast('Authenticator URI copied. It contains the TOTP setup secret; keep it private.'); });
els.confirmTotpSetup?.addEventListener('click', async () => {
  try {
    if (!pendingTotpSetup) throw new Error('Start authenticator setup again.');
    const code = String($('totpSetupCode').value || '').trim();
    if (!(await verifyTotp(pendingTotpSetup.secret, code))) throw new Error('The authenticator code is incorrect. Check the device time and try again.');
    const recoveryCodeHashes = await hashRecoveryCodes(pendingTotpSetup.recoveryCodes);
    vault.security = vault.security || {};
    vault.security.vaultTotp = { enabled:true, secret:pendingTotpSetup.secret, recoveryCodeHashes, enabledAt:new Date().toISOString() };
    await saveUnlockedVault(vault);
    await setSettings({ vaultTotpEnabled:true });
    settingsState = await getSettings();
    await clearSensitiveAccess();
    $('totpRecoveryCodes').textContent = pendingTotpSetup.recoveryCodes.join('\n');
    $('totpRecoveryPanel').classList.remove('hidden');
    $('confirmTotpSetup').disabled = true;
    $('totpSetupCode').disabled = true;
    updateFirstRunSecurityStatus();
    toast('VaultCove authenticator confirmation enabled. Save the recovery codes now.');
  } catch (error) { toast(error.message, true); }
});
els.copyRecoveryCodes?.addEventListener('click', async () => { if (!pendingTotpSetup?.recoveryCodes) return; await navigator.clipboard.writeText(pendingTotpSetup.recoveryCodes.join('\n')); toast('Recovery codes copied. Store them somewhere safe outside VaultCove.'); });

installTooltips(document);
tooltipObserver = new MutationObserver(() => installTooltips(document));
tooltipObserver.observe(document.body, { childList:true, subtree:true });

document.addEventListener('keydown',(event)=>{if((event.ctrlKey||event.metaKey)&&event.key.toLowerCase()==='k'&&vault){event.preventDefault();els.search.classList.remove('hidden');els.search.focus();}});
document.addEventListener('pointerdown', markVaultActivity, { passive: true }); document.addEventListener('keydown', markVaultActivity);
setInterval(() => enforceUiAutoLock().catch(() => {}), 5000);
setInterval(() => enforceSensitiveUiExpiry().catch(() => {}), 2000);
bootstrap().catch(showBootstrapFailure);
