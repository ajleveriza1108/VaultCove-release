import { bytesToBase64Url, base64UrlToBytes, randomBytes, randomId, utf8ToBytes, bytesToUtf8 } from './encoding.js';
import { createItem } from './model.js';
import { saveBlob } from './file-save.js';

export const SHARE_IDENTITY_MAGIC = 'VAULTCOVE-PUBLIC-IDENTITY';
export const SHARE_PACKAGE_MAGIC = 'VAULTCOVE-SECURE-SHARE';
export const SHARE_VERSION = 2;

async function digestBytes(bytes) {
  return new Uint8Array(await crypto.subtle.digest('SHA-256', bytes));
}

async function fingerprintJwk(jwk) {
  const stable = JSON.stringify({ kty: jwk.kty, crv: jwk.crv, x: jwk.x, y: jwk.y });
  const digest = await digestBytes(utf8ToBytes(stable));
  const hex = [...digest].map((byte) => byte.toString(16).padStart(2, '0').toUpperCase()).join('');
  return hex.match(/.{1,4}/g).slice(0, 8).join(' ');
}

function shareIdFromFingerprint(fingerprint) {
  return `VC-${fingerprint.replace(/\s+/g, '').slice(0, 16).match(/.{1,4}/g).join('-')}`;
}

async function exportPair(pair) {
  return {
    publicJwk: await crypto.subtle.exportKey('jwk', pair.publicKey),
    privateJwk: await crypto.subtle.exportKey('jwk', pair.privateKey)
  };
}

export async function ensureSharingIdentity(vault) {
  if (vault.sharingIdentity?.encryption?.privateJwk && vault.sharingIdentity?.signing?.privateJwk) return vault.sharingIdentity;

  const encryptionPair = await crypto.subtle.generateKey({ name: 'ECDH', namedCurve: 'P-256' }, true, ['deriveBits']);
  const signingPair = await crypto.subtle.generateKey({ name: 'ECDSA', namedCurve: 'P-256' }, true, ['sign', 'verify']);
  const encryption = await exportPair(encryptionPair);
  const signing = await exportPair(signingPair);
  const fingerprint = await fingerprintJwk(encryption.publicJwk);
  const identity = {
    shareId: shareIdFromFingerprint(fingerprint),
    fingerprint,
    createdAt: new Date().toISOString(),
    encryption,
    signing
  };
  vault.sharingIdentity = identity;
  vault.trustedShareContacts = Array.isArray(vault.trustedShareContacts) ? vault.trustedShareContacts : [];
  vault.shareHistory = Array.isArray(vault.shareHistory) ? vault.shareHistory : [];
  return identity;
}

export async function exportPublicSharingIdentity(vault, displayName = 'VaultCove User') {
  const identity = await ensureSharingIdentity(vault);
  return {
    magic: SHARE_IDENTITY_MAGIC,
    version: SHARE_VERSION,
    shareId: identity.shareId,
    fingerprint: identity.fingerprint,
    displayName: String(displayName || 'VaultCove User').slice(0, 80),
    encryptionPublicJwk: identity.encryption.publicJwk,
    signingPublicJwk: identity.signing.publicJwk,
    exportedAt: new Date().toISOString()
  };
}

export async function validatePublicSharingIdentity(value) {
  if (!value || value.magic !== SHARE_IDENTITY_MAGIC || value.version !== SHARE_VERSION) throw new Error('Unsupported VaultCove sharing identity.');
  if (!value.encryptionPublicJwk || !value.signingPublicJwk) throw new Error('Sharing identity is incomplete.');
  const fingerprint = await fingerprintJwk(value.encryptionPublicJwk);
  if (fingerprint !== value.fingerprint || shareIdFromFingerprint(fingerprint) !== value.shareId) throw new Error('Sharing identity fingerprint does not match its public key.');
  await crypto.subtle.importKey('jwk', value.encryptionPublicJwk, { name: 'ECDH', namedCurve: 'P-256' }, true, []);
  await crypto.subtle.importKey('jwk', value.signingPublicJwk, { name: 'ECDSA', namedCurve: 'P-256' }, true, ['verify']);
  return {
    shareId: value.shareId,
    fingerprint,
    displayName: String(value.displayName || value.shareId).slice(0, 80),
    encryptionPublicJwk: value.encryptionPublicJwk,
    signingPublicJwk: value.signingPublicJwk,
    trustedAt: new Date().toISOString()
  };
}

function sharePayloadFromItem(item, include = {}) {
  if (!item || item.type !== 'login' || item.deletedAt) throw new Error('VCShare currently shares login credentials only.');
  const payload = {
    type: 'login',
    name: item.name,
    username: include.username !== false ? item.username : '',
    password: include.password !== false ? item.password : '',
    urls: Array.isArray(item.urls) ? item.urls.slice(0, 10) : [],
    notes: include.notes ? String(item.notes || '') : '',
    totpSecret: include.totp ? String(item.totpSecret || '') : '',
    tags: Array.isArray(item.tags) ? item.tags.slice(0, 20) : [],
    sourceItemId: item.id
  };
  if (!payload.password && !payload.username) throw new Error('The share must include at least the username or password.');
  return payload;
}

async function deriveShareAesKey(privateKey, publicKey, salt) {
  const bits = new Uint8Array(await crypto.subtle.deriveBits({ name: 'ECDH', public: publicKey }, privateKey, 256));
  const material = await crypto.subtle.importKey('raw', bits, 'HKDF', false, ['deriveKey']);
  return crypto.subtle.deriveKey(
    { name: 'HKDF', hash: 'SHA-256', salt, info: utf8ToBytes(`VaultCove:VCShare:v${SHARE_VERSION}`) },
    material,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt']
  );
}

function canonicalHeader(pkg) {
  const header = {
    magic: pkg.magic,
    version: pkg.version,
    senderShareId: pkg.senderShareId,
    recipientShareId: pkg.recipientShareId,
    createdAt: pkg.createdAt,
    expiresAt: pkg.expiresAt,
    ephemeralPublicJwk: pkg.ephemeralPublicJwk,
    hkdfSalt: pkg.hkdfSalt,
    iv: pkg.iv,
    ciphertext: pkg.ciphertext
  };
  if (Number(pkg.version) >= 2) header.itemCount = Number(pkg.itemCount || 0);
  return JSON.stringify(header);
}

export async function createSecureShare(vault, recipient, items, options = {}) {
  const sender = await ensureSharingIdentity(vault);
  const trusted = await validatePublicSharingIdentity(recipient);
  const selected = (Array.isArray(items) ? items : [items]).filter(Boolean);
  if (!selected.length) throw new Error('Select at least one login to share.');
  if (selected.length > 50) throw new Error('A secure share can contain at most 50 login items.');
  const payloadItems = selected.map((item) => sharePayloadFromItem(item, options.include || {}));

  const recipientPublic = await crypto.subtle.importKey('jwk', trusted.encryptionPublicJwk, { name: 'ECDH', namedCurve: 'P-256' }, true, []);
  const ephemeral = await crypto.subtle.generateKey({ name: 'ECDH', namedCurve: 'P-256' }, true, ['deriveBits']);
  const ephemeralPublicJwk = await crypto.subtle.exportKey('jwk', ephemeral.publicKey);
  const salt = randomBytes(16);
  const key = await deriveShareAesKey(ephemeral.privateKey, recipientPublic, salt);
  const iv = randomBytes(12);
  const createdAt = new Date().toISOString();
  const expiresAt = options.expiresAt || null;
  const aad = utf8ToBytes(`${SHARE_PACKAGE_MAGIC}|${SHARE_VERSION}|${sender.shareId}|${trusted.shareId}`);
  const plaintextPayload = {
    kind: 'login-bundle',
    count: payloadItems.length,
    items: payloadItems
  };
  const plaintext = utf8ToBytes(JSON.stringify(plaintextPayload));
  const ciphertext = new Uint8Array(await crypto.subtle.encrypt({ name: 'AES-GCM', iv, additionalData: aad, tagLength: 128 }, key, plaintext));

  const pkg = {
    magic: SHARE_PACKAGE_MAGIC,
    version: SHARE_VERSION,
    senderShareId: sender.shareId,
    senderFingerprint: sender.fingerprint,
    senderSigningPublicJwk: sender.signing.publicJwk,
    recipientShareId: trusted.shareId,
    itemCount: payloadItems.length,
    createdAt,
    expiresAt,
    ephemeralPublicJwk,
    hkdfSalt: bytesToBase64Url(salt),
    iv: bytesToBase64Url(iv),
    ciphertext: bytesToBase64Url(ciphertext)
  };
  const signingKey = await crypto.subtle.importKey('jwk', sender.signing.privateJwk, { name: 'ECDSA', namedCurve: 'P-256' }, false, ['sign']);
  const signature = new Uint8Array(await crypto.subtle.sign({ name: 'ECDSA', hash: 'SHA-256' }, signingKey, utf8ToBytes(canonicalHeader(pkg))));
  pkg.signature = bytesToBase64Url(signature);
  return pkg;
}

function importedItemFromPayload(payload) {
  if (payload.type !== 'login') throw new Error('Unsupported shared item type.');
  return createItem('login', {
    name: String(payload.name || 'Shared Login').slice(0, 160),
    username: String(payload.username || ''),
    password: String(payload.password || ''),
    urls: Array.isArray(payload.urls) ? payload.urls.slice(0, 10) : [],
    notes: String(payload.notes || ''),
    totpSecret: String(payload.totpSecret || ''),
    tags: [...new Set(['Shared', ...(Array.isArray(payload.tags) ? payload.tags : [])])].slice(0, 20),
    autoLogin: false,
    requireReauthBeforeFill: false
  });
}

export async function openSecureShare(vault, pkg) {
  if (!pkg || pkg.magic !== SHARE_PACKAGE_MAGIC || ![1, SHARE_VERSION].includes(pkg.version)) throw new Error('Unsupported or invalid .vcshare package.');
  const identity = await ensureSharingIdentity(vault);
  if (pkg.recipientShareId !== identity.shareId) throw new Error('This secure share was encrypted for a different VaultCove recipient.');
  if (pkg.expiresAt && Date.now() > Date.parse(pkg.expiresAt)) throw new Error('This secure share has expired.');

  const senderSigning = await crypto.subtle.importKey('jwk', pkg.senderSigningPublicJwk, { name: 'ECDSA', namedCurve: 'P-256' }, false, ['verify']);
  const signatureValid = await crypto.subtle.verify({ name: 'ECDSA', hash: 'SHA-256' }, senderSigning, base64UrlToBytes(pkg.signature), utf8ToBytes(canonicalHeader(pkg)));
  if (!signatureValid) throw new Error('Secure-share signature verification failed. The package may have been changed.');

  const recipientPrivate = await crypto.subtle.importKey('jwk', identity.encryption.privateJwk, { name: 'ECDH', namedCurve: 'P-256' }, false, ['deriveBits']);
  const ephemeralPublic = await crypto.subtle.importKey('jwk', pkg.ephemeralPublicJwk, { name: 'ECDH', namedCurve: 'P-256' }, false, []);
  // Version 1 packages used a v1 HKDF info string. Keep that derivation for compatibility.
  let key;
  if (pkg.version === 1) {
    const bits = new Uint8Array(await crypto.subtle.deriveBits({ name: 'ECDH', public: ephemeralPublic }, recipientPrivate, 256));
    const material = await crypto.subtle.importKey('raw', bits, 'HKDF', false, ['deriveKey']);
    key = await crypto.subtle.deriveKey(
      { name: 'HKDF', hash: 'SHA-256', salt: base64UrlToBytes(pkg.hkdfSalt), info: utf8ToBytes('VaultCove:VCShare:v1') },
      material, { name: 'AES-GCM', length: 256 }, false, ['decrypt']
    );
  } else {
    key = await deriveShareAesKey(recipientPrivate, ephemeralPublic, base64UrlToBytes(pkg.hkdfSalt));
  }
  const aad = utf8ToBytes(`${SHARE_PACKAGE_MAGIC}|${pkg.version}|${pkg.senderShareId}|${pkg.recipientShareId}`);
  const plaintext = new Uint8Array(await crypto.subtle.decrypt({ name: 'AES-GCM', iv: base64UrlToBytes(pkg.iv), additionalData: aad, tagLength: 128 }, key, base64UrlToBytes(pkg.ciphertext)));
  const decoded = JSON.parse(bytesToUtf8(plaintext));
  const payloads = pkg.version === 1 ? [decoded] : (decoded.kind === 'login-bundle' && Array.isArray(decoded.items) ? decoded.items : []);
  if (!payloads.length) throw new Error('Secure share contains no supported login items.');

  const trustedContact = (vault.trustedShareContacts || []).find((contact) => contact.shareId === pkg.senderShareId);
  return {
    items: payloads.map(importedItemFromPayload),
    sender: {
      shareId: pkg.senderShareId,
      fingerprint: String(pkg.senderFingerprint || ''),
      trusted: Boolean(trustedContact),
      displayName: trustedContact?.displayName || pkg.senderShareId
    }
  };
}

export function addTrustedShareContact(vault, contact) {
  vault.trustedShareContacts = Array.isArray(vault.trustedShareContacts) ? vault.trustedShareContacts : [];
  const index = vault.trustedShareContacts.findIndex((candidate) => candidate.shareId === contact.shareId);
  if (index >= 0) vault.trustedShareContacts[index] = { ...vault.trustedShareContacts[index], ...contact };
  else vault.trustedShareContacts.push(contact);
  return contact;
}

export function recordShareHistory(vault, entry) {
  vault.shareHistory = Array.isArray(vault.shareHistory) ? vault.shareHistory : [];
  vault.shareHistory.unshift({ id: randomId('share'), occurredAt: new Date().toISOString(), ...entry });
  vault.shareHistory = vault.shareHistory.slice(0, 250);
}

export async function downloadJsonFile(value, filename, mime = 'application/octet-stream') {
  const blob = new Blob([JSON.stringify(value, null, 2)], { type: mime });
  return saveBlob(blob, filename, { description: 'VaultCove encrypted file', mime });
}
