function sanitizeFilename(filename) {
  return String(filename || 'VaultCove-file').replace(/[\\/:*?"<>|]+/g, '-').slice(0, 180) || 'VaultCove-file';
}

function extensionOf(filename) {
  const match = String(filename || '').match(/(\.[a-z0-9]+)$/i);
  return match ? match[1].toLowerCase() : '';
}

function beginVisiblePointerState() {
  document.documentElement.classList.add('vcFilePickerActive');
  document.body?.classList.add('vcFilePickerActive');
  try { if (document.pointerLockElement && document.exitPointerLock) document.exitPointerLock(); } catch {}
  try { window.focus(); } catch {}
}

function endVisiblePointerState() {
  document.documentElement.classList.remove('vcFilePickerActive');
  document.body?.classList.remove('vcFilePickerActive');
  try { window.focus(); } catch {}
  try { document.body?.focus?.({ preventScroll: true }); } catch {}
}

export async function chooseSaveHandle(filename, { description = 'VaultCove file', mime = 'application/octet-stream' } = {}) {
  const safeName = sanitizeFilename(filename);
  if (typeof window.showSaveFilePicker !== 'function') return { handle: null, filename: safeName, method: 'download' };
  beginVisiblePointerState();
  try {
    const extension = extensionOf(safeName);
    const types = extension ? [{ description, accept: { [mime]: [extension] } }] : undefined;
    const handle = await window.showSaveFilePicker({ suggestedName: safeName, types });
    return { handle, filename: safeName, method: 'picker' };
  } catch (error) {
    if (error?.name === 'AbortError') return { handle: null, filename: safeName, method: 'cancelled' };
    // Chrome may deny the picker when transient user activation has already expired.
    // Fall back to a normal download rather than losing the encrypted export.
    return { handle: null, filename: safeName, method: 'download', pickerError: error };
  } finally {
    endVisiblePointerState();
  }
}

export async function writeBlobToSaveTarget(target, blob) {
  if (!target || target.method === 'cancelled') return { saved: false, cancelled: true };
  if (target.handle) {
    beginVisiblePointerState();
    try {
      const writable = await target.handle.createWritable();
      await writable.write(blob);
      await writable.close();
      return { saved: true, method: 'picker' };
    } finally {
      endVisiblePointerState();
    }
  }

  const url = URL.createObjectURL(blob);
  try {
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = sanitizeFilename(target.filename);
    document.body.append(anchor);
    anchor.click();
    anchor.remove();
    return { saved: true, method: 'download' };
  } finally {
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
}

export async function saveBlob(blob, filename, options = {}) {
  const target = await chooseSaveHandle(filename, options);
  return writeBlobToSaveTarget(target, blob);
}
