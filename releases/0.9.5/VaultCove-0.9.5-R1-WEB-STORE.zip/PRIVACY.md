## 0.9.4 License & Devices local monitor cache
VaultCove may keep a short-lived local display snapshot of the last successfully returned **License & Devices** ledger so the page can render immediately and remain informative during a temporary network failure. The snapshot is stored only in extension-local storage and is scoped to the current verified signed-license identity plus the current installation.

The snapshot may include sanitized device metadata already shown by the device ledger, such as device label, platform/app label, status/role, last-seen/created/released timestamps, current-device marker, and physical-device grouping/count metadata. It does **not** include the raw license serial, refresh token, registered email, Master Password, vault key, website credentials, cards, bank data, identities, notes, TOTP secrets, VCShare contents, management OTP/token, or other vault contents. The snapshot is display-only, expires after seven days, and is cleared with local license state or when the verified license identity changes.

## 0.9.3 Guardian privacy boundary

Guardian policies, Security Ledger entries, password-change receipts, breach dates entered by the user, passkey-coach state, Backup Confidence, Recovery Drill state, and quarantine state remain in the encrypted local vault/settings unless a feature explicitly needs the licensing service. Trusted Device Approval sends only signed-lease proof plus approval ID, operation, opaque item ID, a safe host/critical-action label, and same-license installation IDs. It never sends Master Passwords, vault keys, saved passwords/history, TOTP secrets, recovery codes, cards, bank data, Secure Notes, or encrypted vault contents.

## 0.9.1 same-license device display
License & Devices no longer displays a derived License Identity fingerprint. Same-license membership is still determined by the existing server-side license record and device ledger, and device rows may show normalized platform/device labels plus **Same key verified**. Raw license keys are never displayed or transmitted between devices.

## 0.8.6 backend-version diagnostics
Licensing responses may include the VaultCove Apps Script build number so the extension can identify an outdated deployment. This is static software-version metadata and does not add vault, password, or user telemetry.

## 0.8.5 License & Devices responsiveness
Opening License & Devices no longer waits for a remote ledger call before showing locally verified Premium status. The background ledger refresh sends the same licensing proof already required for device management; this release adds no vault records, passwords, usernames, or Master Password data to licensing traffic.

## 0.8.4 released-device history cleanup

Deleting released device history removes only released rows from the licensing `Devices` table after fresh Master Password + registered-email OTP authorization. It does not transmit vault contents, does not delete the license entitlement/key hash, and does not change the seven-device standard Premium policy.

## VaultCove 0.8.0 local Backup Health metadata

VaultCove stores non-secret local backup-health metadata such as whether protected changes are waiting for a new manual backup, the number of pending protected changes, the reminder due date, and the last verified manual-backup time. This metadata stays in Chrome local extension storage and is not sent to the licensing service. Item names, usernames, passwords, URLs, notes, custom-field values, and old password values are not placed in this reminder metadata. Security Skills and duplicate-login analysis run locally inside the unlocked extension.

The configurable clipboard timeout is best-effort. VaultCove does not add broad clipboard-read permission only to implement timed clearing. It clears a VaultCove-copied secret only when the browser allows VaultCove to confirm that the clipboard still contains that exact value; otherwise it leaves the clipboard untouched rather than risking deletion of newer user clipboard data.

# VaultCove Privacy - 0.7.82 R1

## 0.7.82 startup-layout privacy

The compact startup redesign changes only local presentation. No additional data is collected or transmitted. Profile, import, security-email, and Premium activation values keep their existing storage/transport boundaries.

## 0.7.78 card input and TOTP maintenance privacy

Card-network detection and formatting run locally in the VaultCove extension and do not transmit the PAN. TOTP maintenance mode does not upload or delete existing TOTP secrets.

## 0.7.78 licensing, Share history, and backup privacy

A standard Premium key may be used on up to seven devices, with up to three signed Device Admins. Device-management requests send only licensing/device metadata, the signed lease or encrypted license transport proof, challenge/OTP values, and short-lived management tokens. The master password is verified only inside VaultCove and is never sent to Apps Script.

The 30-day Sharing History is part of the encrypted local vault. It can record share time, recipient email, credential display names, item count, and access duration; it never records the shared password itself.

Free Forever `.vcvault` backup exports Login credentials only. Premium complete backup includes owned vault categories, folders, Trash, Favorites, website TOTP data, sharing recipients/history, encrypted security activity history, recovery material, and all VaultCove local settings. This can include the locally stored cropped profile photo because the user requested a complete settings backup. Recipient-bound Use Only shared credentials remain excluded so their access restrictions cannot be turned into portable owned credentials.


## Free Forever, Premium and uninstall data handling

VaultCove no longer uses an expiring trial. Free Forever stores the encrypted vault and local settings in Chrome extension-local storage. Premium licensing stores only licensing/device metadata and encrypted device-bound license credentials.

Removing the extension causes Chrome to remove the extension-local vault data. Encrypted `.vcvault` backup files explicitly exported by the user are separate files and remain on disk until the user deletes them.

0.7.56 removes obsolete local trial timing/anchor metadata during initialization. That legacy metadata is not used to determine access.

## 0.7.24 cropped profile preview

The Settings preview now reloads the already-saved local crop whenever Appearance and personalization is rendered. This is a local rendering repair only; VaultCove does not upload, synchronize, or transmit the original or cropped profile image.

## 0.7.21 local security metadata

The new activity history is stored inside the encrypted local vault. It records bounded security-event metadata such as a backup creation, restore, trash action, migration import, or Secure Login use. It does not record the actual password, master password, TOTP secret, private sharing key, or plaintext credential fields. No activity history is sent to GitHub, Payhip, Apps Script, Google, or another service.

One-use Secure Login capabilities and capture-rate state live only in Chrome extension session storage. They are ephemeral authorization/abuse-control data, not cloud identifiers. Migration limits and Restore Preview operate locally; previewing a backup does not upload it. The license-service endpoint remains unconfigured in this build and Payhip/API secrets are not embedded in the extension.


## Local website thumbnail permission

The Chrome `favicon` permission remains required because website thumbnails are enabled by default and use Chrome's own local favicon cache. VaultCove does not contact an external favicon service. Store website-origin access remains separately optional.

## Backup privacy

Free Forever backup is intentionally Login-credentials-only. Premium complete backup selects all owned VaultCove backup components and carries encrypted local history/recovery metadata plus the complete local settings object inside the authenticated `.vcvault` payload. The backup is never uploaded automatically.

The complete-settings payload may include local profile personalization. It still excludes raw external/private publisher secrets because those are not VaultCove user settings. Recipient-bound Use Only shared credentials remain excluded from portable backup files because their rights belong to the designated recipient context.

VaultCove is designed as an offline-first encrypted vault.

## Data kept locally

Vault records, passwords, usernames, saved URLs, secure notes, cards, bank records, identities, website TOTP secrets, private VCShare keys, pending login/password-change candidates, local security-health results, and visited-site visual metadata remain inside the encrypted local vault.

Website thumbnails are enabled by default and use only Chrome's local favicon cache after VaultCove has handled a matching saved site. VaultCove does not contact a third-party icon service or upload a list of saved or visited domains.


## Security notice email

VaultCove can send security notices through the same Apps Script licensing service used for verification. General protected-record notices remain optional and metadata-only. A **password-changed** notice is automatic for an active Premium installation because the destination is the email already verified and registered to that license; the extension cannot substitute another recipient for that event.

For a password-changed notice, VaultCove sends only the website **hostname** (not the full saved URL/path/query), local event timestamp and time-zone identifier, device label/installation proof, notice ID, and the minimum signed-license/transport metadata needed to authenticate the request. The message never contains the username, account title, old password, new password, password history, Master Password, vault key, TOTP secret, cards, bank data, Secure Note text, other saved sites, or page contents.

The password-change email contains no account-login link. Its security guidance tells a recipient who does not recognize the change to open the provider's official website/app independently.

## Developer update checks

The Developer build can check the official VaultCove release metadata for a newer version. It does not attach vault records, saved websites, usernames, passwords, cards, bank data, notes, TOTP secrets, master passwords, vault keys, or security-health data to that request.

## Licensing and devices

When the user tests Apps Script licensing, VaultCove may transmit only the fields allowed by the licensing protocol: serial during activation, license email, random installation ID, random device-recovery token, user device label, platform/app version, verification codes/challenge IDs, and random refresh/management tokens.

Never sent to licensing: master password, vault key, saved website list, usernames, passwords, website TOTP secrets, cards, bank accounts, secure notes, private VCShare keys, browsing history, MAC address, Windows serial, IMEI, or a hardware fingerprint.

The serial becomes associated with a verified email after the first successful activation if no email is already bound. Device-management actions require a fresh email verification session.

## VaultCove Authenticator

Google Authenticator or another TOTP app is used only to generate a local verification code for VaultCove. VaultCove does not send website passwords to Google Authenticator and does not connect the password vault to the user's Google account.

## Sharing

`.vckey` contains a public sharing identity encrypted with its own file password. `.vcshare` contains recipient-encrypted shared records. A private sharing key never leaves protected VaultCove storage except when the user deliberately creates an encrypted `.vcvault` backup, where it remains inside the encrypted portable payload.

## Testing status

Free Forever is the normal baseline. Premium Lifetime unlocks optional advanced features without changing access to the user's local encrypted vault.


## Explicit export downloads

The Chrome `downloads` permission is used only when the user explicitly exports a VaultCove file such as an encrypted `.vckey`. VaultCove requests `saveAs: true`; it does not use this permission to download website content in the background.

## Local profile photo

An optional profile photo is resized inside the extension and stored only in local VaultCove settings on that device. It is not uploaded, cloud-synced, included in licensing requests, or sent to Payhip/Apps Script. Premium complete `.vcvault` backup can include this local profile setting inside the encrypted backup payload.

## Locked login capture inbox

After VaultCove provisions a capture-inbox keypair, the public key may be used while the vault is locked to encrypt a submitted login/registration into a local hybrid RSA-OAEP + AES-GCM envelope. The private key remains inside the encrypted vault. On unlock, VaultCove drains and reconciles the queue, then removes successfully recovered queue entries.

## Profile crop editor

The selected profile image is processed in the extension page. VaultCove stores only the cropped local data image and does not upload the original or cropped photo.

## HTTP login capture

If new-login capture is enabled, VaultCove may locally capture a submitted username/email and password pair from an HTTP page just as it can from HTTPS. This data is not sent to VaultCove servers. HTTP itself is insecure, so Strict Secure Login never submits a saved VaultCove password over HTTP.


## Optional support links

VaultCove 0.7.29 adds user-initiated links to `https://payhip.com/AJCoderDigitalStore` and `https://paypal.me/ajleveriza`. VaultCove does not automatically contact these services and does not append vault contents, passwords, security scores, saved-site lists, master passwords, or license secrets to those links. The external site receives normal browser/network information only after the user chooses to open the link.


## Support improvement email

The Support page can open a `mailto:` link to `leveriza.aj08@gmail.com` when the user explicitly chooses to send an improvement suggestion. VaultCove pre-fills only a subject line and does not attach vault contents, passwords, license keys, Backup Keys, TOTP secrets, or files.

## Unified encrypted backups

VaultCove 0.7.34 uses `.vcvault` as its single backup/recovery container. New backup-snapshot-v3 files can include private sharing identity, trusted-share recovery metadata, VaultCove authenticator configuration, and device-recovery material inside the encrypted payload. VaultCove does not automatically upload `.vcvault` files or their unique Backup Keys to the publisher. The user controls where the file and its separately provided Backup Key are stored.

### Legacy trial metadata

Older VaultCove versions stored local trial start/expiry metadata. 0.7.56 removes those legacy keys during initialization. They are not sent to the licensing service and are no longer used for access control.



## Owner-admin device ledger

Unlimited owner-admin devices do not add hardware fingerprinting. The licensing ledger continues to use VaultCove's random installation ID, user-selected device label, platform/app version, status, and timestamps. It does not collect MAC addresses, Windows serial numbers, IMEI, Android ID, or browsing history.
## Automatic Disaster Recovery (0.7.96)
Automatic Disaster Recovery is optional and does not upload the vault to VaultCove, Apps Script, Payhip, or GitHub. VaultCove writes an authenticated encrypted `.vcvault` into the browser Downloads folder. The Master Password is never stored in the recovery file. The recovery email is inside authenticated ciphertext and is revealed locally only after the correct backup Master Password opens the encrypted key wrap. When the user restores an automatic Disaster Recovery backup, VaultCove sends only the recovery email, a random backup ID, a random installation ID, and the six-digit OTP/challenge messages needed for verification to the configured Apps Script endpoint. Saved websites, usernames, passwords, cards, bank records, notes, website TOTP secrets, vault keys, and the Master Password are never sent with that request.

For protection against total device loss, the user must keep the generated `VaultCove Disaster Recovery` folder on an off-device or cloud-synced storage location. VaultCove does not silently upload the recovery file to a VaultCove-operated cloud.

## 0.8.1 verification-email privacy

Verification messages display only the six-digit code and minimal request/device context. VaultCove no longer creates Copy code links or sends the OTP through a helper URL. Device Admin promotion uses the email already registered to the same Premium license; no alternate promotion email can be supplied by the requesting device.

## 0.8.3 password-change notice and Device Admin synchronization privacy

Password-change security notices disclose one additional contextual field compared with older generic notices: the affected **website hostname**. This is intentionally limited to the hostname so the registered license owner can identify which account provider needs attention; URL paths, query strings, usernames and passwords remain local. The event's date/time and the browser's time-zone identifier are transmitted so Apps Script can render the time in the user's expected zone.

Device Admin lease synchronization sends the existing signed lease, lease signature and random installation ID. It does not send the Master Password, vault key, raw license serial, refresh token, vault records, website list, username or password. The server uses the already-recorded device role as the authority; synchronization cannot promote a regular device.


## 0.9.3 critical security-notice metadata
For automatic Premium security emails, VaultCove may transmit only the minimum event metadata needed to generate the notice:
- protected-record category (`card`, `bank`, or `identity`) and whether it was updated or removed;
- event timestamp/time zone and authorized device label;
- for VCShare export, only the number of shared logins and a locally masked recipient hint.

VaultCove does not transmit the Card/Bank/Identity contents, login names, usernames, passwords, website names from a VCShare package, Master Password, vault key, or VCShare encrypted payload.

## 0.9.3 same-computer browser-link metadata
When you explicitly create or use a same-computer link code, licensing may process the random installation ID, random physical-device group ID, short-lived challenge/OTP metadata, and a keyed hash of the one-time link code. VaultCove does **not** read or send a MAC address, motherboard/drive serial, Windows machine serial, IMEI, or hidden browser fingerprint for this feature.
