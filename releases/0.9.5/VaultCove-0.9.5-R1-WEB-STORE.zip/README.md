# VaultCove 0.9.5 — Security Engineering Upgrade
VaultCove 0.9.5 strengthens the local security engine and the release process without changing the persisted vault cryptographic profile. Origin Trust Engine 2.0 improves phishing-safe site matching and private-tenant isolation; Password Intelligence 2.0 detects predictable cracker patterns and account/site context locally. The source repository now includes ASVS mapping, CodeQL/OSV/SBOM gates, deterministic fuzzing, Puppeteer extension E2E, and repo-local clean-release skills.

# VaultCove 0.9.4 Guardian
VaultCove 0.9.4 makes **License & Devices** resilient and immediate: the page can render a sanitized, license-scoped local device snapshot first, then reconcile the authoritative Apps Script ledger asynchronously. It adds explicit Live/Cached/Syncing/stale states, manual refresh, 15-second live refresh while the view is open, and refresh-on-online/focus/visibility return. Cached rows are display-only and never enable device-management actions. VaultCove 0.9.3 same-computer physical-device grouping and 1.2-million-iteration password wrapping remain intact.
VaultCove 0.9.0 introduces **VaultCove Guardian**, the Premium protection layer for users who want stricter credential-use policies without making everyday password management difficult. Guardian adds Fortress Mode, Security Zones, exact-domain pinning, Blind Credential Mode, Split-Trust TOTP, Trusted Device Approval, Security Cooldown, Backup Confidence, Recovery Drill, rolling Disaster Recovery generations, Security Ledger, password-change receipts, quarantine/review intelligence, breach-date analysis, account-takeover recovery playbooks, and a Passkey Migration Coach. Core Free Forever security remains strong and is not intentionally weakened to upsell Premium.
VaultCove 0.9.1 refines the Guardian release with faster navigation and clearer cross-platform device recognition. Guardian now paints immediately without waiting for remote approval data, Licensed Devices uses platform/device icons instead of the generic VC badge, the visible License Identity fingerprint has been retired, and the legacy `.vckey` conversion utility no longer breaks the main Share tab layout. The 0.9.0 Guardian security architecture remains intact.

## 0.8.11 Regular Device Admin cross-platform same-key management
VaultCove 0.8.11 explicitly locks the regular Device Admin rule: a Device Admin promoted on a standard Premium key can see and manage the other devices using that same key across supported platforms, while the `manager` role itself remains device-specific. Main/Owner Admin remains different: Owner Admin authority follows the owner/admin license identity across supported platforms. This release also repairs the final Windows publisher verifier so it checks the asynchronous refresh guard in `vault.js`, where the guard actually lives.

## 0.8.9 Publisher self-check repair
VaultCove 0.8.9 keeps the current cross-platform Main Admin and same-key device behavior unchanged. This release repairs only the Windows publisher regression guard so it validates the actual post-install License & Devices verifier instead of matching text inside its own self-check.

## 0.8.8 Publisher verifier repair
VaultCove 0.8.8 keeps the 0.8.7 cross-platform Main Admin and same-key device ledger behavior unchanged, while repairing the Windows publisher's stale final verifier so the current immediate License & Devices render plus asynchronous device refresh is recognized correctly. The server protocol remains compatible with the already-deployed 0.8.7 Code.gs.

## 0.8.7 Cross-platform Main Admin and same-key device ledger
VaultCove 0.8.7 treats Main/Owner Admin as a license-identity authority across supported platforms. A Main Admin established on Android can be detected by Chrome when Chrome uses the same owner/admin key, and the same license ledger can show Android, Chrome, Windows, and future supported platforms together. Raw license keys are never shared between devices; the server correlates devices by the existing license record/hash identity. Device Admin remains device-specific.

## 0.8.6 Released-history backend compatibility
VaultCove 0.8.6 completes the **Delete all released records** path across both sides of licensing. The extension action and Apps Script router now share the same canonical action, the server accepts compatibility aliases, and stale Web App deployments are diagnosed explicitly. Deploy the matching 0.8.6 `Code.gs` as a new version of the existing Web App while keeping the same `/exec` URL.

## 0.8.5 Released-history cleanup transport + responsive device management
VaultCove 0.8.5 fixes the client transport allowlist for **Delete all released records** and makes **License & Devices** open immediately without waiting for the remote device ledger. Device history still refreshes from Apps Script after the page is visible, and the current signed license remains the local source for immediate Premium/Device Admin UI state.

## 0.8.4 Password-change compatibility + direct editing + clean Device Admin ledger

VaultCove 0.8.4 restores broader high-confidence detection for real password-change/reset pages that omit proper field labels, while keeping ordinary login typos out of the automatic overwrite path. The vault dashboard is now null-safe during lock/refresh races, and **Edit in dashboard** opens the exact selected login directly in its editor.

**License & Devices** now treats the server ledger as authoritative before rendering promotion controls: if the current installation is already a Device Admin, **Make this device admin** is hidden immediately. Authorized Device Admins also get **Delete all released records**, which permanently removes released device-history rows only. It never deletes the license and never changes the standard Premium entitlement of up to 7 physical devices. Multiple linked browser profiles on one PC/Mac can share one physical-device slot.

## 0.8.3 Automatic password-change protection + Device Admin state repair

VaultCove 0.8.3 automatically saves a **high-confidence** password change for an owned login, retains the previous password in encrypted history, marks Backup Health/Disaster Recovery pending, shows a short fading **Password updated** toast, and queues a professional security email to the email already registered to the active Premium license. The notice contains only the website hostname, device label, and password-change date/time/time zone—never the username, old/new password, password history, or other vault secrets. Ambiguous ordinary-login submissions still require review and cannot silently overwrite a saved credential.

0.8.3 also repairs an already-promoted Device Admin whose server role changed successfully but whose local client could not persist the returned credential state. VaultCove can synchronize a fresh signed lease from the existing signed entitlement, immediately render **Device Admin**, and remove **Make this device admin** without requiring reactivation or a second OTP.

## 0.8.2 Publisher cleanup fix

VaultCove 0.8.2 preserves the 0.8.1 Device Admin and code-only OTP behavior and fixes clean upgrades by removing the retired root `copy-code.html` helper before security validation.


## 0.8.1 Device Admin email promotion + code-only verification email

- Standard Premium devices now activate as **Regular Devices**.
- From **License & Devices**, a regular device can choose **Make this device admin**. VaultCove requires a fresh Master Password check and sends a new six-digit OTP to the email already registered to that Premium license. Only after the OTP is verified is the current device promoted to **Device Admin**.
- A standard Premium license still supports up to **7 physical devices**, with up to **3 Device Admins**. Device Admin authority is scoped only to that license's device ledger; it never grants access to other customer licenses or vault contents.
- The private main owner-admin entitlement remains separate, unlimited, and identifies its devices as **Owner Admin**.
- Verification emails no longer contain a Copy code icon/link or clipboard helper. They display only the continuous six-digit code as selectable text for manual copy/paste. The old `copy-code.html` helper is removed.

## 0.8.0 Security & Usability release

VaultCove 0.8.0 adds persistent monthly Backup Health, local self-verification of every newly created manual `.vcvault`, multiple URLs and encrypted custom fields for logins, possible-duplicate review, Security Skills, password-history visibility, and a best-effort clipboard timeout. The Dashboard month-end reminder cannot be dismissed while protected changes remain outside a newly verified manual backup. Automatic Disaster Recovery remains separate additional protection.

## 0.7.100 publisher bootstrap repair + selective backup preserved

The 0.7.100 publisher restores the complete PowerShell helper bootstrap that was accidentally missing from 0.7.99. The app behavior remains the approved selective manual `.vcvault` design: **Login credentials are the only required component**; Premium users may independently select Folders, Cards, Bank accounts, Identities, Secure notes, TOTP codes, Trash, Favorites, and All settings & preferences. Automatic Disaster Recovery remains independent.

## 0.7.99 selective encrypted .vcvault backup

Manual encrypted `.vcvault` backup is selective again. **Login credentials are the only required component** and remain permanently checked. Premium users can independently check or uncheck Folders, Cards, Bank accounts, Identities, Secure notes, TOTP codes, Trash, Favorites, and All settings & preferences. Free Forever remains Login-credentials-only. Automatic Disaster Recovery keeps its existing independent scope and is not changed by this manual-backup UI fix.

## 0.7.98 publisher verification repair + visible login nicknames

Login names/nicknames are now visible and directly editable from both Vault and Logins. Imported credentials that have no nickname show **Not set** and expose an **Add nickname** action. Website/login title remains separate from the optional nickname so multiple credentials for one site/IP are easy to distinguish.

## 0.7.96 Automatic Disaster Recovery

VaultCove can optionally maintain an encrypted Disaster Recovery `.vcvault` while the vault is unlocked. It never stores the Master Password. The recovery package reuses the existing encrypted master-password key wrap, encrypts the recovery email inside the package, and requires both the Master Password that protected the backup and a fresh six-digit email verification code before import. Manual `.vcvault` backups keep their separate random Backup Key and remain independently restorable offline. Automatic recovery is saved under the browser Downloads folder; sync or copy the `VaultCove Disaster Recovery` folder off-device if protection against complete device loss is required.

## 0.7.95 email Copy code helper

Verification-email Copy code now uses the static `copy-code.html` helper instead of an Apps Script `/macros` GET page. The OTP is placed only in the URL fragment, removed from the address bar immediately by the page, and copied with the Clipboard API plus a legacy fallback. The email itself remains script-free.

## 0.7.94 publisher + Copy code reliability repair

VaultCove 0.7.94 fixes the false post-install backup regression that expected snapshot v3 even though the current complete backup schema is v4. The branded verification email also refuses to render a decorative-only Copy code icon: the action must resolve to a valid Apps Script Web App HTTPS helper. The helper keeps the OTP server-side behind an opaque short-lived token and copies the continuous six-digit code with the modern Clipboard API plus a legacy fallback.

## 0.7.93 login distinction and backup refresh

Owned login credentials can now have an optional name/nickname such as Personal, Work, Admin, or Router. This is available to Free and Premium users and is preserved by `.vcvault` backup/restore. Premium complete backup includes all current supported vault records, history, recovery material and the complete local settings object. The branded OTP email now links its Copy code icon to a short-lived VaultCove copy helper because email clients do not permit direct clipboard JavaScript.

## 0.7.92 verification email copy/paste polish

The branded verification email now presents OTP codes as an uninterrupted six-digit string (`123456`) with a clipboard-style visual cue. The email remains script-free, tracking-free, and includes the same plain-text fallback. All 0.7.89 guarded HTTP behavior remains intact.

## 0.7.91 publisher permission-contract repair

0.7.91 repairs the release publisher only; it preserves the 0.7.89 guarded HTTP-login behavior and the 0.7.90 premium transactional email template. Persistent website handling remains HTTPS-only. HTTP credentials are supported only through explicit user-invoked activeTab access with a visible insecure-transport warning and exact-origin matching.

## 0.7.90 premium security email

VaultCove licensing/email verification now uses an email-safe responsive HTML template with an inline VaultCove logo, large single-use verification code, request/device details, expiry guidance, privacy reminder, and a plain-text fallback. Security-change notices use the same visual shell and never include vault secrets or remote tracking images.

## 0.7.89 security hardening
VaultCove website handling is HTTPS-only and top-frame-only. Five incorrect Master Password attempts trigger a 60-second persistent cooldown with a live countdown on the unlock screen. See `THREAT-MODEL.md`, `SECURITY-HARDENING.md`, and `CWS-SECURITY-CHECKLIST.md`.

## 0.7.89 purchase and GUI containment

VaultCove links directly to the official Premium Lifetime Payhip product (https://payhip.com/b/0foVO) from startup and License & Devices. No remote Payhip script executes inside the extension. The main GUI receives a scoped readability/navigation fix while the accepted compact startup remains independent.

## 0.7.84 GUI isolation repair

VaultCove 0.7.84 keeps the compact single-window startup while restoring the established main dashboard/sidebar GUI. Startup layout rules are treated as first-run-only and may not globally redefine dashboard cards, Quick Actions, navigation markup, or Premium badges.

## 0.7.82 single-window first-run setup

VaultCove 0.7.82 restructures first-run setup so normal desktop/laptop viewports use one compact window with no independent panel scrolling. Before the encrypted vault exists, the screen shows Profile/Import, Master Password, and Security in three columns. After the vault is created, the Master Password card disappears and Premium License takes the third column. The acknowledgement cards and Finish Setup remain permanently visible at the bottom.

## 0.7.78 startup repair, payment-card entry, input semantics, and TOTP maintenance

VaultCove 0.7.78 repairs the dashboard module contract after first-run vault creation, improves payment-card entry with network detection and local formatting, applies field-aware input semantics, and temporarily places TOTP Codes under maintenance without deleting existing encrypted secrets.

A standard Premium Lifetime serial is one shared license for up to **7 active devices**. Standard devices activate as Regular Devices. Up to **3** active devices can later become **Device Admins** after a fresh registered-email OTP verification; the remaining active devices are regular Premium devices. Device Admins can view and manage the shared Licensed Devices ledger for that license. The private owner-admin entitlement remains unlimited.

Release, Revoke, Restore, and permanent Delete are protected operations. VaultCove requires a fresh local master-password verification and then a fresh email OTP before each action. The resulting server management token is single-use. Released devices immediately vacate a license slot; only a released device record can be permanently deleted. The old Retain action is no longer shown.

Share includes a polished **30-day Sharing History** showing the date/time, recipient email, credential names, and access duration for outbound shares. History stays encrypted inside the local vault and is included in Premium complete backups.

Premium `.vcvault` backup is a complete portable backup of owned VaultCove data: vault categories, folders, Trash, Favorites, website TOTP, Share recipients/history, encrypted activity history, recovery material, and all local settings. Free Forever intentionally remains Login-credentials-only backup. Recipient-bound Use Only credentials stay non-portable so sharing restrictions cannot be converted into owned credentials.

Cards, Bank Accounts, Identities, and Secure Notes retain inline encrypted folder creation, and all successful vault/import/settings/license mutations continue to propagate to open VaultCove surfaces and authorized website handlers without manual refresh.

## 0.7.75 owner-admin device management

Licensed Devices is now sourced from the server device ledger using the current verified signed lease when local wrapped licensing transport credentials are unreadable. Owner-admin installations can manage devices directly without an additional email OTP, and the device list refreshes automatically while open.

## 0.7.74 recipient persistence and live state

Email Share recipients are stored inside the encrypted vault model and verified after every Add/Edit/Remove transaction. Vault, Share, popup, settings, license state, and website-handler matching now refresh from storage changes without requiring manual page reloads.

## 0.7.73 content-handler error recovery

VaultCove now contains Chrome runtime-context failures inside the website handler. If an old content script remains on a tab while the extension is reloaded or updated, failed `chrome.runtime` messaging is converted into a controlled response instead of an unhandled extension error. A versioned handler guard also allows a newly injected build to initialize even when an older build left the legacy `__vaultCoveHandlerLoaded` flag behind.

The release suite additionally rejects any website-handler file that contains copied line-number gutters or other content before the handler IIFE.

## 0.7.72 activated-state and detected-login persistence fixes

License & Devices now uses the verified signed entitlement for the current installation as the activation source of truth. An already-active Premium/admin device shows **Activated** and the activation button stays disabled.

Detected-login candidates also receive a temporary local encrypted fallback. Clicking **Add to VaultCove** must result in a verified persisted login or an explicit error; a missing capture is never presented as success. Encrypted vault changes made by the background worker are reloaded into open VaultCove dashboard/vault pages automatically, so no extension-page refresh is required.

## 0.7.71 License & Devices activation/release behavior

The activation button has a deterministic live state: **Verify and activate this device** -> **Activating...** (spinner) -> disabled **Activated**. Releasing the current device explicitly marks its backend device row as released, clears local license credentials, refreshes Premium navigation/profile state immediately, and restores the enabled activation button. Releasing a license never deletes the encrypted local vault.

# VaultCove 0.7.67 R1

VaultCove is an offline-first encrypted Chrome password manager with **Free Forever** core vault access and optional **Premium Lifetime** advanced features. There is no expiring trial.

## 0.7.70 detected-login Add behavior

When VaultCove detects a submitted website login that is not already saved, the inline prompt remains user-consent based. Clicking **Add to VaultCove** never requires a second master-password verification merely to accept the capture. If the vault is unlocked, the credential is encrypted into the vault immediately. If the vault is locked, the accepted credential remains sealed in the capture inbox and is promoted automatically after the next normal unlock.

## Free Forever

Free Forever keeps the user's local encrypted vault usable without a paid license. It includes:

- unlimited local vault items;
- 12-character strong master-password policy;
- unlock, add, edit, organize, Trash and encrypted local storage;
- Strict Secure Login / core Autofill;
- local TOTP;
- password generation;
- password-manager CSV import with automatic source detection;
- encrypted `.vcvault` backup/restore with a unique Backup Key;
- duplicate-aware restore/import merge;
- basic Security Center with local score, weak/reused password detection, strength bars and affected-credential drill-down;
- local profile, security notice email, auto-lock and Sensitive Access.

Premium being inactive, unavailable, or temporarily unable to refresh never locks the user's own local vault.

## Premium Lifetime

Premium Lifetime is optional, has **no annual subscription**, and uses the existing signed licensing service. A valid existing Standard or owner-admin entitlement is treated as Premium Lifetime.

Premium currently unlocks:

- Advanced Security Center password-age review;
- tamper-evident encrypted security activity history;
- Secure Sharing using `.vckey` and `.vcshare`;
- the protected Shared Keys workflow;
- standard Premium entitlement on up to **7 licensed devices**, with the private owner-admin entitlement supporting unlimited devices.

## Offline-first security boundary

Vault records remain encrypted in Chrome extension-local storage. VaultCove does not upload passwords, usernames, saved websites, TOTP secrets, cards, bank accounts, Secure Notes, Shared Keys content, or browsing history to the licensing service.

Internet access is used only where a feature inherently needs it, such as visiting websites, Premium activation/device management, license refresh, and developer update checks in Developer builds.

## Important uninstall warning

Removing VaultCove from Chrome permanently deletes the vault stored in extension-local storage. Before uninstalling, reinstalling, resetting the browser, or moving to another installation, create an encrypted `.vcvault` backup and keep its matching unique Backup Key separately.

## Lock behavior

Once an encrypted VaultCove vault exists, manual Lock and inactivity auto-lock always show the existing **Master password** unlock gate. The setup wizard is not a legal locked-state destination. Fresh setup is shown only when no encrypted vault exists; if a genuinely unfinished setup needs to resume, it can do so only after the existing master password has first unlocked that vault.

## First-run setup

After the encrypted vault is created, the one-window security setup keeps the following visible and available:

- local profile name and optional cropped photo;
- Restore `.vcvault`;
- Import password-manager backup;
- duplicate-aware merge;
- required valid Security notice email;
- auto-lock;
- optional Authenticator setup;
- forgotten-master-password acknowledgement;
- uninstall/backup acknowledgement;
- **Finish Setup**, kept in a permanent footer so expanded restore/import content cannot hide it.

The master password minimum is 12 characters while retaining all strong-password checks.

## Shared Keys

Received use-only shared credentials are automatically organized in the protected **Shared Keys** system folder. Shared Keys cannot be renamed/deleted or used as a normal owned-item folder.

## Licensing privacy

Premium activation/device management may transmit only the license/email/device-license metadata and random tokens required by the signed licensing protocol. Raw Premium credentials stored on the client are encrypted per device at rest.

Never send your master password, saved credentials, TOTP secrets, Backup Keys, `.vckey` passwords, private sharing identity, or full license key in a support message.

## Owner-admin device policy

The private owner-admin `VCA-...` entitlement is not subject to the standard seven-device ceiling. Each activation still receives its own random installation ID and appears in **License & Devices**. Unknown installations can be Released or Revoked after the existing email-verification management step. The Apps Script backend also provides editor-only owner-device list/release/revoke helpers; they are not public web-app actions.



## Inline new-login save prompt

When VaultCove detects a submitted login that is not already stored for the trusted site/account, it shows an isolated in-page **Save this login to VaultCove?** prompt. The prompt contains no password and remains visible for at least seven seconds before fading automatically when there is no response. Save/Dismiss actions are authorized by a background tab-bound prompt record; a webpage cannot choose an arbitrary pending capture ID. If the vault is locked, a Save request is held only long enough to complete the guarded unlock flow, after which the credential is promoted into the encrypted vault. **Not now** and timeout discard the candidate.

## Official Chrome Web Store identity

VaultCove's permanent Chrome Web Store item ID is `dpbmpmnibbpimedfmanoabihipdfdfko`. Future Store releases must be uploaded as new versions of this same Developer Dashboard item. Do not add a `manifest.id` field. A sideloaded unpacked build is not guaranteed to receive this same ID unless the exact matching Chrome Web Store public key is available and intentionally embedded as the manifest `key`.

## Support

- Email: `leveriza.aj08@gmail.com`
- Store: https://payhip.com/AJCoderDigitalStore
- Support development: https://paypal.me/ajleveriza

## Release model

- Developer build: signed GitHub release metadata may be checked for developer-distributed updates.
- Chrome Web Store build: GitHub update code is removed; Chrome Web Store/Chrome manages updates.
- No remote executable code is used.

See `PRIVACY.md`, `SECURITY.md`, `LICENSE-PLAN.md`, `CHANGELOG.md`, and `TEST-REPORT.md` for the detailed contracts.

## 0.7.59 Free Forever / Premium Lifetime boundary

Free Forever keeps the encrypted local vault, Login credentials, Secure Login, password generator, migration/import, restore, Login-only encrypted `.vcvault` backup, bank accounts, identities, settings, and email-recipient sharing up to five saved recipients.

Premium Lifetime additionally unlocks Cards, Secure Notes, website TOTP Codes, Favorites, the Security Center, full selectable `.vcvault` component backups with encrypted recovery material, encrypted `.vckey` to TXT conversion, and unlimited email recipients. Premium data is never deleted when Premium becomes inactive; it remains encrypted locally until Premium access returns.

Warm Ivory is the default theme for a new or unconfigured installation. Existing saved theme choices are preserved.


## 0.7.70 real-time detected-login commit
When the user approves Add to VaultCove, the background worker commits the login through a serialized fresh-vault transaction and verifies persistence before reporting success. Open website handlers are refreshed from the encrypted-vault storage change event, so the newly saved credential is recognized without reloading the webpage.

## Recent Activity (0.7.89)
The Dashboard Recent Activity panel is backed by VaultCove's encrypted tamper-evident activity chain. It can show privacy-safe events such as Card viewed, Password used for login, Login changed, Password changed, and protected-record changes. Secret field values are never added to activity details.

### Legacy HTTP-only websites
VaultCove preserves explicitly saved/imported `http://` URLs and visibly marks them as not secure. HTTPS remains the default. HTTP passwords are never auto-submitted automatically; use requires the extension popup and an explicit warning confirmation.
