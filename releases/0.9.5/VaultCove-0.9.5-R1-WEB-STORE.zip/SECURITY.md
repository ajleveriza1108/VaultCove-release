## 0.9.5 Security Engineering boundary
VaultCove 0.9.5 strengthens phishing-safe origin decisions and local password analysis without changing the persisted vault cryptographic envelope. Origin Trust Engine 2.0 uses the browser WHATWG URL parser for canonical hostname/IDNA handling, treats reviewed private-hosting suffixes as tenant boundaries, and allows generic apex-to-subdomain inheritance only when the saved host is a recognized non-private registrable apex. Unknown suffix structures therefore fail toward narrower matching rather than broader credential reuse.

Password Intelligence 2.0 is local-only. It evaluates cracker-friendly patterns and account/site context without sending passwords, tokens, hashes, or derived guesses to a service. The extension runtime remains zero-npm-dependency and contains no remotely hosted executable code. Supply-chain controls (CodeQL, OSV, SBOM and Puppeteer) are source/CI gates only.

The Master Password envelope remains the backward-compatible 0.9.4 profile (PBKDF2-HMAC-SHA-256 at 1,200,000 iterations for newly wrapped supported envelopes). Argon2id is reserved for a dedicated migration release with explicit old-vault unlock/re-wrap and rollback testing rather than being mixed into this security-engineering release.

## 0.9.4 Resilient device-ledger security boundary
The License & Devices snapshot introduced in 0.9.4 is a **display cache, not an authority cache**. VaultCove allowlists only non-secret device-ledger presentation fields, binds the snapshot to the current verified license identity and installation, and gives it a seven-day maximum age. Cached rows never render mutation controls.

Every consequential device operation—Release, Revoke, Restore, permanent released-history deletion, Device Admin promotion, and same-computer linking—continues to require a fresh live server path and the existing authentication/authorization controls. A stale or forged local snapshot therefore cannot grant a license slot, Premium entitlement, Device Admin authority, or a device-management capability.

## 0.9.3 VaultCove Guardian security model

Guardian adds layered policy enforcement above the existing encrypted vault: per-login Fortress/Strict/Protected modes, exact-domain pinning, quarantine, Blind Credential Mode, Split-Trust TOTP, trusted same-license device approval, and optional critical-action cooldowns. Trusted Device Approval is short-lived, same-license scoped, requester devices cannot approve their own requests, and approved requests are single-use. Backup Confidence and Recovery Drill validate recoverability locally without restoring data.

## 0.8.11 Same-key verification evidence
VaultCove no longer exposes a separate License Identity fingerprint in the UI. Device-ledger rows can still show Same key verified only when returned from the server's exact same-licenseId ledger. Platform/device labels are display metadata only and do not grant authority; Owner Admin and Device Admin authorization rules remain separate.

## 0.8.6 licensing backend compatibility
Released-device cleanup remains management-token protected and deletes only `released` rows from Devices. Compatibility aliases map to the same server handler and do not broaden request fields or authority. The server build identifier is non-secret version metadata used only to diagnose extension/Web App drift.

## 0.8.5 device-ledger transport and responsiveness
The released-history bulk-delete action is now present in the client request allowlist with the minimum two fields required by the server: the fresh management token and this installation ID. No serial, vault data, Master Password, or OTP is added to the cleanup request. License & Devices no longer blocks its initial render on the network; the server ledger is reconciled asynchronously after the locally verified signed lease is displayed.

## 0.8.4 Device Admin authority reconciliation and cleanup boundary

The backend device ledger is authoritative for whether the current installation is a Regular Device or Device Admin. The UI suppresses promotion controls when the server already reports `manager`, even if the prior local lease was stale. Bulk cleanup is restricted to rows on the same license with `status = released`; active/retained/revoked devices and the `Licenses` row are not deleted. The cleanup requires the same fresh Master Password + registered-email OTP gate used by protected device-management actions.

## 0.8.0 Backup Health and friendly security controls

Every meaningful encrypted-vault write marks the independent manual-backup health state as pending. During the final three calendar days of the month, an overdue Dashboard reminder remains visible until a new manual `.vcvault` is created and the exact encrypted payload passes a local decrypt/parse verification. Disaster Recovery success does not clear this independent manual-backup requirement. View-only security-history events are explicitly excluded from backup-dirty tracking.

Multiple login URLs continue to pass through the existing strict HTTP/HTTPS parser and origin/host matching boundaries. Custom-field values and password-history values remain inside the encrypted vault. Duplicate detection and Security Skills are local analyses and do not transmit credential metadata.

## 0.7.90 transactional-email security

Verification and security-notice email now uses a branded HTML shell with a plain-text fallback. The logo is embedded with `cid:`/`inlineImages`; the template does not fetch remote images or scripts. Verification codes are not placed in the subject line. Messages include only request/device metadata needed to understand the security action and never include Master Passwords, Backup Keys, website credentials, card/bank values, Secure Note contents, or other vault secrets.

## 0.7.89 HTTPS-only + Master-auth throttling
VaultCove no longer injects or requests handler access on HTTP pages. Website handling is HTTPS-only and top-frame-only in an explicit isolated execution world. Master Password verification surfaces share a persistent local throttle: five incorrect Master Password attempts trigger a 60-second cooldown. Only failure counters/timestamps are stored; no password material is persisted by the throttle.

## 0.7.89 external purchase-link boundary
Payhip purchase controls are ordinary user-initiated HTTPS links. VaultCove does not embed or execute `payhip.js`, does not send vault contents to Payhip, and keeps Manifest V3 extension-page scripts self-hosted.

## 0.7.84 GUI isolation note
The release changes presentation scope only. Vault cryptography, license proof, sharing, backup, Sensitive Access, and local-only security boundaries are unchanged.

## 0.7.82 startup viewport/security note

The first-run layout change is presentation-only: it does not weaken the master-password, encrypted-vault, Premium activation, import verification, or acknowledgement gates. The Premium controls are deferred until a real local encrypted vault exists, preventing licensing UI from competing with vault-creation controls in the same desktop viewport.

## 0.7.78 module-contract and sensitive-input security note

The release pipeline now rejects unresolved local named imports before packaging. Payment-card PANs are normalized to digits before encrypted persistence, while UI formatting is display-only. TOTP maintenance mode preserves existing encrypted secrets and intentionally avoids rewriting them while the feature is disabled.

Standard Premium is one seven-device entitlement with at most three active signed Device Admins. Device roles are stored server-side and signed into leases. App-based Release, Revoke, Restore, and Delete require two independent local/remote gates: VaultCove first verifies the master password locally, then Apps Script sends and verifies a fresh email OTP. The resulting management token is single-use for one mutation. Public direct release/admin-action web endpoints are not exposed. The master password never leaves the extension.

Premium complete backup keeps the existing authenticated `.vcvault` encryption but includes all owned vault categories, folders/overlays, Trash, Favorites, TOTP, Share recipient/history metadata, tamper-evident activity history, recovery material, and all local VaultCove settings. Free Forever remains Login-only. Recipient-bound Use Only shared credentials remain excluded by policy.

## 0.7.78 live-state and licensing recovery security note

Inline folder creation never writes folder names outside the encrypted vault envelope. Success is reported only after an encrypted save and reload confirms the folder. Website live refresh carries only a change signal; website handlers re-query redacted matching metadata and never receive bulk vault plaintext. Handler reinjection is attempted only on pages where VaultCove already has host permission or an existing on-demand authorization.

A broken local wrapped licensing transport credential no longer invalidates a still-current signed lease. The client re-verifies the RSA signature locally; Apps Script independently re-verifies the signed lease, installation binding, expiry, current device status, and admin type before owner-admin management. Standard Premium device mutation still requires a fresh email OTP, but that OTP challenge may be started from the verified signed lease when the old local transport credential is unavailable.

## 0.7.75 signed-lease device proof

Read-only device discovery and owner-admin device actions can use the current server-signed lease as proof when local AES-GCM-wrapped transport credentials cannot be decrypted. The Apps Script backend re-computes and constant-time compares the lease signature, checks expiry/product/protocol/installation binding, confirms the installation is still active in the device ledger, and restricts direct management actions to the admin license type.

## 0.7.74 encrypted recipient persistence

Email recipient names/addresses remain inside the AES-256-GCM encrypted vault envelope. Recipient mutations are performed against a fresh decrypted vault and success is reported only after a persisted-state verification reload. Live propagation carries only change signals; it does not broadcast recipient plaintext to website handlers.

## 0.7.73 handler runtime containment

Website content scripts treat an unavailable/reloaded Chrome extension context as a closed communication channel. They stop handler activity and remove VaultCove overlay UI instead of throwing runtime messaging exceptions into the host page or Chrome Extensions error log. Release validation requires a clean executable handler prefix.

# VaultCove Security Model - 0.7.29 R1

## Free Forever / Premium boundary

0.7.56 removes trial expiry as an access-control boundary. Free Forever always retains the user's core encrypted vault capabilities. Premium Lifetime is an additive entitlement for advanced features and up to seven Premium device slots.

If a signed Premium lease is unavailable, expired, invalid or temporarily cannot refresh, VaultCove falls back to Free Forever instead of hiding or locking the user's local vault.

Legacy trial timing/anchor metadata is deleted during initialization and is no longer consulted for access.

## Uninstall boundary

The encrypted vault is stored only in extension-local storage. Chrome removes that storage when the extension is removed. VaultCove therefore displays the uninstall/backup warning during first-run security setup and in relevant backup/license surfaces. Explicitly exported encrypted backup files are outside extension storage and are not automatically deleted.

## 0.7.24 local profile persistence

The cropped profile image remains local-only. VaultCove stores only the generated 256 x 256 data image in extension-local settings, reads the value back after each save, verifies persistence, and refreshes visible avatars only from that local setting. The original uploaded image is not copied into the vault and no profile image is sent to licensing, update, sharing, or analytics services.

## 0.7.22 login compatibility without restoring password Fill

VaultCove still exposes saved passwords only through the one-shot Strict Secure Login path. For compatibility with controlled web frameworks, the isolated injection transaction now synchronizes the username/email and password field state, yields one event-loop turn, then prefers the website's own visible Login/Sign in control before falling back to `requestSubmit()`. The password remains protected by the existing one-use capability, exact tab/top-frame/HTTPS authorization, and aggressive post-submit clearing. Apex-domain credentials may match their own subdomains, but subdomain-scoped credentials do not automatically authorize deeper subdomains and shared-hosting tenants remain isolated.

## 0.7.21 extension/backend boundary hardening

Strict Secure Login uses a one-use random capability that expires after five seconds and is bound to a single saved login, Chrome tab, top-level frame and exact HTTPS origin. The capability is removed from session storage before it is accepted, preventing normal replay even if the same token is presented again. The website content handler requests the capability first and then submits only that capability to the fill operation; it does not send a reusable credential ID to the final password-release operation.

All runtime messages are validated against explicit message schemas. Handler-originated messages include a protocol version and request ID, unknown fields are rejected, and handler-only versus extension-only sources are enforced by the background service worker. This reduces confused-deputy and arbitrary-message attack surface.

Locked/new-login capture is bounded by field sizes and session rate limits (20 per origin and 100 globally per 10-minute window). These limits protect local encrypted storage from a hostile/noisy page without weakening the rule that captured credentials remain encrypted while VaultCove is locked.

Security Center now exposes an encrypted local activity history. Events contain only bounded metadata, never password/TOTP/master-password values. Each event records the previous event hash and its own SHA-256 hash; VaultCove verifies the chain and reports integrity issues. The chain helps detect accidental/tampered local event history but does not replace the encrypted vault's AES-GCM authentication.

Backup restore now has a two-stage flow: decrypt and preview the exact `.vcvault`+secret first, then require fresh Sensitive Access again before applying it. Changing the selected file or secret invalidates the preview. Migration input parsers additionally enforce bounded file/row/column/field/header sizes and reject malformed quoted CSV input.

The vault envelope now identifies the current `VC-PBKDF2-SHA256-AES256GCM` cryptographic profile and component versions. Existing valid envelopes that predate this marker remain readable; explicitly unsupported profiles or PBKDF2 iteration counts below the supported security floor are rejected.


## Store favicon permission contract

Website thumbnails use Chrome's local `_favicon/` endpoint and are enabled by default. The local `favicon` permission is therefore required in both Developer and Store manifests. This permission does not grant arbitrary remote network access; Store HTTPS website access remains separately optional and the Store package removes Developer-only static content-script registration.


## License credential encryption

VaultCove persists neither the raw license key nor the raw refresh token in `chrome.storage.local`. Each installation creates a non-extractable AES-256-GCM Web Crypto key and stores that CryptoKey in extension-origin IndexedDB. Only authenticated ciphertext envelopes are stored in Chrome local storage. Additional authenticated data binds each envelope to its purpose and the random VaultCove installation ID.

A raw Payhip or owner-admin key is decrypted only in extension memory immediately before an HTTPS licensing request. Apps Script stores only an HMAC hash of the key. The server no longer keeps raw Payhip keys in Script Properties, and the 0.7.29 initializer purges legacy `VC_PAYHIP_LICENSE_*` properties. The temporary `VC_OWNER_ADMIN_KEY` provisioning property is deleted in a `finally` block.

Standard Premium has a hard server-enforced maximum of seven active devices, with at most three active Device Admins. The private owner-admin entitlement is unlimited.

## Strict Secure Login boundary

Saved-password Fill is removed from the handler and popup. Strict Secure Login accepts only a verified top-level HTTPS origin, rejects unapproved ports and unrelated subdomains, injects a password only for immediate submission without ordinary password input/change events, and clears it when safe submission fails or shortly after submission. This is exposure reduction, not a guarantee against a malicious destination page, compromised renderer, DevTools under an attacker-controlled browser, or a compromised operating system. Passkeys/WebAuthn are the stronger long-term model because reusable private key material does not need to be placed into the page DOM.

## Encrypted backup security

Free Forever backup is Login-credentials-only. Premium complete backup uses the existing authenticated outer `.vcvault` encryption and includes all owned vault categories plus folders, Favorites, website TOTP, eligible Trash, Share recipient/history metadata, encrypted activity history, recovery identity material, and all local VaultCove settings. Restore Preview and fresh Sensitive Access remain required before applying a backup.

When Trash is included, source sealed Trash items are decrypted only in memory after authorization and re-sealed under the destination vault key during restore. Expired or damaged Trash is never converted into recoverable plaintext. Recipient-bound Use Only shared credentials are excluded so a recipient-specific access grant cannot be converted into an owned portable credential.

## First-run security essentials

A newly created vault enters a one-time Security Essentials gate before normal use. The user configures auto-lock timing and the generic security-notice email preference, is offered Google Authenticator-compatible TOTP and is reminded to create an encrypted `.vcvault` backup, and must acknowledge that the master password is not recoverable by VaultCove. Secure HTTPS handling, reviewed new-login capture, password-change detection, Sensitive Access, and local encryption start with secure defaults. Existing vaults upgraded from earlier releases are marked setup-complete by migration defaults and are not interrupted.

## Backup restore input integrity

Backup restore reads the selected `.vcvault` file and matching Backup Key from the exact visible restore controls before opening Sensitive Access. New Backup Keys are prefixless 256-bit random Base64URL values; legacy `VC1-...` secrets remain supported for compatibility. This prevents a modal/view refresh from invalidating the DOM input reference. The master password authorizes the restore operation; the Backup Key independently decrypts and authenticates the portable backup.

## Browser-owned `.vckey` Save As

Encrypted `.vckey` export no longer uses `showSaveFilePicker()` on Chrome/Windows. VaultCove completes fresh Sensitive Access and the separate `.vckey` file-password protection first, then calls Chromium's `downloads.download(..., saveAs:true)` path. This avoids the observed native File System Access picker defect where hover continued to work while the pointer itself rendered invisibly. Cancelling Save As creates no export. Restore/Open-file dialogs are unchanged.

## Password creation policy

New security passwords are checked live before creation. The displayed checklist and enforcement code require the configured minimum length, lowercase, capital, number, special character, no three repeated characters, no obvious/common word or sequence, and at least eight unique characters. Confirmation must match before the creation button becomes available. New Master and Recovery Passwords require 16+ characters; new `.vckey` and `.vcshare` package passwords require 14+ characters. Existing encrypted files are not retroactively rejected when opened/imported with an older password.

## Encrypted vault

VaultCove generates a random 256-bit vault key. The master password derives a wrapping key with PBKDF2-HMAC-SHA-256. AES-256-GCM protects the encrypted vault payload and detects tampering.

Encrypted vault data includes usernames, passwords, URLs, notes, TOTP secrets, private VCShare keys, pending new-login/password-change candidates, visited-site visual metadata, and unified backup/recovery metadata.

## Sensitive Access and master-password changes

Unlock and secret disclosure are separate. Reveal, Copy, Edit, export, restore, sharing, protected filling, and master-password changes can require fresh master-password verification. Sensitive Access expires after a short configurable window.

Changing the master password requires the current Master Password, a strong and different replacement, matching confirmation, and the VaultCove Authenticator/recovery code when enabled. There is no typed confirmation phrase. VaultCove verifies the new wrapped vault key before committing it and locks immediately after success.

## Website handler and Secure Login

The Developer build runs the HTTPS handler automatically for testing. The Chrome Web Store preflight removes mandatory website access and keeps broad HTTPS access optional.

The page handler receives masked login summaries only. It does not receive stored passwords. The service worker validates the actual HTTPS sender and trusted-site relationship before releasing one selected credential.

Handler account search is performed in the trusted extension background. Search does not expose the complete unmasked username or password to the website.

Clicking a login card or List action creates a short-lived one-time Secure Login selection for that exact credential. VaultCove arms the selection before navigating to the saved HTTPS URL so a fast-loading page cannot race ahead of the selected-item state.

Secure Login does not use the system clipboard. It fills only the chosen credential, submits promptly, and clears the injected page password after a guarded fallback when safe. Once a legitimate destination receives the password, that page can potentially read it; traditional password autofill cannot guarantee otherwise.

## New logins, password changes, and password generation

New-login capture remains an explicit save workflow. Password replacement is narrower: a **high-confidence password-change form** (for example, explicit `new-password` semantics or a matching new/confirm pair associated with a password-change form) may update the single matching owned login immediately. VaultCove retains the previous password in encrypted password history, records only non-secret activity metadata, marks manual Backup Health and Disaster Recovery pending, and returns a short fading **Password updated** status to the page.

An ordinary login form with a different submitted password is deliberately **not** treated as proof that the website accepted a password change. That ambiguous candidate remains encrypted and pending for review so a typo, failed login, hostile form, or unusual site flow cannot silently overwrite a working credential. Use-only VCShare credentials remain immutable and cannot enter password-change capture.

When active Premium licensing is available, a confirmed password update queues a security notice to the email already registered to that license. Only the website **hostname**, device label, event timestamp/time zone, notice ID and signed licensing proof/transport metadata are sent. Username, account title, URL path/query, old/new password, password history, Master Password, vault key and other vault records are never sent. The email deliberately contains no direct login link; suspected unauthorized changes direct the user to open the provider's official website/app independently.

The inline generator uses browser cryptographic randomness and can fill matching New Password and Confirm Password fields.

## VaultCove Authenticator protection

VaultCove can enroll a standard TOTP secret compatible with Google Authenticator and other TOTP apps. The authenticator app does not receive, store, or synchronize website passwords from VaultCove. Recovery codes are generated locally and only their hashes remain in the encrypted vault after setup.

Because verification is local, TOTP is an additional local access-confirmation gate, not a separate cloud-held encryption key.

## VCKey and VCShare

`.vckey` v2 exports only the public sharing identity. It is encrypted with a separate file password using PBKDF2-HMAC-SHA-256 at 1,200,000 iterations for newly created exports and AES-256-GCM. VaultCove requires fresh master verification for reveal/export/import and rejects a `.vckey` password that is the same as the current master password.

VCShare v3 is the dedicated **Use Only shared-login** format. User 1 chooses a trusted recipient and a separate package password, then freshly verifies User 1's Master Password. The inner package is recipient-bound with P-256 ECDH + HKDF-SHA-256, AES-256-GCM, and an ECDSA P-256 sender signature. A second PBKDF2-HMAC-SHA-256 (1,200,000 iterations for newly created packages) + AES-256-GCM password envelope protects the file with the package password.

User 2 must supply that package password and freshly verify User 2's own Master Password before import. Imported credentials are immediately moved into a second local sealed envelope: a fresh per-item AES-256-GCM key protects username/password, and that key is wrapped by User 2's vault key. Normal UI/model fields do not contain the plaintext shared username/password. The recipient can invoke Secure Login but cannot reveal, copy, edit, auto-login-enable, reshare, or capture password changes for the shared credential.

This is enforceable against normal VaultCove use, not against a malicious recipient who fully controls their operating system or modifies VaultCove code/runtime memory. Once a credential is delivered to a website for login, a compromised recipient device or page can potentially capture it. Rotate the website password when true revocation is required.

## Licensing privacy and device recovery

The Apps Script reference backend may receive a serial during activation, verified license email, random installation ID, random device-recovery token, user-provided device label, platform/app version, OTP responses, and random license/session tokens.

The server stores a keyed hash of the device-recovery token rather than the raw token in the Devices sheet. A restored backup-snapshot-v3 `.vcvault` can restore the device-recovery token used to help reclaim the same known device record after a reset. Email OTP is still required; the recovery token alone is not sufficient to activate a license.

Standard Premium allows 7 used device slots, with up to 3 active Device Admins. The private owner-admin entitlement is unlimited. Legacy retained records, if present from older builds, continue to reserve a slot until released/revoked; the current UI no longer creates new retained state. Release and Revoke clear the server-side refresh-token hash. Restore makes the record eligible again, but a cleared device session must reactivate.

VaultCove does not use MAC addresses, Windows serial numbers, IMEI values, or hidden hardware fingerprints for device licensing.

## Update distribution

Developer update metadata is fetched only from the official public VaultCove release source and is digitally verified. The Store build removes the developer GitHub update path. Remote executable JavaScript, remote WASM, `eval`, and `new Function` are not used.

## Out of scope

No browser extension can guarantee secrecy if malware controls the operating system, Chrome process memory, DevTools, screen/accessibility capture, the keyboard, or the user's master password. Endpoint security remains necessary.

## 0.7.8 lock, handler, folder, and `.vckey` conversion boundaries

- Locked/setup UI is a full-viewport gate and is not allowed to inherit sidebar/Compact geometry.
- Browser handlers are session-state views, not authorities. After unlock they re-query the extension background and acknowledge the fresh unlocked state before a handler-initiated unlock tab closes.
- Vault folder names and membership live inside the encrypted vault payload. Deleting a folder only clears its items' `folderId`; it never deletes the items.
- `.vckey` to TXT conversion is intentionally high-friction: Google Authenticator-compatible protection must be enabled, fresh Sensitive Access must succeed, and the separate `.vckey` password must decrypt the file. There is no third TXT-conversion password.
- Converted TXT output is restricted to the public sharing identity. It never contains a master password, `.vckey` password, saved credential, TOTP secret, or private sharing key.

## Sealed Trash
Moving an item to Trash is not a normal plaintext soft delete. VaultCove removes the original credential fields from the active decrypted vault model, encrypts the complete original item with a fresh random 256-bit AES-GCM key, and then encrypts/wraps that item key with the active vault key under separate authenticated additional data. The remaining tombstone contains only minimal display/retention metadata and the authenticated ciphertext envelope.

Trash items are not eligible for Secure Login, handler matching, TOTP display, editing, copying, sharing, password-health analysis, folder organization, or item-detail opening. Restore is the only normal path that unwraps and decrypts the sealed payload back into the active vault. Trash expires after 30 days; expiry is enforced locally on unlock/load/save, and a user may also permanently delete early after Sensitive Access confirmation.

This second envelope is defense-in-depth against accidental disclosure by ordinary unlocked-vault UI/data paths. It does not claim to protect against malicious code that already controls the VaultCove extension process and active vault key.



## Browser-owned `.vckey` Save As

The Chrome build uses the `downloads` permission only for explicit user-requested encrypted exports. `.vckey` is fully encrypted before the browser opens Save As, `saveAs: true` keeps destination choice with the user, and cancelling the dialog does not create the export. This replaces the File System Access save-picker path that exhibited an invisible-pointer rendering defect on some Windows/Chromium systems.


## 0.7.19 locked capture and licensing transport hardening

Submitted login/registration capture while locked uses a hybrid public-key envelope: a fresh AES-256-GCM key encrypts the capture and an RSA-OAEP public key wraps that AES key. The matching private key is stored only inside the encrypted vault. Existing upgraded vaults provision this identity on the first successful unlock after update; new vaults provision it at creation.

The Apps Script Web App URL is no longer user-editable or stored as a runtime setting. A later release build will inject the approved endpoint through `src/core/license-endpoint.js`. The endpoint is not a cryptographic secret and can be discovered from client software or network traffic; security therefore depends on server-side Payhip/API secrets, strict request validation, signed leases, rate limiting, and device/account checks—not on hiding the URL.

## 0.7.20 HTTP capture boundary

VaultCove can observe a submitted username/email + password pair on an HTTP page so a legacy-site registration is not silently lost. When the vault is locked, that pair is immediately sealed into the local locked-capture inbox using the existing public-key/AES-GCM capture envelope. This does **not** make HTTP secure: the website/network may already expose those credentials. VaultCove therefore keeps Strict Secure Login HTTPS-only and will not send a saved password over HTTP.

Profile-photo cropping is also local-only. The browser decodes the user-selected image, allows drag/zoom crop positioning, writes a 256 x 256 WebP crop to local VaultCove settings, and discards the original object URL. No image is uploaded or sent to the licensing service.



## 0.7.24 final pre-licensing boundary
- Runtime packages intentionally contain no production payment secret or private signing key.
- Client/server licensing protocol v3 keeps nonce/timestamp/replay controls and adds device-encrypted persisted license credentials plus server-side raw-key elimination.
- Store packaging must disable Testing Full Access before it can pass preflight.
- The Apps Script URL is not treated as a secret; server-side secrets and authoritative entitlement checks remain the security boundary.


## 0.7.29 local password-health drill-down

Weak/reused credential lists and password-strength bars are computed only from the already-decrypted in-memory vault after unlock. The Security Center renders item name/metadata and local strength/reuse status, never the password itself. Password reveal/copy/edit continues to use the existing Sensitive Access boundary. The new Payhip/PayPal support anchors are explicit user-click navigations and introduce no automatic external request or new extension permission.


## Damaged Trash backup isolation (0.7.29)

A legacy/damaged sealed Trash item that fails AES-GCM authentication is never treated as recoverable plaintext. During an explicitly selected Trash backup it is skipped and counted, while healthy active vault data continues into the authenticated portable backup. The original damaged local Trash record is not modified by the backup operation.

## Unified `.vcvault` recovery

VaultCove 0.7.34 removes the separate recovery-container format. New backup snapshot v3 `.vcvault` files include private sharing identity, trusted-share recovery metadata, VaultCove authenticator configuration, and device-recovery token inside the same outer AES-256-GCM protected portable export as the selected vault backup data. Every new `.vcvault` receives a fresh random 256-bit Backup Key. The exact matching Backup Key is required for preview or restore and should be stored separately from the backup file and master password.

## Historical pre-0.7.56: 0.7.36 trial-start persistence

The seven-day trial start and expiry are local extension state. VaultCove 0.7.36 keeps a second immutable local anchor containing the original trial start/expiry. If the mutable trial record is accidentally lost or reset while the extension storage still exists, VaultCove reconstructs the trial from that original anchor rather than granting a fresh seven days. Reloads and normal extension updates therefore do not restart the trial. The trial anchor is not stored with Chrome Sync and contains no vault credentials.

Because Chrome intentionally deletes extension-local storage when an extension is uninstalled, no purely local mechanism can guarantee anti-reset persistence after a complete uninstall/reinstall. VaultCove does not fingerprint the machine or upload a trial identity merely to bypass that Chrome privacy boundary.

## First-run UX hardening (0.7.36)

Starting fresh requires no mode selection. Restore/import actions are explicit user gestures; .vcvault must authenticate locally with its unique Backup Key, while supported password-manager CSV format detection occurs locally and automatically after file selection.


## Owner-admin device management boundary (0.7.65)

Owner-admin unlimited activation does not remove device accountability. Each device is recorded using a random installation ID. In-app release/revoke actions still require the short-lived email-verified management token. Apps Script editor-only owner-device helpers are deliberately absent from `doPost()` and require direct project-editor authority; temporary target-device Script Properties are deleted after use.


## Inline new-login save prompt

When VaultCove detects a submitted login that is not already stored for the trusted site/account, it shows an isolated in-page **Save this login to VaultCove?** prompt. The prompt contains no password and remains visible for at least seven seconds before fading automatically when there is no response. Save/Dismiss actions are authorized by a background tab-bound prompt record; a webpage cannot choose an arbitrary pending capture ID. If the vault is locked, a Save request is held only long enough to complete the guarded unlock flow, after which the credential is promoted into the encrypted vault. **Not now** and timeout discard the candidate.

## Official Chrome Web Store identity

VaultCove's permanent Chrome Web Store item ID is `dpbmpmnibbpimedfmanoabihipdfdfko`. Future Store releases must be uploaded as new versions of this same Developer Dashboard item. Do not add a `manifest.id` field. A sideloaded unpacked build is not guaranteed to receive this same ID unless the exact matching Chrome Web Store public key is available and intentionally embedded as the manifest `key`.


## 0.7.70 detected-login approval boundary

An explicit **Add to VaultCove** click is sufficient consent to save a newly detected website login; VaultCove does not ask for a second master-password check for that Add action. When the main vault is locked, VaultCove cannot decrypt or rewrite the main vault, so the accepted credential stays inside the asymmetric encrypted capture inbox. Only the opaque capture ID is recorded as accepted. On the next normal unlock, the already-approved capture is promoted into the encrypted vault automatically.


## 0.7.71 license release boundary

License release is an authorization-state operation only. The server marks the installation `released`, clears its refresh-token hash, and explicitly returns `slotVacant: true`. The client then clears only device-local license credentials and Premium entitlement state. The encrypted VaultCove vault, master-password material, and saved records are not deleted or rewritten by license release.


## 0.7.72 detected-login persistence and activation-state boundary

The current-device activation UI is derived from the verified signed lease bound to the installation ID, not from whether decrypted transport credentials happen to be available at render time. Detected-login candidates are protected by both the encrypted vault pending queue and a short-lived RSA/AES sealed fallback. A Save result is reported only after the encrypted vault is reloaded and the new login item is verified present. A missing candidate is an error, never success. Open VaultCove pages reload encrypted-vault changes without exposing secret data through extension messaging.
### Legacy HTTP warning
VaultCove can keep credentials for explicitly saved HTTP-only websites, but these records are marked as not secure. HTTP use requires explicit confirmation and remains vulnerable to network interception or modification because HTTP itself provides no TLS protection.


## Disaster Recovery security boundary (0.7.96)
Automatic Disaster Recovery copies only the existing authenticated Master Password key-wrap metadata needed to reopen the random vault key; it deliberately does not embed the live full-vault ciphertext in the outer recovery envelope. The selected backup snapshot and recovery email are encrypted under that vault key with a Disaster-Recovery-specific AES-GCM AAD. Restore first verifies the historical backup Master Password locally, then requires a fresh single-use email OTP. The Apps Script endpoint receives no Master Password, vault key, or decrypted backup contents. Manual `.vcvault` exports remain a separate offline-capable path protected by their own random Backup Key.


## 0.8.3 Device Admin synchronization boundary

Device Admin promotion is a server authorization change followed by a signed local entitlement update. If the server has already promoted the current device but an older client cannot reopen its encrypted raw serial at the exact commit step, VaultCove must not force a second promotion or silently downgrade the UI. The rotated refresh credential and fresh signed lease can be committed while preserving the existing encrypted serial wrapper.

For recovery from an already-split state, the current device may present its still-valid signed lease to a read-only synchronization endpoint. Apps Script verifies the lease signature, product, installation ID, status, expiry, current license record and current server-side device record, then returns only a newly signed lease reflecting the existing server role. This endpoint cannot create Device Admin authority. **License & Devices** compares the server device record with the local lease and automatically synchronizes when the server already records the current installation as `manager` or `owner-admin`.

## 0.8.1 Device Admin promotion boundary

A regular Premium device cannot silently become an administrator. Promotion is a server-authorized transition on the current license only: the client presents its verified signed lease, VaultCove sends a fresh single-use OTP to the license's already-bound email, and the backend promotes only the requesting active installation after OTP verification. The server rotates that installation's refresh token and returns a newly signed lease carrying the `manager` management role. The main owner-admin entitlement remains a distinct unlimited license type.

Verification emails are now code-only: no clipboard link, no external copy helper, and no OTP-bearing URL is generated.


## 0.9.3 critical activity email boundary
Password changes, Card/Bank/Identity updates or removals, and VCShare password exports use the authenticated license transport only to deliver a metadata-only security notice to the already registered Premium license email. The background queue is retryable and deduplicated by a random notice ID. Protected secrets never enter the Apps Script request.

The VCShare notice sends only a count and a locally masked recipient hint. It never sends the shared item names, websites, usernames, passwords, or `.vcshare` payload.

## 0.9.3 same-computer device grouping and KDF hardening
- License capacity is counted by random server-side **physical-device group IDs**, not by hidden hardware fingerprints. Every browser profile still keeps its own random installation ID for audit, release and revoke.
- A sibling browser joins an existing physical-device group only with a one-time `VCPC-XXXX-XXXX-XXXX` code created from an already licensed browser. Creating that code requires fresh Master Password access locally plus a fresh registered-email OTP. The server stores only a keyed hash of the short-lived code and marks it used after successful activation.
- Existing device rows without a physical-device group ID are treated as separate legacy slots until explicitly linked, preventing silent license-account merges.
- New Master Password key wraps use PBKDF2-HMAC-SHA-256 at **1,200,000 iterations**. VaultCove still accepts valid historical 600,000-iteration envelopes, then re-wraps the existing random vault key at the current work factor after a successful Master Password unlock. The vault ciphertext remains AES-256-GCM.
- New `.vckey` and VCShare password envelopes also use 1,200,000 iterations; supported historical files remain readable under their authenticated stored KDF parameters.
