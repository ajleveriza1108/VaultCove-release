import { getLicenseState, featureAllowed, licenseBadgeText } from '../core/license.js';
import { getSettings } from '../core/storage.js';
import { applyTheme } from '../core/themes.js';
import { passwordPolicy } from '../core/password.js';
import { SETTINGS_STORAGE_KEY, VAULT_STORAGE_KEY } from '../core/constants.js';

const $ = (id) => document.getElementById(id);
const elements = Object.fromEntries([...document.querySelectorAll('[id]')].map((el) => [el.id, el]));
let activeTab = null;
let licenseState = null;
let pageState = null;
let pendingSensitiveAction = null;
let unlockBusy = false;
let sensitiveVerifyBusy = false;
let settingsState = null;
let popupSearchTimer = null;
let popupSearchSerial = 0;

let clipboardWriteSequence = 0;

async function copyPopupClipboard(value, label = 'Sensitive value') {
  const text = String(value ?? '');
  await navigator.clipboard.writeText(text);
  const sequence = ++clipboardWriteSequence;
  const seconds = Math.max(0, Math.min(300, Number(settingsState?.clipboardClearSeconds ?? 30)));
  if (seconds > 0) {
    setTimeout(async () => {
      if (sequence !== clipboardWriteSequence) return;
      try {
        const current = await navigator.clipboard.readText();
        if (current === text) await navigator.clipboard.writeText('');
      } catch {}
    }, seconds * 1000);
  }
  message(`${label} copied.${seconds > 0 ? ` Timed clearing is set to ${seconds} seconds.` : ''}`);
}


const PASSWORD_RULE_LABELS = Object.freeze({
  length: '12+ characters',
  lower: 'Lowercase letter',
  upper: 'Capital letter',
  number: 'Number',
  special: 'Special character',
  repeat: 'No 3 repeated characters',
  common: 'No common word or sequence',
  variety: 'At least 8 unique characters'
});

function renderSetupPasswordGuide() {
  if (!elements.setupPasswordGuide) return false;
  const policy = passwordPolicy(elements.setupPassword.value, 12);
  const matches = Boolean(elements.setupPassword.value) && elements.setupPassword.value === elements.setupConfirm.value;
  elements.setupPasswordGuide.replaceChildren();
  const head = document.createElement('div'); head.className = 'passwordGuideHead';
  const label = document.createElement('strong'); label.textContent = 'Password requirements';
  const count = document.createElement('span'); count.textContent = `${policy.passed}/${policy.total} secure checks`;
  head.append(label, count); elements.setupPasswordGuide.append(head);
  const meter = document.createElement('div'); meter.className = 'passwordGuideMeter';
  const meterFill = document.createElement('span'); meterFill.style.width = `${Math.round((policy.passed / policy.total) * 100)}%`; meter.append(meterFill); elements.setupPasswordGuide.append(meter);
  const grid = document.createElement('div'); grid.className = 'passwordRuleGrid';
  for (const [key, text] of Object.entries(PASSWORD_RULE_LABELS)) {
    const row = document.createElement('span'); row.className = `passwordRule ${policy.rules[key] ? 'pass' : ''}`; row.textContent = text; grid.append(row);
  }
  const match = document.createElement('span'); match.className = `passwordRule matchRule ${matches ? 'pass' : ''}`; match.textContent = 'Passwords must match'; grid.append(match);
  elements.setupPasswordGuide.append(grid);
  const valid = policy.complete && matches;
  elements.createVault.disabled = !valid;
  return valid;
}

function wirePasswordToggle(button, input) {
  if (!button || !input) return;
  button.addEventListener('click', () => {
    const reveal = input.type === 'password';
    input.type = reveal ? 'text' : 'password';
    button.textContent = reveal ? 'Hide' : 'Show';
    button.setAttribute('aria-label', `${reveal ? 'Hide' : 'Show'} master password`);
    input.focus();
  });
}

function show(id) {
  for (const target of ['setupView', 'lockedView', 'unlockedView']) elements[target].classList.toggle('hidden', target !== id);
}

function message(text, error = false) {
  elements.message.textContent = text;
  elements.message.style.color = error ? '#ff879d' : '#f4c969';
}

async function runtimeMessage(payload) {
  const response = await chrome.runtime.sendMessage(payload);
  if (!response?.ok) throw new Error(response?.error || 'VaultCove request failed.');
  return response;
}

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab || null;
}

function pageFromUrl(value) {
  try {
    const url = new URL(value);
    return ['http:','https:'].includes(url.protocol) ? url : null;
  } catch { return null; }
}

function hostFromUrl(value) { return pageFromUrl(value)?.hostname.toLowerCase() || ''; }

async function getPageState(query = '') {
  if (!activeTab?.id) return { enabled: false, matches: [], supported: false };
  return runtimeMessage({
    type: 'GET_ACTIVE_TAB_LOGINS',
    tabId: activeTab.id,
    query: String(query || '').trim().slice(0, 160)
  });
}


async function attachOnDemandHandler() {
  if (pageState?.handlerEnabled || pageState?.siteDisabled) return false;
  if (!activeTab?.id || !pageFromUrl(activeTab.url)) return false;
  try {
    const result = await runtimeMessage({ type: 'ENABLE_ONDEMAND_HANDLER', tabId: activeTab.id });
    return Boolean(result.enabled);
  } catch {
    return false;
  }
}

async function ensureSensitiveAccess(reason, action) {
  const status = await runtimeMessage({ type: 'SENSITIVE_ACCESS_STATUS' });
  if (status.active) return action();
  pendingSensitiveAction = action;
  elements.sensitiveReason.textContent = reason;
  elements.sensitivePassword.value = '';
  elements.sensitiveTotp.value = '';
  elements.sensitiveTotp.classList.toggle('hidden', !settingsState?.vaultTotpEnabled);
  if (elements.sensitiveInlineError) { elements.sensitiveInlineError.textContent = ''; elements.sensitiveInlineError.classList.add('hidden'); }
  elements.sensitivePrompt.classList.remove('hidden');
  elements.sensitivePassword.focus();
}

function closeSensitivePrompt() {
  elements.sensitivePrompt.classList.add('hidden');
  elements.sensitivePassword.value = '';
  elements.sensitiveTotp.value = '';
  if (elements.sensitiveInlineError) { elements.sensitiveInlineError.textContent = ''; elements.sensitiveInlineError.classList.add('hidden'); }
  pendingSensitiveAction = null;
}

async function getSensitiveField(itemId, field) {
  const result = await runtimeMessage({ type: 'GET_SENSITIVE_LOGIN_FIELD', tabId: activeTab.id, itemId, field });
  return result.value || '';
}

async function copySensitiveField(itemId, field) {
  await ensureSensitiveAccess(`Re-enter your master password to copy the saved ${field}.`, async () => {
    const value = await getSensitiveField(itemId, field);
    await copyPopupClipboard(value, field === 'username' ? 'Username' : 'Password');
  });
}

async function revealCredential(item, mount) {
  await ensureSensitiveAccess('Re-enter your master password to reveal this username and password for 10 seconds.', async () => {
    const [username, password] = await Promise.all([
      getSensitiveField(item.id, 'username'),
      getSensitiveField(item.id, 'password')
    ]);
    mount.textContent = '';
    const userLine = document.createElement('div');
    const passLine = document.createElement('div');
    const ub = document.createElement('b'); ub.textContent = 'Username: ';
    const pb = document.createElement('b'); pb.textContent = 'Password: ';
    userLine.append(ub, document.createTextNode(username || '(empty)'));
    passLine.append(pb, document.createTextNode(password || '(empty)'));
    mount.append(userLine, passLine);
    mount.classList.remove('hidden');
    setTimeout(() => { mount.textContent = ''; mount.classList.add('hidden'); }, 10000);
  });
}

async function runSecureLogin(item) {
  const perform = async () => {
    if (!featureAllowed(licenseState, 'autofill')) throw new Error('Secure Login is unavailable in this build.');
    const page = pageFromUrl(activeTab?.url || '');
    if (!activeTab?.id || !page) throw new Error('Open an HTTP or HTTPS login page first.');
    const insecureHttp = page.protocol === 'http:';
    if (insecureHttp) {
      const confirmed = window.confirm('This website uses HTTP, not HTTPS. Your username/password can be intercepted or changed in transit. Use this saved login on the unencrypted site anyway?');
      if (!confirmed) return;
    }
    const result = await runtimeMessage({ type: 'FILL_ACTIVE_TAB_LOGIN', tabId: activeTab.id, itemId: item.id, submit: true, allowInsecureHttp:insecureHttp });
    message(insecureHttp ? (result.submitted ? 'HTTP login submitted after your warning confirmation.' : 'HTTP login could not submit.') : (result.submitted ? 'Strict Secure Login submitted.' : 'Strict Secure Login could not submit safely.'));
  };
  try {
    if (item.requireReauthBeforeFill) {
      await ensureSensitiveAccess('This credential requires your master password before Strict Secure Login.', perform);
    } else {
      await perform();
    }
  } catch (error) { message(error.message, true); }
}

function renderMatches() {
  const page = pageFromUrl(activeTab?.url || '');
  const host = page?.hostname.toLowerCase() || '';
  const insecureHttp = page?.protocol === 'http:';
  const matches = pageState?.matches || [];

  elements.siteInfo.replaceChildren();
  const siteWrap = document.createElement('div'); siteWrap.className = 'siteStatus';
  const siteStrong = document.createElement('strong'); siteStrong.textContent = host || 'No web site';
  if (insecureHttp) siteStrong.classList.add('httpSite');
  const siteState = document.createElement('span');
  const totalMatches = Number(pageState?.matchCount ?? matches.length);
  const filteredMatches = Number(pageState?.filteredMatchCount ?? matches.length);
  const searching = Boolean(elements.search?.value?.trim());
  siteState.textContent = host
    ? insecureHttp
      ? `${searching ? `${filteredMatches} of ${totalMatches}` : totalMatches} exact HTTP account${(searching ? filteredMatches : totalMatches) === 1 ? '' : 's'} - connection not secure`
      : `${searching ? `${filteredMatches} of ${totalMatches}` : totalMatches} matching account${(searching ? filteredMatches : totalMatches) === 1 ? '' : 's'} - trusted site check`
    : 'Open an HTTP or HTTPS page';
  siteWrap.append(siteStrong, siteState); elements.siteInfo.append(siteWrap);

  elements.matches.replaceChildren();
  if (!matches.length) {
    const empty = document.createElement('div');
    empty.className = 'empty';
    empty.textContent = host ? (insecureHttp ? 'No login is explicitly saved for this exact HTTP origin. Add one manually if this legacy site is intentional.' : 'No trusted login matches this website. VaultCove will not offer credentials from unrelated sites.') : 'No login available.';
    elements.matches.append(empty);
    return;
  }

  for (const item of matches.slice(0, 30)) {
    const card = document.createElement('div'); card.className = 'item';
    const top = document.createElement('div'); top.className = 'top';
    const info = document.createElement('div');
    const name = document.createElement('div'); name.className = 'name'; name.textContent = item.nickname || item.name;
    const meta = document.createElement('div'); meta.className = 'meta'; meta.textContent = item.nickname && item.name ? `${item.name} - ${item.usernameMasked || '(no username)'}` : (item.usernameMasked || '(no username)');
    info.append(name, meta); top.append(info);
    const badges = document.createElement('div');
    if (item.pendingPasswordChange) { const badge = document.createElement('span'); badge.className = 'pendingBadge'; badge.textContent = 'CHANGE'; badges.append(badge); }
    if (item.requireReauthBeforeFill) { const badge = document.createElement('span'); badge.className = 'protectedBadge'; badge.textContent = 'MASTER CHECK'; badges.append(badge); }
    if (insecureHttp || item.insecureHttp) { const badge = document.createElement('span'); badge.className = 'httpWarningBadge'; badge.textContent = 'NOT SECURE - HTTP'; badges.append(badge); }
    if (badges.childElementCount) top.append(badges);

    if (insecureHttp) { const warning = document.createElement('div'); warning.className = 'httpWarningText'; warning.textContent = 'This page is not encrypted with HTTPS. VaultCove will only use an explicitly saved HTTP login after your confirmation.'; card.append(top, warning); }
    const actions = document.createElement('div'); actions.className = 'actions';
    const login = document.createElement('button'); login.type = 'button'; login.className = insecureHttp ? 'primaryAction httpUseButton' : 'primaryAction'; login.textContent = insecureHttp ? 'Use on HTTP anyway' : 'Secure Login'; login.addEventListener('click', () => runSecureLogin(item));
    const more = document.createElement('button'); more.type = 'button'; more.className = 'moreButton'; more.textContent = '⋮'; more.setAttribute('aria-label', 'More credential actions');
    actions.append(login, more);

    const accountMenu = document.createElement('div'); accountMenu.className = 'accountMenu hidden';
    const reveal = document.createElement('button'); reveal.type = 'button'; reveal.textContent = 'Reveal';
    const revealMount = document.createElement('div'); revealMount.className = 'credentialReveal hidden';
    reveal.addEventListener('click', () => revealCredential(item, revealMount).catch((error) => message(error.message, true)));
    const copyUser = document.createElement('button'); copyUser.type = 'button'; copyUser.textContent = 'Copy user'; copyUser.addEventListener('click', () => copySensitiveField(item.id, 'username').catch((error) => message(error.message, true)));
    const copyPass = document.createElement('button'); copyPass.type = 'button'; copyPass.textContent = 'Copy password'; copyPass.addEventListener('click', () => copySensitiveField(item.id, 'password').catch((error) => message(error.message, true)));
    const edit = document.createElement('button'); edit.type = 'button'; edit.textContent = 'Edit in dashboard'; edit.addEventListener('click', () => chrome.tabs.create({ url: chrome.runtime.getURL(`src/vault/vault.html?view=login&item=${encodeURIComponent(item.id)}`) }));
    accountMenu.append(reveal, copyUser, copyPass, edit);
    more.addEventListener('click', () => accountMenu.classList.toggle('hidden'));
    if (!insecureHttp) card.append(top);
    card.append(actions, accountMenu, revealMount);
    elements.matches.append(card);
  }
}

async function refreshPopupSearch(query) {
  const serial = ++popupSearchSerial;
  const nextState = await getPageState(query);
  if (serial !== popupSearchSerial) return;
  pageState = nextState;
  renderMatches();
}

async function refresh() {
  [licenseState, settingsState] = await Promise.all([getLicenseState(), getSettings()]);
  applyTheme(settingsState?.theme || 'ivory');
  elements.statusBadge.textContent = licenseBadgeText(licenseState);
  activeTab = await getActiveTab();
  const vaultState = await runtimeMessage({ type: 'GET_VAULT_STATE' });

  const setupRequired = vaultState.state === 'setup';
  if (elements.openVault) {
    elements.openVault.disabled = setupRequired;
    elements.openVault.textContent = setupRequired ? 'Complete setup first' : 'Open dashboard';
  }

  if (setupRequired) return show('setupView');
  if (vaultState.state === 'locked') { elements.unlockTotpLabel.classList.toggle('hidden', !settingsState?.vaultTotpEnabled); return show('lockedView'); }

  show('unlockedView');

  elements.search.classList.remove('hidden');
  elements.addCurrentSite.classList.remove('hidden');
  pageState = await getPageState();
  // The extension-icon popup never shows Always-On Handler controls.
  // Store/on-demand builds may still attach the guarded handler silently so the
  // popup can work on the current tab without exposing permission plumbing here.
  await attachOnDemandHandler();
  pageState = await getPageState();
  renderMatches();
}

elements.setupPassword?.addEventListener('input', renderSetupPasswordGuide);
elements.setupConfirm?.addEventListener('input', renderSetupPasswordGuide);

function submitSetupOnEnter(event) {
  if (event.key !== 'Enter' || event.isComposing) return;
  event.preventDefault();
  if (!elements.createVault.disabled) elements.createVault.click();
}

elements.setupPassword?.addEventListener('keydown', submitSetupOnEnter);
elements.setupConfirm?.addEventListener('keydown', submitSetupOnEnter);
wirePasswordToggle(elements.toggleSetupPassword, elements.setupPassword);
wirePasswordToggle(elements.toggleSetupConfirm, elements.setupConfirm);
renderSetupPasswordGuide();

elements.createVault.addEventListener('click', async () => {
  try {
    const password = elements.setupPassword.value;
    const policy = passwordPolicy(password, 12);
    if (!policy.complete) throw new Error('Complete every strong-password requirement before creating the vault.');
    if (password !== elements.setupConfirm.value) throw new Error('Master passwords do not match.');
    await runtimeMessage({ type: 'INITIALIZE_VAULT', masterPassword: password });
    elements.setupPassword.value = ''; elements.setupConfirm.value = '';
    await chrome.tabs.create({ url: chrome.runtime.getURL('src/vault/vault.html') });
    window.close();
  } catch (error) { message(error.message, true); }
});

elements.unlockVault.addEventListener('click', async () => {
  if (unlockBusy) return;
  const password = elements.unlockPassword.value;
  unlockBusy = true;
  elements.unlockVault.disabled = true;
  elements.unlockVault.classList.add('busy');
  elements.unlockPassword.disabled = true;
  if (elements.unlockInlineError) { elements.unlockInlineError.textContent = ''; elements.unlockInlineError.classList.add('hidden'); }
  try {
    await runtimeMessage({ type: 'UNLOCK_VAULT', masterPassword: password, secondFactor: String(elements.unlockTotp.value || '') });
    elements.unlockPassword.value = ''; elements.unlockTotp.value = '';
    await refresh();
  } catch (error) {
    elements.unlockPassword.value = ''; elements.unlockTotp.value = '';
    if (elements.unlockInlineError) { elements.unlockInlineError.textContent = error.message; elements.unlockInlineError.classList.remove('hidden'); }
    message(error.message, true);
  } finally {
    unlockBusy = false;
    elements.unlockVault.disabled = false;
    elements.unlockVault.classList.remove('busy');
    elements.unlockPassword.disabled = false;
    if (!pageState?.unlocked) setTimeout(() => elements.unlockPassword.focus(), 0);
  }
});

elements.unlockPassword.addEventListener('input', () => { if (elements.unlockInlineError) { elements.unlockInlineError.textContent = ''; elements.unlockInlineError.classList.add('hidden'); } });
elements.unlockPassword.addEventListener('keydown', (event) => { if (event.key === 'Enter') { event.preventDefault(); elements.unlockVault.click(); } });
elements.unlockTotp.addEventListener('keydown', (event) => { if (event.key === 'Enter') { event.preventDefault(); elements.unlockVault.click(); } });
elements.search.addEventListener('input', () => {
  clearTimeout(popupSearchTimer);
  const query = elements.search.value;
  popupSearchTimer = setTimeout(() => {
    refreshPopupSearch(query).catch((error) => message(error.message, true));
  }, 90);
});
elements.lockNow.addEventListener('click', async () => { await runtimeMessage({ type: 'LOCK_VAULT' }); await refresh(); });
elements.openVault.addEventListener('click', () => {
  if (elements.openVault.disabled) return;
  chrome.tabs.create({ url: chrome.runtime.getURL('src/vault/vault.html') });
});
elements.addCurrentSite.addEventListener('click', () => {
  const params = new URLSearchParams({ action: 'new-login' });
  if (activeTab?.url?.startsWith('http')) params.set('url', activeTab.url);
  chrome.tabs.create({ url: chrome.runtime.getURL(`src/vault/vault.html?${params}`) });
});

elements.confirmSensitive.addEventListener('click', async () => {
  if (sensitiveVerifyBusy) return;
  const action = pendingSensitiveAction;
  const password = elements.sensitivePassword.value;
  if (!action) return closeSensitivePrompt();
  sensitiveVerifyBusy = true;
  elements.confirmSensitive.disabled = true;
  elements.confirmSensitive.classList.add('busy');
  elements.sensitivePassword.disabled = true;
  if (elements.sensitiveInlineError) { elements.sensitiveInlineError.textContent = ''; elements.sensitiveInlineError.classList.add('hidden'); }
  try {
    await runtimeMessage({ type: 'VERIFY_SENSITIVE_ACCESS', masterPassword: password, secondFactor: String(elements.sensitiveTotp.value || '') });
    elements.sensitivePrompt.classList.add('hidden');
    elements.sensitivePassword.value = '';
    pendingSensitiveAction = null;
    if (action) await action();
  } catch (error) {
    elements.sensitivePassword.value = '';
    if (elements.sensitiveInlineError) { elements.sensitiveInlineError.textContent = error.message; elements.sensitiveInlineError.classList.remove('hidden'); }
    message(error.message, true);
  } finally {
    sensitiveVerifyBusy = false;
    elements.confirmSensitive.disabled = false;
    elements.confirmSensitive.classList.remove('busy');
    elements.sensitivePassword.disabled = false;
    if (!elements.sensitivePrompt.classList.contains('hidden')) setTimeout(() => elements.sensitivePassword.focus(), 0);
  }
});
elements.sensitivePassword.addEventListener('keydown', (event) => { if (event.key === 'Enter') elements.confirmSensitive.click(); });
elements.cancelSensitive.addEventListener('click', closeSensitivePrompt);

// 0.7.74 system-wide live-state invariant. If any open VaultCove surface
// changes the encrypted vault, settings, or license entitlement while the popup
// remains open, refresh it immediately instead of waiting for a close/reopen.
let livePopupRefreshTimer = null;
chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName !== 'local') return;
  if (!changes?.[VAULT_STORAGE_KEY] && !changes?.[SETTINGS_STORAGE_KEY] && !changes?.vaultcoveLicenseClient) return;
  clearTimeout(livePopupRefreshTimer);
  livePopupRefreshTimer = setTimeout(() => refresh().catch((error) => message(error.message, true)), 80);
});

refresh().catch((error) => message(error.message, true));
