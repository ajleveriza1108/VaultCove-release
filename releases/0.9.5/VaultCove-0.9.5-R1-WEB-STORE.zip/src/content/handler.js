(() => {
  const VC_HANDLER_BUILD = '0.9.5';
  // Versioned singleton: a newly injected release must not be blocked by the
  // boolean guard left behind by an older VaultCove content-script build.
  if (globalThis.__vaultCoveHandlerBuild === VC_HANDLER_BUILD) return;
  globalThis.__vaultCoveHandlerBuild = VC_HANDLER_BUILD;
  globalThis.__vaultCoveHandlerLoaded = true;

  const markUrl = 'data:image/svg+xml,' + encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><path fill="#1283ff" d="M32 3 57 13v17c0 15-10 25-25 31C17 55 7 45 7 30V13z"/><path fill="#071a34" d="M32 9 51 17v13c0 11-7 19-19 24-12-5-19-13-19-24V17z"/><circle cx="32" cy="30" r="13" fill="none" stroke="#dfefff" stroke-width="4"/><path fill="#dfefff" d="M29 29a3 3 0 1 1 6 0c0 1.2-.6 2.2-1.5 2.7L36 40h-8l2.5-8.3A3.1 3.1 0 0 1 29 29Z"/><path fill="#38c9ff" d="M14 39c8-6 13-4 18 1 6-5 12-7 18-1-4 7-10 12-18 15-8-3-14-8-18-15Z"/></svg>`);
  let rootHost = null;
  let shadow = null;
  let state = { enabled: location.protocol === 'https:', unlocked: false, matches: [], autoLoginItemId: null, newLoginCaptureEnabled: false, secureLoginAllowed: location.protocol === 'https:' };
  let lastUsernameCandidate = '';
  let lastLoginCaptureReport = '';
  let lastLoginCaptureReportAt = 0;
  let scanTimer = null;
  let autoTimer = null;
  let autoAttemptedFor = '';
  let lastChangeReport = '';
  let lastChangeReportAt = 0;
  let observer = null;
  let lastFields = [];
  const observedRoots = new WeakSet();
  const VC_PROTOCOL_VERSION = 1;
  const NEW_LOGIN_PROMPT_VISIBLE_MS = 7000;
  const NEW_LOGIN_PROMPT_FADE_MS = 450;
  let activeNewLoginPromptId = '';
  let newLoginPromptTimer = null;
  let initialStateLoaded = false;
  let runtimeContextInvalidated = false;

  function isRuntimeContextError(error) {
    return /(extension context invalidated|receiving end does not exist|message port closed|could not establish connection)/i.test(String(error?.message || error || ''));
  }

  function runtimeContextAvailable() {
    try {
      return !runtimeContextInvalidated &&
        typeof chrome !== 'undefined' &&
        Boolean(chrome.runtime?.id) &&
        typeof chrome.runtime.sendMessage === 'function';
    } catch {
      return false;
    }
  }

  function deactivateInvalidRuntimeContext() {
    if (runtimeContextInvalidated) return;
    runtimeContextInvalidated = true;
    try { observer?.disconnect(); } catch {}
    try { clearTimeout(scanTimer); } catch {}
    try { clearTimeout(autoTimer); } catch {}
    try { clearTimeout(newLoginPromptTimer); } catch {}
    try { rootHost?.remove(); } catch {}
    rootHost = null;
    shadow = null;
  }

  function requestId() {
    if (crypto?.randomUUID) return crypto.randomUUID();
    const bytes = new Uint8Array(16);
    crypto.getRandomValues(bytes);
    return [...bytes].map((value) => value.toString(16).padStart(2, '0')).join('');
  }

  async function sendVaultMessage(type, payload = {}) {
    if (!runtimeContextAvailable()) {
      deactivateInvalidRuntimeContext();
      return { ok: false, contextInvalidated: true, error: 'VaultCove extension context is unavailable.' };
    }
    try {
      return await chrome.runtime.sendMessage({ type, protocolVersion: VC_PROTOCOL_VERSION, requestId: requestId(), ...payload });
    } catch (error) {
      const message = String(error?.message || error || 'VaultCove runtime request failed.');
      if (isRuntimeContextError(error) || !runtimeContextAvailable()) {
        deactivateInvalidRuntimeContext();
        return { ok: false, contextInvalidated: true, error: 'VaultCove extension context was reloaded.' };
      }
      // Runtime messaging failures are returned to the caller instead of escaping
      // as unhandled promise rejections in chrome://extensions.
      return { ok: false, error: message };
    }
  }

  function visible(el) {
    if (!(el instanceof HTMLInputElement)) return false;
    const rect = el.getBoundingClientRect();
    const style = getComputedStyle(el);
    return rect.width >= 45 && rect.height >= 16 && style.visibility !== 'hidden' && style.display !== 'none' && !el.disabled && !el.readOnly;
  }

  function fieldToken(el) {
    return `${el.type || ''} ${el.name || ''} ${el.id || ''} ${el.autocomplete || ''} ${el.placeholder || ''} ${el.getAttribute('aria-label') || ''}`.toLowerCase();
  }

  function isUsernameField(el) {
    const type = (el.type || '').toLowerCase();
    if (!['text', 'email', 'tel', ''].includes(type)) return false;
    const autocomplete = String(el.autocomplete || '').toLowerCase();
    if (type === 'email' || ['username', 'email'].includes(autocomplete)) return true;
    return /(user(?:name)?|e[-_\s]*mail|mail|login|account|identifier|member|phone|mobile)/.test(fieldToken(el));
  }

  function observeRoot(root) {
    if (!observer || !root || observedRoots.has(root)) return;
    observer.observe(root, {
      subtree: true,
      childList: true,
      attributes: true,
      attributeFilter: ['type', 'name', 'id', 'autocomplete', 'placeholder', 'disabled', 'readonly']
    });
    observedRoots.add(root);
  }

  function openRoots() {
    const roots = [document];
    for (let index = 0; index < roots.length && index < 64; index += 1) {
      const root = roots[index];
      observeRoot(root);
      for (const node of root.querySelectorAll('*')) {
        if (node.shadowRoot && !roots.includes(node.shadowRoot)) roots.push(node.shadowRoot);
      }
    }
    return roots;
  }

  function allInputs(scope = null) {
    if (scope && scope !== document) return [...scope.querySelectorAll('input')];
    return openRoots().flatMap((root) => [...root.querySelectorAll('input')]);
  }

  function loginFields() {
    const inputs = allInputs().filter(visible);
    const passwordFields = inputs.filter((el) => (el.type || '').toLowerCase() === 'password');
    const explicitUsernames = inputs.filter(isUsernameField);
    if (passwordFields.length) {
      const forms = new Set(passwordFields.map((el) => el.form).filter(Boolean));
      let usernames = explicitUsernames.filter((el) => !el.form || !forms.size || forms.has(el.form));
      if (!usernames.length) {
        const firstPasswordIndex = inputs.indexOf(passwordFields[0]);
        const fallback = inputs
          .slice(0, Math.max(0, firstPasswordIndex))
          .reverse()
          .find((el) => ['text', 'email', 'tel', ''].includes((el.type || '').toLowerCase()));
        if (fallback) usernames = [fallback];
      }
      return [...new Set([...usernames, ...passwordFields])].slice(0, 12);
    }
    return explicitUsernames.slice(0, 6);
  }

  function pageStage(fields) {
    return fields.some((el) => (el.type || '').toLowerCase() === 'password') ? 'password' : 'username';
  }

  function ensureRoot() {
    if (rootHost?.isConnected && shadow) return;
    rootHost = document.createElement('div');
    rootHost.dataset.vaultcove = 'handler-root';
    rootHost.style.cssText = 'all:initial;position:fixed;inset:0;z-index:2147483647;pointer-events:none;';
    shadow = rootHost.attachShadow({ mode: 'closed' });
    const style = document.createElement('style');
    style.textContent = `
      *{box-sizing:border-box;font-family:Inter,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}
      .vc-icon{position:fixed;width:22px;height:22px;border:0;border-radius:8px;padding:1px;background:#07192d;box-shadow:0 4px 16px rgba(0,0,0,.34),0 0 0 1px rgba(35,136,255,.82);cursor:pointer;pointer-events:auto;display:grid;place-items:center;transition:transform .12s ease,box-shadow .12s ease}
      .vc-icon:hover{transform:translateY(-1px);box-shadow:0 6px 20px rgba(0,0,0,.42),0 0 0 1px #43cfff}
      .vc-icon img{width:19px;height:19px;display:block}
      .vc-badge{position:absolute;right:-6px;top:-7px;min-width:14px;height:14px;padding:0 3px;border-radius:999px;background:#1688ff;color:white;font:bold 8px/14px system-ui;text-align:center;box-shadow:0 1px 5px rgba(0,0,0,.4)}
      .vc-badge.locked{background:#6b7f94}.vc-badge.pending{background:#d69220}
      .vc-menu{position:fixed;width:min(320px,calc(100vw - 16px));max-height:350px;overflow:auto;background:#07192d;color:#eef7ff;border:1px solid #28547d;border-radius:12px;box-shadow:0 16px 42px rgba(0,0,0,.48);padding:9px;pointer-events:auto}
      .vc-head{display:flex;align-items:center;gap:8px;padding:4px 4px 8px;border-bottom:1px solid #183b5c}.vc-head img{width:27px;height:27px}.vc-head strong{font-size:13px}.vc-head small{display:block;color:#82a8c8;font-size:10px;margin-top:2px;max-width:250px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
      .vc-search-wrap{position:sticky;top:-9px;z-index:2;background:#07192d;padding:7px 2px 5px}.vc-search{width:100%;border:1px solid #28547d;border-radius:8px;background:#041325;color:#eef7ff;padding:8px 9px;font-size:10px;outline:none}.vc-search:focus{border-color:#43cfff;box-shadow:0 0 0 2px rgba(67,207,255,.12)}.vc-result-count{color:#82a8c8;font-size:8px;margin:5px 2px 0}.vc-empty{padding:15px 8px;color:#94abc0;font-size:11px;line-height:1.45;text-align:center}.vc-row{padding:8px;border-radius:9px;background:#0c2744;margin-top:7px;border:1px solid #173e64}
      .vc-row-main{display:flex;justify-content:space-between;gap:8px;align-items:start}.vc-row strong{font-size:11px;display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.vc-row small{display:block;color:#8eabc4;font-size:9px;margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
      .vc-actions{display:flex;gap:6px;margin-top:7px}.vc-actions button,.vc-open{border:0;border-radius:7px;background:#1487ff;color:white;font:bold 9px system-ui;padding:7px 9px;cursor:pointer}
      .vc-save-prompt{position:fixed;right:16px;top:16px;width:min(360px,calc(100vw - 32px));background:#07192d;color:#eef7ff;border:1px solid #2f73aa;border-radius:14px;box-shadow:0 18px 46px rgba(0,0,0,.5),0 0 0 1px rgba(67,207,255,.14);padding:14px;pointer-events:auto;opacity:1;transform:translateY(0);transition:opacity .45s ease,transform .45s ease}.vc-save-prompt.vc-fading{opacity:0;transform:translateY(-8px);pointer-events:none}.vc-save-title{display:flex;gap:10px;align-items:center}.vc-save-title img{width:30px;height:30px}.vc-save-title strong{font-size:14px;line-height:1.25}.vc-save-title small{display:block;color:#a9c6dd;font-size:10px;margin-top:3px}.vc-save-copy{color:#d8e9f6;font-size:11px;line-height:1.5;margin:10px 0}.vc-save-actions{display:flex;gap:8px}.vc-save-actions button{border:1px solid #355a78;border-radius:8px;background:#102b45;color:#eaf7ff;font:bold 10px system-ui;padding:8px 11px;cursor:pointer}.vc-save-actions button.vc-save-primary{background:#1688ff;border-color:#43a8ff;color:#fff;flex:1}.vc-save-actions button:disabled{opacity:.65;cursor:default}.vc-save-status{color:#9fc2dc;font-size:9px;margin-top:8px;min-height:13px}.vc-auto{color:#54d79b;font-size:8px;white-space:nowrap;margin-top:2px}.vc-pending{color:#f4c565;font-size:8px;white-space:nowrap;margin-top:2px}.vc-open{margin-top:8px;width:100%}.vc-note{padding:6px 7px;color:#61cfff;font-size:9px}.vc-generator{margin-top:7px;padding:9px;border-radius:9px;background:linear-gradient(135deg,#0c3152,#0b2540);border:1px solid #24618d}.vc-generator strong{font-size:11px}.vc-generator small{display:block;color:#91b5d0;font-size:9px;line-height:1.4;margin:3px 0 7px}.vc-generator-row{display:flex;gap:6px;align-items:center}.vc-generator select{background:#07192d;color:#eaf7ff;border:1px solid #315c7c;border-radius:7px;padding:6px;font-size:9px}.vc-generator button{flex:1;border:0;border-radius:7px;background:#1688ff;color:white;font:bold 9px system-ui;padding:7px 9px;cursor:pointer}.vc-generated{color:#64dda3!important}
      .vc-status-toast{position:fixed;right:18px;top:18px;display:flex;align-items:center;gap:9px;min-width:190px;max-width:min(340px,calc(100vw - 36px));padding:11px 14px;border-radius:12px;background:#07192d;color:#eef7ff;border:1px solid #2b7db7;box-shadow:0 16px 42px rgba(0,0,0,.42),0 0 0 1px rgba(67,207,255,.12);pointer-events:none;opacity:0;transform:translateY(-7px) scale(.985);transition:opacity .22s ease,transform .22s ease}.vc-status-toast.vc-visible{opacity:1;transform:translateY(0) scale(1)}.vc-status-toast.vc-fade{opacity:0;transform:translateY(-8px) scale(.985)}.vc-status-dot{width:9px;height:9px;border-radius:999px;background:#54d79b;box-shadow:0 0 0 4px rgba(84,215,155,.12)}.vc-status-copy strong{display:block;font-size:12px;line-height:1.25}.vc-status-copy small{display:block;margin-top:2px;color:#a9c6dd;font-size:9px;line-height:1.35}
    `;
    shadow.append(style);
    (document.documentElement || document.body)?.append(rootHost);
  }

  function clearIcons() {
    if (!shadow) return;
    [...shadow.querySelectorAll('.vc-icon')].forEach((node) => node.remove());
  }

  function clearUi() {
    if (!shadow) return;
    clearTimeout(newLoginPromptTimer);
    newLoginPromptTimer = null;
    activeNewLoginPromptId = '';
    [...shadow.querySelectorAll('.vc-icon,.vc-menu,.vc-save-prompt')].forEach((node) => node.remove());
  }

  function closeMenus() {
    if (!shadow) return;
    [...shadow.querySelectorAll('.vc-menu')].forEach((node) => node.remove());
  }

  function showStatusToast(title, detail = '') {
    ensureRoot();
    shadow.querySelector('.vc-status-toast')?.remove();
    const toast = document.createElement('div');
    toast.className = 'vc-status-toast';
    const dot = document.createElement('span');
    dot.className = 'vc-status-dot';
    const copy = document.createElement('span');
    copy.className = 'vc-status-copy';
    const strong = document.createElement('strong');
    strong.textContent = String(title || 'VaultCove updated');
    copy.append(strong);
    if (detail) {
      const small = document.createElement('small');
      small.textContent = String(detail);
      copy.append(small);
    }
    toast.append(dot, copy);
    shadow.append(toast);
    requestAnimationFrame(() => toast.classList.add('vc-visible'));
    setTimeout(() => {
      if (!toast.isConnected) return;
      toast.classList.remove('vc-visible');
      toast.classList.add('vc-fade');
      setTimeout(() => toast.remove(), 420);
    }, 2400);
  }

  function removeNewLoginPrompt(node, { fade = false } = {}) {
    clearTimeout(newLoginPromptTimer);
    newLoginPromptTimer = null;
    if (!node?.isConnected) return;
    if (!fade) {
      activeNewLoginPromptId = '';
      node.remove();
      return;
    }
    node.classList.add('vc-fading');
    setTimeout(() => {
      if (node.isConnected) node.remove();
      activeNewLoginPromptId = '';
    }, NEW_LOGIN_PROMPT_FADE_MS);
  }

  function showNewLoginPrompt(prompt) {
    if (!prompt?.captureId || activeNewLoginPromptId === prompt.captureId) return;
    ensureRoot();
    shadow.querySelector('.vc-save-prompt')?.remove();
    clearTimeout(newLoginPromptTimer);
    activeNewLoginPromptId = String(prompt.captureId);

    const card = document.createElement('section');
    card.className = 'vc-save-prompt';
    card.setAttribute('role', 'dialog');
    card.setAttribute('aria-label', 'Save new login to VaultCove');
    const head = document.createElement('div'); head.className = 'vc-save-title';
    const img = document.createElement('img'); img.src = markUrl; img.alt = '';
    const titleWrap = document.createElement('div');
    const title = document.createElement('strong'); title.textContent = 'Save this login to VaultCove?';
    const host = document.createElement('small'); host.textContent = String(prompt.hostname || location.hostname || 'This website');
    titleWrap.append(title, host); head.append(img, titleWrap);
    const copy = document.createElement('div'); copy.className = 'vc-save-copy';
    copy.textContent = prompt.queuedWhileLocked
      ? 'This account is not yet saved. Click Add and VaultCove will securely queue it for your encrypted vault without asking for another master-password check.'
      : 'This account is not yet saved in VaultCove. Add it to your encrypted local vault?';
    const actions = document.createElement('div'); actions.className = 'vc-save-actions';
    const save = document.createElement('button'); save.type = 'button'; save.className = 'vc-save-primary'; save.textContent = 'Add to VaultCove';
    const later = document.createElement('button'); later.type = 'button'; later.textContent = 'Not now';
    const status = document.createElement('div'); status.className = 'vc-save-status'; status.textContent = 'This prompt will fade automatically after 7 seconds if you do not respond.';
    actions.append(save, later); card.append(head, copy, actions, status); shadow.append(card);

    const dismiss = async ({ timeout = false } = {}) => {
      save.disabled = true; later.disabled = true;
      if (timeout) removeNewLoginPrompt(card, { fade: true });
      else removeNewLoginPrompt(card);
      try { await sendVaultMessage('DISMISS_NEW_LOGIN_CAPTURE', { captureId: prompt.captureId }); } catch {}
    };
    later.addEventListener('click', () => dismiss());
    save.addEventListener('click', async () => {
      clearTimeout(newLoginPromptTimer);
      save.disabled = true; later.disabled = true; status.textContent = 'Saving securely...';
      try {
        const response = await sendVaultMessage('SAVE_NEW_LOGIN_CAPTURE', { captureId: prompt.captureId });
        if (!response?.ok) throw new Error(response?.error || 'VaultCove could not save this login.');
        if (response.queued) {
          status.textContent = 'Added. VaultCove will finish placing it in the encrypted vault automatically after your next normal unlock.';
          save.textContent = 'Added';
          setTimeout(() => removeNewLoginPrompt(card, { fade: true }), 900);
          return;
        }
        if (response.saved || response.duplicate) {
          status.textContent = response.saved ? 'Saved to your encrypted VaultCove vault.' : 'This login is already saved in VaultCove.';
          save.textContent = response.saved ? 'Saved' : 'Already saved';
          setTimeout(() => removeNewLoginPrompt(card, { fade: true }), 900);
          return;
        }
        throw new Error('VaultCove did not save this login.');
      } catch (error) {
        save.disabled = false; later.disabled = false; save.textContent = 'Add to VaultCove';
        status.textContent = String(error?.message || error);
        newLoginPromptTimer = setTimeout(() => dismiss({ timeout: true }), NEW_LOGIN_PROMPT_VISIBLE_MS);
      }
    });

    newLoginPromptTimer = setTimeout(() => dismiss({ timeout: true }), NEW_LOGIN_PROMPT_VISIBLE_MS);
  }

  async function secureLogin(itemId, automatic = false, stage = 'password') {
    try {
      if (!state.secureLoginAllowed || location.protocol !== 'https:') throw new Error('Secure Login is blocked on HTTP. VaultCove can capture a submitted HTTP login into encrypted local storage, but it will not send a saved password over an unencrypted connection.');
      const issued = await sendVaultMessage('ISSUE_SECURE_LOGIN_CAPABILITY', { itemId, automatic, stage });
      if (!issued?.ok || !issued.capability) throw new Error(issued?.error || 'VaultCove could not authorize this Secure Login request.');
      const response = await sendVaultMessage('FILL_PAGE_LOGIN', { capability: issued.capability, submit: true });
      if (!response?.ok) throw new Error(response?.error || 'VaultCove could not complete Strict Secure Login.');
      closeMenus();
      return response;
    } catch (error) {
      if (!automatic) showTransient(String(error?.message || error));
      return null;
    }
  }

  function showTransient(text) {
    ensureRoot();
    closeMenus();
    const menu = document.createElement('div');
    menu.className = 'vc-menu';
    menu.style.right = '12px';
    menu.style.top = '12px';
    const note = document.createElement('div');
    note.className = 'vc-empty';
    note.textContent = text;
    menu.append(note);
    shadow.append(menu);
    setTimeout(() => menu.remove(), 3500);
  }

  function passwordFormContext(fields = lastFields) {
    const passwords = (fields || []).filter((el) => (el.type || '').toLowerCase() === 'password');
    const tokens = passwords.map((el) => fieldToken(el));
    const explicitNew = passwords.filter((el) => String(el.autocomplete || '').toLowerCase() === 'new-password' || /(new|confirm|change|reset|create).{0,18}pass|pass.{0,18}(new|confirm|change|reset|create)/.test(fieldToken(el)));
    if (!explicitNew.length) return { kind: 'login', fields: [] };
    const hasCurrent = passwords.some((el) => String(el.autocomplete || '').toLowerCase() === 'current-password' || /(current|old).{0,15}pass/.test(fieldToken(el)));
    const pageText = `${document.title || ''} ${location.pathname || ''}`.toLowerCase();
    const kind = hasCurrent || /(change|reset|recover).{0,20}pass|pass.{0,20}(change|reset|recover)/.test(`${tokens.join(' ')} ${pageText}`) ? 'change' : 'signup';
    return { kind, fields: explicitNew };
  }

  function generateStrongPassword(length = 24) {
    const lower = 'abcdefghijkmnopqrstuvwxyz';
    const upper = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
    const digits = '23456789';
    const symbols = '!@#$%^&*()-_=+[]{}:,.?';
    const sets = [lower, upper, digits, symbols];
    const alphabet = sets.join('');
    const bytes = new Uint32Array(Math.max(16, Math.min(64, Number(length) || 24)));
    crypto.getRandomValues(bytes);
    const chars = sets.map((set, index) => set[bytes[index] % set.length]);
    for (let i = sets.length; i < bytes.length; i += 1) chars.push(alphabet[bytes[i] % alphabet.length]);
    for (let i = chars.length - 1; i > 0; i -= 1) {
      const swapBytes = new Uint32Array(1); crypto.getRandomValues(swapBytes);
      const j = swapBytes[0] % (i + 1); [chars[i], chars[j]] = [chars[j], chars[i]];
    }
    return chars.join('');
  }

  function setNativeValue(input, value) {
    const descriptor = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value');
    descriptor?.set?.call(input, value);
    input.dispatchEvent(new Event('input', { bubbles: true, composed: true }));
    input.dispatchEvent(new Event('change', { bubbles: true, composed: true }));
  }

  function generateAndFillPassword(length) {
    const context = passwordFormContext();
    if (!context.fields.length) return showTransient('VaultCove did not find a supported New Password field.');
    const password = generateStrongPassword(length);
    for (const field of context.fields) {
      if (field.isConnected && !field.disabled && !field.readOnly) setNativeValue(field, password);
    }
    const first = context.fields[0]; first?.focus();
    showTransient(`Generated and filled a ${password.length}-character password locally. VaultCove will ask before saving or updating after submission.`);
  }

  function appendGenerator(menu) {
    const context = passwordFormContext();
    if (!context.fields.length) return;
    const box = document.createElement('div'); box.className = 'vc-generator';
    const title = document.createElement('strong'); title.textContent = context.kind === 'change' ? 'Password change detected' : 'New password detected';
    const hint = document.createElement('small'); hint.textContent = context.kind === 'change' ? 'Generate a strong replacement locally. VaultCove will ask before updating the saved login.' : 'Generate a strong password locally. VaultCove will ask before saving the new login.';
    const row = document.createElement('div'); row.className = 'vc-generator-row';
    const length = document.createElement('select');
    for (const value of [20,24,32,40]) { const option = document.createElement('option'); option.value = String(value); option.textContent = `${value} chars`; if (value === 24) option.selected = true; length.append(option); }
    const button = document.createElement('button'); button.type = 'button'; button.textContent = 'Generate and fill';
    button.addEventListener('click', () => generateAndFillPassword(Number(length.value)));
    row.append(length, button); box.append(title, hint, row); menu.append(box);
  }

  function appendLoginRows(container, matches) {
    container.replaceChildren();
    for (const item of matches) {
      const row = document.createElement('div'); row.className = 'vc-row';
      const main = document.createElement('div'); main.className = 'vc-row-main';
      const info = document.createElement('div');
      const name = document.createElement('strong'); name.textContent = `${item.favorite ? 'Favorite: ' : ''}${item.name}`;
      const user = document.createElement('small'); user.textContent = item.usernameMasked || '(no username)';
      info.append(name, user); main.append(info);
      const flags = document.createElement('div');
      if (item.autoLogin) { const flag = document.createElement('div'); flag.className = 'vc-auto'; flag.textContent = 'AUTO-LOGIN'; flags.append(flag); }
      if (item.pendingPasswordChange) { const flag = document.createElement('div'); flag.className = 'vc-pending'; flag.textContent = 'CHANGE DETECTED'; flags.append(flag); }
      if (item.requireReauthBeforeFill) { const flag = document.createElement('div'); flag.className = 'vc-pending'; flag.textContent = 'MASTER CHECK'; flags.append(flag); }
      if (flags.childElementCount) main.append(flags);
      const actions = document.createElement('div'); actions.className = 'vc-actions';
      const loginButton = document.createElement('button'); loginButton.type = 'button'; loginButton.textContent = state.secureLoginAllowed ? 'Secure Login' : 'HTTP - use extension popup'; loginButton.disabled = !state.secureLoginAllowed; loginButton.addEventListener('click', () => secureLogin(item.id));
      if (item.useOnlySharedAccess) {
        const policy = document.createElement('div'); policy.className = 'vc-auto'; policy.textContent = 'USE ONLY'; flags.append(policy);
      }
      actions.append(loginButton);
      row.append(main, actions); container.append(row);
    }
  }

  function showMenu(icon) {
    ensureRoot();
    closeMenus();
    const rect = icon.getBoundingClientRect();
    const menu = document.createElement('div');
    menu.className = 'vc-menu';
    const width = Math.min(340, Math.max(270, innerWidth - 16));
    const left = Math.min(Math.max(8, rect.right - width), Math.max(8, innerWidth - width - 8));
    const top = rect.bottom + 8 + 390 < innerHeight ? rect.bottom + 8 : Math.max(8, rect.top - 398);
    menu.style.left = `${left}px`;
    menu.style.top = `${top}px`;

    const head = document.createElement('div');
    head.className = 'vc-head';
    const img = document.createElement('img'); img.src = markUrl; img.alt = '';
    const title = document.createElement('div');
    const strong = document.createElement('strong'); strong.textContent = 'VaultCove';
    const small = document.createElement('small'); small.textContent = location.hostname || 'Secure login frame';
    title.append(strong, small); head.append(img, title); menu.append(head);
    appendGenerator(menu);

    if (!state.unlocked) {
      const empty = document.createElement('div'); empty.className = 'vc-empty'; empty.textContent = state.newLoginCaptureEnabled ? 'VaultCove is locked. Submitted username/email and password pairs can still be sealed into the encrypted local capture inbox for review after unlock.' : 'VaultCove is locked. Unlock it to use saved credentials on this page.';
      const open = document.createElement('button'); open.className = 'vc-open'; open.type = 'button'; open.textContent = 'Open VaultCove';
      open.addEventListener('click', async () => {
        const response = await sendVaultMessage('OPEN_HANDLER_UNLOCK');
        if (!response?.ok && !response?.contextInvalidated) {
          showTransient(response?.error || 'VaultCove could not open the unlock page.');
        }
      });
      menu.append(empty, open);
    } else if (!Number(state.matchCount || state.matches.length)) {
      const empty = document.createElement('div'); empty.className = 'vc-empty'; empty.textContent = state.secureLoginAllowed ? 'No login is saved for this trusted HTTPS website.' : 'HTTP page detected. New registrations/logins can be captured locally, but VaultCove will not submit saved passwords over HTTP.';
      menu.append(empty);
    } else {
      const note = document.createElement('div'); note.className = 'vc-note'; note.textContent = state.secureLoginAllowed ? 'Trusted-site matching - usernames masked - passwords never enter this menu' : 'HTTP site - capture is allowed; saved-password use requires explicit confirmation in the extension popup'; menu.append(note);

      const searchWrap = document.createElement('div'); searchWrap.className = 'vc-search-wrap';
      const search = document.createElement('input');
      search.type = 'search';
      search.className = 'vc-search';
      search.placeholder = `Search ${state.matchCount || state.matches.length} account${Number(state.matchCount || state.matches.length) === 1 ? '' : 's'}...`;
      search.autocomplete = 'off';
      search.spellcheck = false;
      search.setAttribute('aria-label', 'Search matching VaultCove accounts');
      const count = document.createElement('div'); count.className = 'vc-result-count';
      searchWrap.append(search, count);
      menu.append(searchWrap);

      const results = document.createElement('div');
      menu.append(results);
      const updateResults = (response) => {
        const shown = response.matches || [];
        const total = Number(response.filteredMatchCount ?? shown.length);
        count.textContent = total > shown.length ? `${shown.length} of ${total} matches shown` : `${total} match${total === 1 ? '' : 'es'}`;
        if (!shown.length) {
          results.innerHTML = '<div class="vc-empty">No matching account. Search by account name or username.</div>';
        } else {
          appendLoginRows(results, shown);
        }
      };
      updateResults(state);

      let searchTimer = null;
      search.addEventListener('input', () => {
        clearTimeout(searchTimer);
        const query = search.value;
        searchTimer = setTimeout(async () => {
          try {
            const response = await sendVaultMessage('GET_PAGE_LOGINS', { query });
            if (!response?.ok || !menu.isConnected) return;
            state = { ...state, ...response };
            updateResults(response);
          } catch {}
        }, 120);
      });
      setTimeout(() => search.focus({ preventScroll: true }), 0);
    }
    shadow.append(menu);
  }

  function positionIcon(icon, input) {
    const rect = input.getBoundingClientRect();
    const size = 22;
    const left = Math.max(4, Math.min(innerWidth - size - 4, rect.right - size - 8));
    const top = Math.max(4, Math.min(innerHeight - size - 4, rect.top + Math.max(1, (rect.height - size) / 2)));
    icon.style.left = `${left}px`;
    icon.style.top = `${top}px`;
    icon.hidden = rect.bottom < 0 || rect.top > innerHeight || rect.right < 0 || rect.left > innerWidth;
  }

  function renderIcons(fields) {
    lastFields = fields || [];
    ensureRoot();
    clearIcons();
    for (const input of fields) {
      const icon = document.createElement('button');
      icon.type = 'button'; icon.className = 'vc-icon'; icon.setAttribute('aria-label', 'Open VaultCove login handler');
      const img = document.createElement('img'); img.src = markUrl; img.alt = '';
      const badge = document.createElement('span');
      const pending = state.matches?.some((item) => item.pendingPasswordChange);
      badge.className = `vc-badge${state.unlocked ? '' : ' locked'}${pending ? ' pending' : ''}`;
      const generatorReady = passwordFormContext(fields).fields.length > 0;
      badge.textContent = state.unlocked ? (Number(state.matchCount || state.matches.length) ? String(Math.min(99, Number(state.matchCount || state.matches.length))) : generatorReady ? 'G' : '0') : 'L';
      icon.append(img, badge); positionIcon(icon, input);
      icon.addEventListener('mousedown', (event) => event.preventDefault());
      icon.addEventListener('click', (event) => { event.stopPropagation(); showMenu(icon); });
      shadow.append(icon);
    }
  }

  async function refreshState(fields) {
    try {
      const response = await sendVaultMessage('GET_PAGE_LOGINS');
      if (!response?.ok) return;
      state = response;
      initialStateLoaded = true;
      if (!state.enabled || !state.supported) { clearUi(); return; }
      renderIcons(fields);
      if (state.newLoginPrompt) showNewLoginPrompt(state.newLoginPrompt);
      else if (activeNewLoginPromptId) {
        const active = shadow?.querySelector('.vc-save-prompt');
        if (active) removeNewLoginPrompt(active, { fade: true });
      }

      if (state.unlocked && state.secureLoginAllowed && state.autoLoginItemId && fields.length) {
        const stage = pageStage(fields);
        const key = `${location.href}|${stage}|${state.autoLoginItemId}`;
        if (autoAttemptedFor !== key) {
          autoAttemptedFor = key;
          clearTimeout(autoTimer);
          autoTimer = setTimeout(() => secureLogin(state.autoLoginItemId, true, stage), 250);
        }
      }
    } catch {
      clearUi();
    }
  }

  function scan() {
    if (runtimeContextInvalidated) return;
    clearTimeout(scanTimer);
    scanTimer = setTimeout(() => {
      try {
        const fields = loginFields();
        if (!fields.length && initialStateLoaded) {
          clearIcons();
          closeMenus();
          return;
        }
        refreshState(fields);
      } catch {
        // Website DOM mutations must never surface as an unhandled extension error.
      }
    }, 120);
  }

  function usernameForScope(scope) {
    const inputs = allInputs(scope);
    const explicit = inputs.find((el) => isUsernameField(el) && String(el.value || '').trim());
    if (explicit) {
      lastUsernameCandidate = String(explicit.value || '').trim();
      return lastUsernameCandidate;
    }
    const passwordIndex = inputs.findIndex((el) => (el.type || '').toLowerCase() === 'password');
    if (passwordIndex > 0) {
      const fallback = inputs.slice(0, passwordIndex).reverse().find((el) => ['text', 'email', 'tel', ''].includes((el.type || '').toLowerCase()) && String(el.value || '').trim());
      if (fallback) {
        lastUsernameCandidate = String(fallback.value || '').trim();
        return lastUsernameCandidate;
      }
    }
    return lastUsernameCandidate;
  }

  function passwordChangeContext(scope, actionText = '') {
    const pageText = `${document.title || ''} ${location.pathname || ''} ${location.search || ''}`.toLowerCase();
    const formText = scope instanceof Element ? `${scope.getAttribute?.('aria-label') || ''} ${scope.getAttribute?.('name') || ''} ${scope.getAttribute?.('id') || ''} ${scope.textContent || ''}`.toLowerCase().slice(0, 1200) : '';
    const combined = `${pageText} ${formText} ${String(actionText || '').toLowerCase()}`;
    const changeSignal = /(change|reset|recover|update|replace|new).{0,28}(pass|password)|(?:pass|password).{0,28}(change|reset|recover|update|replace|new)/.test(combined);
    const signupSignal = /(sign\s*up|signup|register|create\s+(?:an?\s+)?account|join\s+now)/.test(combined);
    return { changeSignal, signupSignal };
  }

  function highConfidencePasswordChange(scope, { actionText = '' } = {}) {
    const passwordFields = allInputs(scope).filter((el) => (el.type || '').toLowerCase() === 'password' && !el.disabled && !el.readOnly);
    if (!passwordFields.length) return null;

    const valued = passwordFields.map((el) => ({ el, value: String(el.value || ''), token: fieldToken(el) })).filter((entry) => entry.value.length >= 4);
    if (!valued.length) return null;

    const explicitNew = valued.filter((entry) => String(entry.el.autocomplete || '').toLowerCase() === 'new-password' || /(new|confirm|change|reset|create).{0,18}pass|pass.{0,18}(new|confirm|change|reset|create)/.test(entry.token));
    if (explicitNew.length) {
      const duplicate = explicitNew.find((entry, index) => explicitNew.some((other, otherIndex) => otherIndex !== index && other.value === entry.value));
      const chosen = duplicate || explicitNew[0];
      return { password: chosen.value, reason: duplicate ? 'matching-new-password-fields' : 'explicit-new-password-field' };
    }

    // Classic change-password form: current + new + confirm, even when the site
    // does not provide autocomplete/label metadata.
    if (valued.length >= 3) {
      const last = valued[valued.length - 1];
      const previous = valued[valued.length - 2];
      const first = valued[0];
      if (last.value === previous.value && last.value !== first.value) {
        return { password: last.value, reason: 'current-plus-matching-new-password-fields' };
      }
    }

    // Some real reset/change pages expose only "new" + "confirm" and omit all
    // semantic field labels. Restore detection for those pages, but only when the
    // page/form/button itself clearly says this is a password change/reset and it
    // does not look like account registration.
    const context = passwordChangeContext(scope, actionText);
    if (context.changeSignal && !context.signupSignal && valued.length >= 2) {
      const last = valued[valued.length - 1];
      const matching = valued.slice(0, -1).find((entry) => entry.value === last.value);
      if (matching) return { password: last.value, reason: 'two-matching-password-fields-change-context' };
    }

    // A few sites use one unlabeled password field on a dedicated reset URL.
    // Treat it as high confidence only when the surrounding page/button provides
    // an explicit password-change/reset signal and there is no sign-up context.
    if (context.changeSignal && !context.signupSignal && valued.length === 1) {
      return { password: valued[0].value, reason: 'single-password-field-explicit-change-context' };
    }
    return null;
  }

  function submittedLoginCandidate(scope) {
    const passwords = allInputs(scope)
      .filter((el) => (el.type || '').toLowerCase() === 'password' && !el.disabled && !el.readOnly)
      .map((el) => ({ el, value: String(el.value || '') }))
      .filter((entry) => entry.value.length >= 4);
    if (!passwords.length) return null;
    const current = passwords.find((entry) => String(entry.el.autocomplete || '').toLowerCase() === 'current-password');
    const chosen = current || passwords[0];
    return { password: chosen.value, reason: 'submitted-login-password' };
  }

  function reportPasswordChange(scope, { allowSubmittedLogin = false, actionText = '' } = {}) {
    if (!state.passwordChangeDetectionEnabled) return;
    let candidate = highConfidencePasswordChange(scope, { actionText });
    let confidence = 'high';
    if (!candidate && allowSubmittedLogin) {
      candidate = submittedLoginCandidate(scope);
      confidence = 'submitted-login';
    }
    if (!candidate) return;
    const username = usernameForScope(scope) || usernameForScope(document);
    const signature = `${location.hostname}|${username}|${candidate.password}|${confidence}`;
    const now = Date.now();
    if (signature === lastChangeReport && now - lastChangeReportAt < 5000) return;
    lastChangeReport = signature;
    lastChangeReportAt = now;
    sendVaultMessage('PASSWORD_CHANGE_CANDIDATE', {
      username,
      password: candidate.password,
      reason: candidate.reason,
      confidence
    }).then((response) => {
      if (response?.ok && response.autoUpdated) {
        showStatusToast('Password updated', response.emailQueued ? 'Saved in VaultCove. Security email queued.' : 'Saved in VaultCove.');
        refreshState(lastFields).catch(() => {});
      }
    }).catch(() => {});
  }

  function reportNewLogin(scope) {
    if (!state.newLoginCaptureEnabled) return;
    const username = usernameForScope(scope) || usernameForScope(document);
    if (!username) return;
    const candidate = highConfidencePasswordChange(scope) || submittedLoginCandidate(scope);
    if (!candidate) return;
    const signature = `${location.hostname}|${username}|${candidate.password}|new-login`;
    const now = Date.now();
    if (signature === lastLoginCaptureReport && now - lastLoginCaptureReportAt < 5000) return;
    lastLoginCaptureReport = signature;
    lastLoginCaptureReportAt = now;
    sendVaultMessage('NEW_LOGIN_CANDIDATE', {
      username,
      password: candidate.password,
      reason: candidate.reason,
      pageTitle: String(document.title || location.hostname).slice(0, 120)
    }).then((response) => {
      if (response?.ok && response.detected && response.newLoginPrompt) showNewLoginPrompt(response.newLoginPrompt);
    }).catch(() => {});
  }

  function firstElementFromEvent(event) {
    return event.composedPath?.().find((node) => node instanceof Element) || (event.target instanceof Element ? event.target : null);
  }

  function submitScopeFromEventTarget(target) {
    if (!(target instanceof Element)) return document;
    return target.closest('form') || target.getRootNode?.() || document;
  }

  // Record only matching saved-login sites, locally and inside the encrypted vault.
  // The background rejects unsupported/unapproved pages and records no general history.
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type !== 'VAULTCOVE_SESSION_CHANGED') return false;
    closeMenus();
    clearTimeout(scanTimer);
    const fields = loginFields();
    refreshState(fields)
      .then(() => sendResponse({ ok: true, unlocked: Boolean(state.unlocked), matchCount: Number(state.matchCount || state.matches?.length || 0) }))
      .catch(() => sendResponse({ ok: false, unlocked: false }));
    return true;
  });

  sendVaultMessage('MARK_VISITED_SAVED_SITE').catch(() => {});

  observer = new MutationObserver(scan);
  observeRoot(document);
  addEventListener('resize', scan, { passive: true });
  addEventListener('scroll', scan, { passive: true, capture: true });
  document.addEventListener('focusin', (event) => {
    // Focusing VaultCove's own search/menu must not trigger a page rescan that
    // destroys and redraws the handler while the user is interacting with it.
    if (rootHost && (event.target === rootHost || event.composedPath?.().includes(rootHost))) return;
    scan();
  }, true);
  document.addEventListener('input', (event) => {
    const target = firstElementFromEvent(event);
    if (target instanceof HTMLInputElement && isUsernameField(target) && String(target.value || '').trim()) lastUsernameCandidate = String(target.value || '').trim();
  }, true);
  document.addEventListener('submit', (event) => { const scope = submitScopeFromEventTarget(firstElementFromEvent(event)); const submitter = event.submitter instanceof Element ? event.submitter : null; const actionText = submitter ? `${submitter.textContent || ''} ${submitter.getAttribute?.('aria-label') || ''} ${submitter.getAttribute?.('value') || ''}` : ''; reportPasswordChange(scope, { allowSubmittedLogin: true, actionText }); reportNewLogin(scope); }, true);
  document.addEventListener('click', (event) => {
    const origin = firstElementFromEvent(event);
    const target = origin?.closest?.('button,input[type="submit"],input[type="button"],a[role="button"]') || null;
    if (target) {
      const text = `${target.textContent || ''} ${target.value || ''} ${target.getAttribute('aria-label') || ''}`.toLowerCase();
      const scope = submitScopeFromEventTarget(target);
      if (/(save|update|change|reset|create).{0,18}(pass|password)|(?:pass|password).{0,18}(save|update|change|reset|create)/.test(text)) {
        reportPasswordChange(scope, { actionText: text });
      }
      if (/(sign\s*up|register|create\s*(?:account)?|join|sign\s*in|log\s*in|continue|submit|next)/.test(text)) reportNewLogin(scope);
    }
    if (rootHost && event.target !== rootHost) closeMenus();
  }, true);
  scan();
})();
