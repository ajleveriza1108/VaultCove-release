import { assignItemsToFolder, createFolder, createItem, deleteFolder, ensureSharedKeysFolder, normalizeVault, purgeItem, renameFolder, SHARED_KEYS_FOLDER_NAME, SHARED_KEYS_FOLDER_SYSTEM, upsertItem } from '../core/model.js';
import { initializeVault, loadUnlockedVault, rotateMasterPasswordVerified, saveUnlockedVault as persistUnlockedVault } from '../core/vault.js';
import { BACKUP_COMPONENTS, backupSnapshotSummary, createBackupSnapshot, createPortableExport, decryptPortableExport, defaultBackupSelection, downloadExport, isComponentBackupSnapshot, restoreBackupSnapshot, selectedBackupComponents } from '../core/export.js';
import { createDisasterRecoveryExport, decryptDisasterRecoveryExport, isDisasterRecoveryExport } from '../core/disaster-recovery.js';
import { assessPassword, generatePassword, passwordPolicy, vaultHealth } from '../core/password.js';
import { passwordContextForItem } from '../core/password-intelligence.js';
import { buildTotpUri, generateRecoveryCodes, generateTotp, generateTotpSecret, hashRecoveryCodes, verifyRecoveryCode, verifyTotp } from '../core/totp.js';
import { getLicenseState, featureAllowed, licenseBadgeText, premiumFeatureAllowed } from '../core/license.js';
import { beginFirstRunSetup, clearSensitiveAccess, completeFirstRunSetup, ensureDeviceRecoveryToken, getSessionExpiry, getSettings, getVaultEnvelope, hasSensitiveAccess, markManualBackupPending, reconcileFirstRunSetupState, recordManualBackupSuccess, setDeviceRecoveryToken, setSettings, touchSession } from '../core/storage.js';
import { importMigrationCsv, mergeImportedItems, MIGRATION_LIMITS } from '../core/migration.js';
import { maskIdentifier } from '../core/redaction.js';
import {
  addTrustedShareContact,
  createSecureShare,
  downloadJsonFile,
  ensureSharingIdentity,
  openSecureShare,
  recordShareHistory
} from '../core/share.js';
import { createEncryptedVckey, maskedFingerprint, maskedShareId, openEncryptedVckey } from '../core/share-key.js';
import { isSealedTrashItem, moveVaultItemToTrash, restoreVaultItemFromTrash, trashDaysRemaining, trashPurgeAt, TRASH_RETENTION_DAYS } from '../core/trash.js';
import { THEMES, applyTheme } from '../core/themes.js';
import { passwordAgeState, passwordAgeSummary } from '../core/password-age.js';
import {
  beginCurrentDeviceAdmin,
  beginDeviceManagement,
  beginPhysicalDeviceLink,
  beginDisasterRecoveryRestore,
  beginLicenseActivation,
  changeLicensedDevice,
  deleteReleasedLicensedDevices,
  completeCurrentDeviceAdmin,
  completeDeviceManagement,
  completePhysicalDeviceLink,
  completeDisasterRecoveryRestore,
  completeLicenseActivation,
  completeRetainedDeviceRecovery,
  clearLicenseClientState,
  ensureLicenseServicePermission,
  getLicenseClientState,
  getCachedLicensedDevices,
  licensePrivacyContract,
  listOwnLicensedDevices,
  refreshLicenseLease,
  syncCurrentDeviceLease,
  createGuardianApproval,
  listGuardianApprovals,
  decideGuardianApproval,
  consumeGuardianApproval
} from '../core/license-service.js';
import { BUILD_CHANNEL } from '../core/build.js';
import { uiIcon } from './icons.js';
import { saveBlob, saveBlobSilentlyToDownloads, saveBlobWithBrowserSaveAs } from '../core/file-save.js';
import { isUseOnlySharedLogin, sealSharedLoginForVault, sharedAccessIsExpired, sharedAccessLabel } from '../core/shared-access.js';
import { loginHasInsecureHttpUrl } from '../core/site-match.js';
import { activityLogEntries, appendActivityEvent, verifyActivityLog } from '../core/activity-log.js';
import { uninstallDataDisclosure, PREMIUM_FEATURE_CATALOG } from '../core/product-plan.js';
import {
  SECURITY_ZONES,
  GUARDIAN_MODES,
  applySecurityZone,
  backupConfidence,
  breachAssessment,
  createGuardianReceipt,
  appendGuardianReceipt,
  guardianAllowedHosts,
  guardianBlocksReveal,
  guardianCooldownMinutes,
  guardianPolicy,
  guardianQuarantineAssessment,
  guardianRequiresApproval,
  guardianRiskSummary,
  passkeyCoach,
  recoveryPlaybook
} from '../core/guardian.js';
import { resolveVaultGatePanel } from '../core/ui-route.js';
import { SETTINGS_STORAGE_KEY, VAULT_STORAGE_KEY } from '../core/constants.js';

document.documentElement.dataset.vcModuleLoaded = '1';

// 0.7.63 live-login refresh invariant. Every dashboard/import write first persists
// the encrypted vault, then asks the background worker to refresh already-open
// website handlers. A webpage reload is never required for newly added/imported
// login credentials to become visible to VaultCove on that page.
async function saveUnlockedVault(nextVault, options) {
  await persistUnlockedVault(nextVault, options);
  try { await chrome.runtime.sendMessage({ type: 'VAULT_DATA_CHANGED' }); } catch {}
  if (options?.markRecoveryPending !== false) scheduleDisasterRecoveryIfNeeded().catch(() => {});
}

const $ = (id) => document.getElementById(id);
const els = Object.fromEntries([...document.querySelectorAll('[id]')].map((el) => [el.id, el]));
let vault = null;
let currentView = 'dashboard';
let licenseState = null;
let totpTimer = null;
let generatedPassword = '';
let settingsState = null;
let pendingMigration = null;
let pendingStartupImport = null;
let startupImportIntent = 'fresh';
let pendingBackupPreview = null;
let disasterRecoveryTimer = null;
let manualBackupReminderTimer = null;
let disasterRecoveryRunning = false;
let pendingSensitiveAction = null;
let handlerPermissionState = [];
let selectedItemId = null;
let identityPrivacyTimer = null;
let protectedCategoryAccessUntil = 0;
const PROTECTED_CATEGORY_ACCESS_MS = 5 * 60 * 1000;
const PROTECTED_CATEGORY_VIEWS = new Set(['card','bank','identity','note']);
const TOTP_MAINTENANCE_MODE = false;
let unlockBusy = false;
let unlockCooldownTimer = null;
let unlockCooldownUntil = 0;

let clipboardWriteSequence = 0;

async function copyVaultClipboard(value, { label = 'Sensitive value', sensitive = true } = {}) {
  const text = String(value ?? '');
  await navigator.clipboard.writeText(text);
  const sequence = ++clipboardWriteSequence;
  const seconds = sensitive ? Math.max(0, Math.min(300, Number(settingsState?.clipboardClearSeconds ?? 30))) : 0;
  if (seconds > 0) {
    setTimeout(async () => {
      if (sequence !== clipboardWriteSequence) return;
      try {
        const current = await navigator.clipboard.readText();
        if (current === text) await navigator.clipboard.writeText('');
      } catch {
        // Do not request broad clipboard-read permissions only to implement a
        // timer. If Chrome refuses the comparison, leave newer clipboard data
        // untouched instead of blindly erasing it.
      }
    }, seconds * 1000);
  }
  toast(`${label} copied.${seconds > 0 ? ` VaultCove will clear it after ${seconds} seconds when Chrome allows a safe clipboard comparison.` : ''}`);
}

let sensitiveVerifyBusy = false;
let pendingTotpSetup = null;
let pendingVckeyOperation = null;
let pendingLicenseOtp = null;
let pendingLicenseReclaim = null;
let licenseManagementToken = '';
let licenseDevicesRefreshTimer = null;
let licenseDevicesRefreshInFlight = null;
let licenseDevicesRefreshNow = null;
let licenseDevicesLastLiveRefreshAt = 0;
let guardianAsyncRefreshInFlight = null;
let guardianRenderEpoch = 0;
const guardianTotpGrants = new Map();
let activeFolderId = 'all';
let shareIdentityHideTimer = null;
let pendingProfileCrop = null;
let profileCropUiBound = false;
let securityIssueFilter = 'all';
const isDeveloperBuild = BUILD_CHANNEL === 'dev';

function requestVisibleLicenseDeviceRefresh() {
  if (currentView !== 'license' || document.hidden || typeof licenseDevicesRefreshNow !== 'function') return;
  if (Date.now() - licenseDevicesLastLiveRefreshAt < 5000) return;
  Promise.resolve(licenseDevicesRefreshNow({ quiet:true })).catch(() => {});
}
window.addEventListener('online', requestVisibleLicenseDeviceRefresh);
window.addEventListener('focus', requestVisibleLicenseDeviceRefresh);
document.addEventListener('visibilitychange', requestVisibleLicenseDeviceRefresh);
// 0.7.82 compact startup: one viewport at common Windows/Chrome scaling; Master Password before vault creation, Premium after.

// 0.7.61 lock-route invariant. Once a real encrypted vault has existed in this
// dashboard session, a missing decrypted session means LOCKED, never SETUP.
// uiRouteEpoch invalidates stale async setup callbacks after a lock transition.
let establishedVaultInstallation = false;
let uiSessionState = 'unknown';
let uiRouteEpoch = 0;

function markUiSessionState(state) {
  uiSessionState = state;
  document.documentElement.dataset.vcSessionState = state;
  document.documentElement.dataset.vcEstablishedVault = establishedVaultInstallation ? '1' : '0';
}

function markEstablishedVault() {
  establishedVaultInstallation = true;
  document.documentElement.dataset.vcEstablishedVault = '1';
}


const viewNames = {
  dashboard: 'Vault Overview', all: 'Vault', favorites: 'Favorites', login: 'Logins', card: 'Cards', bank: 'Bank Accounts',
  identity: 'Identities', note: 'Secure Notes', totp: 'TOTP Codes', generator: 'Password Generator', security: 'Security Center', guardian: 'VaultCove Guardian',
  migration: 'Migration Center', shared: 'Share', premium: 'Premium Lifetime', license: 'License and Devices', backup: 'Backup and Restore', trash: 'Trash', settings: 'Settings', support: 'Support'
};

const viewSubtitles = {
  dashboard: 'Everything stays on your device. You are in control.',
  all: 'Browse every encrypted item stored in this local vault.',
  favorites: 'Add or remove Favorites directly while keeping every item encrypted in the local vault.',
  login: 'Passwords and usernames remain encrypted until the vault is unlocked.',
  card: 'Payment-card fields are stored inside the encrypted vault payload.',
  bank: 'Bank details remain local and encrypted on this device.',
  identity: 'Keep identity and address records inside your offline vault.',
  note: 'Store private text without sending it to a cloud service.',
  totp: 'Generate standard six-digit TOTP codes locally from encrypted website authenticator secrets.',
  generator: 'Generate cryptographically random passwords entirely on this device.',
  security: 'Password health is calculated locally after you unlock the vault.',
  migration: 'Import supported password-manager CSV exports locally. VaultCove automatically detects the source layout and re-encrypts imported records.',
  shared: 'Create password-protected recipient-bound shared-login access. Recipients can use shared credentials only for Secure Login and cannot reveal, copy, edit, or reshare them.',
  premium: 'See every Lifetime Premium feature before upgrading. Locked features remain visible with a purpose tooltip and unlock immediately after Premium activation.',
  license: 'Use VaultCove Free Forever, activate optional Premium Lifetime, and monitor Premium device slots.',
  backup: 'Create or restore encrypted .vcvault backups protected by a unique Backup Key.',
  trash: `Removed items are sealed in a second encrypted envelope, cannot be opened, and are automatically deleted after ${TRASH_RETENTION_DAYS} days unless restored.`,
  settings: 'Control appearance, auto-lock, browser handling, master password, backup protection, and privacy.',
  support: 'Support continued VaultCove development without changing the offline-first vault privacy model.'
};

function toast(text, isError = false) {
  els.toast.textContent = text;
  els.toast.style.borderColor = isError ? '#8f3650' : '#3d6d94';
  els.toast.classList.add('show');
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => els.toast.classList.remove('show'), 3500);
}

function showGate(panel) {
  panel = resolveVaultGatePanel(panel, {
    establishedVault: establishedVaultInstallation,
    hasUnlockedVault: Boolean(vault),
    sessionState: uiSessionState
  });
  document.documentElement.dataset.vcBootReady = '1';
  document.documentElement.classList.add('vaultLocked');
  document.body.classList.add('lockedState');
  els.gate.classList.remove('hidden');
  els.app.classList.add('hidden');
  els.setupPanel.classList.add('hidden');
  els.unlockPanel.classList.add('hidden');
  els[panel].classList.remove('hidden');
  if (panel === 'unlockPanel' && els.unlockTotpLabel) els.unlockTotpLabel.classList.toggle('hidden', !settingsState?.vaultTotpEnabled);
}

function showApp() {
  document.documentElement.dataset.vcBootReady = '1';
  markUiSessionState('unlocked');
  document.documentElement.classList.remove('vaultLocked');
  document.body.classList.remove('lockedState');
  els.gate.classList.add('hidden');
  els.app.classList.remove('hidden');
}

function enterLockedUi(message = '') {
  uiRouteEpoch += 1;
  markEstablishedVault();
  markUiSessionState('locked');
  protectedCategoryAccessUntil = 0;
  clearDecryptedUi();
  showGate('unlockPanel');
  if (message) toast(message);
}

function applyCurrentTheme() { return applyTheme(settingsState?.theme || 'ivory'); }
function applyCurrentDensity() { document.documentElement.classList.toggle('compactUi', settingsState?.compactUi !== false); }
function applyCurrentAppearance() { applyCurrentTheme(); applyCurrentDensity(); }

function normalizedProfileName(value = settingsState?.profileName) {
  const name = String(value || '').trim().replace(/\s+/g, ' ').slice(0, 80);
  return name || 'VaultCove User';
}

function profileInitials(value = settingsState?.profileName) {
  const name = normalizedProfileName(value);
  const parts = name.split(/\s+/).filter(Boolean);
  if (!parts.length) return 'VC';
  if (name === 'VaultCove User') return 'VC';
  return `${parts[0]?.[0] || ''}${parts.length > 1 ? parts[parts.length - 1]?.[0] || '' : parts[0]?.[1] || ''}`.toUpperCase().slice(0, 2) || 'VC';
}

function profilePhotoDataUrl() {
  const value = String(settingsState?.profileImageDataUrl || '');
  return /^data:image\/(?:png|jpeg|webp);base64,/i.test(value) ? value : '';
}

function applyAvatarElement(avatar, name = normalizedProfileName()) {
  if (!avatar) return;
  const photo = profilePhotoDataUrl();
  const image = avatar.querySelector?.('[data-avatar-image]') || null;
  const fallback = avatar.querySelector?.('[data-avatar-fallback]') || null;
  avatar.classList.toggle('hasPhoto', Boolean(photo));
  if (image) {
    // Settings uses a real <img> preview rather than a CSS data-URL background.
    // This avoids theme/background shorthands ever masking the persisted crop.
    if (photo) {
      if (image.getAttribute('src') !== photo) image.setAttribute('src', photo);
      image.hidden = false;
    } else {
      image.removeAttribute('src');
      image.hidden = true;
    }
    if (fallback) {
      fallback.hidden = Boolean(photo);
      fallback.textContent = profileInitials(name);
    }
    avatar.style.backgroundImage = '';
    return;
  }
  // Header/legacy compact avatars keep the lightweight CSS-background path.
  avatar.style.backgroundImage = photo ? `url("${photo}")` : '';
  avatar.textContent = photo ? '' : profileInitials(name);
}

async function persistLocalProfilePhoto(profileImageDataUrl) {
  const value = String(profileImageDataUrl || '');
  if (value && !/^data:image\/(?:png|jpeg|webp);base64,/i.test(value)) {
    throw new Error('VaultCove refused an invalid local profile image.');
  }
  await setSettings({ profileImageDataUrl: value });
  settingsState = await getSettings();
  if (String(settingsState.profileImageDataUrl || '') !== value) {
    throw new Error('VaultCove could not persist the cropped profile photo locally.');
  }
  applyProfileIdentity();
  return value;
}

async function localProfileImageFromFile(file) {
  if (!file) return '';
  if (!/^image\/(?:png|jpeg|webp)$/i.test(String(file.type || ''))) throw new Error('Choose a PNG, JPEG, or WebP profile image.');
  if (file.size > 12 * 1024 * 1024) throw new Error('Profile image must be 12 MB or smaller before local cropping.');
  if (pendingProfileCrop) throw new Error('Finish or cancel the current profile-photo crop first.');

  const objectUrl = URL.createObjectURL(file);
  const image = new Image();
  image.decoding = 'async';
  try {
    await new Promise((resolve, reject) => {
      image.onload = resolve;
      image.onerror = () => reject(new Error('VaultCove could not read that image.'));
      image.src = objectUrl;
    });
    if (!image.naturalWidth || !image.naturalHeight) throw new Error('That profile image has no readable dimensions.');
    const imagePixels = image.naturalWidth * image.naturalHeight;
    if (image.naturalWidth > 12000 || image.naturalHeight > 12000 || imagePixels > 50_000_000) {
      throw new Error('Profile image dimensions are too large for safe local cropping.');
    }

    bindProfileCropUi();
    const canvas = $('profileCropCanvas');
    const zoom = $('profileCropZoom');
    const stage = $('profileCropStage');
    const error = $('profileCropError');
    if (!canvas || !zoom || !stage || !els.profileCropDialog) throw new Error('Profile crop controls are unavailable.');

    const stageSize = 360;
    const cropInset = stageSize * 0.08;
    const cropSize = stageSize - cropInset * 2;
    const baseScale = Math.max(cropSize / image.naturalWidth, cropSize / image.naturalHeight);
    zoom.value = '1';
    error.textContent = '';
    error.classList.add('hidden');

    return await new Promise((resolve, reject) => {
      pendingProfileCrop = {
        file,
        image,
        objectUrl,
        resolve,
        reject,
        stageSize,
        cropInset,
        cropSize,
        baseScale,
        zoom: 1,
        offsetX: 0,
        offsetY: 0,
        dragging: false,
        pointerId: null,
        lastX: 0,
        lastY: 0
      };
      drawProfileCropPreview();
      els.profileCropDialog.showModal();
    });
  } catch (error) {
    URL.revokeObjectURL(objectUrl);
    throw error;
  }
}

function constrainProfileCrop(state = pendingProfileCrop) {
  if (!state) return;
  const scale = state.baseScale * state.zoom;
  const width = state.image.naturalWidth * scale;
  const height = state.image.naturalHeight * scale;
  const maxX = Math.max(0, (width - state.cropSize) / 2);
  const maxY = Math.max(0, (height - state.cropSize) / 2);
  state.offsetX = Math.max(-maxX, Math.min(maxX, state.offsetX));
  state.offsetY = Math.max(-maxY, Math.min(maxY, state.offsetY));
}

function drawProfileCropPreview() {
  const state = pendingProfileCrop;
  const canvas = $('profileCropCanvas');
  if (!state || !canvas) return;
  constrainProfileCrop(state);
  const ctx = canvas.getContext('2d', { alpha: false });
  if (!ctx) return;
  const scale = state.baseScale * state.zoom;
  const width = state.image.naturalWidth * scale;
  const height = state.image.naturalHeight * scale;
  const x = state.stageSize / 2 + state.offsetX - width / 2;
  const y = state.stageSize / 2 + state.offsetY - height / 2;
  ctx.clearRect(0, 0, state.stageSize, state.stageSize);
  ctx.fillStyle = '#07111d';
  ctx.fillRect(0, 0, state.stageSize, state.stageSize);
  ctx.drawImage(state.image, x, y, width, height);
}

function finishProfileCrop({ useImage = false } = {}) {
  const state = pendingProfileCrop;
  pendingProfileCrop = null;
  if (!state) return;
  try {
    if (els.profileCropDialog?.open) els.profileCropDialog.close();
    if (!useImage) { state.resolve(''); return; }
    constrainProfileCrop(state);
    const scale = state.baseScale * state.zoom;
    const renderedWidth = state.image.naturalWidth * scale;
    const renderedHeight = state.image.naturalHeight * scale;
    const renderedX = state.stageSize / 2 + state.offsetX - renderedWidth / 2;
    const renderedY = state.stageSize / 2 + state.offsetY - renderedHeight / 2;
    const sourceX = (state.cropInset - renderedX) / scale;
    const sourceY = (state.cropInset - renderedY) / scale;
    const sourceSize = state.cropSize / scale;
    const output = document.createElement('canvas');
    output.width = 256;
    output.height = 256;
    const ctx = output.getContext('2d', { alpha: false });
    if (!ctx) throw new Error('Profile image processing is unavailable.');
    ctx.drawImage(state.image, sourceX, sourceY, sourceSize, sourceSize, 0, 0, 256, 256);
    const data = output.toDataURL('image/webp', 0.88);
    if (data.length > 600000) throw new Error('Cropped profile image is still too large. Choose a smaller image.');
    state.resolve(data);
  } catch (error) {
    state.reject(error);
  } finally {
    URL.revokeObjectURL(state.objectUrl);
    $('profileCropStage')?.classList.remove('dragging');
  }
}

function bindProfileCropUi() {
  if (profileCropUiBound) return;
  profileCropUiBound = true;
  const stage = $('profileCropStage');
  const zoom = $('profileCropZoom');
  const cancel = () => finishProfileCrop({ useImage: false });
  $('cancelProfileCrop')?.addEventListener('click', cancel);
  $('closeProfileCrop')?.addEventListener('click', cancel);
  $('useProfileCrop')?.addEventListener('click', () => finishProfileCrop({ useImage: true }));
  zoom?.addEventListener('input', () => {
    if (!pendingProfileCrop) return;
    pendingProfileCrop.zoom = Math.max(1, Math.min(3, Number(zoom.value) || 1));
    drawProfileCropPreview();
  });
  stage?.addEventListener('pointerdown', (event) => {
    const state = pendingProfileCrop;
    if (!state) return;
    state.dragging = true;
    state.pointerId = event.pointerId;
    state.lastX = event.clientX;
    state.lastY = event.clientY;
    stage.setPointerCapture?.(event.pointerId);
    stage.classList.add('dragging');
    event.preventDefault();
  });
  stage?.addEventListener('pointermove', (event) => {
    const state = pendingProfileCrop;
    if (!state?.dragging || state.pointerId !== event.pointerId) return;
    const rect = stage.getBoundingClientRect();
    const ratio = state.stageSize / Math.max(1, rect.width);
    state.offsetX += (event.clientX - state.lastX) * ratio;
    state.offsetY += (event.clientY - state.lastY) * ratio;
    state.lastX = event.clientX;
    state.lastY = event.clientY;
    drawProfileCropPreview();
    event.preventDefault();
  });
  const stopDrag = (event) => {
    const state = pendingProfileCrop;
    if (!state?.dragging || state.pointerId !== event.pointerId) return;
    state.dragging = false;
    state.pointerId = null;
    stage.releasePointerCapture?.(event.pointerId);
    stage.classList.remove('dragging');
  };
  stage?.addEventListener('pointerup', stopDrag);
  stage?.addEventListener('pointercancel', stopDrag);
  els.profileCropDialog?.addEventListener('cancel', (event) => { event.preventDefault(); cancel(); });
}

function applyProfileIdentity() {
  const name = normalizedProfileName();
  const profile = document.querySelector('.localProfile');
  if (profile) {
    const avatar = profile.querySelector(':scope > span');
    const label = profile.querySelector('strong');
    const account = profile.querySelector('small');
    applyAvatarElement(avatar, name);
    if (label) label.textContent = name;
    if (account) account.textContent = licenseState?.premium ? 'Premium Account' : 'Local Account';
  }
  applyAvatarElement($('firstRunProfilePreview'), name);
  applyAvatarElement($('profilePhotoPreview'), name);
}


function validSecurityEmail(value) {
  const email = String(value || '').trim();
  if (!email || email.length > 254 || /\s/.test(email)) return false;
  const at = email.lastIndexOf('@');
  if (at <= 0 || at !== email.indexOf('@')) return false;

  const local = email.slice(0, at);
  const domain = email.slice(at + 1).toLowerCase();
  if (!local || local.length > 64 || !domain || domain.length > 253) return false;
  if (local.startsWith('.') || local.endsWith('.') || local.includes('..')) return false;
  if (!/^[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+$/.test(local)) return false;

  const labels = domain.split('.');
  if (labels.length < 2 || labels.some((label) => !label || label.length > 63 || !/^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/i.test(label))) return false;
  const tld = labels.at(-1);
  return /^(?:[a-z]{2,63}|xn--[a-z0-9-]{2,59})$/i.test(tld);
}

function passwordGuideInnerMarkup(minLength) {
  const min = Math.max(8, Math.min(128, Number(minLength) || 12));
  return `
    <div class="passwordGuideHead"><span>Strong password requirements</span><strong data-password-guide-status>Start typing</strong></div>
    <div class="passwordGuideMeter" aria-hidden="true"><i data-password-guide-meter></i></div>
    <div class="passwordRuleGrid">
      <span data-password-rule="length"><i></i>${min}+ characters</span>
      <span data-password-rule="lower"><i></i>Lowercase letter</span>
      <span data-password-rule="upper"><i></i>Capital letter</span>
      <span data-password-rule="number"><i></i>Number</span>
      <span data-password-rule="special"><i></i>Special character</span>
      <span data-password-rule="repeat"><i></i>No 3 repeated characters</span>
      <span data-password-rule="common"><i></i>No common word or sequence</span>
      <span data-password-rule="variety"><i></i>At least 8 unique characters</span>
    </div>
    <div class="passwordMatch hidden" data-password-match><i></i><span>Passwords match</span></div>`;
}

function passwordGuideMarkup(id, minLength) {
  const min = Math.max(8, Math.min(128, Number(minLength) || 12));
  return `<div id="${id}" class="passwordGuide" data-min-length="${min}">${passwordGuideInnerMarkup(min)}</div>`;
}

function ensurePasswordGuideContent(guide, minLength) {
  if (!guide) return;
  const min = Math.max(8, Math.min(128, Number(minLength) || Number(guide.dataset.minLength) || 12));
  guide.dataset.minLength = String(min);
  if (!guide.querySelector('[data-password-rule="length"]')) guide.innerHTML = passwordGuideInnerMarkup(min);
}

function addPasswordVisibilityToggle(input) {
  if (!input || input.dataset.vcVisibilityToggle === '1') return;
  input.dataset.vcVisibilityToggle = '1';
  const parent = input.parentElement;
  if (!parent) return;
  const row = document.createElement('span');
  row.className = 'passwordEntry';
  parent.insertBefore(row, input);
  row.append(input);
  const button = document.createElement('button');
  button.type = 'button';
  button.className = 'passwordVisibilityToggle';
  button.textContent = 'Show';
  button.setAttribute('aria-label', 'Show password');
  button.addEventListener('click', () => {
    const showing = input.type === 'text';
    input.type = showing ? 'password' : 'text';
    button.textContent = showing ? 'Show' : 'Hide';
    button.setAttribute('aria-label', showing ? 'Show password' : 'Hide password');
  });
  row.append(button);
}

function updatePasswordGuide(guide, input, confirmInput = null) {
  if (!guide || !input) return { valid: false, policy: passwordPolicy('', 12), matches: !confirmInput };
  const min = Number(guide.dataset.minLength) || Number(input.minLength) || 12;
  ensurePasswordGuideContent(guide, min);
  const policy = passwordPolicy(input.value, min);
  for (const [rule, met] of Object.entries(policy.rules)) {
    guide.querySelector(`[data-password-rule="${rule}"]`)?.classList.toggle('met', met);
  }
  const matches = !confirmInput || (Boolean(input.value) && input.value === confirmInput.value);
  const match = guide.querySelector('[data-password-match]');
  if (match) {
    match.classList.toggle('hidden', !confirmInput);
    match.classList.toggle('met', matches);
    const matchText = match.querySelector('span');
    if (matchText) matchText.textContent = matches ? 'Passwords match' : 'Passwords must match';
  }
  const status = guide.querySelector('[data-password-guide-status]');
  if (status) status.textContent = policy.complete ? (matches ? 'Ready to continue' : 'Confirm password') : `${policy.passed}/${policy.total} secure checks`;
  const meter = guide.querySelector('[data-password-guide-meter]');
  if (meter) {
    const progress = Math.round((policy.passed / policy.total) * 100);
    meter.style.width = `${progress}%`;
    meter.dataset.complete = String(Boolean(policy.complete && matches));
  }
  guide.classList.toggle('complete', Boolean(policy.complete && matches));
  return { valid: Boolean(policy.complete && matches), policy, matches };
}

function bindPasswordGuide({ inputId, confirmId = '', guideId, onChange = null }) {
  const input = $(inputId);
  const confirmInput = confirmId ? $(confirmId) : null;
  const guide = $(guideId);
  if (!input || !guide || guide.dataset.bound === '1') return;
  ensurePasswordGuideContent(guide, Number(input.minLength) || Number(guide.dataset.minLength) || 12);
  addPasswordVisibilityToggle(input);
  addPasswordVisibilityToggle(confirmInput);
  guide.dataset.bound = '1';
  const refresh = () => {
    const state = updatePasswordGuide(guide, input, confirmInput);
    onChange?.(state);
  };
  input.addEventListener('input', refresh);
  confirmInput?.addEventListener('input', refresh);
  refresh();
}

function requirePasswordPolicy(value, minLength, label = 'Password') {
  const policy = passwordPolicy(value, minLength);
  if (!policy.complete) throw new Error(`${label} must satisfy every strong-password requirement shown: minimum length, lowercase, capital, number, special character, no repeated pattern, no common sequence, and enough character variety.`);
  return policy;
}

function updateFirstRunSecurityStatus() {
  if (!els.firstRunAuthenticatorStatus) return;
  const protection = vault ? vaultTotpProtection() : { enabled:false };
  if (!vault) {
    els.firstRunAuthenticatorStatus.textContent = 'Create the encrypted vault first';
    if (els.firstRunAuthenticator) {
      els.firstRunAuthenticator.textContent = 'Create vault first';
      els.firstRunAuthenticator.disabled = true;
    }
    return;
  }
  els.firstRunAuthenticatorStatus.textContent = protection.enabled
    ? 'Enabled - save the recovery codes outside VaultCove'
    : 'Recommended before storing important logins';
  if (els.firstRunAuthenticator) {
    els.firstRunAuthenticator.textContent = protection.enabled ? 'Authenticator enabled' : 'Set up now';
    els.firstRunAuthenticator.disabled = Boolean(protection.enabled);
  }
}



function startupModePanel(mode) {
  return document.querySelector(`[data-startup-mode-panel="${mode}"]`);
}

function setStartupImportIntent(mode, { resetPending = true } = {}) {
  const next = ['fresh','vcvault','migration'].includes(mode) ? mode : 'fresh';
  startupImportIntent = next;
  if (resetPending) pendingStartupImport = null;
  for (const panel of document.querySelectorAll('[data-startup-mode-panel]')) {
    panel.classList.toggle('hidden', panel.dataset.startupModePanel !== next);
  }
  const preview = $('startupImportPreview');
  if (preview) {
    preview.innerHTML = '';
    preview.classList.add('hidden');
    preview.classList.remove('error');
  }
  if (els.startupApplyPreparedImport) {
    els.startupApplyPreparedImport.classList.add('hidden');
    els.startupApplyPreparedImport.disabled = false;
    els.startupApplyPreparedImport.textContent = 'Merge into this vault';
  }
}

function validateStartupImportReady() {
  if (startupImportIntent === 'fresh') return true;
  if (startupImportIntent === 'vcvault' && pendingStartupImport?.kind === 'vcvault') return true;
  if (startupImportIntent === 'migration' && pendingStartupImport?.kind === 'migration') return true;
  if (startupImportIntent === 'vcvault') throw new Error('Verify the selected .vcvault with its exact Backup Key before creating the vault.');
  throw new Error('Wait for VaultCove to detect and preview the selected password-manager export before creating the vault.');
}

function resetStartupImportToFresh() {
  pendingStartupImport = null;
  startupImportIntent = 'fresh';
  if ($('startupVaultBackupFile')) $('startupVaultBackupFile').value = '';
  if ($('startupMigrationFile')) $('startupMigrationFile').value = '';
  if ($('startupVaultBackupKey')) $('startupVaultBackupKey').value = '';
  if ($('startupVaultBackupName')) $('startupVaultBackupName').textContent = 'No file selected';
  if ($('startupMigrationName')) $('startupMigrationName').textContent = 'No file selected';
  setStartupImportIntent('fresh', { resetPending:false });
}

function updateStartupSelectedFile(id, file, fallback = 'No file selected') {
  const mount = $(id);
  if (!mount) return;
  mount.textContent = file?.name || fallback;
}

function updateFirstRunFinishAvailability() {
  if (!els.firstRunFinish) return;

  const email = String(els.firstRunSecurityEmail?.value || '').trim();
  const emailValid = validSecurityEmail(email);
  const emailEntered = Boolean(email);

  if (els.firstRunSecurityEmail) {
    els.firstRunSecurityEmail.classList.toggle('validField', emailValid);
    els.firstRunSecurityEmail.classList.toggle('invalidField', emailEntered && !emailValid);
    els.firstRunSecurityEmail.setAttribute('aria-invalid', String(emailEntered && !emailValid));
  }

  if (els.firstRunSecurityEmailStatus) {
    els.firstRunSecurityEmailStatus.classList.toggle('valid', emailValid);
    els.firstRunSecurityEmailStatus.classList.toggle('invalid', emailEntered && !emailValid);
    els.firstRunSecurityEmailStatus.textContent = emailValid
      ? 'Valid email format. This address will be saved locally for security notices.'
      : emailEntered
        ? 'Enter a complete valid email address, for example name@example.com.'
        : 'Required before Finish Setup.';
  }

  const ready = Boolean(
    vault &&
    emailValid &&
    els.firstRunMasterAck?.checked &&
    els.firstRunRemovalAck?.checked
  );
  els.firstRunFinish.disabled = !ready;
  els.firstRunFinish.setAttribute('aria-disabled', String(!ready));
}

function startupImportFileSignature(file) {
  if (!file) return '';
  return `${file.name}|${file.size}|${file.lastModified}`;
}

function showStartupImportPreview(html, { error = false } = {}) {
  const mount = $('startupImportPreview');
  if (!mount) return;
  mount.classList.remove('hidden');
  mount.classList.toggle('error', Boolean(error));
  mount.innerHTML = html;
  keepStartupImportResultVisible();
}

function keepStartupImportResultVisible() {
  requestAnimationFrame(() => {
    const apply = els.startupApplyPreparedImport;
    const actionVisible = Boolean(apply && !apply.classList.contains('hidden'));
    const target = actionVisible ? apply : $('startupImportPreview');
    target?.scrollIntoView({
      block: actionVisible ? 'center' : 'nearest',
      inline:'nearest'
    });
  });
}


function cloneForMergePreview(value) {
  return value == null ? value : JSON.parse(JSON.stringify(value));
}

function startupMergeSummary(result = {}) {
  return {
    added: Number(result.accepted?.length || 0),
    merged: Number(result.mergedCount ?? result.merged?.length ?? 0),
    unchanged: Number(result.unchanged || 0),
    conflicts: Number(result.conflicts || 0)
  };
}

function startupMergeSummaryHtml(result = {}) {
  const summary = startupMergeSummary(result);
  return `<div class="startupMergeSummary">
    <span><strong>${summary.added}</strong> new</span>
    <span><strong>${summary.merged}</strong> merged</span>
    <span><strong>${summary.unchanged}</strong> already matched</span>
    <span><strong>${summary.conflicts}</strong> secret conflict${summary.conflicts === 1 ? '' : 's'} preserved</span>
  </div>`;
}

function showStartupPreparedApplyButton(label = 'Merge into this vault', { enabled = Boolean(vault) } = {}) {
  if (!els.startupApplyPreparedImport) return;
  els.startupApplyPreparedImport.textContent = label;
  els.startupApplyPreparedImport.disabled = !enabled;
  els.startupApplyPreparedImport.setAttribute('aria-disabled', String(!enabled));
  els.startupApplyPreparedImport.setAttribute(
    'aria-label',
    enabled
      ? `${label}. Merge the detected password-manager records into this encrypted vault now.`
      : `${label}. Create the encrypted vault first; the selected import will then be applied automatically.`
  );
  els.startupApplyPreparedImport.classList.remove('hidden');
  keepStartupImportResultVisible();
}

function mergeBackupFoldersIntoCurrentVault(incomingVault) {
  const cloned = cloneForMergePreview(incomingVault) || { items:[], folders:[] };
  const folderIdMap = new Map();

  for (const incomingFolder of cloned.folders || []) {
    const name = String(incomingFolder?.name || '').trim();
    if (!name) continue;
    let target = (vault.folders || []).find((folder) => String(folder.name || '').trim().toLowerCase() === name.toLowerCase());
    if (!target) target = createFolder(vault, name);
    folderIdMap.set(String(incomingFolder.id || ''), target.id);
  }

  for (const item of cloned.items || []) {
    if (!item?.folderId) continue;
    item.folderId = folderIdMap.get(String(item.folderId)) || null;
  }
  return cloned;
}

async function preparedBackupMergeItems(decrypted) {
  if (!isComponentBackupSnapshot(decrypted)) {
    const incoming = mergeBackupFoldersIntoCurrentVault(normalizeVault(decrypted));
    return (incoming.items || []).filter((item) => !item.deletedAt && item.sharedAccess?.mode !== 'use-only');
  }

  const state = await loadUnlockedVault({ touch:false });
  if (state.state !== 'unlocked' || !state.vaultKey) throw new Error('Unlock the current VaultCove before merging this .vcvault.');

  const restored = await restoreBackupSnapshot(normalizeVault(cloneForMergePreview(vault)), decrypted, { vaultKey:state.vaultKey });
  const backupIds = new Set(
    (decrypted?.vault?.items || [])
      .filter((item) => item && !item.deletedAt && item.sharedAccess?.mode !== 'use-only')
      .map((item) => String(item.id || ''))
      .filter(Boolean)
  );

  const incoming = mergeBackupFoldersIntoCurrentVault({
    ...restored.vault,
    items: (restored.vault?.items || []).filter((item) => backupIds.has(String(item.id || '')))
  });
  return (incoming.items || []).filter((item) => !item.deletedAt && item.sharedAccess?.mode !== 'use-only');
}

function clearCompletedStartupImportSelection() {
  pendingStartupImport = null;
  startupImportIntent = 'fresh';
  if (els.startupVaultBackupFile) els.startupVaultBackupFile.value = '';
  if (els.startupMigrationFile) els.startupMigrationFile.value = '';
  if (els.startupVaultBackupKey) els.startupVaultBackupKey.value = '';
  updateStartupSelectedFile('startupVaultBackupName', null);
  updateStartupSelectedFile('startupMigrationName', null);
  for (const panel of document.querySelectorAll('[data-startup-mode-panel]')) panel.classList.add('hidden');
  if (els.startupApplyPreparedImport) {
    els.startupApplyPreparedImport.disabled = false;
    els.startupApplyPreparedImport.classList.add('hidden');
    els.startupApplyPreparedImport.textContent = 'Merge into this vault';
  }
}

async function applyPreparedImportIntoExistingVault() {
  if (!vault) throw new Error('Create or unlock the local VaultCove before merging another backup.');
  if (!pendingStartupImport) throw new Error('Choose and verify an import first.');

  let result;
  let source = '';

  if (pendingStartupImport.kind === 'migration') {
    const migration = pendingStartupImport.migration;
    source = migration.source;
    result = mergeImportedItems(vault.items, migration.items, {
      skipDuplicates:true,
      mergeDuplicates:true
    });
  } else if (pendingStartupImport.kind === 'vcvault') {
    source = '.vcvault';
    const incomingItems = await preparedBackupMergeItems(pendingStartupImport.decrypted);
    result = mergeImportedItems(vault.items, incomingItems, {
      skipDuplicates:true,
      mergeDuplicates:true
    });
  } else {
    throw new Error('Unsupported startup import selection.');
  }

  vault.items.push(...result.accepted);
  vault.updatedAt = new Date().toISOString();
  await appendActivityEvent(vault, 'startup-existing-vault-merge', {
    source,
    added:result.accepted.length,
    merged:result.mergedCount,
    unchanged:result.unchanged,
    conflicts:result.conflicts
  });
  await saveUnlockedVault(vault);

  const summaryHtml = startupMergeSummaryHtml(result);
  clearCompletedStartupImportSelection();
  showStartupImportPreview(`<strong>Merge complete</strong><span>${escapeHtml(source)} was merged into this vault without creating duplicate records.</span>${summaryHtml}<small>Existing conflicting passwords, TOTP secrets, card numbers, bank identifiers, PINs, and government IDs were preserved.</small>`);
  const summary = startupMergeSummary(result);
  toast(`${summary.added} new, ${summary.merged} merged, ${summary.unchanged} already matched.`);
  return result;
}

function clearPendingStartupImport(message = 'Startup import selection changed. Verify the file again before creating the vault.') {
  pendingStartupImport = null;
  showStartupImportPreview(`<span>${escapeHtml(message)}</span>`);
}

async function previewStartupVaultBackup() {
  try {
    const file = $('startupVaultBackupFile')?.files?.[0];
    const recoveryCredential = String($('startupVaultBackupKey')?.value || '').trim();
    if (!file) throw new Error('Choose a .vcvault backup first.');
    if (!recoveryCredential) throw new Error('Enter the Backup Key or Disaster Recovery Master Password for this .vcvault.');
    if (file.size > 100 * 1024 * 1024) throw new Error('Encrypted backup exceeds the 100 MB startup restore safety limit.');
    const payloadText = await file.text();
    const payload = JSON.parse(payloadText);
    let decrypted;
    let disasterRecovery = false;
    let backupId = '';
    let emailVerified = false;

    if (isDisasterRecoveryExport(payload)) {
      const recovery = await decryptDisasterRecoveryExport(payload, recoveryCredential);
      await verifyDisasterRecoveryEmail(recovery.backupId, recovery.recoveryEmail);
      decrypted = recovery.snapshot;
      disasterRecovery = true;
      backupId = recovery.backupId;
      emailVerified = true;
    } else {
      decrypted = await decryptPortableExport(payload, recoveryCredential);
    }

    const summary = backupSnapshotSummary(decrypted);
    startupImportIntent = 'vcvault';
    pendingStartupImport = {
      kind:'vcvault',
      fileSignature:startupImportFileSignature(file),
      recoveryCredential,
      payloadText,
      decrypted,
      summary,
      disasterRecovery,
      backupId,
      emailVerified
    };
    const verifiedLabel = disasterRecovery ? 'Disaster Recovery verified' : '.vcvault verified';
    const authNote = disasterRecovery
      ? 'Master Password verified locally - recovery email verified with a fresh six-digit code'
      : 'unique Backup Key verified locally';
    showStartupImportPreview(`<strong>${verifiedLabel}</strong><span>${summary?.legacy ? 'Legacy full-vault backup' : `Backup v${escapeHtml(summary?.version)}`} - ${escapeHtml(summary?.createdAt ? new Date(summary.createdAt).toLocaleString() : 'date unknown')}</span><small>${(summary?.selected || []).map(escapeHtml).join(' - ') || 'Vault data detected'}${summary?.recoveryMaterial ? ' - unified recovery material included' : ''}</small><small>${escapeHtml(authNote)}</small>${vault ? '<small>Duplicate-aware merge is ready. Existing conflicting secrets will be preserved. If you do not merge it now, Finish Setup will apply this verified backup automatically.</small>' : '<small>This verified backup will be applied automatically when the encrypted vault is created.</small>'}`);
    if (vault) showStartupPreparedApplyButton('Merge verified .vcvault');
    toast(disasterRecovery ? 'Disaster Recovery backup verified. Master Password and recovery email checks passed.' : 'Startup .vcvault verified. Its exact Backup Key will be required again if you restore this file later.');
  } catch (error) {
    pendingStartupImport = null;
    showStartupImportPreview(`<strong>Backup verification failed</strong><span>${escapeHtml(error.message)}</span>`, { error:true });
    toast(error.message, true);
  }
}

async function previewStartupMigration() {
  try {
    const file = $('startupMigrationFile')?.files?.[0];
    if (!file) throw new Error('Choose a password-manager CSV export first.');
    if (file.size > MIGRATION_LIMITS.maxBytes) throw new Error('For safety, migration files are limited to 25 MB.');
    const text = await file.text();
    const migration = importMigrationCsv(text);
    startupImportIntent = 'migration';
    pendingStartupImport = {
      kind: 'migration',
      fileSignature: startupImportFileSignature(file),
      migration
    };
    const counts = migration.items.reduce((out, item) => { out[item.type] = (out[item.type] || 0) + 1; return out; }, {});
    let mergePreview = '';
    if (vault) {
      const previewResult = mergeImportedItems(cloneForMergePreview(vault.items || []), cloneForMergePreview(migration.items), {
        skipDuplicates:true,
        mergeDuplicates:true
      });
      mergePreview = `${startupMergeSummaryHtml(previewResult)}<small>Matching records will be merged. Existing conflicting secrets stay unchanged.</small>`;
    }

    // Every supported password-manager CSV gets the same visible merge action.
    // Before the encrypted vault exists the action stays visible but disabled; Create Vault / Enter
    // will apply the prepared import automatically. After a vault exists it becomes immediately usable.
    showStartupPreparedApplyButton(`Merge ${migration.source}`, { enabled:Boolean(vault) });

    showStartupImportPreview(`<strong>${escapeHtml(migration.source)} detected automatically</strong><span>${migration.items.length} item(s) detected</span><small>${Object.entries(counts).map(([type,count]) => `${escapeHtml(type)}: ${count}`).join(' - ')}</small>${mergePreview}<small>${vault ? 'Finish Setup will apply this prepared import automatically if you do not merge it now.' : 'The detected records will be applied automatically when the encrypted vault is created.'}</small>`);
    toast(vault ? `${migration.source} detected. Review the merge summary, then merge it into this vault.` : `${migration.source} detected automatically. The imported records will be encrypted after the new vault is created.`);
  } catch (error) {
    pendingStartupImport = null;
    showStartupImportPreview(`<strong>Import detection failed</strong><span>${escapeHtml(error.message)}</span>`, { error:true });
    toast(error.message, true);
  }
}

async function prepareSelectedStartupImportForFinish() {
  if (startupImportIntent === 'fresh') return null;

  if (startupImportIntent === 'migration') {
    const file = els.startupMigrationFile?.files?.[0];
    if (!file) throw new Error('Choose the password-manager CSV export again before finishing setup.');
    const signature = startupImportFileSignature(file);
    if (pendingStartupImport?.kind !== 'migration' || pendingStartupImport.fileSignature !== signature) {
      await previewStartupMigration();
    }
    if (pendingStartupImport?.kind !== 'migration' || pendingStartupImport.fileSignature !== signature) {
      throw new Error('VaultCove could not prepare the selected password-manager export. Review the startup import message and try again.');
    }
    return pendingStartupImport;
  }

  if (startupImportIntent === 'vcvault') {
    const file = els.startupVaultBackupFile?.files?.[0];
    const recoveryCredential = String(els.startupVaultBackupKey?.value || '').trim();
    if (!file) throw new Error('Choose the .vcvault backup again before finishing setup.');
    if (!recoveryCredential) throw new Error('Enter the Backup Key or Disaster Recovery Master Password for the selected .vcvault before finishing setup.');
    const signature = startupImportFileSignature(file);
    if (
      pendingStartupImport?.kind !== 'vcvault' ||
      pendingStartupImport.fileSignature !== signature ||
      pendingStartupImport.recoveryCredential !== recoveryCredential
    ) {
      await previewStartupVaultBackup();
    }
    if (
      pendingStartupImport?.kind !== 'vcvault' ||
      pendingStartupImport.fileSignature !== signature ||
      pendingStartupImport.recoveryCredential !== recoveryCredential
    ) {
      throw new Error('VaultCove could not verify the selected .vcvault. Review the backup credential and startup restore message, then try again.');
    }
    return pendingStartupImport;
  }

  throw new Error('Unsupported startup import selection.');
}

async function applySelectedStartupImportBeforeFinish() {
  await prepareSelectedStartupImportForFinish();
  if (!pendingStartupImport) return { applied:false, message:'' };
  const result = await applyPreparedImportIntoExistingVault();
  const summary = startupMergeSummary(result);
  return {
    applied:true,
    message:`Startup import applied: ${summary.added} new, ${summary.merged} merged, ${summary.unchanged} already matched.`
  };
}

async function applyPendingStartupImport() {
  if (!pendingStartupImport) return { applied:false, message:'' };
  if (pendingStartupImport.kind === 'migration') {
    const migration = pendingStartupImport.migration;
    const merged = mergeImportedItems(vault.items, migration.items, { skipDuplicates:true, mergeDuplicates:true });
    vault.items.push(...merged.accepted);
    await appendActivityEvent(vault, 'startup-migration-imported', {
      source:migration.source,
      imported:merged.accepted.length,
      merged:merged.mergedCount,
      unchanged:merged.unchanged,
      conflicts:merged.conflicts
    });
    await saveUnlockedVault(vault);
    return { applied:true, message:`${merged.accepted.length} new and ${merged.mergedCount} merged item(s) from ${migration.source}.` };
  }

  if (pendingStartupImport.kind === 'vcvault') {
    const decrypted = pendingStartupImport.decrypted;
    if (!isComponentBackupSnapshot(decrypted)) {
      vault = normalizeVault(decrypted);
      await appendActivityEvent(vault, 'startup-backup-restored', { mode:'legacy-full-vault', items:vault.items.length });
      await saveUnlockedVault(vault);
      return { applied:true, message:`Legacy .vcvault restored with ${vault.items.length} item(s).` };
    }
    const state = await loadUnlockedVault({ touch:false });
    if (state.state !== 'unlocked' || !state.vaultKey) throw new Error('The new VaultCove could not open its local encryption key for startup restore.');
    const result = await restoreBackupSnapshot(vault, decrypted, { vaultKey:state.vaultKey });
    vault = result.vault;
    await appendActivityEvent(vault, 'startup-backup-restored', { mode:'component', version:Number(decrypted.version || 0) });
    await saveUnlockedVault(vault);
    if (result.recoveryMaterial?.deviceRecoveryToken) await setDeviceRecoveryToken(result.recoveryMaterial.deviceRecoveryToken);
    if (result.settings || result.recoveryMaterial?.vaultTotp) {
      await setSettings({
        ...(result.settings || {}),
        ...(result.recoveryMaterial?.vaultTotp ? { vaultTotpEnabled:Boolean(result.recoveryMaterial.vaultTotp.enabled) } : {}),
        disasterRecoveryEnabled:false,
        disasterRecoveryPending:false,
        disasterRecoveryDueAt:null,
        firstRunSecurityComplete:false
      });
    }
    return { applied:true, message:`Verified .vcvault restored${result.recoveryMaterial ? ' with unified recovery material' : ''}.` };
  }
  return { applied:false, message:'' };
}

function showUnifiedFirstRunSetup({ vaultReady = Boolean(vault), preserveInputs = false } = {}) {
  // A stale setup callback must never win a race against Lock. If this installation
  // already has a vault but the decrypted in-memory vault is gone, the only legal
  // UI is the existing-master-password gate.
  if ((establishedVaultInstallation && !vault) || uiSessionState === 'locked') {
    markUiSessionState('locked');
    showGate('unlockPanel');
    return false;
  }
  markUiSessionState(vaultReady ? 'unlocked' : 'setup');
  showGate('setupPanel');
  els.setupPanel?.classList.toggle('vaultReady', Boolean(vaultReady));

  if (els.firstRunSetupTitle) {
    els.firstRunSetupTitle.textContent = vaultReady ? 'Finish setting up VaultCove' : 'Set up VaultCove';
  }
  if (els.firstRunSetupSubtitle) {
    els.firstRunSetupSubtitle.textContent = vaultReady
      ? 'Vault ready. Finish security, restore/import if needed, or activate Premium.'
      : 'Create your local vault. Restore or import only if you need it.';
  }
  if (els.startupPreviewVaultBackup) {
    els.startupPreviewVaultBackup.textContent = vaultReady ? 'Verify for merge' : 'Verify backup locally';
  }

  if (!preserveInputs) {
    if (els.firstRunProfileName) {
      els.firstRunProfileName.value = normalizedProfileName(settingsState?.profileName) === 'VaultCove User'
        ? ''
        : normalizedProfileName(settingsState?.profileName);
    }
    if (els.firstRunSecurityEmail) els.firstRunSecurityEmail.value = settingsState?.securityNoticeEmail || '';
    if (els.firstRunEmailNotice) els.firstRunEmailNotice.checked = settingsState?.securityEmailNoticeEnabled !== false;
    if (els.firstRunLockMinutes) els.firstRunLockMinutes.value = String(Math.max(1, Math.min(120, Number(settingsState?.lockMinutes) || 5)));
    if (els.firstRunMasterAck) els.firstRunMasterAck.checked = false;
    if (els.firstRunRemovalAck) els.firstRunRemovalAck.checked = false;
  }

  applyProfileIdentity();

  if (els.setupSubmit) {
    els.setupSubmit.textContent = vaultReady ? 'Encrypted vault created' : 'Create encrypted vault';
    els.setupSubmit.disabled = Boolean(vaultReady) || els.setupSubmit.disabled;
  }
  if (els.setupVaultStatus) {
    els.setupVaultStatus.textContent = vaultReady
      ? ''
      : 'Create the encrypted vault before finishing setup.';
    els.setupVaultStatus.classList.toggle('ready', Boolean(vaultReady));
    els.setupVaultStatus.classList.toggle('hidden', Boolean(vaultReady));
  }

  if (els.firstRunSecurityError) {
    els.firstRunSecurityError.textContent = '';
    els.firstRunSecurityError.classList.add('hidden');
  }

  updateFirstRunSecurityStatus();
  updateFirstRunFinishAvailability();
}

function installNavigationIcons() {
  const icons = { dashboard:'dashboard', all:'vault', favorites:'favorite', login:'login', card:'card', bank:'bank', identity:'identity', note:'note', totp:'totp', generator:'generator', security:'security', guardian:'security', migration:'migration', shared:'shared', premium:'premium', license:'devices', backup:'backup', trash:'trash', settings:'settings', support:'support' };
  document.querySelectorAll('nav button[data-view]').forEach((button) => {
    const mount = button.querySelector('.navIcon');
    if (mount) mount.innerHTML = uiIcon(icons[button.dataset.view] || 'vault', 16);
  });
}

installNavigationIcons();

function escapeHtml(value) {
  return String(value ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#039;');
}

function escapeAttr(value) {
  return escapeHtml(value);
}

async function downloadTextFile(text, filename) {
  const blob = new Blob([String(text || '')], { type: 'text/plain;charset=utf-8' });
  return saveBlob(blob, filename, { description: 'VaultCove public identity text', mime: 'text/plain' });
}

function publicIdentityText(identity) {
  return [
    'VaultCove Public Sharing Identity',
    '================================',
    '',
    `Display Name: ${identity.displayName || 'VaultCove User'}`,
    `Share ID: ${identity.shareId}`,
    `Fingerprint: ${identity.fingerprint}`,
    `Exported/Converted: ${new Date().toISOString()}`,
    '',
    'Encryption Public Key (JWK)',
    JSON.stringify(identity.encryptionPublicJwk, null, 2),
    '',
    'Signing Public Key (JWK)',
    JSON.stringify(identity.signingPublicJwk, null, 2),
    '',
    'SECURITY NOTE',
    'This TXT contains public sharing identity data only. It does not contain the VaultCove master password, .vckey password, saved website credentials, TOTP secrets, or private sharing keys.'
  ].join('\n');
}

async function runtimeMessage(payload) {
  const response = await chrome.runtime.sendMessage(payload);
  if (!response?.ok) { const error = new Error(response?.error || 'VaultCove request failed.'); Object.assign(error, response); throw error; }
  return response;
}

async function queueSecurityEventNotice(eventKind, { recordType = '', shareCount = 0, recipientHint = '', occurredAt = '' } = {}) {
  return runtimeMessage({
    type:'SECURITY_EVENT_NOTICE',
    eventKind:String(eventKind || ''),
    recordType:String(recordType || ''),
    shareCount:Math.max(0, Math.min(50, Number(shareCount) || 0)),
    recipientHint:String(recipientHint || '').slice(0,120),
    occurredAt:String(occurredAt || new Date().toISOString()).slice(0,40)
  });
}

function maskedRecipientHint(email = '') {
  const value = String(email || '').trim().toLowerCase();
  const at = value.indexOf('@');
  if (at <= 0) return 'saved recipient';
  const local = value.slice(0, at);
  const domain = value.slice(at + 1);
  if (!domain) return 'saved recipient';
  const visible = local.slice(0, 1);
  return `${visible}${'*'.repeat(Math.min(5, Math.max(3, local.length - 1)))}@${domain}`.slice(0,120);
}

function closeSensitiveDialog() {
  els.sensitivePassword.value = '';
  if (els.sensitiveTotp) els.sensitiveTotp.value = '';
  if (els.sensitiveError) { els.sensitiveError.textContent = ''; els.sensitiveError.classList.add('hidden'); }
  pendingSensitiveAction = null;
  if (els.sensitiveDialog.open) els.sensitiveDialog.close();
}

async function ensureSensitiveAccess(reason, action) {
  if (await hasSensitiveAccess()) return action();
  pendingSensitiveAction = action;
  els.sensitiveReason.textContent = reason;
  els.sensitivePassword.value = '';
  if (els.sensitiveTotp) els.sensitiveTotp.value = '';
  if (els.sensitiveTotpLabel) els.sensitiveTotpLabel.classList.toggle('hidden', !settingsState?.vaultTotpEnabled);
  if (els.sensitiveError) { els.sensitiveError.textContent = ''; els.sensitiveError.classList.add('hidden'); }
  els.sensitiveDialog.showModal();
  setTimeout(() => els.sensitivePassword.focus(), 0);
  return undefined;
}


async function ensureFreshSensitiveAccess(reason, action) {
  // Some identity/key operations intentionally require a new master-password
  // verification every time rather than inheriting the short Sensitive Access window.
  await clearSensitiveAccess();
  return ensureSensitiveAccess(reason, action);
}


async function ensureProtectedCategoryAccess(reason, action) {
  if (Date.now() < protectedCategoryAccessUntil) return action();
  await clearSensitiveAccess();
  return ensureSensitiveAccess(reason, async () => {
    protectedCategoryAccessUntil = Date.now() + PROTECTED_CATEGORY_ACCESS_MS;
    return action();
  });
}


function closeVckeyDialog(error = null) {
  const pending = pendingVckeyOperation;
  pendingVckeyOperation = null;
  if ($('vckeyPassword')) $('vckeyPassword').value = '';
  if ($('vckeyPasswordConfirm')) $('vckeyPasswordConfirm').value = '';
  if ($('vckeyError')) { $('vckeyError').textContent = ''; $('vckeyError').classList.add('hidden'); }
  if (els.vckeyDialog?.open) els.vckeyDialog.close();
  if (pending && error) pending.reject(error);
}

function requestVckeyPassword(mode) {
  if (pendingVckeyOperation) return Promise.reject(new Error('Another .vckey password operation is already open.'));
  return new Promise((resolve, reject) => {
    pendingVckeyOperation = { mode, resolve, reject };
    $('vckeyDialogTitle').textContent = mode === 'export' ? 'Protect exported .vckey' : mode === 'convert' ? 'Decrypt .vckey for TXT conversion' : 'Unlock imported .vckey';
    $('vckeyDialogSubtitle').textContent = mode === 'export'
      ? 'Create a password only for this .vckey file. It must be different from and is never a replacement for your VaultCove master password.'
      : mode === 'convert'
        ? 'Enter the separate password that protects this .vckey file. Google Authenticator authorization is checked separately before VaultCove permits plaintext conversion.'
        : "Enter the separate password chosen when this .vckey was exported. Your VaultCove master password is not used to decrypt another person's .vckey.";
    $('vckeyConfirmLabel').classList.toggle('hidden', mode !== 'export');
    $('vckeyPasswordGuide')?.classList.toggle('hidden', mode !== 'export');
    $('vckeyPassword').value = '';
    $('vckeyPasswordConfirm').value = '';
    $('vckeyError').textContent = '';
    $('vckeyError').classList.add('hidden');
    if ($('confirmVckey')) $('confirmVckey').disabled = mode === 'export';
    updatePasswordGuide($('vckeyPasswordGuide'), $('vckeyPassword'), mode === 'export' ? $('vckeyPasswordConfirm') : null);
    els.vckeyDialog.showModal();
    setTimeout(() => $('vckeyPassword').focus(), 0);
  });
}
function closeLicenseOtpDialog(error = null) {
  const pending = pendingLicenseOtp;
  pendingLicenseOtp = null;
  $('licenseOtpCode').value = '';
  $('licenseOtpError').textContent = '';
  $('licenseOtpError').classList.add('hidden');
  if (els.licenseOtpDialog?.open) els.licenseOtpDialog.close();
  if (pending && error) pending.reject(error);
}

function requestLicenseOtp({ title, subtitle, onVerify }) {
  if (pendingLicenseOtp) return Promise.reject(new Error('A license verification prompt is already open.'));
  return new Promise((resolve, reject) => {
    pendingLicenseOtp = { resolve, reject, onVerify };
    $('licenseOtpTitle').textContent = title;
    $('licenseOtpSubtitle').textContent = subtitle;
    $('licenseOtpCode').value = '';
    $('licenseOtpError').textContent = '';
    $('licenseOtpError').classList.add('hidden');
    els.licenseOtpDialog.showModal();
    setTimeout(() => $('licenseOtpCode').focus(), 0);
  });
}


function closeLicenseReclaimDialog(error = null) {
  const pending = pendingLicenseReclaim;
  pendingLicenseReclaim = null;
  if ($('licenseReclaimError')) { $('licenseReclaimError').textContent = ''; $('licenseReclaimError').classList.add('hidden'); }
  if (els.licenseReclaimDialog?.open) els.licenseReclaimDialog.close();
  if (pending && error) pending.reject(error);
}
function requestLicenseReclaim(result, deviceLabel, serial) {
  if (pendingLicenseReclaim) return Promise.reject(new Error('A device recovery selection is already open.'));
  const candidates = Array.isArray(result?.reclaimCandidates) ? result.reclaimCandidates : [];
  return new Promise((resolve, reject) => {
    pendingLicenseReclaim = { resolve, reject, result, deviceLabel, serial };
    const select = $('licenseReclaimSelect');
    select.innerHTML = candidates.map((device) => {
      const last = device.lastSeenAt ? new Date(device.lastSeenAt).toLocaleString() : 'unknown';
      return `<option value="${escapeHtml(device.installationId)}">Reclaim ${escapeHtml(device.deviceLabel || 'VaultCove device')} - ${escapeHtml(device.platform || 'unknown platform')} - last seen ${escapeHtml(last)}</option>`;
    }).join('') + (Number(result.usedDevices || 0) < Number(result.maxDevices || 0) ? '<option value="__new__">Use a new device slot instead</option>' : '');
    $('licenseReclaimError').textContent = '';
    $('licenseReclaimError').classList.add('hidden');
    els.licenseReclaimDialog.showModal();
    setTimeout(() => select.focus(), 0);
  });
}

async function refreshHandlerPermissions() {
  const result = await runtimeMessage({ type: 'LIST_SITE_HANDLERS' });
  handlerPermissionState = Array.isArray(result.origins) ? result.origins : [];
  return handlerPermissionState;
}

async function refreshUpdateBanner({ force = false } = {}) {
  const mount = $('updateBanner');
  if (!mount || !settingsState?.updateChecksEnabled) return;
  try {
    const result = await runtimeMessage({ type: 'CHECK_FOR_UPDATES', force });
    if (!result.enabled) return;
    if (result.updateAvailable) {
      mount.innerHTML = `<div class="updateNotice ${result.critical ? 'critical' : ''}"><div><strong>${result.critical ? 'Security update available' : 'VaultCove update available'} - ${escapeHtml(result.version)}</strong><span>${escapeHtml(result.summary || 'A newer verified developer release is available from the official VaultCove release repository.')}</span></div><div><button id="updateNotes" class="outline">View release</button><button id="updateDownload">Download update</button></div></div>`;
      $('updateNotes')?.addEventListener('click', () => { if (result.notesUrl) chrome.tabs.create({ url: result.notesUrl }); });
      $('updateDownload')?.addEventListener('click', () => { if (result.downloadUrl) chrome.tabs.create({ url: result.downloadUrl }); });
    } else {
      mount.innerHTML = `<div class="updateCurrent"><span>Developer update check: VaultCove ${escapeHtml(result.currentVersion || '')} is current</span><button id="manualUpdateCheck" class="linkButton">Check again</button></div>`;
      $('manualUpdateCheck')?.addEventListener('click', () => refreshUpdateBanner({ force: true }));
    }
  } catch (error) {
    mount.innerHTML = `<div class="updateCurrent mutedUpdate"><span>Update check unavailable. VaultCove continues fully offline.</span><button id="manualUpdateCheck" class="linkButton">Retry</button></div>`;
    $('manualUpdateCheck')?.addEventListener('click', () => refreshUpdateBanner({ force: true }));
  }
}

function clearDecryptedUi() {
  vault = null;
  clearInterval(totpTimer);
  els.content.replaceChildren();
  els.search.value = '';
  els.itemId.value = '';
  els.itemName.value = '';
  els.itemNotes.value = '';
  els.itemTags.value = '';
  els.dynamicFields.replaceChildren();
  els.exportSecret.textContent = '';
  if (els.itemDialog.open) els.itemDialog.close();
  if (els.secretDialog.open) els.secretDialog.close();
  if (els.sensitiveDialog.open) els.sensitiveDialog.close();
}

async function enforceUiAutoLock() {
  if (!vault) return;
  const expiresAt = await getSessionExpiry();
  if (!expiresAt || Date.now() >= expiresAt) {
    await runtimeMessage({ type: 'LOCK_VAULT' });
    enterLockedUi('Vault auto-locked. Enter your master password to unlock.');
  }
}

async function enforceSensitiveUiExpiry() {
  if (!vault || !els.itemDialog.open || !els.itemId.value) return;
  if (await hasSensitiveAccess()) return;
  els.itemDialog.close();
  els.dynamicFields.replaceChildren();
  els.itemId.value = '';
  toast('Sensitive Access expired. Decrypted item fields were closed; unsaved changes were discarded.');
}

let lastActivityTouch = 0;
async function markVaultActivity() {
  if (!vault) return;
  const now = Date.now();
  if (now - lastActivityTouch < 10000) return;
  lastActivityTouch = now;
  const touched = await touchSession().catch(() => false);
  if (!touched) await enforceUiAutoLock().catch(() => {});
}

async function markVaultActivityAfterExpiryCheck() {
  if (!vault) return;
  await enforceUiAutoLock();
  if (vault) await markVaultActivity();
}

function activeItems() { return Array.isArray(vault?.items) ? vault.items.filter((item) => !item.deletedAt) : []; }
function countType(type) { return activeItems().filter((item) => item.type === type).length; }

function itemMeta(item) {
  if (isUseOnlySharedLogin(item)) return sharedAccessLabel(item);
  if (item.type === 'login') return item.username ? maskIdentifier(item.username) : ((item.urls || [])[0] || 'Login');
  if (item.type === 'card') { const brand = String(item.brand || paymentCardBrand(item.number).label || 'Card'); return item.number ? `${brand} •••• ${item.number.replace(/\D/g,'').slice(-4)}` : item.cardholder || brand; }
  if (item.type === 'bank') return item.accountNumber ? `•••• ${item.accountNumber.replace(/\s/g,'').slice(-4)}` : item.bankName || 'Bank account';
  if (item.type === 'identity') {
    const displayName = [item.firstName,item.lastName].filter(Boolean).join(' ');
    return displayName || (item.email ? maskIdentifier(item.email) : 'Identity');
  }
  return 'Encrypted secure note';
}

function loginNicknameValue(item) {
  return item?.type === 'login' ? String(item.nickname || '').trim() : '';
}

function loginDisplayLabel(item) {
  if (!item || item.type !== 'login') return String(item?.name || 'Login');
  const nickname = loginNicknameValue(item);
  return nickname || String(item.name || 'Login');
}

function loginNicknameMarkup(item, { compact = false } = {}) {
  if (!item || item.type !== 'login' || isUseOnlySharedLogin(item)) return '';
  const nickname = loginNicknameValue(item);
  const label = nickname || 'Not set';
  return `<div class="loginNicknameDisplay ${nickname ? 'hasNickname' : 'missingNickname'} ${compact ? 'compact' : ''}"><span>Login name / nickname</span><strong>${escapeHtml(label)}</strong></div>`;
}

function itemTypeLabel(item) {
  if (isUseOnlySharedLogin(item)) return 'Shared Login Access';
  return ({login:'Login',card:'Card',bank:'Bank Account',identity:'Identity',note:'Note'})[item.type] || 'Item';
}

function itemIconName(itemOrType) {
  const type = typeof itemOrType === 'string' ? itemOrType : itemOrType?.type;
  return ({ login:'login', card:'card', bank:'bank', identity:'identity', note:'note', totp:'totp' })[type] || 'vault';
}

function passwordAgeBadge(item, { compact = false, showUnknown = true } = {}) {
  if (item?.type !== 'login' || isUseOnlySharedLogin(item)) return '';
  const age = passwordAgeState(item);
  if (age.state === 'unknown' && !showUnknown) return '';
  const label = age.state === 'unknown' ? 'Password age unknown' : age.label;
  const text = age.state === 'unknown' ? 'Age unknown' : age.needsReview ? `Review ${age.shortLabel}` : compact ? age.shortLabel : age.label;
  return `<span class="passwordAgeBadge age-${escapeHtml(age.state)}">${uiIcon(age.needsReview ? 'warningClock' : 'clock', 14)}<span>${escapeHtml(text)}</span></span>`;
}

function safeHostname(value) {
  try {
    const source = /^https?:/i.test(String(value || '')) ? String(value) : `https://${String(value || '')}`;
    return new URL(source).hostname.toLowerCase().replace(/^www\./, '');
  } catch { return ''; }
}


function loginHttpSecurityState(item) {
  if (!item || item.type !== 'login') return { insecure:false, url:'' };
  const url = (item.urls || []).find((value) => /^http:\/\//i.test(String(value || '').trim())) || '';
  return { insecure: Boolean(url && loginHasInsecureHttpUrl(item)), url:String(url || '') };
}

function httpWarningBadge(item) {
  const state = loginHttpSecurityState(item);
  return state.insecure ? '<span class="securityBadge insecureHttpBadge">Not secure - HTTP</span>' : '';
}
function visualHost(item) {
  if (item?.type !== 'login') return '';
  return safeHostname(item.siteVisual?.host || (item.urls || [])[0] || '');
}

function faviconUrl(item, size = 64) {
  if (!settingsState?.websiteIconsEnabled || !item?.siteVisual?.visitedAt) return '';
  const host = visualHost(item);
  if (!host) return '';
  const url = new URL(chrome.runtime.getURL('/_favicon/'));
  url.searchParams.set('pageUrl', `https://${host}/`);
  url.searchParams.set('size', String(size));
  return url.toString();
}

function siteCardVisual(item) {
  const host = visualHost(item);
  const icon = faviconUrl(item);
  const initials = (host || item.name || 'VC').replace(/[^a-z0-9]/gi, '').slice(0, 2).toUpperCase() || 'VC';
  return `<div class="siteCardVisual"><div class="siteFallback">${uiIcon('lock', 28, 'siteFallbackIcon')}<b>${escapeHtml(initials)}</b></div>${icon ? `<img data-vc-favicon src="${escapeHtml(icon)}" alt="">` : ''}</div>`;
}

function wireFaviconFallbacks(root = document) {
  root.querySelectorAll('[data-vc-favicon]').forEach((img) => {
    img.addEventListener('error', () => img.remove(), { once: true });
  });
}

function vaultTotpProtection() {
  return vault?.security?.vaultTotp || { enabled: false, secret: '', recoveryCodeHashes: [] };
}

function secondFactorLabelText() {
  return settingsState?.vaultTotpEnabled ? 'Authenticator or recovery code' : '';
}

function relativeTime(iso) {
  const value = Date.parse(iso || '');
  if (!Number.isFinite(value)) return '';
  const seconds = Math.max(0, Math.floor((Date.now() - value) / 1000));
  if (seconds < 60) return `${seconds}s ago`;
  const minutes = Math.floor(seconds / 60); if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60); if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24); if (days < 30) return `${days}d ago`;
  return new Date(value).toLocaleDateString();
}


function folderById(folderId) {
  return (vault?.folders || []).find((folder) => folder.id === folderId) || null;
}


function organizeReceivedSharedKeys(vaultState = vault) {
  if (!vaultState) return false;
  const sharedItems = (vaultState.items || []).filter((item) => isUseOnlySharedLogin(item));
  if (!sharedItems.length) return false;

  const ensured = ensureSharedKeysFolder(vaultState);
  const now = new Date().toISOString();
  let changed = Boolean(ensured.changed);

  for (const item of sharedItems) {
    if (item.folderId === ensured.folder.id) continue;
    item.folderId = ensured.folder.id;
    item.updatedAt = now;
    changed = true;
  }

  if (changed) vaultState.updatedAt = now;
  return changed;
}

function folderOptionsMarkup(selectedId = null, { includeAll = false, includeSystem = false } = {}) {
  const folders = [...(vault?.folders || [])]
    .filter((folder) => includeSystem || folder.system !== SHARED_KEYS_FOLDER_SYSTEM)
    .sort((a, b) => String(a.name || '').localeCompare(String(b.name || '')));
  const options = [];
  if (includeAll) options.push(`<option value="all"${selectedId === 'all' ? ' selected' : ''}>All folders</option>`);
  options.push(`<option value=""${!selectedId || selectedId === '' ? ' selected' : ''}>No Folder</option>`);
  for (const folder of folders) {
    options.push(`<option value="${escapeHtml(folder.id)}"${selectedId === folder.id ? ' selected' : ''}>${escapeHtml(folder.name)}</option>`);
  }
  return options.join('');
}

function folderChip(item) {
  const folder = item?.folderId ? folderById(item.folderId) : null;
  return folder ? `<span class="chip folderChip">${uiIcon('folder', 13)} ${escapeHtml(folder.name)}</span>` : '';
}

function vaultFolderToolbarMarkup() {
  if (currentView === 'totp' || currentView === 'trash') return '';
  if (activeFolderId !== 'all' && !folderById(activeFolderId)) activeFolderId = 'all';
  const sortMode = ['favorites','name','recent','oldest'].includes(settingsState?.vaultSortMode) ? settingsState.vaultSortMode : 'favorites';
  return `<div class="vaultFolderToolbar">
    <div class="vaultToolbarFields">
      <label>Folder<select id="vaultFolderFilter">${folderOptionsMarkup(activeFolderId, { includeAll: true, includeSystem: true })}</select></label>
      <label>Sort<select id="vaultSortMode">
        <option value="favorites" ${sortMode === 'favorites' ? 'selected' : ''}>Favorites first</option>
        <option value="name" ${sortMode === 'name' ? 'selected' : ''}>Name A-Z</option>
        <option value="recent" ${sortMode === 'recent' ? 'selected' : ''}>Recently updated</option>
        <option value="oldest" ${sortMode === 'oldest' ? 'selected' : ''}>Oldest updated</option>
      </select></label>
    </div>
    <div class="vaultToolbarActions"><button id="openVaultSettings" type="button" class="outline">${uiIcon('settings', 15)} Organize Vault</button></div>
  </div>`;
}

function wireVaultFolderToolbar() {
  $('vaultFolderFilter')?.addEventListener('change', () => {
    activeFolderId = $('vaultFolderFilter').value || '';
    selectedItemId = null;
    renderItems();
  });
  $('vaultSortMode')?.addEventListener('change', async () => {
    const next = ['favorites','name','recent','oldest'].includes($('vaultSortMode')?.value) ? $('vaultSortMode').value : 'favorites';
    settingsState.vaultSortMode = next;
    await setSettings({ vaultSortMode:next });
    renderItems();
  });
  $('openVaultSettings')?.addEventListener('click', openVaultSettingsDialog);
}

function vaultSettingsFolderRows() {
  const folders = [...(vault?.folders || [])].sort((a, b) => String(a.name || '').localeCompare(String(b.name || '')));
  if (!folders.length) return '<div class="emptyState compactEmpty">No folders yet. Create one below.</div>';
  return folders.map((folder) => {
    const count = (vault.items || []).filter((item) => !item.deletedAt && item.folderId === folder.id).length;
    const sharedSystem = folder.system === SHARED_KEYS_FOLDER_SYSTEM;
    return `<div class="folderSettingsRow ${sharedSystem ? 'systemFolderRow' : ''}" data-folder-row="${escapeHtml(folder.id)}">
      <input data-folder-name="${escapeHtml(folder.id)}" value="${escapeHtml(folder.name)}" maxlength="80" aria-label="Folder name" ${sharedSystem ? 'disabled' : ''}>
      <span>${count} item${count === 1 ? '' : 's'}${sharedSystem ? ' - received shared access' : ''}</span>
      ${sharedSystem
        ? '<button type="button" class="outline" disabled>Automatic</button><button type="button" class="outline" disabled>Protected</button>'
        : `<button type="button" class="outline" data-rename-folder="${escapeHtml(folder.id)}">Rename</button><button type="button" class="danger" data-delete-folder="${escapeHtml(folder.id)}">Delete</button>`}
    </div>`;
  }).join('');
}

function vaultSettingsLoginRows() {
  const logins = (vault.items || []).filter((item) => item.type === 'login' && !item.deletedAt && !isUseOnlySharedLogin(item))
    .sort((a, b) => loginDisplayLabel(a).localeCompare(loginDisplayLabel(b)));
  if (!logins.length) return '<div class="emptyState compactEmpty">No saved logins are available to organize.</div>';
  return logins.map((item) => {
    const folder = item.folderId ? folderById(item.folderId) : null;
    const searchText = [item.name, item.nickname, item.username, itemMeta(item), folder?.name || 'No Folder']
      .map((value) => String(value || '').toLowerCase())
      .join(' ');
    return `<label class="folderLoginRow" data-folder-login-row data-folder-search="${escapeHtml(searchText)}">
      <input type="checkbox" name="folderLoginIds" value="${escapeHtml(item.id)}">
      <span><strong>${escapeHtml(loginDisplayLabel(item))}</strong><small>${escapeHtml(item.nickname ? `${item.name} - ${itemMeta(item)}` : itemMeta(item))}</small></span>
      <em>${escapeHtml(folder?.name || 'No Folder')}</em>
    </label>`;
  }).join('');
}

function renderVaultSettingsDialog() {
  const mount = $('vaultSettingsMount');
  if (!mount) return;
  mount.innerHTML = `
    <section class="vaultSettingsSection">
      <div class="vaultSettingsSectionHead"><div><h3>Folders</h3><p>Create folders for encrypted vault organization. Deleting a folder never deletes its items; they return to No Folder.</p></div></div>
      <div id="folderSettingsRows" class="folderSettingsRows">${vaultSettingsFolderRows()}</div>
      <div class="createFolderRow"><input id="newFolderName" maxlength="80" placeholder="New folder name"><button id="createFolderButton" type="button">Create folder</button></div>
    </section>
    <section class="vaultSettingsSection">
      <div class="vaultSettingsSectionHead"><div><h3>Put logins in a folder</h3><p>Search, select one or more saved logins, choose a folder, then move them. Login passwords are never shown or searched in this organizer.</p></div><strong id="folderSelectedCount">0 selected</strong></div>
      <div class="folderLoginSearchWrap"><input id="folderLoginSearch" type="search" autocomplete="off" placeholder="Search logins by nickname, website, username, or folder" aria-label="Search saved logins"><span id="folderSearchCount"></span></div>
      <div class="folderBulkToolbar"><select id="folderTarget">${folderOptionsMarkup(null)}</select><button id="folderSelectAll" type="button" class="outline">Select visible</button><button id="folderClearSelection" type="button" class="outline">Clear</button><button id="moveSelectedToFolder" type="button" disabled>Move selected</button></div>
      <div id="folderLoginRows" class="folderLoginRows">${vaultSettingsLoginRows()}</div>
    </section>`;

  const selectedLoginIds = () => [...document.querySelectorAll('input[name="folderLoginIds"]:checked')].map((input) => input.value);
  const visibleFolderRows = () => [...document.querySelectorAll('[data-folder-login-row]')].filter((row) => !row.classList.contains('hidden'));
  const updateSelection = () => {
    const count = selectedLoginIds().length;
    if ($('folderSelectedCount')) $('folderSelectedCount').textContent = `${count} selected`;
    if ($('moveSelectedToFolder')) $('moveSelectedToFolder').disabled = count === 0;
  };
  const filterFolderLogins = () => {
    const query = String($('folderLoginSearch')?.value || '').trim().toLowerCase();
    let shown = 0;
    document.querySelectorAll('[data-folder-login-row]').forEach((row) => {
      const matches = !query || String(row.dataset.folderSearch || '').includes(query);
      row.classList.toggle('hidden', !matches);
      if (matches) shown += 1;
    });
    if ($('folderSearchCount')) $('folderSearchCount').textContent = query ? `${shown} shown` : `${shown} logins`;
  };
  document.querySelectorAll('input[name="folderLoginIds"]').forEach((input) => input.addEventListener('change', updateSelection));
  $('folderLoginSearch')?.addEventListener('input', filterFolderLogins);
  $('folderSelectAll')?.addEventListener('click', () => {
    visibleFolderRows().forEach((row) => {
      const input = row.querySelector('input[name="folderLoginIds"]');
      if (input) input.checked = true;
    });
    updateSelection();
  });
  $('folderClearSelection')?.addEventListener('click', () => { document.querySelectorAll('input[name="folderLoginIds"]').forEach((input) => { input.checked = false; }); updateSelection(); });
  filterFolderLogins();

  $('createFolderButton')?.addEventListener('click', async () => {
    try {
      createFolder(vault, $('newFolderName')?.value || '');
      await saveUnlockedVault(vault);
      renderVaultSettingsDialog();
      renderItems();
      toast('Encrypted vault folder created.');
    } catch (error) { toast(error.message, true); }
  });

  document.querySelectorAll('[data-rename-folder]').forEach((button) => button.addEventListener('click', async () => {
    try {
      const folderId = button.dataset.renameFolder;
      const input = document.querySelector(`[data-folder-name="${CSS.escape(folderId)}"]`);
      renameFolder(vault, folderId, input?.value || '');
      await saveUnlockedVault(vault);
      renderVaultSettingsDialog();
      renderItems();
      toast('Folder renamed.');
    } catch (error) { toast(error.message, true); }
  }));

  document.querySelectorAll('[data-delete-folder]').forEach((button) => button.addEventListener('click', async () => {
    const folderId = button.dataset.deleteFolder;
    const folder = folderById(folderId);
    if (!folder || !confirm(`Delete the folder "${folder.name}"? Its vault items will move to No Folder.`)) return;
    deleteFolder(vault, folderId);
    if (activeFolderId === folderId) activeFolderId = 'all';
    await saveUnlockedVault(vault);
    renderVaultSettingsDialog();
    renderItems();
    toast('Folder deleted. Its items were moved to No Folder.');
  }));

  $('moveSelectedToFolder')?.addEventListener('click', async () => {
    try {
      const ids = selectedLoginIds();
      const target = $('folderTarget')?.value || null;
      const moved = assignItemsToFolder(vault, ids, target || null);
      await saveUnlockedVault(vault);
      renderVaultSettingsDialog();
      renderItems();
      toast(`${moved} login${moved === 1 ? '' : 's'} moved.`);
    } catch (error) { toast(error.message, true); }
  });
}

function openVaultSettingsDialog() {
  if (!vault) return;
  renderVaultSettingsDialog();
  els.vaultSettingsDialog?.showModal();
}

async function vaultKeyForTrash() {
  const state = await loadUnlockedVault({ touch: false });
  if (state.state !== 'unlocked' || !state.vaultKey) throw new Error('VaultCove is locked.');
  return state.vaultKey;
}

async function moveItemToTrashWithConfirmation(itemId) {
  const item = (vault?.items || []).find((candidate) => candidate.id === itemId && !candidate.deletedAt);
  if (!item) return false;
  const confirmed = confirm(`Move "${item.name}" to Trash?\n\nIt will be locked immediately, sealed inside a second encrypted envelope, and automatically deleted after ${TRASH_RETENTION_DAYS} days unless you restore it.`);
  if (!confirmed) return false;
  const vaultKey = await vaultKeyForTrash();
  const moved = await moveVaultItemToTrash(vault, itemId, vaultKey);
  if (!moved) return false;
  if (selectedItemId === itemId) selectedItemId = null;
  const removedAt = new Date().toISOString();
  await appendActivityEvent(vault, 'item-trashed', { itemId, type: item.type, occurredAt:removedAt });
  await saveUnlockedVault(vault);
  if (['card','bank','identity'].includes(item.type)) {
    queueSecurityEventNotice('protected-record-removed', { recordType:item.type, occurredAt:removedAt }).catch(() => {});
  }
  render();
  toast(`Moved to Trash. It is locked and scheduled for deletion in ${TRASH_RETENTION_DAYS} days.`);
  return true;
}

async function restoreTrashItem(itemId) {
  const vaultKey = await vaultKeyForTrash();
  const restored = await restoreVaultItemFromTrash(vault, itemId, vaultKey);
  if (!restored) return false;
  const restoredItem = (vault.items || []).find((candidate) => candidate.id === itemId);
  await appendActivityEvent(vault, 'item-restored', { itemId, type: restoredItem?.type || 'item' });
  await saveUnlockedVault(vault);
  render();
  toast('Item restored and decrypted back into the active vault.');
  return true;
}

function trashRetentionLabel(item) {
  const purgeAt = trashPurgeAt(item);
  const days = trashDaysRemaining(item);
  if (!purgeAt) return `Auto-delete after ${TRASH_RETENTION_DAYS} days`;
  if (days <= 0) return 'Scheduled for automatic deletion';
  return `${days} day${days === 1 ? '' : 's'} until automatic deletion`;
}

function visibleItems() {
  const q = els.search.value.trim().toLowerCase();
  return vault.items.filter((item) => {
    const deleted = Boolean(item.deletedAt);
    if (currentView === 'trash') {
      if (!deleted) return false;
    } else if (deleted) return false;
    if (['login','card','bank','identity','note'].includes(currentView) && item.type !== currentView) return false;
    if (item.type === 'identity' && currentView !== 'identity') return false;
    if (currentView === 'totp' && !(item.type === 'login' && item.totpSecret)) return false;
    if (currentView === 'favorites' && !item.favorite) return false;
    if (!['trash', 'totp'].includes(currentView) && activeFolderId !== 'all') {
      if (activeFolderId === '') {
        if (item.folderId) return false;
      } else if (item.folderId !== activeFolderId) return false;
    }
    if (q) {
      const searchableFields = [
        item.name, item.nickname, item.username, item.email, item.bankName, item.cardholder,
        ...(item.urls || []), ...(item.tags || [])
      ].map((value) => String(value || '').toLowerCase()).join('\n');
      if (!searchableFields.includes(q)) return false;
    }
    return true;
  }).sort((a,b) => {
    const mode = ['favorites','name','recent','oldest'].includes(settingsState?.vaultSortMode) ? settingsState.vaultSortMode : 'favorites';
    if (mode === 'recent' || mode === 'oldest') {
      const aTime = Date.parse(String(a.updatedAt || a.createdAt || '')) || 0;
      const bTime = Date.parse(String(b.updatedAt || b.createdAt || '')) || 0;
      return mode === 'recent' ? (bTime - aTime || String(a.name || '').localeCompare(String(b.name || ''))) : (aTime - bTime || String(a.name || '').localeCompare(String(b.name || '')));
    }
    if (mode === 'name') return String(a.name || '').localeCompare(String(b.name || ''));
    return Number(Boolean(b.favorite)) - Number(Boolean(a.favorite)) || String(a.name || '').localeCompare(String(b.name || ''));
  });
}

function pageHead(title = viewNames[currentView], subtitle = viewSubtitles[currentView], withStatus = false) {
  const status = withStatus ? `<div class="statusPills"><span class="pill good">Offline Only</span><span class="pill">Local Encrypted Storage</span><span class="pill">No Cloud Sync</span></div>` : '';
  return `<div class="pageHead"><div><h1>${escapeHtml(title)}</h1><p>${escapeHtml(subtitle)}</p></div>${status}</div>`;
}

const PREMIUM_VIEW_GATES = Object.freeze({
  favorites: 'favorites',
  card: 'cards',
  note: 'notes',
  totp: 'totp',
  security: 'security-center'
});

function premiumGateForView(view = currentView) {
  return PREMIUM_VIEW_GATES[String(view || '')] || '';
}

function premiumGateForItem(item) {
  if (!item) return '';
  if (item.type === 'card') return 'cards';
  if (item.type === 'note') return 'notes';
  return '';
}

function premiumFeatureTitle(gate) {
  return ({ cards:'Cards', notes:'Secure Notes', totp:'TOTP Codes', favorites:'Favorites', 'security-center':'Security Center', 'vckey-txt':'Convert encrypted .vckey to TXT' })[gate] || 'Premium feature';
}

function renderPremiumLockedView(gate, title = premiumFeatureTitle(gate)) {
  const feature = PREMIUM_FEATURE_CATALOG.find((entry) => entry.gate === gate);
  const purpose = feature?.purpose || `${title} is available with Premium Lifetime.`;
  els.content.innerHTML = `${pageHead(title, purpose)}<section class="premiumLockedPanel"><span class="premiumTag">Premium Lifetime</span><h2>${escapeHtml(title)}</h2><p>${escapeHtml(purpose)}</p>${premiumInlineActionsMarkup()}</section>`;
  wirePremiumInlineActions();
}

function wirePremiumInlineActions() {
  document.querySelectorAll('[data-open-premium-license]').forEach((button) => button.addEventListener('click', () => switchView('license')));
}

function render() {
  // Live storage/settings events can arrive just after lock clears decrypted state.
  // Never render vault-dependent views against a null in-memory vault.
  if (!vault) return;
  clearInterval(totpTimer);
  if (currentView !== 'license') {
    if (licenseDevicesRefreshTimer) { clearInterval(licenseDevicesRefreshTimer); licenseDevicesRefreshTimer = null; }
    licenseDevicesRefreshNow = null;
  }
  applyProfileIdentity();
  syncPremiumNavigation();
  if (licenseState?.premium && currentView === 'premium') currentView = 'license';
  els.search.classList.toggle('hidden', ['generator','security','guardian','migration','shared','premium','license','backup','settings','support'].includes(currentView));
  els.newItem.classList.toggle('hidden', ['security','guardian','settings','trash','migration','shared','premium','license','backup','generator','support'].includes(currentView));
  document.querySelectorAll('nav button[data-view]').forEach((button) => button.classList.toggle('active', button.dataset.view === currentView));
  const gatedView = premiumGateForView(currentView);
  if (gatedView && !premiumFeatureAllowed(licenseState, gatedView)) return renderPremiumLockedView(gatedView);
  if (currentView === 'dashboard') return renderDashboard();
  if (currentView === 'security') return renderSecurity();
  if (currentView === 'guardian') return renderGuardian();
  if (currentView === 'settings') return renderSettings();
  if (currentView === 'support') return renderSupport();
  if (currentView === 'migration') return renderMigration();
  if (currentView === 'backup') return renderBackup();
  if (currentView === 'shared') return renderShared();
  if (currentView === 'premium') return renderPremium();
  if (currentView === 'license') return renderLicense();
  if (currentView === 'generator') return renderGenerator();
  return renderItems();
}

function securityHealthPresentation(health) {
  const score = Math.max(0, Math.min(100, Number(health?.score || 0)));
  const atRisk = Math.max(0, Number(health?.atRisk || 0));
  if (!atRisk) return { score, atRisk, tone:'healthy', label:'Protected' };
  if (score >= 75) return { score, atRisk, tone:'caution', label:'Needs attention' };
  if (score >= 50) return { score, atRisk, tone:'warning', label:'At risk' };
  return { score, atRisk, tone:'critical', label:'High risk' };
}

function securityScoreRingMarkup(health, { compact = false } = {}) {
  const state = securityHealthPresentation(health);
  return `<div class="scoreRing securityScoreRing health-${state.tone}${compact ? ' compact' : ''}" style="--score:${Math.max(0,Math.min(360,state.score*3.6))}deg">
    <div><strong>${state.score}</strong><small>/100</small><span>Security score</span></div>
  </div>`;
}

function premiumInlineActionsMarkup() {
  return `<div class="premiumInlineActions">
    <a class="buttonLink" href="https://payhip.com/b/0foVO" target="_blank" rel="noopener noreferrer">Buy Premium Lifetime</a>
    <button type="button" class="outline" data-open-premium-license>Already own Premium? Activate</button>
  </div>`;
}


function manualBackupHealth(settings = settingsState, nowMs = Date.now()) {
  const pending = Boolean(settings?.manualBackupPending);
  const pendingCount = Math.max(0, Number(settings?.manualBackupPendingCount || 0));
  const dueMs = Date.parse(String(settings?.manualBackupReminderDueAt || '')) || 0;
  const lastMs = Date.parse(String(settings?.manualBackupLastSuccessAt || '')) || 0;
  const overdue = pending && dueMs > 0 && nowMs >= dueMs;
  const lastLabel = lastMs ? new Date(lastMs).toLocaleString() : 'No verified manual backup yet';
  const dueLabel = dueMs ? new Date(dueMs).toLocaleDateString(undefined, { year:'numeric', month:'short', day:'numeric' }) : 'End of this month';
  return { pending, pendingCount, dueMs, lastMs, overdue, lastLabel, dueLabel };
}

function backupChangeSummary(sourceVault = vault, lastBackupMs = 0) {
  const importantTypes = new Set([
    'item-created','login-created','login-updated','login-password-changed','password-change-approved',
    'card-created','card-updated','bank-created','bank-updated','identity-created','identity-updated','secure-note-created','secure-note-updated','protected-record-created','protected-record-updated','item-trashed','item-restored','item-purged',
    'folder-created','folder-renamed','folder-deleted','migration-imported','startup-backup-restored','backup-restored',
    'vault-totp-enabled','vault-totp-disabled','master-password-changed'
  ]);
  const entries = activityLogEntries(sourceVault || {}).filter((entry) => {
    const occurred = Date.parse(String(entry?.occurredAt || '')) || 0;
    const type = String(entry?.type || '');
    return occurred > lastBackupMs && (importantTypes.has(type) || /^(login|item|card|bank|identity|secure-note|protected-record|folder|password|vault-totp|migration|share)-/.test(type));
  });
  const labels = [];
  const types = new Set(entries.map((entry) => String(entry?.type || '')));
  if ([...types].some((type) => /login-created|new-login|migration-imported|item-created/.test(type))) labels.push('new logins or records');
  if ([...types].some((type) => /password/.test(type))) labels.push('password changes');
  if ([...types].some((type) => /updated|card|bank|identity|secure-note|protected-record|folder|trashed|restored|purged|share/.test(type))) labels.push('important vault changes');
  return { count: entries.length, labels: labels.slice(0, 3) };
}

function dashboardBackupReminderMarkup() {
  const health = manualBackupHealth(settingsState);
  if (!health.overdue) return '';
  const changes = backupChangeSummary(vault, health.lastMs);
  const reason = changes.labels.length ? changes.labels.join(', ') : 'protected vault changes';
  return `<section class="dashboardBackupReminder" role="status" aria-live="polite">
    <span class="dashboardBackupReminderIcon">${uiIcon('backup',22)}</span>
    <div><strong>Monthly backup reminder</strong><p>VaultCove has ${escapeHtml(reason)} that are not yet covered by a new verified manual <code>.vcvault</code> backup. This reminder stays here until a backup is created successfully.</p><small>Last verified backup: ${escapeHtml(health.lastLabel)}${health.pendingCount ? ` - ${health.pendingCount} protected change${health.pendingCount === 1 ? '' : 's'} since backup` : ''}</small></div>
    <button id="dashboardBackupReminderNow" type="button">Back up now</button>
  </section>`;
}


function scheduleManualBackupReminderRefresh() {
  if (manualBackupReminderTimer) clearTimeout(manualBackupReminderTimer);
  manualBackupReminderTimer = null;
  if (currentView !== 'dashboard') return;
  const health = manualBackupHealth(settingsState);
  if (!health.pending || health.overdue || !health.dueMs) return;
  const delay = Math.max(1_000, Math.min(health.dueMs - Date.now(), 5 * 60_000));
  manualBackupReminderTimer = setTimeout(() => {
    manualBackupReminderTimer = null;
    if (currentView === 'dashboard') renderDashboard();
  }, delay);
}

function dashboardBackupHealthMarkup() {
  const health = manualBackupHealth(settingsState);
  const changes = backupChangeSummary(vault, health.lastMs);
  const stateClass = health.overdue ? 'overdue' : health.pending ? 'pending' : 'protected';
  const stateLabel = health.overdue ? 'Backup due now' : health.pending ? 'Changes pending backup' : 'Protected';
  const detail = health.pending
    ? `${Math.max(health.pendingCount, changes.count)} protected change${Math.max(health.pendingCount, changes.count) === 1 ? '' : 's'} since the last verified backup. Monthly reminder: ${health.dueLabel}.`
    : `Last verified manual backup: ${health.lastLabel}.`;
  return `<section class="panel backupHealthPanel backupHealth-${stateClass}">
    <div class="panelTitle"><div><h2>Backup Health</h2><p>${escapeHtml(stateLabel)}</p></div><span class="pill ${health.overdue ? 'warning' : health.pending ? '' : 'good'}">${escapeHtml(stateLabel)}</span></div>
    <div class="backupHealthBody"><div><strong>${escapeHtml(health.lastLabel)}</strong><span>${escapeHtml(detail)}</span></div><button id="dashboardBackupHealthNow" type="button" class="outline">${health.pending ? 'Create backup now' : 'Create fresh backup'}</button></div>
    <small>Automatic Disaster Recovery is additional protection and does not replace your independent manual <code>.vcvault</code> backup.</small>
  </section>`;
}

function dashboardFocusStripMarkup(health, backupHealth) {
  const guardianActive = premiumFeatureAllowed(licenseState, 'guardian');
  const backupLabel = backupHealth.pending ? `${Math.max(1, backupHealth.pendingCount)} change${backupHealth.pendingCount === 1 ? '' : 's'} pending` : 'Verified backup current';
  return `<div class="dashboardFocusStrip" aria-label="Vault status">
    <button type="button" data-dashboard-focus="login"><span>${uiIcon('login',16)}</span><div><strong>${countType('login')} logins</strong><small>Encrypted locally</small></div></button>
    <button type="button" data-dashboard-focus="security" class="${health.atRisk ? 'attention' : ''}"><span>${uiIcon(health.atRisk ? 'weak' : 'strong',16)}</span><div><strong>${health.atRisk ? `${health.atRisk} need attention` : 'Security healthy'}</strong><small>${health.riskFindings || 0} local risk finding${health.riskFindings === 1 ? '' : 's'}</small></div></button>
    <button type="button" data-dashboard-focus="backup" class="${backupHealth.pending ? 'attention' : ''}"><span>${uiIcon('backup',16)}</span><div><strong>${escapeHtml(backupLabel)}</strong><small>${escapeHtml(backupHealth.lastLabel)}</small></div></button>
    <button type="button" data-dashboard-focus="${guardianActive ? 'guardian' : 'license'}"><span>${uiIcon('security',16)}</span><div><strong>${guardianActive ? 'Guardian active' : 'Guardian Premium'}</strong><small>${guardianActive ? 'Advanced protection ready' : 'Optional advanced protection'}</small></div></button>
  </div>`;
}

function renderDashboard() {
  const items = activeItems();
  const handlerOn = isDeveloperBuild || (Array.isArray(handlerPermissionState) && handlerPermissionState.length > 0);
  const alwaysOn = isDeveloperBuild || (Array.isArray(handlerPermissionState) && handlerPermissionState.includes('https://*/*'));
  const autoLoginOn = Boolean(settingsState?.autoLoginEnabled);
  const ownedItems = items.filter((item) => !isUseOnlySharedLogin(item));
  const health = vaultHealth(ownedItems);
  const ageSummary = passwordAgeSummary(ownedItems);
  const healthState = securityHealthPresentation(health);
  const securityPremium = premiumFeatureAllowed(licenseState, 'security-center');
  const premiumAdvanced = securityPremium && premiumFeatureAllowed(licenseState, 'security-advanced');
  const recentEvents = dashboardActivityEntries(vault, 6);
  const recentRows = recentEvents.length ? recentEvents.map((event) => dashboardActivityRowMarkup(event)).join('')
    : '<div class="emptyState compactEmpty">No activity yet. VaultCove will show recent local actions here.</div>';

  els.content.innerHTML = `
    ${pageHead('Vault Overview','Everything stays on your device. You are in control.',true)}
    <div id="updateBanner"></div>
    ${dashboardBackupReminderMarkup()}
    ${dashboardFocusStripMarkup(health, manualBackupHealth(settingsState))}
    <div class="summaryGrid">
      ${summaryCard('login','login','Logins',countType('login'),'saved logins')}
      ${summaryCard('card','card','Cards',countType('card'),'payment cards', 'cards')}
      ${summaryCard('bank','bank','Bank Accounts',countType('bank'),'bank records')}
      ${summaryCard('note','note','Secure Notes',countType('note'),'secure notes', 'notes')}
      ${summaryCard('identity','identity','Identities',countType('identity'),'identity records')}
      ${summaryCard('totp','totp','TOTP Codes',items.filter((item)=>item.type==='login'&&item.totpSecret).length,'protected accounts', 'totp')}
    </div>
    <div class="dashboardGrid">
      ${securityPremium ? `
      <section class="panel securityPanel health-${healthState.tone}">
        <div class="panelTitle securityPanelTitle">
          <div><h2>Security Health</h2><p>${health.atRisk ? `${health.atRisk} unique credential${health.atRisk === 1 ? '' : 's'} need attention` : 'No weak or reused credentials detected'}</p></div>
          <button id="openSecurity" class="linkButton">View details</button>
        </div>
        <div class="healthBody">
          ${securityScoreRingMarkup(health)}
          <div class="healthMetrics">
            <button class="healthMetric healthMetricButton ${health.weak ? 'hasRisk' : ''}" data-security-filter="weak" type="button"><i>${uiIcon('weak', 17)}</i><div><b>Weak Passwords</b><small>Weak passwords count as at-risk credentials</small></div><em>${health.weak}</em></button>
            <button class="healthMetric healthMetricButton ${health.reused ? 'hasRisk' : ''}" data-security-filter="reused" type="button"><i>${uiIcon('reused', 17)}</i><div><b>Reused Passwords</b><small>Reused passwords increase account exposure</small></div><em>${health.reused}</em></button>
            ${premiumAdvanced
              ? `<button id="openPasswordAgeReview" class="healthMetric healthMetricButton" type="button"><i>${uiIcon('warningClock', 17)}</i><div><b>Password Age Review</b><small>Premium review for credentials unchanged 90+ days</small></div><em>${ageSummary.over90}</em></button>`
              : `<div class="healthMetric premiumHealthMetric premiumFeatureLocked" tabindex="0" aria-disabled="true" title="Premium Lifetime reviews passwords that are 90 days old or older and separates credentials whose true change date is unknown."><i>${uiIcon('lock', 17)}</i><div><b>Password Age Review</b><small>Advanced Security Center</small></div><span class="premiumTag">Premium</span><span class="premiumFeaturePurposeTooltip" role="tooltip">Reviews passwords that are 90 days old or older and separates credentials whose true change date is unknown.</span></div>`}
          </div>
        </div>
        <button class="healthRiskSummary" type="button" data-security-filter="risk">
          <span><strong>${health.atRisk}</strong><small>At-risk credentials</small></span>
          <span><strong>${health.riskFindings}</strong><small>Risk findings</small></span>
          <span><strong>${health.total}</strong><small>Saved logins</small></span>
          <b>${health.atRisk ? escapeHtml(healthState.label) : 'Protected'}</b>
        </button>
      </section>
      ` : `<section class="panel premiumLockedPanel"><span class="premiumTag">Premium Lifetime</span><h2>Security Center</h2><p>Password-health scoring, weak/reused analysis, password-age review, and encrypted activity history are Premium features.</p><button type="button" class="outline" data-open-premium-license>Unlock Security Center</button></section>`}

      <section class="panel recentPanel">
        <div class="panelTitle"><h2>Recent Activity</h2><button id="viewActivityHistory" class="linkButton">View all</button></div>
        <div class="recentList">${recentRows}</div>
      </section>
      <section class="panel quickPanel">
        <div class="panelTitle"><h2>Quick Actions</h2></div>
        <div class="quickGrid">
          <button id="dashAddLogin"><span class="quickActionIcon">${uiIcon('add',18)}</span><span><strong>Add Login</strong><small>Create an encrypted login</small></span></button>
          <button id="dashGenerate"><span class="quickActionIcon">${uiIcon('generator',18)}</span><span><strong>Generate Password</strong><small>Create a strong password</small></span></button>
          <button id="dashExport"><span class="quickActionIcon">${uiIcon('export',18)}</span><span><strong>Export Backup</strong><small>Create an encrypted vault backup</small></span></button>
          <button id="dashImport"><span class="quickActionIcon">${uiIcon('import',18)}</span><span><strong>Import Backup</strong><small>Restore a VaultCove backup</small></span></button>
          <button id="dashMaster"><span class="quickActionIcon">${uiIcon('master',18)}</span><span><strong>Master Password</strong><small>Review password protection</small></span></button>
          <button id="dashLock" class="dangerQuick"><span class="quickActionIcon">${uiIcon('lock',18)}</span><span><strong>Lock Vault</strong><small>Clear the unlocked session</small></span></button>
        </div>
      </section>
    </div>
    <div class="lowerGrid">
      <section class="panel backupPanel">
        <div class="panelTitle"><h2>Backup and Recovery</h2>${uiIcon('backup',18)}</div>
        <p class="mutedText">Keep one encrypted portable .vcvault copy of your vault, sharing identity, and device-recovery material.</p>
        <div class="backupNote"><strong>Keep the unique Backup Key separate.</strong><span>Every .vcvault gets a fresh random 256-bit Backup Key. The file cannot be previewed or restored without the exact matching key.</span></div>
        <div class="backupActions"><button id="dashExport2">${uiIcon('export',16)}<span>Export Encrypted Backup</span></button><button id="dashBackupPage" class="outline">Open Backup and Restore</button></div>
      </section>
      ${dashboardBackupHealthMarkup()}
      <section class="panel browserPanel">
        <div class="panelTitle"><h2>Browser Integration</h2><span class="pill good">Ready</span></div>
        <div class="browserRows">
          <div class="browserRow"><i>${uiIcon('browser',18)}</i><div><strong>Website Handler</strong><b>${alwaysOn ? 'Always-On Handler enabled' : handlerOn ? 'Individual site access enabled' : 'On-demand only'}</b><small>${alwaysOn ? 'VaultCove appears automatically on supported HTTPS login and password forms. Per-site exclusions can be managed in Settings.' : 'Enable website access to show VaultCove automatically on supported HTTPS login forms.'}</small></div></div>
          <div class="browserRow"><i>${uiIcon('autologin',18)}</i><div><strong>Automatic Login</strong><b>${autoLoginOn ? 'Enabled for opted-in entries' : 'Off by default'}</b><small>Only trusted HTTPS entries explicitly marked Auto-login can be submitted automatically.</small></div></div>
          <div class="browserRow"><i>${uiIcon('match',18)}</i><div><strong>Domain Matching</strong><b>Trusted HTTPS matching</b><small>Legacy imported URLs are normalized to HTTPS while unrelated or suspicious hostnames remain blocked.</small></div></div>
        </div>
      </section>
    </div>`;

  scheduleManualBackupReminderRefresh();
  $('openSecurity')?.addEventListener('click', () => openSecurityFilter('all'));
  $('openPasswordAgeReview')?.addEventListener('click', () => switchView('security'));
  document.querySelectorAll('[data-security-filter]').forEach((button) => button.addEventListener('click', () => openSecurityFilter(button.dataset.securityFilter)));
  wirePremiumInlineActions();
  $('viewActivityHistory')?.addEventListener('click', () => {
    if (!premiumFeatureAllowed(licenseState, 'security-advanced')) { switchView('security'); return; }
    currentView = 'security';
    render();
    requestAnimationFrame(() => document.querySelector('#activityHistorySection')?.scrollIntoView({ behavior:'smooth', block:'start' }));
  });
  $('dashAddLogin').addEventListener('click', () => openItemDialog(null,'login'));
  $('dashGenerate').addEventListener('click', () => switchView('generator'));
  $('dashExport').addEventListener('click', exportVault);
  $('dashExport2').addEventListener('click', exportVault);
  $('dashImport').addEventListener('click', () => switchView('backup'));
  $('dashBackupPage').addEventListener('click', () => switchView('backup'));
  $('dashboardBackupReminderNow')?.addEventListener('click', () => switchView('backup'));
  $('dashboardBackupHealthNow')?.addEventListener('click', () => switchView('backup'));
  $('dashMaster').addEventListener('click', () => switchView('settings'));
  $('dashLock').addEventListener('click', lockFromUi);
  document.querySelectorAll('[data-activity-open-id]').forEach((row) => row.addEventListener('click', () => {
    const item = vault.items.find((candidate) => candidate.id === row.dataset.activityOpenId && !candidate.deletedAt);
    if (item) openItemDialog(item);
  }));
  wireSummaryCards();
  document.querySelectorAll('[data-dashboard-focus]').forEach((button) => button.addEventListener('click', () => switchView(button.dataset.dashboardFocus)));
  refreshUpdateBanner().catch(() => {});
}

function summaryCard(view, icon, label, count, unit, premiumGate = '') {
  const locked = premiumGate && !premiumFeatureAllowed(licenseState, premiumGate);
  return `<button class="summaryCard${locked ? ' premiumLockedSummary' : ''}" data-summary-view="${escapeHtml(view)}"><span class="summaryIcon">${uiIcon(locked ? 'lock' : icon, 18)}</span><span class="summaryCopy"><span>${escapeHtml(label)}</span><strong>${locked ? 'Premium' : count}</strong><small>${escapeHtml(locked ? 'Premium Lifetime feature' : unit)}</small></span></button>`;
}

function wireSummaryCards() {
  document.querySelectorAll('[data-summary-view]').forEach((button) => button.addEventListener('click', () => switchView(button.dataset.summaryView)));
}

function emptyStateMarkup() {
  const byView = {
    trash: ['trash', 'Trash is empty', `Items moved to Trash are locked, sealed in a second encrypted envelope, and automatically deleted after ${TRASH_RETENTION_DAYS} days unless restored.`, ''],
    totp: ['totp', 'No TOTP codes yet', 'Add a compatible TOTP secret to a saved login to generate authenticator codes locally.', ''],
    card: ['card', 'No payment cards yet', 'Store card details locally inside your encrypted VaultCove vault.', 'Add Card'],
    bank: ['bank', 'No bank accounts yet', 'Keep bank records encrypted locally and protected by Sensitive Access.', 'Add Bank Account'],
    identity: ['identity', 'No identities yet', 'Keep identity and address records inside your offline encrypted vault.', 'Add Identity'],
    note: ['note', 'No secure notes yet', 'Store private text without uploading it to a cloud service.', 'Add Secure Note'],
    favorites: ['favorite', 'No favorites yet', 'Use the star button on any vault item to add or remove it from Favorites.', ''],
    login: ['login', 'No matching logins', 'Add a login or adjust your search. Imported LastPass records remain encrypted here.', 'Add Login'],
    all: ['vault', 'No vault items yet', 'Use Quick Add to create your first encrypted record.', 'Add Login']
  };
  const [icon, title, text, action] = byView[currentView] || byView.all;
  return `<div class="emptyState richEmpty"><div class="emptyIcon">${uiIcon(icon, 28)}</div><strong>${escapeHtml(title)}</strong><p>${escapeHtml(text)}</p>${action ? `<button id="emptyAdd">${escapeHtml(action)}</button>` : ''}</div>`;
}

function activityLabel(item) {
  const imported = item.importedAt ? Date.parse(item.importedAt) : 0;
  const updated = Date.parse(item.updatedAt || item.createdAt || 0);
  if (imported && Math.abs(updated - imported) < 5000) return `Imported ${relativeTime(item.importedAt)}`;
  if (item.lastPasswordChangeAt && Math.abs(updated - Date.parse(item.lastPasswordChangeAt)) < 5000) return `Password changed ${relativeTime(item.lastPasswordChangeAt)}`;
  return `Updated ${relativeTime(item.updatedAt || item.createdAt)}`;
}

function viewModeControls() {
  const mode = settingsState?.vaultViewMode === 'list' ? 'list' : 'grid';
  return `<div class="viewModeSwitch" role="group" aria-label="Vault view"><button data-vault-view="grid" class="${mode === 'grid' ? 'active' : ''}">Grid</button><button data-vault-view="list" class="${mode === 'list' ? 'active' : ''}">List</button></div>`;
}

function vaultCardMarkup(item) {
  const login = item.type === 'login';
  const shared = isUseOnlySharedLogin(item);
  const expiredShared = shared && sharedAccessIsExpired(item);
  const status = expiredShared ? 'Shared access expired' : login && item.pendingPasswordChange ? 'Password change pending' : activityLabel(item);
  const visual = login ? siteCardVisual(item) : item.type === 'card' ? `<div class="siteCardVisual genericVisual paymentCardVisual"><div class="paymentCardVisualInner">${compactCardBrandBadgeMarkup(paymentCardBrand(item.number))}<strong>${escapeHtml(item.cardholder || item.name || 'Payment card')}</strong><small>${escapeHtml(item.number ? `•••• ${paymentCardDigits(item.number).slice(-4)}` : 'Encrypted card')}</small></div></div>` : `<div class="siteCardVisual genericVisual"><div class="siteFallback">${uiIcon(itemIconName(item), 28)}</div></div>`;
  const primary = login
    ? `<button class="siteCardOpen" data-open-login="${escapeHtml(item.id)}" ${expiredShared ? 'disabled' : ''}>Secure Login</button>`
    : `<button class="siteCardOpen" data-details-id="${escapeHtml(item.id)}">Open details</button>`;
  const age = login && !shared ? passwordAgeBadge(item, { compact: true, showUnknown: false }) : '';
  const favoriteControl = shared ? `<span class="sharedAccessCorner">${uiIcon('lock', 16)}</span>` : `<button class="favoriteToggle ${item.favorite ? 'active' : ''}" data-favorite-id="${escapeHtml(item.id)}" aria-label="${item.favorite ? 'Remove from Favorites' : 'Add to Favorites'}">${uiIcon('favorite', 16)}</button>`;
  return `<article class="siteVaultCard ${shared ? 'sharedUseOnlyCard' : ''} ${item.id === selectedItemId ? 'selected' : ''}" data-select-item="${escapeHtml(item.id)}">
    ${favoriteControl}
    ${visual}
    <div class="siteCardBody">
      <div class="siteCardTitle"><strong>${escapeHtml(item.type === 'login' ? loginDisplayLabel(item) : item.name)}</strong><span>${escapeHtml(itemTypeLabel(item))}</span></div>${item.type === 'login' && item.nickname ? `<small class="loginSiteName">${escapeHtml(item.name)}</small>` : ''}
      <small class="siteCardAccount">${escapeHtml(itemMeta(item))}</small>
      <div class="siteCardBadges">${folderChip(item)}${age}${login ? httpWarningBadge(item) : ''}${shared ? '<span class="securityBadge sharedPolicyBadge">Use only</span>' : login && item.requireReauthBeforeFill ? '<span class="securityBadge">Master check</span>' : ''}</div>
      <div class="siteCardFooter"><span>${escapeHtml(status)}</span></div>
      <div class="siteCardActions">${primary}${login && !shared ? `<button class="siteCardNickname" data-edit-nickname="${escapeHtml(item.id)}" aria-label="${loginNicknameValue(item) ? 'Edit login nickname' : 'Add login nickname'}">Name</button>` : ''}<button class="siteCardDetails" data-details-id="${escapeHtml(item.id)}">Details</button><button class="siteCardTrash" data-trash-id="${escapeHtml(item.id)}" aria-label="Move ${escapeHtml(item.name)} to Trash">${uiIcon('trash', 15)}</button></div>
    </div>
  </article>`;
}

function loginPasswordHealthMarkup(item) {
  if (!item || item.type !== 'login' || isUseOnlySharedLogin(item)) return '';
  const assessment = assessPassword(item.password || '', passwordContextForItem(item));
  const policy = passwordPolicy(item.password || '', 16);
  const percent = Math.max(4, Math.min(100, assessment.score * 25));
  const reuseCount = (vault?.items || []).filter((candidate) => !candidate.deletedAt && candidate.type === 'login' && !isUseOnlySharedLogin(candidate) && candidate.password && candidate.password === item.password).length;
  const reuseText = reuseCount > 1 ? `Reused in ${reuseCount} saved logins` : 'Not reused in another saved login';
  const issues = [...assessment.issues];
  if (!policy.rules.common) issues.push('Contains a common word or obvious sequence');
  if (!policy.rules.variety) issues.push('Low character variety');
  const issueText = [...new Set(issues)].slice(0, 4).map((issue) => `<li>${escapeHtml(issue)}</li>`).join('');
  return `<div class="drawerPasswordHealth" data-password-score="${assessment.score}">
    <div class="drawerHealthHead"><span>Password health</span><strong>${escapeHtml(assessment.label)}</strong></div>
    <div class="drawerHealthMeter"><i style="width:${percent}%"></i></div>
    <div class="drawerHealthFacts"><span>${escapeHtml(`${String(item.password || '').length} characters`)}</span><span>${escapeHtml(`${assessment.entropy || 0} bit local estimate`)}</span><span class="${reuseCount > 1 ? 'risk' : 'good'}">${escapeHtml(reuseText)}</span></div>
    ${issueText ? `<ul class="drawerHealthIssues">${issueText}</ul>` : '<p class="drawerHealthGood">No obvious local weakness detected.</p>'}
    <small>Analyzed locally inside the unlocked extension. The password itself is never displayed in this panel.</small>
  </div>`;
}

function renderSelectedDrawer(item) {
  if (!item) return '<aside class="itemDrawer emptyDrawer"><strong>Select an item</strong><p>Choose a vault item to see protected details and available actions.</p></aside>';
  if (isUseOnlySharedLogin(item)) {
    const expired = sharedAccessIsExpired(item);
    const sender = item.sharedAccess?.senderDisplayName || item.sharedAccess?.senderShareId || 'Verified sender';
    const expiresAt = item.sharedAccess?.expiresAt ? new Date(item.sharedAccess.expiresAt).toLocaleString() : 'No expiration';
    return `<aside class="itemDrawer sharedAccessDrawer" data-drawer-id="${escapeHtml(item.id)}">
      <div class="drawerType">Shared Login Access</div>
      <h2>${escapeHtml(item.name)}</h2>
      <p class="drawerMeta">${escapeHtml(sharedAccessLabel(item))}</p>
      <div class="chips"><span class="chip secureChip">Use only</span><span class="chip secureChip">Immutable</span><span class="chip secureChip">Master check</span></div>
      <div class="drawerSecurity"><strong>Sender-controlled credential</strong><span>The username and password are sealed in a second encrypted envelope. This recipient vault can use them only for Secure Login. Reveal, Copy, Edit, password-change capture, Auto-login, and Reshare are blocked.</span></div>
      <div class="sharedAccessMeta"><small>Sender</small><strong>${escapeHtml(sender)}</strong><small>Access expiration</small><strong>${escapeHtml(expiresAt)}</strong></div>
      <div class="drawerActions"><button data-open-login="${escapeHtml(item.id)}" ${expired ? 'disabled' : ''}>${expired ? 'Access expired' : 'Secure Login'}</button></div>
      <small class="drawerActivity">Received ${escapeHtml(relativeTime(item.sharedAccess?.receivedAt || item.importedAt || item.createdAt))}</small>
    </aside>`;
  }
  const chips = [...(item.tags || [])].slice(0, 5).map((tag) => `<span class="chip">${escapeHtml(tag)}</span>`).join('');
  const protectedFill = item.type === 'login' && item.requireReauthBeforeFill ? '<span class="chip secureChip">Master check before Secure Login</span>' : '';
  const auto = item.type === 'login' && item.autoLogin ? '<span class="chip autoChip">Auto-login</span>' : '';
  const httpState = loginHttpSecurityState(item);
  const httpChip = httpState.insecure ? '<span class="chip insecureHttpChip">Not secure - HTTP</span>' : '';
  const age = item.type === 'login' ? passwordAgeBadge(item) : '';
  const historyCount = item.type === 'login' ? Math.min(10, Array.isArray(item.passwordHistory) ? item.passwordHistory.length : 0) : 0;
  const passwordHistorySummary = historyCount ? `<div class="drawerPasswordHistory"><strong>Password history</strong><span>${historyCount} previous encrypted password${historyCount === 1 ? '' : 's'} retained locally. Old password values are never shown in this drawer.</span></div>` : '';
  const ageAction = item.type === 'login' ? '<button data-mark-password-changed class="outline">Mark changed today</button>' : '';
  return `<aside class="itemDrawer" data-drawer-id="${escapeHtml(item.id)}">
    <div class="drawerType">${escapeHtml(itemTypeLabel(item))}</div>
    <h2>${escapeHtml(item.type === 'login' ? loginDisplayLabel(item) : item.name)}</h2>
    ${item.type === 'login' && item.nickname ? `<p class="drawerSiteName">Website / login title: ${escapeHtml(item.name)}</p>` : ''}
    <p class="drawerMeta">${escapeHtml(itemMeta(item))}</p>
    ${item.type === 'login' ? `${loginNicknameMarkup(item)}<button class="outline drawerNicknameAction" data-edit-nickname="${escapeHtml(item.id)}">${loginNicknameValue(item) ? 'Edit login nickname' : 'Add login nickname'}</button>` : ''}
    <div class="chips">${folderChip(item)}${protectedFill}${auto}${httpChip}${chips}</div>
    ${age ? `<div class="drawerAge">${age}</div>` : ''}
    ${item.type === 'login' ? `${passwordHistorySummary}${httpState.insecure ? '<div class="drawerHttpWarning"><strong>Not secure - HTTP website</strong><span>This saved website does not use HTTPS. Credentials can be intercepted or modified in transit. VaultCove never auto-logins on HTTP and requires explicit confirmation before use.</span></div>' : ''}${loginPasswordHealthMarkup(item)}<div class="drawerSecurity"><strong>Credential protection</strong><span>Username and password remain hidden here. Reveal, Copy and Edit require Sensitive Access.</span></div>` : ''}
    <div class="drawerActions"><button data-edit-selected>Open or Edit</button><button data-favorite-selected class="outline">${item.favorite ? 'Remove from Favorites' : 'Add to Favorites'}</button>${ageAction}</div>
    <small class="drawerActivity">${escapeHtml(activityLabel(item))}</small>
  </aside>`;
}

function renderItems() {
  if (currentView === 'totp' && TOTP_MAINTENANCE_MODE) {
    els.content.innerHTML = `${pageHead()}<section class="settingsCard totpMaintenanceNotice"><span class="maintenanceTag">Under maintenance</span><h3>TOTP Codes are temporarily unavailable</h3><p>VaultCove is preserving every existing encrypted website TOTP secret, but code display, new TOTP enrollment, and TOTP editing are disabled in this release while the feature is under maintenance.</p><p class="settingHint">No TOTP secret is deleted by this maintenance mode. A later update can re-enable the feature against the same encrypted vault data.</p></section>`;
    return;
  }
  const items = visibleItems();
  els.content.innerHTML = `${pageHead()}${vaultFolderToolbarMarkup()}<div id="itemsMount"></div>`;
  wireVaultFolderToolbar();
  const mount = $('itemsMount');
  if (!items.length) {
    mount.innerHTML = emptyStateMarkup();
    $('emptyAdd')?.addEventListener('click', () => openItemDialog(null, ['login','card','bank','identity','note'].includes(currentView) ? currentView : 'login'));
    return;
  }

  if (currentView === 'totp' || currentView === 'trash') {
    const grid = document.createElement('div'); grid.className = 'itemGrid';
    for (const item of items) {
      const node = document.createElement('article'); node.className = 'vaultItem';
      node.innerHTML = `<div class="type">${escapeHtml(itemTypeLabel(item))}</div><div class="name">${escapeHtml(`${item.favorite ? 'Favorite: ' : ''}${item.name}`)}</div><div class="meta">${escapeHtml(itemMeta(item))}</div>`;
      if (currentView === 'totp' && item.totpSecret) {
        const policy = guardianPolicy(item);
        const grantUntil = Number(guardianTotpGrants.get(item.id) || 0);
        if (premiumFeatureAllowed(licenseState, 'guardian') && policy.splitTotp === 'disabled') {
          const code=document.createElement('div'); code.className='totpCode guardianTotpBlocked'; code.textContent='Unavailable on this device - Split-Trust policy'; node.append(code);
        } else if (premiumFeatureAllowed(licenseState, 'guardian') && policy.splitTotp === 'approval' && Date.now() >= grantUntil) {
          const code=document.createElement('div'); code.className='totpCode guardianTotpBlocked'; code.textContent='Trusted-device approval required'; node.append(code);
          const approve=document.createElement('button'); approve.type='button'; approve.className='outline'; approve.textContent='Request TOTP approval';
          approve.addEventListener('click', async (event)=>{event.stopPropagation();try{await guardianAuthorizeOperation(item,'totp');guardianTotpGrants.set(item.id,Date.now()+60_000);toast('TOTP approved for 60 seconds on this device.');renderItems();}catch(error){toast(error.message,true);}});
          node.append(approve);
        } else {
          const code=document.createElement('div'); code.className='totpCode'; code.dataset.totpId=item.id; code.textContent='••• •••'; node.append(code);
        }
      }
      if (currentView === 'trash') {
        node.classList.add('trashLockedItem');
        const sealed = isSealedTrashItem(item);
        node.innerHTML = `<div class="trashLockedHead"><span class="trashLockIcon">${uiIcon('lock', 18)}</span><div><div class="type">${escapeHtml(itemTypeLabel(item))}</div><div class="name">${escapeHtml(item.name || 'Locked item')}</div></div></div><div class="meta">${escapeHtml(sealed ? 'Locked in Trash - contents cannot be opened' : 'Securing legacy Trash item...')}</div><div class="trashRetention">${escapeHtml(trashRetentionLabel(item))}</div>`;
        const actions=document.createElement('div'); actions.className='trashActions';
        const restore=document.createElement('button'); restore.textContent='Restore'; restore.disabled=!sealed; restore.addEventListener('click', async(e)=>{e.stopPropagation();try{await restoreTrashItem(item.id);}catch(error){toast(error.message,true);}});
        const purge=document.createElement('button'); purge.textContent='Delete now'; purge.className='danger'; purge.addEventListener('click', async(event)=>{event.stopPropagation();try{await ensureSensitiveAccess('Re-enter your master password before permanently deleting this sealed Trash item.',async()=>{if(!confirm('Permanently delete this item now? This cannot be undone and bypasses the remaining 30-day Trash period.'))return;purgeItem(vault,item.id);await saveUnlockedVault(vault);render();toast('Item permanently deleted.');});}catch(error){toast(error.message,true);}});
        actions.append(restore,purge); node.append(actions);
      } else node.addEventListener('click', () => openItemDialog(item));
      grid.append(node);
    }
    if (currentView === 'totp') {
      const accessBar=document.createElement('div');accessBar.className='totpAccessBar';
      const copy=document.createElement('div');copy.innerHTML='<strong>Protected authenticator codes</strong><small>TOTP values stay hidden until you freshly verify the master password. The short Sensitive Access window then expires automatically.</small>';
      const button=document.createElement('button');button.type='button';button.textContent='Verify and show codes';button.addEventListener('click',()=>ensureSensitiveAccess('Re-enter your master password before displaying live TOTP authenticator codes.',()=>refreshTotpCodes()).catch((error)=>toast(error.message,true)));
      accessBar.append(copy,button);mount.append(accessBar);
    }
    mount.append(grid); refreshTotpCodes(); return;
  }

  if (!items.some((item) => item.id === selectedItemId)) selectedItemId = null;
  const selected = items.find((item) => item.id === selectedItemId) || null;
  const mode = settingsState?.vaultViewMode === 'list' ? 'list' : 'grid';
  let browser;
  if (mode === 'grid') {
    browser = `<div class="vaultCardGrid">${items.map(vaultCardMarkup).join('')}</div>`;
  } else {
    const rows = items.map((item) => {
      const shared = isUseOnlySharedLogin(item);
      const expiredShared = shared && sharedAccessIsExpired(item);
      const httpState = loginHttpSecurityState(item);
      const status = expiredShared ? 'Shared access expired' : shared ? 'Use only - immutable' : httpState.insecure ? 'Not secure - HTTP' : item.type === 'login' && item.pendingPasswordChange ? 'Password change pending' : activityLabel(item);
      const favorite = shared ? `<span class="sharedListLock" aria-label="Use-only shared access">${uiIcon('lock', 15)}</span>` : `<button class="favoriteToggle listFavorite ${item.favorite ? 'active' : ''}" data-favorite-id="${escapeHtml(item.id)}" aria-label="${item.favorite ? 'Remove from Favorites' : 'Add to Favorites'}">${uiIcon('favorite', 15)}</button>`;
      return `<div class="vaultListRow ${shared ? 'sharedUseOnlyRow' : ''} ${item.id === selectedItemId ? 'selected' : ''}" data-select-item="${escapeHtml(item.id)}">${favorite}<span class="listTypeIcon">${uiIcon(itemIconName(item), 16)}</span><span class="listMain"><strong>${escapeHtml(item.type === 'login' ? loginDisplayLabel(item) : item.name)}</strong><small>${escapeHtml(item.type === 'login' && item.nickname ? `${item.name} - ${itemMeta(item)}` : itemMeta(item))}</small></span>${item.type === 'login' && !shared ? passwordAgeBadge(item, { compact: true, showUnknown: false }) : ''}<span class="listStatus">${escapeHtml(status)}</span>${item.type === 'login' ? `<button class="miniAction" data-open-login="${escapeHtml(item.id)}" ${expiredShared ? 'disabled' : ''}>${httpState.insecure ? 'Open HTTP site' : 'Secure Login'}</button>${!shared ? `<button class="miniAction outline" data-edit-nickname="${escapeHtml(item.id)}">${loginNicknameValue(item) ? 'Edit nickname' : 'Add nickname'}</button>` : ''}` : ''}<button class="miniAction outline" data-details-id="${escapeHtml(item.id)}">Details</button><button class="miniAction listTrashAction" data-trash-id="${escapeHtml(item.id)}" aria-label="Move ${escapeHtml(item.name)} to Trash">${uiIcon('trash', 14)}</button></div>`;
    }).join('');
    browser = `<div class="vaultList">${rows}</div>`;
  }
  mount.innerHTML = `<div class="vaultBrowseToolbar"><span>${items.length} item${items.length === 1 ? '' : 's'}</span>${viewModeControls()}</div><div class="vaultListLayout"><div>${browser}</div>${renderSelectedDrawer(selected)}</div>`;
  wireFaviconFallbacks(mount);
  document.querySelectorAll('[data-select-item]').forEach((node) => node.addEventListener('click', (event) => {
    if (event.target.closest('button,input,a,label')) return;
    selectedItemId = node.dataset.selectItem || null;
    renderItems();
    requestAnimationFrame(() => document.querySelector('.itemDrawer')?.scrollIntoView({ block: 'nearest', behavior: 'smooth' }));
  }));
  document.querySelectorAll('[data-edit-nickname]').forEach((button) => button.addEventListener('click', async (event) => {
    event.stopPropagation();
    const item = vault.items.find((candidate) => candidate.id === button.dataset.editNickname && !candidate.deletedAt);
    if (!item || item.type !== 'login' || isUseOnlySharedLogin(item)) return;
    await openLoginNicknameEditor(item);
  }));
  document.querySelectorAll('[data-details-id]').forEach((button) => button.addEventListener('click', (event) => { event.stopPropagation(); selectedItemId = button.dataset.detailsId; renderItems(); }));
  document.querySelectorAll('[data-trash-id]').forEach((button) => button.addEventListener('click', async (event) => {
    event.stopPropagation();
    try { await moveItemToTrashWithConfirmation(button.dataset.trashId); }
    catch (error) { toast(error.message, true); }
  }));
  document.querySelectorAll('[data-open-login]').forEach((button) => button.addEventListener('click', async (event) => { event.stopPropagation(); const item = vault.items.find((candidate) => candidate.id === button.dataset.openLogin && !candidate.deletedAt); if (!item) return; try { if (isUseOnlySharedLogin(item) && sharedAccessIsExpired(item)) throw new Error('This shared login access has expired. Ask the sender for a new package.'); const httpState=loginHttpSecurityState(item); if (httpState.insecure && isUseOnlySharedLogin(item)) throw new Error('Sender-controlled shared credentials cannot be opened on HTTP websites.'); if (httpState.insecure && !confirm('This saved website uses HTTP, not HTTPS. The connection is not encrypted and credentials can be intercepted or changed in transit. Open the HTTP site anyway?')) return; const run=()=>runtimeMessage({ type:'OPEN_LOGIN_ITEM', itemId:item.id, allowInsecureHttp:httpState.insecure }); if (isUseOnlySharedLogin(item)) await ensureFreshSensitiveAccess('Enter your master password before using this sender-controlled shared credential for Secure Login.', run); else if (item.requireReauthBeforeFill) await ensureSensitiveAccess('Re-enter your master password before opening and signing in with this protected credential.', run); else await run(); toast(httpState.insecure ? 'Opened the HTTP website. Use the VaultCove extension icon there to confirm and submit the saved login.' : 'Opening the saved website for Secure Login.'); } catch(error) { toast(error.message,true); } }));
  document.querySelectorAll('[data-favorite-id]').forEach((button) => button.addEventListener('click', async (event) => {
    if (!premiumFeatureAllowed(licenseState, 'favorites')) { event.stopPropagation(); toast('Favorites requires Premium Lifetime.', true); return; }
    event.stopPropagation();
    const item = vault.items.find((candidate) => candidate.id === button.dataset.favoriteId);
    if (!item || isUseOnlySharedLogin(item)) return;
    item.favorite = !item.favorite;
    upsertItem(vault, item);
    await saveUnlockedVault(vault);
    renderItems();
    toast(item.favorite ? 'Added to Favorites.' : 'Removed from Favorites.');
  }));
  document.querySelectorAll('[data-vault-view]').forEach((button) => button.addEventListener('click', async () => {
    settingsState.vaultViewMode = button.dataset.vaultView === 'list' ? 'list' : 'grid';
    await setSettings({ vaultViewMode: settingsState.vaultViewMode });
    renderItems();
  }));
  document.querySelector('[data-edit-selected]')?.addEventListener('click', () => {
    if (!selected || isUseOnlySharedLogin(selected)) return;
    openItemDialog(selected);
  });
  document.querySelector('[data-favorite-selected]')?.addEventListener('click', async () => {
    if (!premiumFeatureAllowed(licenseState, 'favorites')) { toast('Favorites requires Premium Lifetime.', true); return; }
    if (!selected || isUseOnlySharedLogin(selected)) return;
    selected.favorite = !selected.favorite; upsertItem(vault, selected); await saveUnlockedVault(vault); renderItems(); toast(selected.favorite ? 'Added to Favorites.' : 'Removed from Favorites.');
  });
  document.querySelector('[data-mark-password-changed]')?.addEventListener('click', async () => {
    if (!selected || selected.type !== 'login' || isUseOnlySharedLogin(selected)) return;
    selected.lastPasswordChangeAt = new Date().toISOString();
    upsertItem(vault, selected);
    await appendActivityEvent(vault, 'password-age-marked', { itemId:selected.id, itemType:'login', itemName:selected.name || 'Login' });
    await saveUnlockedVault(vault);
    renderItems();
    toast('Password age marked as changed today.');
  });
}

const DASHBOARD_ACTIVITY_TYPES = new Set([
  'secure-login-used', 'insecure-http-login-used',
  'new-login-saved',
  'login-created', 'login-updated', 'password-updated',
  'card-created', 'card-viewed', 'card-updated',
  'bank-created', 'bank-viewed', 'bank-updated',
  'identity-created', 'identity-viewed', 'identity-updated',
  'secure-note-created', 'secure-note-viewed', 'secure-note-updated',
  'password-age-marked',
  'backup-created', 'backup-restored', 'migration-imported',
  'item-trashed', 'item-restored', 'master-password-changed', 'passwords-shared'
]);

function activityEventLabel(event) {
  const labels = {
    'secure-login-used': 'Password used for login',
    'insecure-http-login-used': 'Password used on HTTP (not secure)',
    'new-login-saved': 'New login saved',
    'login-created': 'Login added',
    'login-updated': 'Login changed',
    'password-updated': 'Password changed',
    'card-created': 'Card added',
    'card-viewed': 'Card viewed',
    'card-updated': 'Card changed',
    'bank-created': 'Bank Account added',
    'bank-viewed': 'Bank Account viewed',
    'bank-updated': 'Bank Account changed',
    'identity-created': 'Identity added',
    'identity-viewed': 'Identity viewed',
    'identity-updated': 'Identity changed',
    'secure-note-created': 'Secure Note added',
    'secure-note-viewed': 'Secure Note viewed',
    'secure-note-updated': 'Secure Note changed',
    'password-age-marked': 'Password change date marked',
    'password-change-candidate': 'Password-change candidate detected',
    'new-login-candidate': 'New-login candidate detected',
    'backup-created': 'Encrypted backup created',
    'backup-restored': 'Encrypted backup restored',
    'migration-imported': 'Password-manager import completed',
    'item-trashed': 'Item moved to Trash',
    'item-restored': 'Item restored from Trash',
    'master-password-changed': 'Master Password changed',
    'passwords-shared': 'Passwords shared'
  };
  return labels[event?.type] || String(event?.type || 'Vault activity').replace(/[-_.]+/g, ' ');
}

function activityEventItem(event) {
  const itemId = String(event?.details?.itemId || '');
  if (!itemId) return null;
  return (vault?.items || []).find((item) => item.id === itemId) || null;
}

function activityEventFallbackSubject(event) {
  if (event?.details?.itemName) return String(event.details.itemName);
  if (event?.type === 'backup-created' || event?.type === 'backup-restored') return 'Backup & Restore';
  if (event?.type === 'migration-imported') return 'Migration Center';
  if (event?.type === 'master-password-changed') return 'Vault security';
  return 'VaultCove';
}

function activityEventIconName(event, item = activityEventItem(event)) {
  if (item) return itemIconName(item);
  const type = String(event?.details?.itemType || '');
  if (type === 'login') return 'login';
  if (type === 'card') return 'card';
  if (type === 'bank') return 'bank';
  if (type === 'identity') return 'identity';
  if (type === 'note') return 'note';
  if (String(event?.type || '').startsWith('backup-')) return 'backup';
  if (event?.type === 'migration-imported') return 'migration';
  if (event?.type === 'master-password-changed') return 'master';
  if (event?.type === 'passwords-shared') return 'shared';
  if (event?.type === 'item-trashed') return 'trash';
  return 'security';
}

function activityEventPresentation(event) {
  const item = activityEventItem(event);
  const subject = item?.name || activityEventFallbackSubject(event);
  const action = activityEventLabel(event);
  const host = event?.details?.host ? String(event.details.host) : '';
  return {
    item,
    subject,
    action,
    detail: host && ['secure-login-used','insecure-http-login-used'].includes(event?.type) ? `${action} - ${host}` : action,
    icon: activityEventIconName(event, item),
    at: event?.at || ''
  };
}

function dashboardActivityEntries(sourceVault = vault, limit = 6) {
  return activityLogEntries(sourceVault, 100)
    .filter((event) => DASHBOARD_ACTIVITY_TYPES.has(String(event?.type || '')))
    .slice(0, Math.max(1, Math.min(10, Number(limit) || 6)));
}

function dashboardActivityRowMarkup(event) {
  const view = activityEventPresentation(event);
  const identityPrivate = view.item?.type === 'identity' || String(event?.details?.itemType || '') === 'identity';
  const subject = identityPrivate ? 'Identity record' : view.subject;
  const itemId = view.item && !view.item.deletedAt ? String(view.item.id) : '';
  const tag = itemId ? 'button' : 'div';
  const openAttr = itemId ? ` data-activity-open-id="${escapeHtml(itemId)}"` : '';
  return `<${tag} class="recentRow activityEventRow"${openAttr}>
    <span class="recentIcon">${uiIcon(view.icon, 18)}</span>
    <span class="recentMain"><strong>${escapeHtml(subject)}</strong><small>${escapeHtml(view.detail)}</small></span>
    <span class="recentTime">${escapeHtml(relativeTime(view.at))}</span>
  </${tag}>`;
}

async function appendItemActivity(type, item, details = {}) {
  if (!vault || !item?.id) return null;
  const event = await appendActivityEvent(vault, type, {
    itemId: item.id,
    itemType: item.type,
    itemName: item.name || itemTypeLabel(item),
    ...details
  });
  // Activity is already inside the encrypted vault. Persist it without sending a
  // website-login data refresh because no credential data changed.
  await persistUnlockedVault(vault, { touch:false, markRecoveryPending:false, markManualBackupPending:false });
  return event;
}

function protectedViewActivityType(item) {
  return ({ card:'card-viewed', bank:'bank-viewed', identity:'identity-viewed', note:'secure-note-viewed' })[item?.type] || '';
}

function itemSaveActivityType(existing, item) {
  if (!item) return '';
  if (!existing) return ({ login:'login-created', card:'card-created', bank:'bank-created', identity:'identity-created', note:'secure-note-created' })[item.type] || '';
  if (item.type === 'login') return existing.password !== item.password ? 'password-updated' : 'login-updated';
  return ({ card:'card-updated', bank:'bank-updated', identity:'identity-updated', note:'secure-note-updated' })[item.type] || '';
}

function securityPasswordRows(items) {
  const logins = items.filter((item) => item.type === 'login' && !item.deletedAt && !isUseOnlySharedLogin(item));
  const groups = new Map();
  for (const item of logins) {
    if (!item.password) continue;
    const group = groups.get(item.password) || [];
    group.push(item.id);
    groups.set(item.password, group);
  }
  return logins.map((item) => {
    const assessment = assessPassword(item.password, passwordContextForItem(item));
    const reuseCount = item.password ? (groups.get(item.password)?.length || 0) : 0;
    return {
      item,
      assessment,
      weak: assessment.score < 3,
      reused: reuseCount > 1,
      reuseCount
    };
  }).sort((a, b) => a.assessment.score - b.assessment.score || Number(b.reused) - Number(a.reused) || a.item.name.localeCompare(b.item.name));
}

function securityFilterLabel(filter) {
  if (filter === 'risk') return 'At-risk credentials';
  if (filter === 'weak') return 'Weak passwords';
  if (filter === 'reused') return 'Reused passwords';
  return 'All login credentials';
}

function openSecurityFilter(filter = 'all') {
  securityIssueFilter = ['risk', 'weak', 'reused'].includes(filter) ? filter : 'all';
  currentView = 'security';
  els.search.value = '';
  Promise.resolve(render()).then(() => {
    document.querySelector('#passwordStrengthReview')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }).catch((error) => toast(error.message, true));
}

function passwordStrengthRowMarkup(entry) {
  const { item, assessment, reused, reuseCount } = entry;
  const percent = Math.max(4, Math.min(100, assessment.score * 25));
  const issue = assessment.issues?.length ? assessment.issues.join(' - ') : 'No obvious local weakness detected';
  return `<div class="passwordStrengthRow score-${assessment.score}" data-security-credential="${escapeAttr(item.id)}">
    <span class="passwordStrengthIcon">${uiIcon(assessment.score >= 3 ? 'strong' : 'weak', 18)}</span>
    <span class="passwordStrengthMain"><strong>${escapeHtml(item.name)}</strong><small>${escapeHtml(itemMeta(item))}</small></span>
    <span class="passwordStrengthMeter" aria-label="Password strength ${escapeAttr(assessment.label)}"><span><i style="width:${percent}%"></i></span><b>${escapeHtml(assessment.label)}</b><small>${escapeHtml(issue)}</small></span>
    <span class="passwordStrengthFlags">${entry.weak ? '<em class="securityIssuePill weakIssue">Weak</em>' : '<em class="securityIssuePill strongIssue">Strong</em>'}${reused ? `<em class="securityIssuePill reusedIssue">Reused in ${reuseCount}</em>` : ''}</span>
    <button class="miniAction outline" type="button" data-security-details="${escapeAttr(item.id)}">Credential details</button>
  </div>`;
}


function duplicateLoginGroups(items = []) {
  const groups = new Map();
  for (const item of items) {
    if (!item || item.deletedAt || item.type !== 'login' || isUseOnlySharedLogin(item)) continue;
    const username = String(item.username || '').trim().toLowerCase();
    let host = '';
    try { host = new URL((item.urls || [])[0] || '').hostname.toLowerCase(); } catch {}
    if (!host && !username) continue;
    const key = `${host}|${username}`;
    const group = groups.get(key) || [];
    group.push(item);
    groups.set(key, group);
  }
  return [...groups.values()].filter((group) => group.length > 1).sort((a,b) => b.length - a.length || String(a[0]?.name || '').localeCompare(String(b[0]?.name || '')));
}

function securitySkillsMarkup(health, securityItems) {
  const backup = manualBackupHealth(settingsState);
  const insecureHttp = securityItems.filter((item) => item.type === 'login' && !item.deletedAt && loginHasInsecureHttpUrl(item)).length;
  const skills = [
    { title:'Use unique passwords', done:health.reused === 0, detail:health.reused ? `${health.reused} reused credential${health.reused === 1 ? '' : 's'} need review.` : 'No reused passwords detected locally.', action:'security', button:'Review passwords' },
    { title:'Use strong passwords', done:health.weak === 0, detail:health.weak ? `${health.weak} weak credential${health.weak === 1 ? '' : 's'} need attention.` : 'No weak passwords detected locally.', action:'security', button:'Review passwords' },
    { title:'Avoid insecure HTTP logins', done:insecureHttp === 0, detail:insecureHttp ? `${insecureHttp} saved login${insecureHttp === 1 ? '' : 's'} use HTTP and cannot be made safe by a password manager.` : 'All saved login URLs use HTTPS.', action:'login', button:'Review logins' },
    { title:'Keep a verified manual backup', done:!backup.pending && Boolean(backup.lastMs), detail:!backup.pending && backup.lastMs ? `Verified ${backup.lastLabel}.` : 'Protected changes are waiting for a new encrypted .vcvault backup.', action:'backup', button:'Back up now' },
    { title:'Prepare Disaster Recovery', done:Boolean(settingsState?.disasterRecoveryEnabled && settingsState?.disasterRecoveryLastSuccessAt), detail:settingsState?.disasterRecoveryEnabled ? 'Automatic encrypted Disaster Recovery is enabled.' : 'Optional off-device Disaster Recovery is not enabled.', action:'backup', button:'Recovery settings' },
    { title:'Protect VaultCove with an authenticator', done:Boolean(settingsState?.vaultTotpEnabled), detail:settingsState?.vaultTotpEnabled ? 'Authenticator confirmation is enabled.' : 'Add an authenticator for stronger VaultCove Sensitive Access.', action:'settings', button:'Security settings' }
  ];
  const completed = skills.filter((skill) => skill.done).length;
  return `<section class="settingsCard securitySkillsCard"><div class="panelTitle"><div><h3>Security Skills</h3><p class="settingHint">Short, practical checks that help you strengthen the vault without exposing any secret values.</p></div><span class="pill ${completed === skills.length ? 'good' : ''}">${completed} of ${skills.length} complete</span></div><div class="securitySkillsGrid">${skills.map((skill) => `<div class="securitySkill ${skill.done ? 'complete' : 'attention'}"><span class="securitySkillIcon">${uiIcon(skill.done ? 'strong' : 'warningClock',18)}</span><div><strong>${escapeHtml(skill.title)}</strong><small>${escapeHtml(skill.detail)}</small></div><button type="button" class="miniAction outline" data-security-skill-action="${escapeAttr(skill.action)}">${escapeHtml(skill.button)}</button></div>`).join('')}</div></section>`;
}

function renderSecurity() {
  const securityItems = vault.items.filter((item) => !isUseOnlySharedLogin(item));
  const health = vaultHealth(securityItems);
  const ageSummary = passwordAgeSummary(securityItems);
  const passwordRows = securityPasswordRows(securityItems);
  const duplicateGroups = duplicateLoginGroups(securityItems);
  const duplicateItems = duplicateGroups.reduce((sum, group) => sum + group.length, 0);
  const filteredPasswordRows = securityIssueFilter === 'risk'
    ? passwordRows.filter((entry) => entry.weak || entry.reused)
    : securityIssueFilter === 'weak'
      ? passwordRows.filter((entry) => entry.weak)
      : securityIssueFilter === 'reused'
        ? passwordRows.filter((entry) => entry.reused)
        : passwordRows;
  const passwordStrengthHtml = filteredPasswordRows.length ? filteredPasswordRows.slice(0, 100).map(passwordStrengthRowMarkup).join('') : `<div class="emptyState compactEmpty">No ${escapeHtml(securityFilterLabel(securityIssueFilter).toLowerCase())} found.</div>`;
  const ageReviewItems = securityItems.filter((item) => item.type === 'login' && !item.deletedAt).map((item) => ({ item, age: passwordAgeState(item) })).filter(({ age }) => age.state === 'review' || age.state === 'high' || age.state === 'unknown').sort((a, b) => {
    const rank = { high: 0, review: 1, unknown: 2 };
    return (rank[a.age.state] ?? 9) - (rank[b.age.state] ?? 9) || (b.age.days ?? -1) - (a.age.days ?? -1) || a.item.name.localeCompare(b.item.name);
  });
  const pending = vault.items.filter((item) => item.type === 'login' && !item.deletedAt && item.pendingPasswordChange?.password);
  const newLoginCaptures = Array.isArray(vault.pendingLoginCaptures) ? vault.pendingLoginCaptures : [];
  const ageHtml = ageReviewItems.length ? ageReviewItems.slice(0, 50).map(({ item, age }) => `<div class="passwordAgeRow age-${escapeHtml(age.state)}">
    <span class="passwordAgeRowIcon">${uiIcon(age.needsReview ? 'warningClock' : 'clock', 18)}</span>
    <span class="passwordAgeRowMain"><strong>${escapeHtml(item.name)}</strong><small>${escapeHtml(itemMeta(item))}</small></span>
    ${passwordAgeBadge(item, { compact: true })}
    <button class="miniAction outline" data-age-details="${escapeHtml(item.id)}">Details</button>
    <button class="miniAction" data-age-mark-today="${escapeHtml(item.id)}">Mark changed today</button>
  </div>`).join('') : '<div class="emptyState compactEmpty">No passwords currently need an age review.</div>';

  const pendingHtml = pending.length ? pending.map((item) => {
    const change = item.pendingPasswordChange;
    const detectionLabel = change.confidence === 'submitted-login' ? 'Different password submitted on login form' : 'Password-change form detected';
    return `<div class="passwordChangeCard" data-change-id="${escapeHtml(item.id)}">
      <div><strong>${escapeHtml(item.name)}</strong><small>${escapeHtml(detectionLabel)} - ${escapeHtml(change.hostname || 'Saved HTTPS login')} - ${escapeHtml(relativeTime(change.detectedAt))}</small><p>A possible password update was captured locally and stored only inside the encrypted vault. It is not displayed here and is never applied until you approve it. A different password submitted on a login form may simply be a typo, so review before updating.</p></div>
      <div class="passwordChangeActions"><button data-approve-change="${escapeHtml(item.id)}">Update saved password</button><button data-ignore-change="${escapeHtml(item.id)}" class="outline">Ignore</button></div>
    </div>`;
  }).join('') : '<div class="emptyState">No pending password changes.</div>';

  const newLoginHtml = newLoginCaptures.length ? newLoginCaptures.map((capture) => `<div class="passwordChangeCard" data-new-login-id="${escapeHtml(capture.id)}">
    <div><strong>${escapeHtml(capture.name || capture.hostname || 'New login')}</strong><small>${escapeHtml(capture.hostname || 'Website')} - ${escapeHtml(maskIdentifier(capture.username || ''))} - ${escapeHtml(relativeTime(capture.detectedAt))}</small><p>VaultCove detected a submitted account that is not currently saved for this website and identifier. The password remains hidden and is stored only inside the encrypted vault candidate until you save or ignore it.</p></div>
    <div class="passwordChangeActions"><button data-save-new-login="${escapeHtml(capture.id)}">Save login</button><button data-ignore-new-login="${escapeHtml(capture.id)}" class="outline">Ignore</button></div>
  </div>`).join('') : '<div class="emptyState">No pending new logins.</div>';

  const duplicateHtml = duplicateGroups.length ? duplicateGroups.slice(0, 30).map((group) => {
    const first = group[0];
    let host = '';
    try { host = new URL((first.urls || [])[0] || '').hostname; } catch {}
    return `<div class="duplicateGroup"><div><strong>${escapeHtml(host || first.name || 'Possible duplicate')}</strong><small>${escapeHtml(maskIdentifier(first.username || 'No username'))} - ${group.length} matching records</small></div><div class="duplicateGroupItems">${group.slice(0,5).map((item) => `<button type="button" class="miniAction outline" data-security-details="${escapeAttr(item.id)}">${escapeHtml(loginDisplayLabel(item))}</button>`).join('')}</div></div>`;
  }).join('') : '<div class="emptyState compactEmpty">No obvious duplicate login records detected.</div>';

  const premiumAdvanced = premiumFeatureAllowed(licenseState, 'security-advanced');
  const activityEntries = activityLogEntries(vault, 50);
  const activityHtml = activityEntries.length ? activityEntries.map((event) => {
    const view = activityEventPresentation(event);
    return `<div class="passwordAgeRow"><span class="passwordAgeRowIcon">${uiIcon(view.icon,18)}</span><span class="passwordAgeRowMain"><strong>${escapeHtml(view.subject)}</strong><small>${escapeHtml(view.detail)} - ${escapeHtml(relativeTime(view.at))}</small></span></div>`;
  }).join('') : '<div class="emptyState compactEmpty">No local security activity has been recorded yet.</div>';

  const advancedSecurityHtml = premiumAdvanced
    ? `<section class="settingsCard"><div class="panelTitle"><h3>Password age review</h3><span class="pill ${ageSummary.over90 ? 'warningPill' : 'good'}">${ageSummary.over90} over 90 days</span></div><p>Premium Lifetime adds password-age review. Imported credentials without a trustworthy password-change timestamp are shown as Age unknown instead of using the import date.</p><div class="passwordAgeList">${ageHtml}</div></section>
       <section class="settingsCard" id="activityHistorySection"><div class="panelTitle"><h3>Encrypted activity history</h3><span id="activityIntegrity" class="pill">Checking chain</span></div><p>Premium Lifetime shows the tamper-evident encrypted security activity history without passwords or secret values.</p><div class="passwordAgeList">${activityHtml}</div></section>`
    : `<section class="settingsCard premiumLockedSection securityPremiumPreview"><div class="panelTitle"><div><h3>Advanced Security Center</h3><p class="settingHint">Free Forever keeps the local security score plus weak and reused password detection. Premium adds the advanced local checks below.</p></div><span class="premiumTag">Premium</span></div>
         <div class="premiumFeatureCatalog compactCatalog">${premiumLockedFeatureMarkup('password-age-review', { compact:true })}${premiumLockedFeatureMarkup('encrypted-activity-history', { compact:true })}</div>
         ${premiumInlineActionsMarkup()}
       </section>`;

  const healthState = securityHealthPresentation(health);
  const ageOverview = premiumAdvanced
    ? `<div class="securityOverviewMetric"><i>${uiIcon('warningClock',18)}</i><strong>${ageSummary.over90}</strong><span>Password age risks</span><small>90+ days unchanged</small></div>`
    : `<div class="securityOverviewMetric premiumFeatureLocked" tabindex="0" aria-disabled="true" title="Premium Lifetime reviews passwords that are 90 days old or older and separates credentials whose true change date is unknown."><i>${uiIcon('lock',18)}</i><strong>Premium</strong><span>Password age review</span><small>Advanced Security Center</small><span class="premiumFeaturePurposeTooltip" role="tooltip">Reviews passwords that are 90 days old or older and separates credentials whose true change date is unknown.</span></div>`;

  els.content.innerHTML = `${pageHead('Security Center','Review local password risks and the exact credentials that need attention. Nothing in this analysis leaves your vault.')}
    <section class="settingsCard securityOverviewCard health-${healthState.tone}">
      <div class="securityOverviewPrimary">
        ${securityScoreRingMarkup(health)}
        <div class="securityOverviewCopy">
          <span class="securityStateBadge">${escapeHtml(healthState.label)}</span>
          <h2>${health.atRisk ? `${health.atRisk} credential${health.atRisk === 1 ? '' : 's'} need attention` : 'No weak or reused passwords found'}</h2>
          <p>Weak and reused passwords are counted as risk. A credential that is both weak and reused is counted once in the at-risk total, while both findings remain visible.</p>
          <div class="securityOverviewFacts"><span>${health.strong} strong</span><span>${health.riskFindings} findings</span><span>${health.total} saved logins</span></div>
        </div>
      </div>
      <div class="securityOverviewMetrics">
        <button class="securityOverviewMetric securityOverviewButton" type="button" data-security-list-filter="risk"><i>${uiIcon('security',18)}</i><strong>${health.atRisk}</strong><span>At-risk credentials</span><small>Unique weak or reused logins</small></button>
        <button class="securityOverviewMetric securityOverviewButton" type="button" data-security-list-filter="weak"><i>${uiIcon('weak',18)}</i><strong>${health.weak}</strong><span>Weak passwords</span><small>Needs stronger passwords</small></button>
        <button class="securityOverviewMetric securityOverviewButton" type="button" data-security-list-filter="reused"><i>${uiIcon('reused',18)}</i><strong>${health.reused}</strong><span>Reused passwords</span><small>Shared across multiple logins</small></button>
        ${ageOverview}
      </div>
    </section>
    ${securitySkillsMarkup(health, securityItems)}
    <section class="settingsCard"><div class="panelTitle"><div><h3>Possible duplicate logins</h3><p class="settingHint">Matches use the same saved host and username. VaultCove never merges or deletes them automatically.</p></div><span class="pill">${duplicateGroups.length} group${duplicateGroups.length === 1 ? '' : 's'} - ${duplicateItems} records</span></div><div class="duplicateList">${duplicateHtml}</div></section>
    <section id="passwordStrengthReview" class="settingsCard passwordStrengthReview"><div class="panelTitle"><div><h3>Password strength and reuse</h3><p class="settingHint">Free Forever includes local password-strength bars and affected-credential drill-down without exposing passwords.</p></div><span class="pill">${escapeHtml(securityFilterLabel(securityIssueFilter))}</span></div><div class="securityFilterBar"><button type="button" data-security-list-filter="all" class="${securityIssueFilter === 'all' ? 'active' : ''}">All (${passwordRows.length})</button><button type="button" data-security-list-filter="risk" class="${securityIssueFilter === 'risk' ? 'active' : ''}">At risk (${health.atRisk})</button><button type="button" data-security-list-filter="weak" class="${securityIssueFilter === 'weak' ? 'active' : ''}">Weak (${health.weak})</button><button type="button" data-security-list-filter="reused" class="${securityIssueFilter === 'reused' ? 'active' : ''}">Reused (${health.reused})</button></div><div class="passwordStrengthList">${passwordStrengthHtml}</div></section>
    <div class="securityReviewGrid">
      <section class="settingsCard"><h3>New-login review</h3><p>New submitted accounts stay as encrypted review candidates until you explicitly save or ignore them.</p><div class="passwordChangeList">${newLoginHtml}</div></section>
      <section class="settingsCard"><h3>Password-change review</h3><p>Ambiguous password-change candidates stay encrypted and pending until you approve or discard them. High-confidence password-change forms are saved automatically.</p><div class="passwordChangeList">${pendingHtml}</div></section>
    </div>
    ${advancedSecurityHtml}`;
  if (premiumAdvanced) {
    verifyActivityLog(vault).then((integrity) => {
      const badge = $('activityIntegrity');
      if (!badge) return;
      badge.textContent = integrity.ok ? `Chain verified - ${integrity.count}` : `Chain issue at entry ${Number(integrity.index || 0) + 1}`;
      badge.className = `pill ${integrity.ok ? 'good' : 'warningPill'}`;
    }).catch(() => {
      const badge = $('activityIntegrity');
      if (badge) { badge.textContent = 'Chain check failed'; badge.className = 'pill warningPill'; }
    });
  } else {
    wirePremiumUpgradeActions();
  }

  document.querySelectorAll('[data-security-list-filter]').forEach((button) => button.addEventListener('click', () => {
    securityIssueFilter = ['risk', 'weak', 'reused'].includes(button.dataset.securityListFilter) ? button.dataset.securityListFilter : 'all';
    renderSecurity();
    document.querySelector('#passwordStrengthReview')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }));
  document.querySelectorAll('[data-security-skill-action]').forEach((button) => button.addEventListener('click', () => {
    const action = button.dataset.securitySkillAction;
    if (action === 'security') { securityIssueFilter = 'risk'; renderSecurity(); return; }
    if (action === 'backup' || action === 'settings' || action === 'login') switchView(action);
  }));

  document.querySelectorAll('[data-security-details]').forEach((button) => button.addEventListener('click', () => {
    const item = vault.items.find((candidate) => candidate.id === button.dataset.securityDetails && !candidate.deletedAt);
    if (item) openItemDialog(item);
  }));

  document.querySelectorAll('[data-age-details]').forEach((button) => button.addEventListener('click', () => {
    const item = vault.items.find((candidate) => candidate.id === button.dataset.ageDetails);
    if (item) openItemDialog(item);
  }));
  document.querySelectorAll('[data-age-mark-today]').forEach((button) => button.addEventListener('click', async () => {
    const item = vault.items.find((candidate) => candidate.id === button.dataset.ageMarkToday);
    if (!item || item.type !== 'login') return;
    item.lastPasswordChangeAt = new Date().toISOString();
    upsertItem(vault, item);
    await appendActivityEvent(vault, 'password-age-marked', { itemId:item.id, itemType:'login', itemName:item.name || 'Login' });
    await saveUnlockedVault(vault);
    renderSecurity();
    toast('Password age marked as changed today.');
  }));

  document.querySelectorAll('[data-approve-change]').forEach((button) => button.addEventListener('click', () => {
    const id = button.dataset.approveChange;
    ensureSensitiveAccess('Re-enter your master password before replacing a saved password.', async () => {
      const item = vault.items.find((candidate) => candidate.id === id);
      const pendingChange = item?.pendingPasswordChange;
      if (!item || !pendingChange?.password) throw new Error('This password change is no longer pending.');
      if (item.password && item.password !== pendingChange.password) {
        item.passwordHistory = [...(item.passwordHistory || []), { password: item.password, changedAt: pendingChange.detectedAt || new Date().toISOString() }].slice(-10);
      }
      item.password = pendingChange.password;
      item.lastPasswordChangeAt = new Date().toISOString();
      item.pendingPasswordChange = null;
      upsertItem(vault, item);
      await appendActivityEvent(vault, 'password-updated', { itemId:item.id, itemType:'login', itemName:item.name || 'Login' });
      await saveUnlockedVault(vault);
      await runtimeMessage({ type: 'PASSWORD_CHANGE_CONFIRMED', itemId: item.id, hostname:String(pendingChange.hostname || ''), occurredAt:String(item.lastPasswordChangeAt || new Date().toISOString()) });
      renderSecurity();
      toast('Saved password updated inside the encrypted vault.');
    }).catch((error) => toast(error.message, true));
  }));
  document.querySelectorAll('[data-ignore-change]').forEach((button) => button.addEventListener('click', () => {
    const id = button.dataset.ignoreChange;
    ensureSensitiveAccess('Re-enter your master password before discarding a captured password-change candidate.', async () => {
      const item = vault.items.find((candidate) => candidate.id === id);
      if (!item) throw new Error('Login no longer exists.');
      item.pendingPasswordChange = null;
      upsertItem(vault, item);
      await saveUnlockedVault(vault);
      renderSecurity();
      toast('Password-change candidate discarded.');
    }).catch((error) => toast(error.message, true));
  }));

  document.querySelectorAll('[data-save-new-login]').forEach((button) => button.addEventListener('click', async () => {
    const id = button.dataset.saveNewLogin;
    try {
      // This is an explicit user-approved Add action inside an already-unlocked
      // vault. Do not demand a second master-password verification just to save
      // the newly detected login.
      const capture = (vault.pendingLoginCaptures || []).find((candidate) => candidate.id === id);
      if (!capture?.password || !capture?.username) throw new Error('This new-login candidate is no longer pending.');
      const duplicate = vault.items.find((item) => item.type === 'login' && !item.deletedAt && (item.urls || []).some((url) => {
        try { return new URL(url).hostname.replace(/^www\./, '') === String(capture.hostname || '').replace(/^www\./, ''); } catch { return false; }
      }) && String(item.username || '').trim().toLowerCase() === String(capture.username || '').trim().toLowerCase());
      if (duplicate) throw new Error('This website/account is already saved in VaultCove. Review the existing login instead.');
      const item = createItem('login', {
        name: capture.name || capture.hostname || 'New Login',
        username: capture.username,
        password: capture.password,
        urls: [capture.origin || `https://${capture.hostname}`],
        autoLogin: false,
        requireReauthBeforeFill: false,
        lastPasswordChangeAt: new Date().toISOString()
      });
      upsertItem(vault, item);
      vault.pendingLoginCaptures = (vault.pendingLoginCaptures || []).filter((candidate) => candidate.id !== id);
      await saveUnlockedVault(vault);
      selectedItemId = item.id;
      renderSecurity();
      toast('New login encrypted and saved to VaultCove.');
    } catch (error) { toast(error.message, true); }
  }));
  document.querySelectorAll('[data-ignore-new-login]').forEach((button) => button.addEventListener('click', async () => {
    const id = button.dataset.ignoreNewLogin;
    vault.pendingLoginCaptures = (vault.pendingLoginCaptures || []).filter((candidate) => candidate.id !== id);
    await saveUnlockedVault(vault);
    renderSecurity();
    toast('New-login candidate ignored.');
  }));

  const newLoginHighlight = new URLSearchParams(location.search).get('newLogin');
  if (newLoginHighlight) document.querySelector(`[data-new-login-id="${CSS.escape(newLoginHighlight)}"]`)?.scrollIntoView({ block: 'center', behavior: 'smooth' });

  const highlight = new URLSearchParams(location.search).get('passwordChange');
  if (highlight) document.querySelector(`[data-change-id="${CSS.escape(highlight)}"]`)?.scrollIntoView({ block: 'center', behavior: 'smooth' });
}

function renderGenerator() {
  generatedPassword = generatedPassword || generatePassword({length:20});
  els.content.innerHTML = `${pageHead()}<section class="settingsCard generatorShell"><h3>Local Password Generator</h3><p>Generation uses the browser cryptographic random-number generator. Nothing is transmitted.</p><div class="generatorOutput"><input id="generatedPassword" value="${escapeHtml(generatedPassword)}" readonly><button id="copyGenerated">Copy</button><button id="regenPassword" class="outline">Regenerate</button></div><div class="generatorOptions"><label class="rangeRow"><span>Length</span><input id="generatorLength" type="range" min="12" max="64" value="20"><b id="generatorLengthValue">20</b></label><label><input id="genLower" type="checkbox" checked> Lowercase</label><label><input id="genUpper" type="checkbox" checked> Uppercase</label><label><input id="genDigits" type="checkbox" checked> Numbers</label><label><input id="genSymbols" type="checkbox" checked> Symbols</label></div></section>`;
  const regenerate = () => {
    try {
      const length=Number($('generatorLength').value); $('generatorLengthValue').textContent=String(length);
      generatedPassword=generatePassword({length,lower:$('genLower').checked,upper:$('genUpper').checked,digits:$('genDigits').checked,symbols:$('genSymbols').checked});
      $('generatedPassword').value=generatedPassword;
    } catch (error) { toast(error.message,true); }
  };
  $('regenPassword').addEventListener('click',regenerate);
  $('generatorLength').addEventListener('input',regenerate);
  for (const id of ['genLower','genUpper','genDigits','genSymbols']) $(id).addEventListener('change',regenerate);
  $('copyGenerated').addEventListener('click',async()=>{await copyVaultClipboard($('generatedPassword').value,{label:'Generated password'});});
}

async function renderMigration() {
  pendingMigration = null;
  els.content.innerHTML = `${pageHead()}<div class="settingsGrid migrationGrid">
    <section class="settingsCard">
      <h3>Import from another password manager</h3>
      <p>VaultCove reads the export only inside this extension. Nothing is uploaded. After import, records are stored inside the encrypted VaultCove vault.</p>
      <label>Export file<input id="migrationFile" type="file" accept=".csv,text/csv,text/plain"></label>
      <p class="settingHint">VaultCove automatically detects the supported source layout. No source-format selection is required.</p>
      <div class="migrationMergePolicy"><strong>Duplicate-aware merge is automatic.</strong><span>New records are added, matching records are merged, and existing conflicting secrets are preserved.</span></div>
      <div class="migrationActions"><button id="migrationPreview">Preview locally</button><button id="migrationImport" class="outline" disabled>Import and encrypt</button></div>
      <div class="migrationWarning"><strong>Important:</strong> Password-manager CSV exports are plaintext. Delete the source CSV securely after you verify the VaultCove import and encrypted .vcvault backup.</div>
    </section>
    <section class="settingsCard">
      <h3>Migration preview</h3>
      <div id="migrationPreviewMount" class="migrationPreview"><p>Select an export file to inspect it locally. Password values are never displayed in this preview.</p></div>
    </section>
    <section class="settingsCard">
      <h3>Supports the following Password Managers</h3>
      <p><strong>Automatic detection:</strong> LastPass and Zoho Vault CSV are recognized directly. Common login CSV layouts from Chrome/Google Password Manager, Bitwarden-compatible exports, 1Password-compatible exports, and other standard name/URL/username/password CSV layouts can also be recognized automatically.</p>
      <p>Encrypted vendor-specific backup containers are not decrypted by VaultCove. Export logins as CSV from the source password manager first.</p>
    </section>
  </div>`;

  const mount = $('migrationPreviewMount');
  const previewButton = $('migrationPreview');
  const importButton = $('migrationImport');
  previewButton.addEventListener('click', async () => {
    try {
      const file = $('migrationFile').files?.[0];
      if (!file) throw new Error('Choose a password-manager CSV export first.');
      if (file.size > MIGRATION_LIMITS.maxBytes) throw new Error('For safety, migration files are limited to 25 MB in this build.');
      const text = await file.text();
      pendingMigration = importMigrationCsv(text);
      const counts = pendingMigration.items.reduce((out, item) => { out[item.type] = (out[item.type] || 0) + 1; return out; }, {});
      const sample = pendingMigration.items.slice(0, 8).map((item) => `<div class="migrationRow"><strong>${escapeHtml(item.name)}</strong><span>${escapeHtml(itemTypeLabel(item))}</span><small>${escapeHtml(item.type === 'login' ? (item.username || '(no username)') : itemMeta(item))}</small></div>`).join('');
      const warnings = pendingMigration.warnings?.length ? `<div class="migrationWarning">${pendingMigration.warnings.slice(0, 8).map(escapeHtml).join('<br>')}</div>` : '';
      const mergePreview = mergeImportedItems(cloneForMergePreview(vault.items || []), cloneForMergePreview(pendingMigration.items), { skipDuplicates:true, mergeDuplicates:true });
      mount.innerHTML = `<div class="migrationSummary"><strong>${pendingMigration.items.length}</strong><span>items detected from ${escapeHtml(pendingMigration.source)}</span></div><p>${Object.entries(counts).map(([type,count]) => `${escapeHtml(type)}: ${count}`).join(' - ')}</p>${startupMergeSummaryHtml(mergePreview)}${warnings}<div class="migrationRows">${sample}</div>`;
      importButton.disabled = pendingMigration.items.length === 0;
    } catch (error) {
      pendingMigration = null; importButton.disabled = true; mount.textContent = error.message; toast(error.message, true);
    }
  });
  importButton.addEventListener('click', async () => {
    try {
      if (!pendingMigration) throw new Error('Preview the migration file first.');
      if (!featureAllowed(licenseState, 'edit')) throw new Error('Import is unavailable in this build.');
      const merged = mergeImportedItems(vault.items, pendingMigration.items, { skipDuplicates:true, mergeDuplicates:true });
      if (!merged.accepted.length && !merged.mergedCount && !merged.unchanged) throw new Error('No importable items were found.');
      vault.items.push(...merged.accepted);
      await appendActivityEvent(vault, 'migration-imported', {
        source: pendingMigration.source,
        imported: merged.accepted.length,
        merged: merged.mergedCount,
        unchanged: merged.unchanged,
        conflicts: merged.conflicts
      });
      await saveUnlockedVault(vault);
      const imported = merged.accepted.length;
      const mergedCount = merged.mergedCount;
      const unchanged = merged.unchanged;
      const conflicts = merged.conflicts;
      pendingMigration = null;
      $('migrationFile').value = '';
      importButton.disabled = true;
      mount.innerHTML = `<div class="migrationSummary"><strong>${imported}</strong><span>new item(s) imported</span></div><p>${mergedCount} matching item(s) merged; ${unchanged} already matched. ${conflicts} conflicting secret field(s) were preserved from the existing vault.</p>`;
      toast(`${imported} new, ${mergedCount} merged, ${unchanged} already matched.`);
    } catch (error) { toast(error.message, true); }
  });
}

function shareSelectorCard(item) {
  return `<label class="shareLoginCard" data-share-card="${escapeHtml(item.id)}"><input type="checkbox" name="shareLoginIds" value="${escapeHtml(item.id)}">${siteCardVisual(item)}<div class="shareLoginBody"><strong>${escapeHtml(loginDisplayLabel(item))}</strong><small>${escapeHtml(item.nickname ? `${item.name} - ${itemMeta(item)}` : itemMeta(item))}</small><span>${item.siteVisual?.visitedAt ? 'Visited site visual available' : 'Fallback card until site is visited'}</span></div></label>`;
}


async function renderGuardian() {
  if (!premiumFeatureAllowed(licenseState, 'guardian')) return renderPremiumLockedView('guardian', 'VaultCove Guardian');

  // Navigation must never wait for Apps Script or ledger verification. Render
  // immediately from already-unlocked local state, then hydrate slow panels.
  const renderEpoch = ++guardianRenderEpoch;
  const summary = guardianRiskSummary(vault?.items || []);
  const confidence = backupConfidence(settingsState || {});
  const receipts = Array.isArray(vault?.security?.guardianReceipts) ? [...vault.security.guardianReceipts].reverse().slice(0, 12) : [];
  const logins = (vault?.items || []).filter((item) => item.type === 'login' && !item.deletedAt && !isUseOnlySharedLogin(item));
  const highBreach = logins.filter((item) => breachAssessment(item).state === 'high');
  const quarantined = logins.filter((item) => guardianQuarantineAssessment(item).quarantine);
  const passkeyReady = logins.filter((item) => ['available','likely'].includes(passkeyCoach(item).state));
  const loginOptions = logins.map((item) => `<option value="${escapeAttr(item.id)}">${escapeHtml(loginDisplayLabel(item))}</option>`).join('');
  const confidenceChecks = confidence.checks.map((check) => `<div class="guardianCheck ${check.ok?'good':'attention'}"><strong>${check.ok?'Protected':'Review'}</strong><span>${escapeHtml(check.label)}</span></div>`).join('');
  const receiptRows = receipts.length ? receipts.map((receipt) => `<div class="guardianLedgerRow"><div><strong>${escapeHtml(String(receipt.eventKind || 'security event').replace(/-/g,' '))}</strong><span>${escapeHtml(receipt.itemName || 'Login')} ${receipt.host ? `- ${escapeHtml(receipt.host)}` : ''}</span></div><small>${escapeHtml(new Date(receipt.occurredAt).toLocaleString())}</small></div>`).join('') : '<div class="emptyState compactEmpty">Guardian receipts will appear after protected credential events.</div>';
  const riskRows = [
    ['Fortress accounts', summary.fortress],
    ['Blind credentials', summary.blind],
    ['Trusted-device approval', summary.approval],
    ['Quarantined logins', summary.quarantined],
    ['High-priority breach reviews', summary.breachHigh],
    ['Passkey migration candidates', summary.passkeyReady]
  ].map(([label,count])=>`<div class="securityOverviewMetric"><strong>${Number(count)}</strong><span>${escapeHtml(label)}</span></div>`).join('');
  const reviewRows = [...highBreach, ...quarantined, ...passkeyReady].slice(0,12).map((item) => {
    const breach = breachAssessment(item); const quarantine = guardianQuarantineAssessment(item); const passkey = passkeyCoach(item);
    const reason = quarantine.quarantine ? quarantine.reason : breach.state === 'high' ? breach.label : passkey.label;
    return `<button type="button" class="guardianReviewRow" data-guardian-edit="${escapeAttr(item.id)}"><strong>${escapeHtml(loginDisplayLabel(item))}</strong><span>${escapeHtml(reason)}</span></button>`;
  }).join('') || '<div class="emptyState compactEmpty">No Guardian review items right now.</div>';

  els.content.innerHTML = `${pageHead('VaultCove Guardian','Advanced Premium protection that remains local-first and only uses the licensing service for signed device identity, email verification, and optional trusted-device approvals.')}
    <section class="guardianHero">
      <div><span class="premiumTag">Premium Guardian</span><h2>Protection ${escapeHtml(confidence.grade)}</h2><p>Fortress policies, recovery readiness, trusted devices, breach timing, quarantine, passkey coaching and a tamper-evident Security Ledger.</p></div>
      <div class="guardianScore"><strong>${confidence.score}</strong><span>Backup confidence</span></div>
    </section>
    <div class="securityOverview guardianOverview">${riskRows}</div>
    <div class="settingsGrid guardianGrid">
      <section class="settingsCard"><div class="settingsCardTitleRow"><div><h3>Backup Confidence</h3><p>VaultCove checks whether recovery is likely to work before a device is lost.</p></div><strong>${escapeHtml(confidence.grade)}</strong></div>${confidenceChecks}<label class="check"><input id="guardianOffDevice" type="checkbox" ${settingsState?.guardianOffDeviceBackupConfirmed?'checked':''}> I confirmed a current encrypted backup exists off this device</label><label>Critical-action Security Cooldown<select id="guardianCriticalCooldown"><option value="0" ${Number(settingsState?.guardianCriticalCooldownMinutes||0)===0?'selected':''}>Off</option><option value="5" ${Number(settingsState?.guardianCriticalCooldownMinutes||0)===5?'selected':''}>5 minutes</option><option value="10" ${Number(settingsState?.guardianCriticalCooldownMinutes||0)===10?'selected':''}>10 minutes</option><option value="30" ${Number(settingsState?.guardianCriticalCooldownMinutes||0)===30?'selected':''}>30 minutes</option></select></label><label class="check"><input id="guardianCriticalApproval" type="checkbox" ${settingsState?.guardianCriticalTrustedApproval?'checked':''}> Require another same-license trusted device for critical actions</label><p class="fieldHint">When enabled, changing the Master Password or applying a backup restore requires both trusted-device approval and any configured cooldown.</p><div class="backupPresetRow"><button id="guardianOpenBackup" type="button" class="outline">Open Backup & Restore</button></div></section>
      <section class="settingsCard"><div class="settingsCardTitleRow"><div><h3>Security Ledger</h3><p>Tamper-evident local activity plus password-change security receipts. No passwords appear here.</p></div><strong id="guardianLedgerState">CHECKING</strong></div><div id="guardianLedgerStatus" class="integrationStatus"><strong>Checking ledger integrity locally</strong><span>This does not block Guardian navigation.</span></div>${receiptRows}</section>
      <section class="settingsCard guardianApprovals"><div class="settingsCardTitleRow"><div><h3>Trusted Device Approval</h3><p>Another active device on the same license can approve a protected action. The requester cannot approve itself.</p></div><span class="premiumTag">Same license</span></div><div id="guardianApprovalError"></div><div id="guardianIncomingApprovals"><div class="emptyState compactEmpty">Loading same-license approval requests...</div></div><div class="guardianRequestRow"><select id="guardianApprovalLogin">${loginOptions || '<option value="">No logins</option>'}</select><button id="guardianRequestApproval" type="button" class="outline" ${logins.length?'':'disabled'}>Request test approval</button><button id="guardianRefreshApprovals" type="button" class="outline">Refresh</button></div><h4>My requests</h4><div id="guardianOutgoingApprovals"><div class="emptyState compactEmpty">Loading recent requests...</div></div></section>
      <section class="settingsCard"><div class="settingsCardTitleRow"><div><h3>Account Takeover Emergency</h3><p>Launch a strict recovery checklist for a selected account without sending the account data anywhere.</p></div></div><div class="guardianRequestRow"><select id="guardianEmergencyLogin">${loginOptions || '<option value="">No logins</option>'}</select><button id="guardianEmergencyStart" type="button" ${logins.length?'':'disabled'}>Start recovery checklist</button></div><div id="guardianEmergencyMount"></div></section>
      <section class="settingsCard"><div class="settingsCardTitleRow"><div><h3>Guardian Review Queue</h3><p>Prioritize quarantined imports, passwords that predate a reported breach, and accounts that may be ready for passkeys.</p></div><strong>${summary.quarantined + summary.breachHigh + summary.passkeyReady}</strong></div><div class="guardianReviewList">${reviewRows}</div></section>
      <section class="settingsCard"><div class="settingsCardTitleRow"><div><h3>Security Zones</h3><p>Apply understandable presets instead of managing many switches one by one.</p></div></div><div class="guardianZoneList"><div><strong>Personal</strong><span>Standard protection and local TOTP.</span></div><div><strong>Financial</strong><span>Fortress, exact-domain pinning, Blind Credential Mode and trusted-device TOTP approval.</span></div><div><strong>Work</strong><span>Strict exact-domain protection and Master Password reauthentication.</span></div><div><strong>Recovery</strong><span>Fortress controls for recovery-critical accounts.</span></div></div><p class="fieldHint">Open any login and edit its VaultCove Guardian section to change the zone, Fortress level, Split-Trust TOTP policy, breach date, passkey state, quarantine, domain pinning or cooldown.</p></section>
    </div>`;

  const approvalMarkup = (approvals = []) => {
    const incoming = approvals.filter((approval) => !approval.isRequester && approval.status === 'pending');
    const outgoing = approvals.filter((approval) => approval.isRequester);
    const incomingHtml = incoming.length ? incoming.map((approval) => `<div class="guardianApprovalRow" data-approval-id="${escapeAttr(approval.approvalId)}"><div><strong>${escapeHtml(approval.operation || 'Protected action')}</strong><span>${escapeHtml(approval.itemLabel || 'VaultCove item')}</span><small>Another same-license device requested approval.</small></div><div><button type="button" class="outline" data-guardian-deny="${escapeAttr(approval.approvalId)}">Deny</button><button type="button" data-guardian-approve="${escapeAttr(approval.approvalId)}">Approve</button></div></div>`).join('') : '<div class="emptyState compactEmpty">No trusted-device approvals are waiting on this device.</div>';
    const outgoingHtml = outgoing.length ? outgoing.map((approval) => `<div class="guardianLedgerRow"><div><strong>${escapeHtml(approval.operation || 'Protected action')}</strong><span>${escapeHtml(approval.itemLabel || 'VaultCove item')}</span></div><small>${escapeHtml(String(approval.status || 'pending').toUpperCase())}</small></div>`).join('') : '<div class="emptyState compactEmpty">No recent outgoing approval requests.</div>';
    return { incomingHtml, outgoingHtml };
  };

  const wireApprovalDecisionButtons = () => {
    document.querySelectorAll('[data-guardian-approve]').forEach((button)=>button.addEventListener('click',async()=>{try{await decideGuardianApproval(button.dataset.guardianApprove,'approve');toast('Guardian request approved for the other device.');await hydrateGuardianAsync({ force:true });}catch(error){toast(error.message,true);}}));
    document.querySelectorAll('[data-guardian-deny]').forEach((button)=>button.addEventListener('click',async()=>{try{await decideGuardianApproval(button.dataset.guardianDeny,'deny');toast('Guardian request denied.');await hydrateGuardianAsync({ force:true });}catch(error){toast(error.message,true);}}));
  };

  const hydrateGuardianAsync = async ({ force = false } = {}) => {
    if (guardianAsyncRefreshInFlight && !force) return guardianAsyncRefreshInFlight;
    const task = Promise.allSettled([
      verifyActivityLog(vault),
      listGuardianApprovals()
    ]).then(([ledgerResult, approvalResult]) => {
      if (currentView !== 'guardian' || renderEpoch !== guardianRenderEpoch) return;

      const ledgerState = $('guardianLedgerState');
      const ledgerStatus = $('guardianLedgerStatus');
      if (ledgerResult.status === 'fulfilled') {
        const ledger = ledgerResult.value || { ok:false, count:0 };
        if (ledgerState) ledgerState.textContent = ledger.ok ? 'VERIFIED' : 'CHECK';
        if (ledgerStatus) ledgerStatus.innerHTML = `<strong>${ledger.ok?'Ledger integrity verified':'Ledger verification needs attention'}</strong><span>${Number(ledger.count || 0)} chained security events are currently retained.</span>`;
      } else {
        if (ledgerState) ledgerState.textContent = 'CHECK';
        if (ledgerStatus) ledgerStatus.innerHTML = `<strong>Ledger verification unavailable</strong><span>${escapeHtml(String(ledgerResult.reason?.message || ledgerResult.reason || 'Try Refresh.'))}</span>`;
      }

      const errorMount = $('guardianApprovalError');
      const incomingMount = $('guardianIncomingApprovals');
      const outgoingMount = $('guardianOutgoingApprovals');
      if (approvalResult.status === 'fulfilled') {
        const rows = approvalMarkup(approvalResult.value?.approvals || []);
        if (errorMount) errorMount.innerHTML = '';
        if (incomingMount) incomingMount.innerHTML = rows.incomingHtml;
        if (outgoingMount) outgoingMount.innerHTML = rows.outgoingHtml;
        wireApprovalDecisionButtons();
      } else {
        const message = String(approvalResult.reason?.message || approvalResult.reason || 'Trusted-device approval service is unavailable.');
        if (errorMount) errorMount.innerHTML = `<div class="migrationWarning">${escapeHtml(message)}</div>`;
        if (incomingMount) incomingMount.innerHTML = '<div class="emptyState compactEmpty">Approval requests could not be refreshed.</div>';
        if (outgoingMount) outgoingMount.innerHTML = '<div class="emptyState compactEmpty">Recent requests are temporarily unavailable.</div>';
      }
    }).finally(() => {
      if (guardianAsyncRefreshInFlight === task) guardianAsyncRefreshInFlight = null;
    });
    guardianAsyncRefreshInFlight = task;
    return task;
  };

  $('guardianOffDevice')?.addEventListener('change', async () => { await setSettings({ guardianOffDeviceBackupConfirmed:Boolean($('guardianOffDevice')?.checked) }); settingsState=await getSettings(); toast('Backup Confidence updated.'); renderGuardian().catch(()=>{}); });
  $('guardianCriticalCooldown')?.addEventListener('change', async () => { await setSettings({ guardianCriticalCooldownMinutes:Math.max(0,Number($('guardianCriticalCooldown')?.value||0)) }); settingsState=await getSettings(); toast('Guardian Security Cooldown updated.'); });
  $('guardianCriticalApproval')?.addEventListener('change', async () => { await setSettings({ guardianCriticalTrustedApproval:Boolean($('guardianCriticalApproval')?.checked) }); settingsState=await getSettings(); toast('Guardian trusted-device critical approval updated.'); });
  $('guardianOpenBackup')?.addEventListener('click', () => switchView('backup'));
  $('guardianRefreshApprovals')?.addEventListener('click', () => hydrateGuardianAsync({ force:true }).catch((error)=>toast(error.message,true)));
  $('guardianRequestApproval')?.addEventListener('click', async () => { try { const item=(vault.items||[]).find((candidate)=>candidate.id===$('guardianApprovalLogin')?.value); if(!item) throw new Error('Choose a saved login.'); const result=await createGuardianApproval({operation:'guardian-test',itemId:item.id,itemLabel:loginDisplayLabel(item)}); toast(`Guardian approval requested. ${result.peerDevices || 0} other active same-license device(s) can approve it.`); await hydrateGuardianAsync({ force:true }); } catch(error){toast(error.message,true);} });
  document.querySelectorAll('[data-guardian-edit]').forEach((button)=>button.addEventListener('click',()=>{const item=(vault.items||[]).find((candidate)=>candidate.id===button.dataset.guardianEdit);if(item)openItemDialog(item);}));
  $('guardianEmergencyStart')?.addEventListener('click',()=>{const item=(vault.items||[]).find((candidate)=>candidate.id===$('guardianEmergencyLogin')?.value);if(!item)return;const plan=recoveryPlaybook(item);const mount=$('guardianEmergencyMount');if(mount)mount.innerHTML=`<div class="guardianEmergencyPlan"><strong>Secure ${escapeHtml(plan.host)}</strong><ol>${plan.steps.map((step)=>`<li>${escapeHtml(step)}</li>`).join('')}</ol><button id="guardianOpenOfficial" type="button" class="outline">Open saved official site</button></div>`;$('guardianOpenOfficial')?.addEventListener('click',()=>{const url=String((item.urls||[])[0]||'');if(/^https:\/\//i.test(url))chrome.tabs.create({url});else toast('Add a trusted HTTPS website URL to this login first.',true);});});

  // Hydrate network/verification-dependent panels only after first paint.
  queueMicrotask(() => hydrateGuardianAsync().catch(() => {}));
}


async function renderShared() {
  const recipients = Array.isArray(vault.emailShareRecipients) ? vault.emailShareRecipients : [];
  vault.emailShareRecipients = recipients;
  const recipientLimit = licenseState?.premium ? Number.POSITIVE_INFINITY : 5;
  const recipientLimitText = licenseState?.premium ? 'Unlimited recipients with Premium Lifetime' : `${recipients.length} of 5 recipients`;
  const logins = activeItems().filter((item) => item.type === 'login' && !isUseOnlySharedLogin(item));
  const historyCutoff = Date.now() - 30 * 24 * 60 * 60 * 1000;
  const history = (vault.shareHistory || []).filter((entry) => Date.parse(String(entry?.occurredAt || '')) >= historyCutoff);
  const historyGroups = new Map();
  for (const entry of history) {
    const date = new Date(entry.occurredAt);
    const dayKey = Number.isFinite(date.getTime()) ? date.toLocaleDateString(undefined, { year:'numeric', month:'long', day:'numeric' }) : 'Unknown date';
    if (!historyGroups.has(dayKey)) historyGroups.set(dayKey, []);
    historyGroups.get(dayKey).push(entry);
  }
  const historyHtml = history.length ? `<div class="shareHistoryPremium">${[...historyGroups.entries()].map(([day, entries]) => `<section class="shareHistoryDay"><h4>${escapeHtml(day)}</h4>${entries.map((entry) => {
    const itemNames = Array.isArray(entry.itemNames) && entry.itemNames.length ? entry.itemNames : [entry.itemName || 'Login'];
    const email = entry.peerEmail || entry.peerName || 'VaultCove recipient';
    const days = Number(entry.accessDays || 0);
    const access = days > 0 ? `${days} day${days === 1 ? '' : 's'} access` : (entry.expiresAt ? `Until ${new Date(entry.expiresAt).toLocaleString()}` : 'No expiration');
    return `<article class="shareHistoryPremiumRow"><div><strong>${escapeHtml(entry.direction === 'out' ? 'Shared by me' : 'Shared with me')}</strong><small>${escapeHtml(new Date(entry.occurredAt).toLocaleTimeString())}</small></div><div><span class="shareHistoryEmail">${escapeHtml(email)}</span><div class="shareHistoryItems">${itemNames.map((name) => `<span>${escapeHtml(name)}</span>`).join('')}</div></div><div><strong>${escapeHtml(access)}</strong><small>${escapeHtml(entry.policy || 'recipient-bound')}</small></div></article>`;
  }).join('')}</section>`).join('')}</div>` : '<div class="emptyState compactEmpty">No sharing activity in the last 30 days.</div>';
  const vckeyTextPremium = premiumFeatureAllowed(licenseState, 'vckey-txt');
  const vckeyTextAllowed = Boolean(vckeyTextPremium && vaultTotpProtection().enabled && settingsState?.vaultTotpEnabled);
  const recipientOptions = recipients.map((recipient) => `<option value="${escapeHtml(recipient.id)}">${escapeHtml(recipient.displayName)} — ${escapeHtml(recipient.email)}</option>`).join('');
  const recipientRows = recipients.length ? recipients.map((recipient) => `<div class="emailRecipientRow" data-recipient-id="${escapeHtml(recipient.id)}"><div><strong>${escapeHtml(recipient.displayName)}</strong><small>${escapeHtml(recipient.email)}</small></div><div class="emailRecipientActions"><button class="outline miniAction" data-edit-recipient="${escapeHtml(recipient.id)}" type="button">Edit</button><button class="danger miniAction" data-remove-recipient="${escapeHtml(recipient.id)}" type="button">Remove</button></div></div>`).join('') : '<div class="emptyState compactEmpty">No email recipients saved yet.</div>';

  els.content.innerHTML = `${pageHead('Share','Share login credentials with saved email recipients and import .vcshare files sent to you.')}
    <div class="shareNavBlock">
      <div class="shareTabs" role="tablist" aria-label="Share sections">
        <button class="shareTab active" type="button" data-share-tab="recipients">Email Recipients</button>
        <button class="shareTab" type="button" data-share-tab="send">Share Passwords</button>
        <button class="shareTab" type="button" data-share-tab="received">Shared Passwords</button>
        <button class="shareTab" type="button" data-share-tab="history">History</button>
      </div>
      <div class="shareUtilityBar">
        <span>Advanced sharing utility</span>
        <button class="outline shareUtilityButton" type="button" data-share-tab="convert">VCKey Tools - Convert encrypted .vckey to TXT</button>
      </div>
    </div>

    <section class="sharePane" data-share-pane="recipients">
      <div class="emailRecipientLayout">
        <section class="settingsCard emailRecipientListCard">
          <div class="settingsCardTitleRow"><div><h3>Email Recipients</h3><p>Add, edit, or remove the people you can share passwords with.</p></div><strong class="selectionCount">${escapeHtml(recipientLimitText)}</strong></div>
          <div class="emailRecipientList">${recipientRows}</div>
          ${licenseState?.premium ? '' : '<p class="settingHint">Free Forever supports up to 5 saved recipients. Removing one immediately frees a slot. Premium Lifetime removes the recipient limit.</p>'}
        </section>
        <section class="settingsCard emailRecipientFormCard">
          <h3 id="recipientFormTitle">Add Recipient</h3>
          <input id="recipientEditId" type="hidden" value="">
          <label>Name or nickname<input id="recipientNickname" type="text" maxlength="80" placeholder="Enter name or nickname" autocomplete="off"></label>
          <label>Email address<input id="recipientEmail" type="email" maxlength="254" placeholder="name@example.com" autocomplete="off"></label>
          <div class="dialogActions"><button id="cancelRecipientEdit" class="outline" type="button">Cancel</button><button id="saveRecipient" type="button">Save Recipient</button></div>
          <p id="recipientLimitNotice" class="settingHint">${Number.isFinite(recipientLimit) && recipients.length >= recipientLimit ? 'Free Forever recipient limit reached. Edit or remove an existing recipient, or activate Premium Lifetime for unlimited recipients.' : 'Recipient email addresses are stored inside your encrypted local vault.'}</p>
        </section>
      </div>
    </section>

    <section class="sharePane hidden" data-share-pane="send">
      <section class="settingsCard shareBundleCard">
        <div class="shareBundleHead"><div><h3>Share Passwords</h3><p>Select saved login credentials, choose a recipient, and export one protected <code>.vcshare</code> file.</p></div><strong id="shareSelectedCount">0 selected</strong></div>
        <div class="shareSelectToolbar"><input id="shareSearch" type="search" placeholder="Search saved logins"><button id="shareSelectAll" class="outline" type="button">Select visible</button><button id="shareClear" class="outline" type="button">Clear</button></div>
        <div id="shareLoginGrid" class="shareLoginGrid">${logins.length ? logins.map(shareSelectorCard).join('') : '<div class="emptyState compactEmpty">No owned login is available to share.</div>'}</div>
        <label>Recipient<select id="shareRecipient">${recipientOptions || '<option value="">Add an email recipient first</option>'}</select></label>
        <label>Expire shared access after<select id="shareExpiry"><option value="7">7 days</option><option value="1">1 day</option><option value="30">30 days</option><option value="0">Never</option></select></label>
        <button id="createShare" disabled>Export .vcshare</button>
        <div class="migrationWarning"><strong>Recipient protection:</strong> The exported file is bound to the selected recipient email. Import requires that exact email plus the recipient's own local VaultCove master-password authorization.</div>
      </section>
    </section>

    <section class="sharePane hidden" data-share-pane="received">
      <section class="settingsCard">
        <h3>Shared Passwords</h3>
        <p>Import a <code>.vcshare</code> file someone sent to you. VaultCove checks the assigned recipient email first, then requires your own local master password before import.</p>
        <label>Shared .vcshare file<input id="shareFile" type="file" accept=".vcshare,application/json"></label>
        <label>Recipient email<input id="shareImportEmail" type="email" maxlength="254" placeholder="name@example.com" autocomplete="email"></label>
        <button id="importShare" type="button">Verify email and import .vcshare</button>
        <div class="migrationWarning"><strong>Two checks required:</strong> the exact recipient email assigned by the sender and this VaultCove vault's local master password.</div>
      </section>
    </section>

    <section class="sharePane hidden" data-share-pane="history">
      <section class="settingsCard">
        <div class="settingsCardTitleRow"><div><h3>30-day Sharing History</h3><p>Recent recipient-bound sharing activity stays encrypted inside your local vault and is included in full Premium backups.</p></div><span class="premiumTag">30 days</span></div>
        ${historyHtml}
      </section>
    </section>

    <section class="sharePane hidden" data-share-pane="convert">
      <section class="settingsCard vckeyTextCard${vckeyTextPremium ? '' : ' premiumLockedPanel'}">
        <h3>Convert encrypted .vckey to TXT ${vckeyTextPremium ? '' : '<span class="premiumTag">Premium</span>'}</h3>
        <p>This legacy utility is separate from normal email-recipient sharing. It converts an encrypted <code>.vckey</code> public-identity file into readable TXT after the existing local authorization checks.</p>
        ${vckeyTextPremium ? '' : '<p><strong>Premium Lifetime required.</strong> Encrypted .vckey files remain unchanged and can still be stored safely.</p>'}
        <div class="integrationStatus"><strong>${vckeyTextAllowed ? 'Authenticator gate ready' : 'Authenticator setup required'}</strong><span>${vckeyTextAllowed ? 'The conversion gate is enabled.' : 'Go to Settings and set up Google Authenticator-compatible protection before plaintext conversion is permitted.'}</span></div>
        <label>Encrypted .vckey file<input id="vckeyTextFile" type="file" accept=".vckey,application/json"></label>
        <button id="convertVckeyToText" ${vckeyTextAllowed ? '' : 'disabled'}>Verify and convert to TXT</button>
        ${vckeyTextAllowed ? '' : '<button id="openAuthenticatorSettings" class="outline" type="button">Open Authenticator Settings</button>'}
        <div class="migrationWarning"><strong>Warning:</strong> TXT is plaintext. Vault passwords, TOTP secrets, and private sharing keys are never written into this TXT.</div>
      </section>
    </section>`;

  const panes = [...document.querySelectorAll('[data-share-pane]')];
  const tabs = [...document.querySelectorAll('[data-share-tab]')];
  const activateSharePane = (name) => {
    panes.forEach((pane) => pane.classList.toggle('hidden', pane.dataset.sharePane !== name));
    tabs.forEach((tab) => tab.classList.toggle('active', tab.dataset.shareTab === name));
  };
  tabs.forEach((tab) => tab.addEventListener('click', () => activateSharePane(tab.dataset.shareTab)));

  const normalizeRecipientEmail = (value) => String(value || '').trim().toLowerCase();
  const recipientEmailValid = (value) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalizeRecipientEmail(value)) && normalizeRecipientEmail(value).length <= 254;
  const resetRecipientForm = () => {
    $('recipientEditId').value = '';
    $('recipientNickname').value = '';
    $('recipientEmail').value = '';
    $('recipientFormTitle').textContent = 'Add Recipient';
  };

  $('cancelRecipientEdit')?.addEventListener('click', resetRecipientForm);
  $('saveRecipient')?.addEventListener('click', async () => {
    try {
      const id = String($('recipientEditId')?.value || '');
      const displayName = String($('recipientNickname')?.value || '').trim();
      const email = normalizeRecipientEmail($('recipientEmail')?.value);
      if (!displayName) throw new Error('Enter a name or nickname for this recipient.');
      if (!recipientEmailValid(email)) throw new Error('Enter a valid recipient email address.');

      // Always mutate a freshly decrypted vault. This prevents an already-open
      // Share tab from overwriting a recipient added by another VaultCove surface.
      const freshState = await loadUnlockedVault({ touch:false });
      if (freshState.state !== 'unlocked') throw new Error('VaultCove is locked. Unlock it and add the recipient again.');
      const freshVault = freshState.vault;
      const freshRecipients = Array.isArray(freshVault.emailShareRecipients) ? [...freshVault.emailShareRecipients] : [];
      const duplicate = freshRecipients.find((entry) => normalizeRecipientEmail(entry.email) === email && entry.id !== id);
      if (duplicate) throw new Error('That email recipient is already saved.');
      const index = freshRecipients.findIndex((entry) => entry.id === id);
      if (index < 0 && Number.isFinite(recipientLimit) && freshRecipients.length >= recipientLimit) throw new Error('Free Forever supports up to 5 saved recipients. Remove one or activate Premium Lifetime for unlimited recipients.');

      const now = new Date().toISOString();
      const recipientId = index >= 0 ? freshRecipients[index].id : crypto.randomUUID();
      if (index >= 0) freshRecipients[index] = { ...freshRecipients[index], displayName:displayName.slice(0,80), email, updatedAt:now };
      else freshRecipients.push({ id:recipientId, displayName:displayName.slice(0,80), email, createdAt:now, updatedAt:now });
      freshVault.emailShareRecipients = freshRecipients;
      await saveUnlockedVault(freshVault);

      // Do not claim success until the encrypted vault can be reloaded and the
      // exact recipient is present. This makes Add/Edit a verified transaction.
      const verifiedState = await loadUnlockedVault({ touch:false });
      if (verifiedState.state !== 'unlocked') throw new Error('VaultCove saved the recipient but could not verify the encrypted vault state. Unlock and check the Share tab.');
      const verified = (verifiedState.vault.emailShareRecipients || []).find((entry) => entry.id === recipientId && normalizeRecipientEmail(entry.email) === email);
      if (!verified) throw new Error('VaultCove could not verify that this recipient was saved. No success was reported.');
      vault = verifiedState.vault;
      toast(index >= 0 ? 'Email recipient updated.' : 'Email recipient added.');
      await renderShared();
    } catch (error) { toast(error.message, true); }
  });

  document.querySelectorAll('[data-edit-recipient]').forEach((button) => button.addEventListener('click', () => {
    const recipient = recipients.find((entry) => entry.id === button.dataset.editRecipient);
    if (!recipient) return;
    $('recipientEditId').value = recipient.id;
    $('recipientNickname').value = recipient.displayName;
    $('recipientEmail').value = recipient.email;
    $('recipientFormTitle').textContent = 'Edit Recipient';
    activateSharePane('recipients');
    $('recipientNickname').focus();
  }));

  document.querySelectorAll('[data-remove-recipient]').forEach((button) => button.addEventListener('click', async () => {
    try {
      const recipient = recipients.find((entry) => entry.id === button.dataset.removeRecipient);
      if (!recipient) return;
      if (!confirm(`Remove ${recipient.displayName} (${recipient.email}) from your saved email recipients?`)) return;
      const freshState = await loadUnlockedVault({ touch:false });
      if (freshState.state !== 'unlocked') throw new Error('VaultCove is locked. Unlock it and try again.');
      const freshVault = freshState.vault;
      const before = Array.isArray(freshVault.emailShareRecipients) ? freshVault.emailShareRecipients : [];
      freshVault.emailShareRecipients = before.filter((entry) => entry.id !== recipient.id);
      if (freshVault.emailShareRecipients.length === before.length) throw new Error('That recipient is no longer present in the encrypted vault.');
      await saveUnlockedVault(freshVault);
      const verifiedState = await loadUnlockedVault({ touch:false });
      if (verifiedState.state !== 'unlocked') throw new Error('VaultCove could not verify the updated recipient list.');
      if ((verifiedState.vault.emailShareRecipients || []).some((entry) => entry.id === recipient.id)) throw new Error('VaultCove could not verify recipient removal.');
      vault = verifiedState.vault;
      toast('Email recipient removed.');
      await renderShared();
    } catch (error) { toast(error.message, true); }
  }));

  const selectedIds = () => [...document.querySelectorAll('input[name="shareLoginIds"]:checked')].map((input) => input.value);
  const updateShareSelection = () => {
    const count = selectedIds().length;
    if ($('shareSelectedCount')) $('shareSelectedCount').textContent = `${count} selected`;
    if ($('createShare')) $('createShare').disabled = !(count && recipients.length && $('shareRecipient')?.value);
  };
  document.querySelectorAll('input[name="shareLoginIds"]').forEach((input) => input.addEventListener('change', updateShareSelection));
  $('shareRecipient')?.addEventListener('change', updateShareSelection);
  $('shareSelectAll')?.addEventListener('click', () => { document.querySelectorAll('.shareLoginCard:not(.filteredOut) input[name="shareLoginIds"]').forEach((input) => { input.checked = true; }); updateShareSelection(); });
  $('shareClear')?.addEventListener('click', () => { document.querySelectorAll('input[name="shareLoginIds"]').forEach((input) => { input.checked = false; }); updateShareSelection(); });
  $('shareSearch')?.addEventListener('input', () => {
    const q = String($('shareSearch').value || '').trim().toLowerCase();
    document.querySelectorAll('.shareLoginCard').forEach((card) => card.classList.toggle('filteredOut', Boolean(q) && !card.textContent.toLowerCase().includes(q)));
  });

  $('createShare')?.addEventListener('click', () => ensureFreshSensitiveAccess('Re-enter your master password before exporting a recipient-bound .vcshare file.', async () => {
    const ids = selectedIds();
    const items = ids.map((id) => vault.items.find((candidate) => candidate.id === id && candidate.type === 'login' && !candidate.deletedAt && !isUseOnlySharedLogin(candidate))).filter(Boolean);
    const recipient = recipients.find((candidate) => candidate.id === $('shareRecipient')?.value);
    if (!items.length || !recipient) throw new Error('Select at least one login and one email recipient.');
    if (items.length > 50) throw new Error('Select at most 50 logins per .vcshare file.');
    const days = Number($('shareExpiry')?.value) || 0;
    const expiresAt = days > 0 ? new Date(Date.now() + days * 86400000).toISOString() : null;
    const pkg = await createSecureShare(vault, recipient, items, { expiresAt, senderDisplayName:normalizedProfileName() });
    const filename = items.length === 1 ? `${items[0].name.replace(/[^a-z0-9._-]+/gi,'-').replace(/^-+|-+$/g,'') || 'Shared-Login'}.vcshare` : `Shared-Passwords-${items.length}.vcshare`;
    await downloadJsonFile(pkg, filename);
    const sharedAt = new Date().toISOString();
    recordShareHistory(vault, { direction:'out', itemName:items.length === 1 ? items[0].name : `${items.length} shared logins`, itemNames:items.map((item) => item.name), itemCount:items.length, peerName:recipient.displayName, peerEmail:recipient.email, accessDays:days, expiresAt, policy:'use-only-email-bound' });
    await appendActivityEvent(vault, 'passwords-shared', { itemCount:items.length, recipientHint:maskedRecipientHint(recipient.email), occurredAt:sharedAt });
    await saveUnlockedVault(vault);
    queueSecurityEventNotice('passwords-shared', { shareCount:items.length, recipientHint:maskedRecipientHint(recipient.email), occurredAt:sharedAt }).catch(() => {});
    toast(`.vcshare exported for ${recipient.displayName}. Security email queued.`);
  }).catch((error) => toast(error.message, true)));

  $('importShare')?.addEventListener('click', async () => {
    try {
      const file = $('shareFile')?.files?.[0];
      if (!file) throw new Error('Choose a .vcshare file first.');
      const recipientEmail = normalizeRecipientEmail($('shareImportEmail')?.value);
      if (!recipientEmailValid(recipientEmail)) throw new Error('Enter the recipient email assigned to this shared file.');
      const wrapper = JSON.parse(await file.text());
      await ensureFreshSensitiveAccess('Enter your own VaultCove master password to finish importing this shared file.', async () => {
        const state = await loadUnlockedVault({ touch:false });
        if (state.state !== 'unlocked' || !state.vaultKey) throw new Error('Your VaultCove vault is locked.');
        const opened = await openSecureShare(vault, wrapper, { recipientEmail });
        const { folder:sharedKeysFolder } = ensureSharedKeysFolder(vault);
        const sealedItems = [];
        for (const item of opened.items) {
          sealedItems.push(await sealSharedLoginForVault(item, state.vaultKey, {
            senderShareId:opened.sender.shareId,
            senderDisplayName:opened.sender.displayName,
            senderFingerprint:opened.sender.fingerprint,
            packageId:opened.packageId,
            expiresAt:opened.expiresAt,
            folderId: sharedKeysFolder.id
          }));
        }
        vault.items.push(...sealedItems);
        recordShareHistory(vault, { direction:'in', itemName:sealedItems.length === 1 ? sealedItems[0].name : `${sealedItems.length} shared logins`, itemNames:sealedItems.map((item) => item.name), itemCount:sealedItems.length, peerName:opened.sender.displayName, accessDays:opened.expiresAt ? Math.max(1, Math.ceil((Date.parse(opened.expiresAt)-Date.now())/86400000)) : 0, expiresAt:opened.expiresAt, policy:'use-only-email-bound' });
        await saveUnlockedVault(vault);
        toast(`${sealedItems.length} shared login${sealedItems.length === 1 ? '' : 's'} imported into ${SHARED_KEYS_FOLDER_NAME}.`);
        currentView = 'login'; selectedItemId = sealedItems[0]?.id || null; render();
      });
    } catch (error) { if (error?.message !== 'Cancelled.') toast(error.message, true); }
  });

  $('openAuthenticatorSettings')?.addEventListener('click', () => switchView('settings'));
  $('convertVckeyToText')?.addEventListener('click', () => {
    if (!vckeyTextPremium) { toast('Convert encrypted .vckey to TXT requires Premium Lifetime.', true); return; }
    if (!vckeyTextAllowed) { toast('Set up Google Authenticator-compatible protection in Settings before converting .vckey to TXT.', true); return; }
    ensureFreshSensitiveAccess('Re-enter your master password and verify Google Authenticator before VaultCove can create plaintext TXT from an encrypted .vckey.', async () => {
      const file = $('vckeyTextFile')?.files?.[0];
      if (!file) throw new Error('Choose an encrypted .vckey file first.');
      if (!confirm('Convert this encrypted .vckey to a readable TXT file?\n\nThe TXT is plaintext.')) return;
      const wrapper = JSON.parse(await file.text());
      const password = await requestVckeyPassword('convert');
      const identityText = await openEncryptedVckey(wrapper, password);
      const safeId = String(identityText.shareId || 'VaultCove').replace(/[^a-z0-9._-]+/gi,'-');
      await downloadTextFile(publicIdentityText(identityText), `VaultCove-${safeId}-PUBLIC-IDENTITY.txt`);
      toast('Plaintext public-identity TXT created. Store or delete it carefully.');
    }).catch((error) => { if (error?.message !== 'Cancelled.') toast(error.message, true); });
  });
  updateShareSelection();
}


function licenseStatusCard(client) {
  const lease = client.lease || null;
  if (!licenseState?.premium || !lease) {
    return `<div class="licenseStateCard freePlanCard"><strong>FREE FOREVER</strong><span>No license is required for the core local vault. Activate Premium Lifetime only when you want Premium features and the shared seven-device Premium entitlement.</span></div>`;
  }
  const expiry = lease.expiresAt ? new Date(lease.expiresAt).toLocaleString() : 'Unknown';
  const adminUnlimited = String(lease.licenseType || licenseState?.licenseType || '').toLowerCase() === 'admin';
  const usage = adminUnlimited
    ? `${escapeHtml(String(lease.usedDevices ?? lease.activeDevices ?? 0))} owner-admin devices registered - unlimited device entitlement`
    : `${escapeHtml(String(lease.usedDevices ?? lease.activeDevices ?? 0))} of ${escapeHtml(String(lease.maxDevices || 7))} Premium device slots used`;
  return `<div class="licenseStateCard goodLicense"><strong>${adminUnlimited ? 'OWNER-ADMIN PREMIUM' : 'PREMIUM LIFETIME'} - ${escapeHtml(client.emailMasked || lease.emailMasked || '')}</strong><span>${usage} - signed entitlement refresh due ${escapeHtml(expiry)}</span></div>`;
}

function planStatusCard() {
  if (licenseState?.premium) {
    const adminUnlimited = Boolean(licenseState.unlimitedDevices || String(licenseState.licenseType || '').toLowerCase() === 'admin');
    return `<div class="licenseStateCard premiumPlanCard"><strong>${adminUnlimited ? 'OWNER-ADMIN PREMIUM ACTIVE' : 'PREMIUM LIFETIME ACTIVE'}</strong><span>${adminUnlimited ? 'Advanced Premium features are unlocked on this installation. The private owner-admin key has no device-count ceiling; unfamiliar devices can still be released or revoked from Licensed devices.' : `Advanced Premium features are unlocked on this installation. Premium licenses support up to ${escapeHtml(String(licenseState.maxDevices || 7))} licensed devices.`}</span></div>`;
  }
  return `<div class="licenseStateCard freePlanCard"><strong>FREE FOREVER ACTIVE</strong><span>Your local vault does not expire. Free Forever keeps login credentials, Secure Login, generator, import/restore, Login-only encrypted backup, email sharing up to five recipients, and settings. Premium unlocks Cards, Secure Notes, TOTP Codes, Favorites, Security Center, full component backups, and .vckey-to-TXT conversion.</span></div>`;
}

function applyLicenseUiRestrictions() {
  // Free Forever never locks or hides the user's local vault.
}

function premiumCatalogFeature(id) {
  return PREMIUM_FEATURE_CATALOG.find((feature) => feature.id === id) || null;
}

function premiumLockedFeatureMarkup(featureOrId, { compact = false } = {}) {
  const feature = typeof featureOrId === 'string' ? premiumCatalogFeature(featureOrId) : featureOrId;
  if (!feature) return '';
  const purpose = String(feature.purpose || 'Available with VaultCove Premium Lifetime.');
  return `<article class="premiumFeatureTile premiumFeatureLocked${compact ? ' compact' : ''}" tabindex="0" aria-disabled="true" title="${escapeAttr(purpose)}" aria-label="${escapeAttr(`${feature.title}. Premium feature. ${purpose}`)}">
    <div class="premiumFeatureHead"><span class="premiumFeatureLock" aria-hidden="true">${uiIcon('lock',14)}</span><strong>${escapeHtml(feature.title)}</strong><span class="premiumTag">Premium</span></div>
    <p>${escapeHtml(purpose)}</p>
    <div class="premiumFeatureState"><span>${uiIcon('lock',11)} Locked</span></div>
    <span class="premiumFeaturePurposeTooltip" role="tooltip">${escapeHtml(purpose)}</span>
  </article>`;
}

function premiumFeatureCatalogMarkup(features = PREMIUM_FEATURE_CATALOG, { compact = false, className = '' } = {}) {
  return `<div class="premiumFeatureCatalog${compact ? ' compactCatalog' : ''}${className ? ` ${escapeHtml(className)}` : ''}">${features.map((feature) => premiumLockedFeatureMarkup(feature, { compact })).join('')}</div>`;
}

function syncPremiumNavigation() {
  const premiumActive = Boolean(licenseState?.premium);
  const premiumNav = $('premiumNav');
  premiumNav?.classList.toggle('hidden', premiumActive);
  const sharedNav = document.querySelector('nav button[data-view="shared"]');
  sharedNav?.classList.remove('premiumLockedNav');
  sharedNav?.querySelector('.navPremiumTag')?.remove();
  sharedNav?.setAttribute('aria-label', 'Share');
  for (const [view, gate] of Object.entries(PREMIUM_VIEW_GATES)) {
    const nav = document.querySelector(`nav button[data-view="${view}"]`);
    const locked = !premiumFeatureAllowed(licenseState, gate);
    nav?.classList.toggle('premiumLockedNav', locked);
    let badge = nav?.querySelector('.navPremiumTag') || null;
    if (locked && nav && !badge) {
      badge = document.createElement('span');
      badge.className = 'navPremiumTag';
      badge.textContent = 'Premium';
      badge.setAttribute('aria-hidden', 'true');
      nav.append(badge);
    } else if (!locked && badge) {
      badge.remove();
    }
    nav?.setAttribute('aria-label', locked ? `${viewNames[view]} - Premium Lifetime` : viewNames[view]);
  }
}


function renderPremium() {
  if (licenseState?.premium) {
    currentView = 'license';
    return renderLicense();
  }

  const vaultFeatures = PREMIUM_FEATURE_CATALOG.filter((feature) => ['cards','notes','totp','favorites'].includes(feature.gate));
  const securityFeatures = PREMIUM_FEATURE_CATALOG.filter((feature) => ['security-center','security-advanced'].includes(feature.gate));
  const sharingFeatures = PREMIUM_FEATURE_CATALOG.filter((feature) => ['vckey-txt','sharing-unlimited'].includes(feature.gate));
  const licenseFeatures = PREMIUM_FEATURE_CATALOG.filter((feature) => feature.gate === 'license');

  els.content.innerHTML = `${pageHead('Premium Lifetime','Unlock advanced security, unlimited email recipients, and Premium device licensing with one purchase. Free Forever remains available if you never upgrade.')}
    <section class="premiumHeroCard">
      <div class="premiumHeroMain">
        <span class="premiumTag">Lifetime Premium</span>
        <h2>Unlock everything with Premium Lifetime</h2>
        <p>Advanced security, unlimited recipients, and support for up to 7 licensed devices — all with one purchase.</p>
        ${premiumInlineActionsMarkup()}
      </div>
      <div class="premiumHeroFacts">
        <div><strong>Lifetime</strong><span>One-time purchase</span></div>
        <div><strong>No subscription</strong><span>No annual fee</span></div>
        <div><strong>Up to 7 devices</strong><span>One Premium license</span></div>
      </div>
    </section>

    <div class="premiumFeatureGroups premiumFeatureGroups0755">
      <section class="settingsCard premiumFeatureGroup">
        <div class="premiumGroupHead"><span>${uiIcon('vault',18)}</span><div><h3>Premium Vault Tools</h3><p>Cards, Secure Notes, TOTP Codes, and Favorites.</p></div><span class="premiumTag">Premium</span></div>
        ${premiumFeatureCatalogMarkup(vaultFeatures, { compact:true })}
      </section>

      <section class="settingsCard premiumFeatureGroup">
        <div class="premiumGroupHead"><span>${uiIcon('security',18)}</span><div><h3>Advanced Security</h3><p>Password Age Review and encrypted local activity history.</p></div><span class="premiumTag">Premium</span></div>
        ${premiumFeatureCatalogMarkup(securityFeatures, { compact:true })}
      </section>
      <section class="settingsCard premiumFeatureGroup premiumSharingGroup">
        <div class="premiumGroupHead"><span>${uiIcon('shared',18)}</span><div><h3>Unlimited Recipients</h3><p>Free Forever supports up to five saved email recipients. Premium removes the limit.</p></div><span class="premiumTag">Premium</span></div>
        ${premiumFeatureCatalogMarkup(sharingFeatures, { compact:true })}
      </section>
      <section class="settingsCard premiumFeatureGroup">
        <div class="premiumGroupHead"><span>${uiIcon('devices',18)}</span><div><h3>Premium Devices</h3><p>Use one Premium Lifetime entitlement on up to seven supported VaultCove devices.</p></div><span class="premiumTag">Premium</span></div>
        ${premiumFeatureCatalogMarkup(licenseFeatures, { compact:true })}
      </section>
    </div>

    <section class="settingsCard premiumFreePromise">
      <div>${uiIcon('strong',18)}</div>
      <span><strong>Free Forever stays yours.</strong><small>Your encrypted local vault, login credentials, Secure Login, generator, import/restore, Login-only encrypted backup, and email sharing up to five saved recipients do not expire.</small></span>
    </section>`;
  wirePremiumUpgradeActions();
}


function premiumUpgradeMarkup(featureTitle, featureCopy, features = []) {
  const rows = features.length ? `<div class="premiumGateFeatures">${features.map((item) => `<span>${escapeHtml(item)}</span>`).join('')}</div>` : '';
  return `<section class="settingsCard premiumGate">
    <span class="premiumTag">Lifetime Premium</span>
    <h3>${escapeHtml(featureTitle)}</h3>
    <p>${escapeHtml(featureCopy)}</p>
    ${rows}
    <div class="premiumGateActions">
      <a class="buttonLink" href="https://payhip.com/b/0foVO" target="_blank" rel="noopener noreferrer">Buy Premium Lifetime</a>
      <button type="button" class="outline" data-open-premium-license>Already own Premium? Activate</button>
    </div>
  </section>`;
}

function wirePremiumUpgradeActions() {
  document.querySelectorAll('[data-open-premium-license]').forEach((button) => button.addEventListener('click', () => {
    currentView = 'license';
    Promise.resolve(render()).catch((error) => toast(error.message, true));
  }));
}


function licensedDevicePlatformMeta(device = {}) {
  const raw = `${device?.platform || ''} ${device?.deviceLabel || ''}`.trim();
  const text = raw.toLowerCase();

  if (/\bipad\b|ipados|ipad os/.test(text)) return { kind:'ipad', icon:'tablet', label:'iPad' };
  if (/\biphone\b|\bios\b/.test(text)) return { kind:'iphone', icon:'phone', label:'iPhone' };

  if (/android/.test(text)) {
    const tablet = /tablet|galaxy\s+tab|\btab\b|sm[- ]?[tx]\d|pixel\s+tablet|lenovo\s+tab|xiaomi\s+pad|oneplus\s+pad/.test(text);
    return tablet
      ? { kind:'android-tablet', icon:'tablet', label:'Android Tablet' }
      : { kind:'android-phone', icon:'android', label:'Android Phone' };
  }

  if (/\bcros\b|chrome\s?os|chromebook/.test(text)) return { kind:'chromeos', icon:'chromeos', label:'Chrome OS' };
  if (/windows|win32|win64|winnt|windows nt/.test(text)) return { kind:'windows', icon:'windows', label:'Windows' };
  if (/macintosh|macintel|mac\s?os|macos/.test(text)) return { kind:'macos', icon:'macos', label:'macOS' };
  if (/linux/.test(text)) return { kind:'linux', icon:'linux', label:'Linux' };

  if (/tablet/.test(text)) return { kind:'tablet', icon:'tablet', label:'Tablet' };
  if (/phone|mobile/.test(text)) return { kind:'phone', icon:'phone', label:'Phone' };
  return { kind:'unknown', icon:'devices', label:'Unknown platform' };
}

function licensedDevicePlatformText(device = {}) {
  const meta = licensedDevicePlatformMeta(device);
  const raw = String(device?.platform || '').trim();
  if (!raw || raw.toLowerCase().includes(meta.label.toLowerCase())) return meta.label;
  return `${meta.label} - ${raw}`;
}

function licensedDevicePlatformSummary(devices = []) {
  const seen = new Set();
  const labels = [];
  for (const device of Array.isArray(devices) ? devices : []) {
    const label = licensedDevicePlatformMeta(device).label;
    if (!seen.has(label)) { seen.add(label); labels.push(label); }
  }
  return labels.slice(0, 8).join(' / ');
}

function licensedDeviceRows(devices, currentInstallationId, allowActions = false) {
  if (!Array.isArray(devices) || !devices.length) return '<div class="emptyState compactEmpty">No devices are currently associated with this license.</div>';
  return devices.map((device) => {
    const current = device.installationId === currentInstallationId;
    const status = String(device.status || 'active');
    const role = String(device.managementRole || 'regular');
    const roleLabel = role === 'owner-admin' ? 'Owner Admin' : role === 'manager' ? 'Device Admin' : 'Regular Device';
    let actions = '';
    if (allowActions) {
      if (['active','retained'].includes(status)) actions = `<button class="outline miniAction" data-license-action="release" data-installation="${escapeHtml(device.installationId)}">Release</button><button class="danger miniAction" data-license-action="revoke" data-installation="${escapeHtml(device.installationId)}">Revoke</button>`;
      else if (status === 'revoked') actions = `<button class="outline miniAction" data-license-action="restore" data-installation="${escapeHtml(device.installationId)}">Restore</button>`;
      else if (status === 'released') actions = `<button class="outline miniAction" data-license-action="restore" data-installation="${escapeHtml(device.installationId)}">Restore</button><button class="danger miniAction" data-license-action="delete" data-installation="${escapeHtml(device.installationId)}">Delete</button>`;
    }
    const platformMeta = licensedDevicePlatformMeta(device);
    return `<div class="licensedDeviceRow ${current ? 'currentDevice' : ''}">
      <div class="deviceIcon platformDeviceIcon platform-${escapeAttr(platformMeta.kind)}" title="${escapeAttr(platformMeta.label)}" aria-label="${escapeAttr(platformMeta.label)}">${uiIcon(platformMeta.icon, 22)}</div>
      <div class="deviceMain"><strong>${escapeHtml(device.deviceLabel || 'VaultCove device')}${current ? ' - This device' : ''}<span class="deviceRoleBadge ${role === 'regular' ? 'regular' : 'manager'}">${escapeHtml(roleLabel)}</span><span class="sameLicenseBadge">Same key verified</span>${Number(device.samePhysicalDeviceInstallations || 1) > 1 ? `<span class="physicalDeviceBadge">${escapeHtml(String(device.samePhysicalDeviceInstallations))} browsers / 1 device slot</span>` : ''}</strong><span>${escapeHtml(licensedDevicePlatformText(device))} - VaultCove ${escapeHtml(device.appVersion || '')}</span><small>First seen ${escapeHtml(device.firstSeenAt ? new Date(device.firstSeenAt).toLocaleString() : 'unknown')} - Last seen ${escapeHtml(device.lastSeenAt ? new Date(device.lastSeenAt).toLocaleString() : 'unknown')}</small></div>
      <div class="deviceState"><b>${escapeHtml(status)}</b>${allowActions ? `<div>${actions}</div>` : ''}</div>
    </div>`;
  }).join('');
}

function licensedDeviceLedgerPresentation(result = {}, installationId = '', managementRole = 'regular', allowActions = false) {
  const devices = Array.isArray(result.devices) ? result.devices : [];
  const currentDevice = devices.find((device) => String(device.installationId || '') === String(installationId || ''));
  const ownerAdminAcrossLicense = Boolean(result.ownerAdminAcrossLicense || String(result.licenseType || '').toLowerCase() === 'admin');
  const canManage = Boolean(ownerAdminAcrossLicense || ['owner-admin','manager'].includes(String(currentDevice?.managementRole || managementRole || 'regular')));
  const used = Number(result.activeDevices || 0) + Number(result.retainedDevices || 0);
  const browserInstalls = Number(result.activeBrowserInstallations || 0) + Number(result.retainedBrowserInstallations || 0);
  const releasedCount = devices.filter((device) => String(device.status || '') === 'released').length;
  const platformSummary = licensedDevicePlatformSummary(devices);
  const sameKeyCount = Number(result.sameKeyDeviceCount ?? devices.length);
  const licenseTypeAdmin = String(result.licenseType || '').toLowerCase() === 'admin';
  const authorityTitle = ownerAdminAcrossLicense
    ? (licenseTypeAdmin ? 'Main Admin - cross-platform / unlimited devices' : `Main Admin - cross-platform / ${Number(result.maxDevices || 7)} devices`)
    : 'Premium - 7 devices / up to 3 Device Admins';
  const authorityDetail = ownerAdminAcrossLicense
    ? `${sameKeyCount} device${sameKeyCount === 1 ? '' : 's'} detected on this same key${platformSummary ? ` / ${platformSummary}` : ''}. Main Admin authority follows the owner/admin key across supported platforms.`
    : `${used} of ${Number(result.maxDevices || 7)} physical-device slots in use${browserInstalls > used ? ` / ${browserInstalls} browser installations` : ''} - ${Number(result.managerDevices || 0)} Device Admin(s)${platformSummary ? ` / ${platformSummary}` : ''}`;
  return {
    devices,
    currentDevice,
    ownerAdminAcrossLicense,
    canManage,
    releasedCount,
    authorityTitle,
    authorityDetail,
    markup:`<div class="deviceSlotSummary"><strong>${escapeHtml(authorityTitle)}</strong><span>${escapeHtml(authorityDetail)}</span></div>${licensedDeviceRows(devices, installationId, Boolean(allowActions && canManage))}`
  };
}

function licensedDeviceSyncTimeText(value) {
  const when = Date.parse(String(value || ''));
  if (!Number.isFinite(when)) return 'No successful device sync has been saved yet.';
  return `Last successful sync ${new Date(when).toLocaleString()}`;
}

async function renderLicense() {
  let client = await getLicenseClientState();
  const privacy = licensePrivacyContract();
  const installationId = licenseState?.deviceId || '';
  const activated = Boolean(licenseState?.premium && String(client.lease?.installationId || '') === String(installationId || '') && client.leaseVerified);
  let managementRole = String(licenseState?.managementRole || client.lease?.managementRole || 'regular');
  const cachedDeviceSnapshot = activated ? await getCachedLicensedDevices().catch(() => null) : null;
  const cachedDevicePresentation = cachedDeviceSnapshot ? licensedDeviceLedgerPresentation(cachedDeviceSnapshot, installationId, managementRole, false) : null;

  // Render License & Devices immediately from the locally verified signed lease.
  // Do not block navigation on a remote device-ledger request. The authoritative
  // server role is reconciled asynchronously by loadLicensedDevices() after the
  // page is already visible.
  const canManageFromLease = activated && (String(licenseState?.licenseType || '').toLowerCase() === 'admin' || ['owner-admin','manager'].includes(managementRole));
  const licenseTransportHealthy = Boolean(client.credentialEncryptionOk && client.refreshToken && client.licenseSerial);
  const canRequestDeviceAdmin = activated && String(licenseState?.licenseType || '').toLowerCase() !== 'admin' && managementRole === 'regular';
  const activationArea = activated ? `<div class="activatedLicenseActions"><div class="integrationStatus"><strong>Activated on this device</strong><span>${canManageFromLease ? (managementRole === 'owner-admin' ? 'This device has Owner Admin authority from the main admin key.' : 'This device is an authorized Device Admin for this license.') : 'This is a regular Premium device.'} The encrypted local vault is independent of the license slot.</span></div><div class="licenseActions licenseActivationActions"><button id="activateLicense" class="licenseActivatedButton" type="button" disabled><span>Activated</span></button>${canRequestDeviceAdmin ? '<button id="makeDeviceAdmin" class="outline" type="button">Make this device admin</button>' : ''}${licenseTransportHealthy ? '<button id="refreshLicense" class="outline">Refresh signed license</button>' : ''}</div>${canRequestDeviceAdmin ? '<p class="settingHint">Device Admin access applies only to this Premium license. VaultCove will require your Master Password and send a fresh 6-digit code to the registered license email before this device is promoted.</p>' : ''}<div class="physicalDeviceLinkPanel"><div><strong>More browsers on this same computer</strong><span>Chrome, Brave, Edge, or another browser profile on this physical PC/Mac can share this one device slot. VaultCove does not read MAC addresses, hardware serial numbers, IMEI, or other hidden hardware fingerprints.</span></div><button id="createPhysicalDeviceLink" class="outline" type="button">Create same-computer link code</button><div id="physicalDeviceLinkResult" class="physicalDeviceLinkResult hidden"></div></div></div>` : `<div class="fieldGrid"><label>VaultCove serial<input id="licenseSerial" autocomplete="off" placeholder="VC-..."></label><label>License email<input id="licenseEmail" type="email" autocomplete="email" value="${escapeHtml(settingsState?.securityNoticeEmail || '')}" placeholder="you@example.com"></label></div><label>This device name<input id="licenseDeviceLabel" maxlength="80" value="${escapeHtml(/CrOS/i.test(navigator.userAgent || '') ? 'Chrome OS device' : navigator.platform || 'Chrome device')}" placeholder="Home laptop, Office PC..."></label><label>Same-computer link code <span class="optionalLabel">(optional)</span><input id="physicalDeviceLinkCode" autocomplete="off" maxlength="24" placeholder="VCPC-XXXX-XXXX-XXXX"></label><p class="settingHint">Leave the link code blank for a new physical device. To make another browser/profile on this same PC/Mac count as the same device slot, create a one-time code from an already activated VaultCove browser on this computer and enter it here. Standard Premium devices activate as regular devices first.</p><div class="licenseActions licenseActivationActions"><button id="activateLicense" type="button"><span>Verify and activate this device</span></button></div>`;
  const devicesHtml = activated
    ? `<div class="licenseDeviceMonitor" data-state="${cachedDeviceSnapshot ? 'cached' : 'loading'}"><div class="licenseDeviceMonitorState"><span id="licenseDeviceSyncState" class="licenseDeviceSyncBadge ${cachedDeviceSnapshot ? 'cached' : 'syncing'}">${cachedDeviceSnapshot ? 'Cached snapshot' : 'Syncing devices'}</span><small id="licenseDeviceSyncTime">${escapeHtml(cachedDeviceSnapshot ? licensedDeviceSyncTimeText(cachedDeviceSnapshot.cachedAt) : 'Checking the shared license ledger...')}</small></div><button id="refreshLicensedDevices" class="outline miniAction" type="button">Refresh devices</button></div><div id="licensedDevices" class="licensedDevices" data-has-snapshot="${cachedDeviceSnapshot ? '1' : '0'}">${cachedDevicePresentation ? cachedDevicePresentation.markup : '<div class="emptyState compactEmpty">Loading devices on this license...</div>'}</div>`
    : '<div class="emptyState compactEmpty">Activate Premium on this device to see the license device ledger.</div>';
  els.content.innerHTML = `${pageHead()}<div class="licenseLayout"><section class="settingsCard licenseActivationCard"><h3>${activated ? 'Premium Lifetime status' : 'Free Forever and Premium Lifetime'}</h3><p>One standard Premium serial can activate up to <strong>7 physical devices</strong>. Multiple supported browser profiles on the same PC/Mac can be securely linked to one physical-device slot. Up to <strong>3</strong> active devices may become <strong>Device Admins</strong> after a fresh code is verified through the registered license email. The private main owner-admin entitlement remains unlimited.</p>${planStatusCard()}${licenseStatusCard(client)}<div class="integrationStatus"><strong>Your vault remains local</strong><span>Licensing never receives vault records or your master password.</span></div>${!activated ? `<div class="licensePurchaseRow"><a class="payhipPurchaseButton" href="https://payhip.com/b/0foVO" target="_blank" rel="noopener noreferrer">Buy Premium Lifetime</a><span>Purchase securely on Payhip, then return here to activate with your serial and email.</span></div>` : ''}${activationArea}<div class="migrationWarning"><strong>Important before uninstalling:</strong> ${escapeHtml(uninstallDataDisclosure())}</div></section><section class="settingsCard deviceManagerCard"><div class="shareBundleHead"><div><h3>Licensed devices</h3><p>All supported devices using this same license key are detected in one shared cross-platform ledger automatically. ${activated ? (canManageFromLease ? 'This Device Admin can manage every device using this same regular license key across supported platforms. Every Release, Revoke, Restore, or Delete requires a fresh Master Password check and a fresh email verification code.' : 'This regular device can view the license ledger. Use Make this device admin above to request Device Admin access by email code.') : 'Activate Premium on this installation to load the shared device ledger.'}</p></div></div>${devicesHtml}<p class="settingHint">Main Admin authority follows only the same owner/admin license identity across supported platforms. Device Admin authority remains limited to the individually promoted device and never grants access to other customer licenses. A browser release frees the physical-device slot only when no other active/retained linked browser remains in that same physical group.</p></section><section class="settingsCard licensePrivacyCard"><h3>Licensing privacy boundary</h3><p><strong>May be sent:</strong> ${escapeHtml(privacy.sent.join('; '))}.</p><p><strong>Never sent:</strong> ${escapeHtml(privacy.neverSent.join('; '))}.</p></section></div>`;

  async function ensureLicenseTransportPermission() { const granted = await ensureLicenseServicePermission(); if (!granted) throw new Error('VaultCove license-service permission was not granted.'); }
  if (!activated) $('activateLicense')?.addEventListener('click', async () => {
    const button=$('activateLicense');
    try { button.disabled=true; button.classList.add('licenseActivatingButton'); button.innerHTML='<span class="licenseButtonSpinner"></span><span>Activating...</span>'; await ensureLicenseTransportPermission(); const serial=$('licenseSerial').value.trim(); const result=await beginLicenseActivation({serial,email:$('licenseEmail').value,deviceLabel:$('licenseDeviceLabel').value}); const challengeId=String(result.challengeId||''); if(!challengeId)throw new Error('License service did not return a verification challenge.'); let activationResult=await requestLicenseOtp({title:'Verify license email',subtitle:`Enter the 6-digit code sent to ${result.emailMasked || 'the license email'}.`,onVerify:(code)=>completeLicenseActivation({challengeId,code,serial,physicalDeviceLinkCode:$('physicalDeviceLinkCode')?.value||''})}); if(activationResult?.reclaimRequired) activationResult=await requestLicenseReclaim(activationResult,$('licenseDeviceLabel').value,serial); licenseState=await getLicenseState(); const email=String($('licenseEmail')?.value||'').trim(); if(email){await setSettings({securityNoticeEmail:email,securityEmailNoticeEnabled:true});settingsState=await getSettings();} syncPremiumNavigation();applyProfileIdentity();toast('Premium activated on this device.');await renderLicense(); } catch(error){ if(button){button.disabled=false;button.classList.remove('licenseActivatingButton');button.innerHTML='<span>Verify and activate this device</span>';} if(error?.message!=='Cancelled.')toast(error.message,true); }
  });
  $('refreshLicense')?.addEventListener('click', async()=>{try{await ensureLicenseTransportPermission();await refreshLicenseLease();licenseState=await getLicenseState();syncPremiumNavigation();applyProfileIdentity();toast('Premium entitlement refreshed.');await renderLicense();}catch(error){toast(error.message,true);}});

  $('createPhysicalDeviceLink')?.addEventListener('click', async () => {
    try {
      await ensureFreshSensitiveAccess('Enter your Master Password before creating a same-computer browser link code. A fresh 6-digit email code is also required.', async () => {
        await ensureLicenseTransportPermission();
        const result = await beginPhysicalDeviceLink();
        const challengeId = String(result.challengeId || '');
        if (!challengeId) throw new Error('License service did not return a same-computer verification challenge.');
        const linked = await requestLicenseOtp({
          title:'Verify same-computer browser linking',
          subtitle:`Enter the 6-digit code sent to ${result.emailMasked || 'the registered license email'}.`,
          onVerify:(code)=>completePhysicalDeviceLink(challengeId, code)
        });
        const mount = $('physicalDeviceLinkResult');
        if (mount) {
          const code = String(linked.linkCode || '');
          const expiry = linked.expiresAt ? new Date(linked.expiresAt).toLocaleTimeString() : '10 minutes';
          mount.classList.remove('hidden');
          mount.innerHTML = `<div><strong>One-time link code</strong><code>${escapeHtml(code)}</code><span>Expires ${escapeHtml(expiry)}. Enter it only in another VaultCove browser/profile on this same physical computer.</span></div><button id="copyPhysicalDeviceLinkCode" class="outline miniAction" type="button">Copy code</button>`;
          $('copyPhysicalDeviceLinkCode')?.addEventListener('click', async () => {
            await copyVaultClipboard(code, { label:'Same-computer link code', sensitive:true });
          });
        }
      });
    } catch (error) {
      if (error?.message !== 'Cancelled.') toast(error.message, true);
    }
  });

  $('makeDeviceAdmin')?.addEventListener('click', async () => {
    try {
      await ensureFreshSensitiveAccess('Enter your Master Password before requesting Device Admin access for this device. A fresh 6-digit code will also be sent to the registered license email.', async () => {
        await ensureLicenseTransportPermission();
        const start = await beginCurrentDeviceAdmin();
        const challengeId = String(start.challengeId || '');
        if (!challengeId) throw new Error('License service did not return a Device Admin verification challenge.');
        await requestLicenseOtp({
          title:'Make this device admin',
          subtitle:`Enter the 6-digit code sent to ${start.emailMasked || 'the registered license email'}.`,
          onVerify:(code)=>completeCurrentDeviceAdmin(challengeId, code)
        });
        licenseState = await getLicenseState();
        syncPremiumNavigation();
        applyProfileIdentity();
        toast('This device is now a Device Admin for this Premium license.');
        await renderLicense();
      });
    } catch (error) {
      if (/already a Device Admin/i.test(String(error?.message || ''))) {
        try {
          await ensureLicenseTransportPermission();
          await syncCurrentDeviceLease();
          licenseState = await getLicenseState();
          syncPremiumNavigation();
          applyProfileIdentity();
          toast('Device Admin status synchronized.');
          await renderLicense();
          return;
        } catch {}
      }
      if (error?.message !== 'Cancelled.') toast(error.message, true);
    }
  });

  let lastSuccessfulDeviceSyncAt = String(cachedDeviceSnapshot?.cachedAt || '');

  async function getFreshManagementToken() {
    await ensureLicenseTransportPermission();
    const start = await beginDeviceManagement();
    const challengeId = String(start.challengeId || '');
    if (!challengeId) throw new Error('License service did not return a device-management verification challenge.');
    const verified = await requestLicenseOtp({ title:'Verify email for this device action', subtitle:`Enter the 6-digit code sent to ${start.emailMasked || 'the license email'}.`, onVerify:(code)=>completeDeviceManagement(challengeId, code) });
    const token = String(verified.managementToken || '');
    if (!token) throw new Error('Device-management authorization was not returned.');
    return token;
  }

  async function loadLicensedDevices({quiet=false,force=false}={}) {
    const mount = $('licensedDevices');
    if (!mount || !activated) return;
    if (!force && quiet && Date.now() - licenseDevicesLastLiveRefreshAt < 5000) return;

    const syncState = $('licenseDeviceSyncState');
    const syncTime = $('licenseDeviceSyncTime');
    const refreshButton = $('refreshLicensedDevices');
    const monitor = document.querySelector('.licenseDeviceMonitor');
    if (syncState) {
      syncState.textContent = 'Syncing devices';
      syncState.className = 'licenseDeviceSyncBadge syncing';
    }
    if (monitor) monitor.dataset.state = 'syncing';
    if (refreshButton) refreshButton.disabled = true;

    try {
      const pendingLedgerRequest = licenseDevicesRefreshInFlight || listOwnLicensedDevices();
      if (!licenseDevicesRefreshInFlight) {
        licenseDevicesRefreshInFlight = pendingLedgerRequest;
        pendingLedgerRequest.finally(() => {
          if (licenseDevicesRefreshInFlight === pendingLedgerRequest) licenseDevicesRefreshInFlight = null;
        }).catch(() => {});
      }
      const result = await pendingLedgerRequest;
      licenseDevicesLastLiveRefreshAt = Date.now();
      lastSuccessfulDeviceSyncAt = String(result.cachedAt || new Date().toISOString());
      const presentation = licensedDeviceLedgerPresentation(result, installationId, managementRole, true);
      const currentDevice = presentation.currentDevice;
      const ownerAdminAcrossLicense = presentation.ownerAdminAcrossLicense;
      const serverRole = ownerAdminAcrossLicense ? 'owner-admin' : String(currentDevice?.managementRole || '');

      // Main/Owner Admin follows the same license-key identity across every supported
      // platform. If Android (or another supported client) established Owner Admin first,
      // Chrome reconciles its signed lease automatically. Device Admin stays device-specific.
      if (currentDevice && ['owner-admin','manager'].includes(serverRole) && String(managementRole || '') !== serverRole) {
        await syncCurrentDeviceLease();
        licenseState = await getLicenseState();
        syncPremiumNavigation();
        applyProfileIdentity();
        toast(serverRole === 'manager' ? 'Device Admin status synchronized.' : 'Main Admin detected across this license key.');
        await renderLicense();
        return;
      }

      const releasedCleanup = presentation.canManage && presentation.releasedCount > 0
        ? `<div class="licenseActions releasedDeviceCleanup"><button id="deleteReleasedDeviceRecords" class="danger" type="button">Delete all released records (${presentation.releasedCount})</button><span class="settingHint">This permanently removes released device history only. It does not delete the license and does not change the standard 7-device capacity.</span></div>`
        : '';
      mount.dataset.hasSnapshot = '1';
      mount.innerHTML = `<div class="deviceSlotSummary"><strong>${escapeHtml(presentation.authorityTitle)}</strong><span>${escapeHtml(presentation.authorityDetail)}</span></div>${releasedCleanup}${licensedDeviceRows(presentation.devices, installationId, presentation.canManage)}`;
      if (syncState) {
        syncState.textContent = 'Live';
        syncState.className = 'licenseDeviceSyncBadge live';
      }
      if (syncTime) syncTime.textContent = licensedDeviceSyncTimeText(lastSuccessfulDeviceSyncAt);
      if (monitor) monitor.dataset.state = 'live';

      if (!presentation.canManage) return;

      $('deleteReleasedDeviceRecords')?.addEventListener('click', () => {
        if (!confirm(`Permanently delete all ${presentation.releasedCount} released device record(s)? Active devices are not touched and this Premium license will still support up to ${Number(result.maxDevices || 7)} devices.`)) return;
        ensureFreshSensitiveAccess('Enter your master password before permanently deleting released device history. A fresh email verification code is also required.', async () => {
          const token = await getFreshManagementToken();
          const cleanup = await deleteReleasedLicensedDevices(token);
          if (!cleanup?.entitlementPreserved) throw new Error('The server did not confirm that the license entitlement was preserved.');
          const deleted = Number(cleanup.deletedCount || 0);
          toast(`${deleted} released device record${deleted === 1 ? '' : 's'} deleted. Your Premium license still supports up to ${Number(cleanup.maxDevices || result.maxDevices || 7)} devices.`);
          await loadLicensedDevices({ force:true });
        }).catch((error) => { if (error?.message !== 'Cancelled.') toast(error.message, true); });
      });

      mount.querySelectorAll('[data-license-action]').forEach((button) => button.addEventListener('click', () => {
        const action = button.dataset.licenseAction;
        const target = button.dataset.installation;
        const warnings = { release:'Release this device and make its license slot vacant?', revoke:'Revoke this device and block it until an authorized restore?', restore:'Restore this device record?', delete:'Permanently delete this released device record?' };
        if (!confirm(warnings[action] || 'Apply this device action?')) return;
        ensureFreshSensitiveAccess(`Enter your master password before ${action}ing this licensed device. A fresh email verification code is also required.`, async () => {
          const token = await getFreshManagementToken();
          const actionResult = await changeLicensedDevice(token, target, action);
          if (action === 'delete' && !actionResult?.deleted) throw new Error('The server did not confirm device deletion.');
          if (target === installationId && ['release','revoke'].includes(action)) {
            await clearLicenseClientState();
            licenseState = await getLicenseState();
            syncPremiumNavigation();
            applyProfileIdentity();
            toast(`This device was ${action}d. Its slot is vacant.`);
            await renderLicense();
            return;
          }
          const messages = { release:'Device released. Its slot is now vacant.', revoke:'Device revoked and blocked.', restore:'Device restored. It must reactivate if its session was cleared.', delete:'Released device record permanently deleted.' };
          toast(messages[action] || 'Device action completed.');
          await loadLicensedDevices({ force:true });
        }).catch((error) => { if (error?.message !== 'Cancelled.') toast(error.message, true); });
      }));
    } catch (error) {
      const hasSnapshot = mount.dataset.hasSnapshot === '1';
      if (syncState) {
        syncState.textContent = hasSnapshot ? 'Cached - sync unavailable' : 'Sync unavailable';
        syncState.className = 'licenseDeviceSyncBadge stale';
      }
      if (monitor) monitor.dataset.state = 'stale';
      if (syncTime && hasSnapshot && lastSuccessfulDeviceSyncAt) syncTime.textContent = `${licensedDeviceSyncTimeText(lastSuccessfulDeviceSyncAt)} - Live refresh failed.`;
      if (!hasSnapshot) mount.innerHTML = `<div class="emptyState compactEmpty"><strong>Device ledger unavailable.</strong><span>${escapeHtml(error.message)}</span><button id="retryLicensedDevices" class="outline miniAction" type="button">Try again</button></div>`;
      $('retryLicensedDevices')?.addEventListener('click', () => loadLicensedDevices({ force:true }).catch(() => {}));
      if (!quiet && hasSnapshot) toast('Live device refresh failed. Showing the last locally saved device snapshot.', true);
      throw error;
    } finally {
      if (refreshButton) refreshButton.disabled = false;
    }
  }

  $('refreshLicensedDevices')?.addEventListener('click', () => loadLicensedDevices({ force:true }).catch(() => {}));
  if (activated) {
    licenseDevicesRefreshNow = (options = {}) => loadLicensedDevices(options);
    loadLicensedDevices({ quiet:Boolean(cachedDeviceSnapshot) }).catch(() => {});
    clearInterval(licenseDevicesRefreshTimer);
    licenseDevicesRefreshTimer = setInterval(() => {
      if (currentView === 'license' && $('licensedDevices')) loadLicensedDevices({ quiet:true }).catch(() => {});
    }, 15000);
  } else {
    licenseDevicesRefreshNow = null;
  }
}

function backupSelectionFromUi() {
  const fallback = defaultBackupSelection();
  const selection = {};
  for (const key of Object.keys(BACKUP_COMPONENTS)) {
    const input = document.querySelector(`[data-backup-component="${key}"]`);
    selection[key] = input ? Boolean(input.checked) : Boolean(fallback[key]);
  }
  return selection;
}

function backupComponentOptionMarkup(key, label, selected, premiumActive = Boolean(licenseState?.premium)) {
  const help = {
    logins: 'Saved login names/nicknames, usernames, passwords, URLs and login-specific protection rules. Use-only shared logins are intentionally excluded.',
    folders: 'Folder names and item-to-folder assignments.',
    cards: 'Payment card records.',
    banks: 'Bank account records.',
    identities: 'Identity and address records.',
    notes: 'Encrypted secure-note records.',
    totpCodes: 'TOTP secrets linked to owned login records.',
    trash: `Locked Trash items that have not reached the ${TRASH_RETENTION_DAYS}-day purge date. They are re-sealed for the destination vault during restore.`,
    favorites: 'Favorite markers for owned vault items.',
    settings: 'All current local VaultCove settings and preferences, including appearance/profile, security timing, handler, update, capture, sharing and security-notice preferences.'
  }[key] || '';
  const required = key === 'logins';
  const premiumLocked = !required && !premiumActive;
  return `<label class="backupChoice ${required ? 'requiredBackupChoice' : ''}${premiumLocked ? ' premiumBackupLocked' : ''}"><input type="checkbox" data-backup-component="${escapeAttr(key)}" ${selected || required ? 'checked' : ''} ${(required || premiumLocked) ? 'disabled aria-disabled="true"' : ''}><span><strong>${escapeHtml(label)}${required ? ' - Required' : ''}${premiumLocked ? '<span class="backupPremiumTag">Premium</span>' : ''}</strong><small>${escapeHtml(premiumLocked ? 'Premium Lifetime unlocks this backup component.' : help)}</small></span></label>`;
}

function updateBackupSelectionUi() {
  const selection = backupSelectionFromUi();
  const chosen = selectedBackupComponents(selection);
  const count = $('backupSelectedCount');
  const button = $('backupExportVault');
  if (count) count.textContent = licenseState?.premium ? `${chosen.length} of ${Object.keys(BACKUP_COMPONENTS).length} selected` : 'Login credentials only - Free Forever';
  if (button) button.disabled = chosen.length === 0;
  const warning = $('backupDependencyHint');
  if (warning) {
    const hints = [];
    if (selection.folders && !selection.logins && !selection.cards && !selection.banks && !selection.identities && !selection.notes) hints.push('Folders can only re-assign items whose IDs already exist on the destination vault unless their item categories are also included.');
    warning.textContent = hints.join(' ');
    warning.classList.toggle('hidden', hints.length === 0);
  }
}


function disasterRecoverySelection() {
  if (licenseState?.premium) return Object.fromEntries(Object.keys(BACKUP_COMPONENTS).map((key) => [key, true]));
  return { logins:true, folders:false, cards:false, banks:false, identities:false, notes:false, totpCodes:false, trash:false, favorites:false, settings:false };
}

async function createCurrentRecoverySnapshot(state, selection) {
  const currentSettings = await getSettings();
  const premiumBackup = Boolean(licenseState?.premium);
  const deviceRecoveryToken = await ensureDeviceRecoveryToken();
  try {
    return await createBackupSnapshot(vault, currentSettings, selection, {
      vaultKey:state.vaultKey,
      deviceRecoveryToken:premiumBackup ? deviceRecoveryToken : '',
      includeRecoveryMaterial:premiumBackup
    });
  } catch (error) {
    const message = String(error?.message || error || '');
    const trashAuthFailure = /Trash (?:key|payload) authentication failed|Trash item identity check failed|Trash key is invalid/i.test(message);
    if (!selection?.trash || !trashAuthFailure) throw error;
    const safeSelection = { ...selection, trash:false };
    const snapshot = await createBackupSnapshot(vault, currentSettings, safeSelection, {
      vaultKey:state.vaultKey,
      deviceRecoveryToken:premiumBackup ? deviceRecoveryToken : '',
      includeRecoveryMaterial:premiumBackup
    });
    snapshot.exclusions = { ...(snapshot.exclusions || {}), damagedTrashItems:Math.max(1, Number(snapshot.exclusions?.damagedTrashItems || 0)) };
    return snapshot;
  }
}

function disasterRecoveryStatusText(settings) {
  if (!settings?.disasterRecoveryEnabled) return 'Off';
  if (settings.disasterRecoveryLastError) return `Needs attention - ${settings.disasterRecoveryLastError}`;
  if (settings.disasterRecoveryPending) return 'Pending - VaultCove will update the encrypted recovery file while the vault is unlocked.';
  if (settings.disasterRecoveryLastSuccessAt) return `Protected - last backup ${new Date(settings.disasterRecoveryLastSuccessAt).toLocaleString()}`;
  return 'Ready - first encrypted recovery backup is pending.';
}

async function performDisasterRecoveryBackup({ force = false } = {}) {
  if (disasterRecoveryRunning) return false;
  const currentSettings = await getSettings();
  if (!currentSettings.disasterRecoveryEnabled && !force) return false;
  const recoveryEmail = String(currentSettings.securityNoticeEmail || '').trim().toLowerCase();
  if (!validSecurityEmail(recoveryEmail)) throw new Error('Set a valid Security notice email before enabling Disaster Recovery.');
  const state = await loadUnlockedVault({ touch:false });
  if (state.state !== 'unlocked' || !state.vaultKey) return false;

  disasterRecoveryRunning = true;
  try {
    const selection = disasterRecoverySelection();
    const snapshot = await createCurrentRecoverySnapshot(state, selection);
    const envelope = await getVaultEnvelope();
    const payload = await createDisasterRecoveryExport(snapshot, envelope, state.vaultKey, recoveryEmail);
    const relativeFilename = 'VaultCove Disaster Recovery/VaultCove-Disaster-Recovery-Latest.vcvault';
    const blob = new Blob([JSON.stringify(payload)], { type:'application/octet-stream' });
    await saveBlobSilentlyToDownloads(blob, relativeFilename, { conflictAction:'overwrite' });

    const generationPatch = {};
    if (licenseState?.premium) {
      const nowMs = Date.now();
      const generations = [
        ['Daily', 'guardianDrDailyAt', 24 * 60 * 60 * 1000],
        ['Weekly', 'guardianDrWeeklyAt', 7 * 24 * 60 * 60 * 1000],
        ['Monthly', 'guardianDrMonthlyAt', 30 * 24 * 60 * 60 * 1000]
      ];
      for (const [label, settingKey, intervalMs] of generations) {
        const previousMs = Date.parse(String(currentSettings?.[settingKey] || '')) || 0;
        if (!previousMs || nowMs - previousMs >= intervalMs) {
          const generationFile = `VaultCove Disaster Recovery/VaultCove-Disaster-Recovery-${label}.vcvault`;
          await saveBlobSilentlyToDownloads(blob, generationFile, { conflictAction:'overwrite' });
          generationPatch[settingKey] = new Date(nowMs).toISOString();
        }
      }
    }

    await setSettings({
      disasterRecoveryPending:false,
      disasterRecoveryDueAt:null,
      disasterRecoveryLastSuccessAt:new Date().toISOString(),
      disasterRecoveryLastError:'',
      disasterRecoveryLastBackupId:payload.backupId,
      disasterRecoveryLastFile:relativeFilename,
      ...generationPatch
    });
    settingsState = await getSettings();
    await appendActivityEvent(vault, 'disaster-recovery-backup-created', {
      backupId:payload.backupId,
      scope:licenseState?.premium ? 'premium-complete' : 'free-logins'
    });
    await saveUnlockedVault(vault, { touch:false, markRecoveryPending:false, markManualBackupPending:false });
    return true;
  } catch (error) {
    await setSettings({
      disasterRecoveryPending:true,
      disasterRecoveryDueAt:new Date(Date.now() + 5 * 60_000).toISOString(),
      disasterRecoveryLastError:String(error?.message || error || 'Automatic backup failed.').slice(0, 240)
    });
    settingsState = await getSettings();
    throw error;
  } finally {
    disasterRecoveryRunning = false;
  }
}

async function scheduleDisasterRecoveryIfNeeded({ force = false } = {}) {
  if (disasterRecoveryTimer) {
    clearTimeout(disasterRecoveryTimer);
    disasterRecoveryTimer = null;
  }
  const currentSettings = await getSettings();
  if (!currentSettings.disasterRecoveryEnabled) return false;
  if (!force && !currentSettings.disasterRecoveryPending) return false;
  const state = await loadUnlockedVault({ touch:false });
  if (state.state !== 'unlocked') return false;
  const dueMs = force ? 0 : Math.max(0, Date.parse(currentSettings.disasterRecoveryDueAt || '') - Date.now()) || 0;
  disasterRecoveryTimer = setTimeout(() => {
    disasterRecoveryTimer = null;
    performDisasterRecoveryBackup({ force }).then((saved) => {
      if (saved && currentView === 'backup') renderBackup().catch(() => {});
    }).catch((error) => {
      if (currentView === 'backup') renderBackup().catch(() => {});
      else console.warn('VaultCove Disaster Recovery backup failed:', error);
    });
  }, Math.min(dueMs, 5 * 60_000));
  return true;
}

async function renderBackup() {
  pendingBackupPreview = null;
  settingsState = await getSettings();
  const premiumBackup = Boolean(licenseState?.premium);
  const defaults = defaultBackupSelection();
  const choices = Object.entries(BACKUP_COMPONENTS).map(([key, label]) => backupComponentOptionMarkup(key, label, defaults[key], premiumBackup)).join('');
  els.content.innerHTML = `${pageHead()}<div class="settingsGrid backupGrid">
    <section class="settingsCard backupCreateCard">
      <div class="settingsCardTitleRow"><div><h3>Encrypted .vcvault backup</h3><p>${premiumBackup ? `Login credentials are always required. Choose any additional Premium components you want to include in this encrypted backup; optional components can be checked or unchecked independently.` : `Free Forever encrypted backups include Login credentials only. Activate Premium Lifetime to choose additional vault categories and encrypted recovery material.`}</p></div><strong id="backupSelectedCount" class="selectionCount">1 of ${Object.keys(BACKUP_COMPONENTS).length} selected</strong></div>
      ${premiumBackup ? '<div class="integrationStatus"><strong>Selective backup</strong><span>Only Login credentials are mandatory. Add folders, cards, bank accounts, identities, secure notes, TOTP, Trash, favorites, or settings only when you want them in this backup.</span></div>' : ''}
      <div class="backupOptionGrid">${choices}</div>
      <p id="backupDependencyHint" class="settingHint warningText hidden"></p>
      <div class="backupPolicyNote"><strong>Unique Backup Key required:</strong><span>Each new <code>.vcvault</code> gets a fresh random 256-bit Backup Key. VaultCove does not store that key inside the file. The exact matching key is required before preview or restore. Use-only shared credentials remain recipient-bound and are never made portable. If an old Trash envelope is damaged, VaultCove skips only that damaged deleted item so healthy vault data can still be backed up.</span></div>
      <button id="backupExportVault">Create encrypted .vcvault backup</button>
    </section>
    <section class="settingsCard backupCreateCard">
      <div class="settingsCardTitleRow"><div><h3>Automatic Disaster Recovery</h3><p>When enabled, VaultCove updates an encrypted recovery <code>.vcvault</code> after vault changes while the vault is unlocked. The Master Password is never stored. Recovery requires the Master Password that protected the backup and a fresh six-digit code sent to the encrypted recovery email.</p></div><strong class="selectionCount">${settingsState?.disasterRecoveryEnabled ? 'On' : 'Off'}</strong></div>
      <label class="check"><input id="disasterRecoveryEnabled" type="checkbox" ${settingsState?.disasterRecoveryEnabled ? 'checked' : ''}> Automatically maintain Disaster Recovery backup</label>
      <div class="integrationStatus"><strong id="disasterRecoveryStatus">${escapeHtml(disasterRecoveryStatusText(settingsState))}</strong><span>Saved automatically as <code>Downloads/VaultCove Disaster Recovery/VaultCove-Disaster-Recovery-Latest.vcvault</code>${premiumBackup ? ' with rolling Daily, Weekly, and Monthly encrypted Guardian generations.' : '.'}</span></div>
      <div class="backupPolicyNote"><strong>Off-device protection:</strong><span>The recovery file must exist somewhere that survives loss of this device. Use a cloud-synced Downloads location or copy/sync the <code>VaultCove Disaster Recovery</code> folder to OneDrive, Dropbox, Google Drive, NAS, USB, or another separate device. A copy that remains only on this PC cannot protect against total device loss.</span></div>
      <div class="backupPresetRow"><button id="disasterBackupNow" type="button" class="outline" ${settingsState?.disasterRecoveryEnabled ? '' : 'disabled'}>Back up now</button></div>
    </section>
    <section class="settingsCard backupRestoreCard">
      <h3>Restore encrypted .vcvault</h3>
      <p>Manual backups use their unique Backup Key. Automatic Disaster Recovery backups use the Master Password that protected that backup, then require a fresh email verification code before restore.</p>
      <div class="backupRestoreInputs">
        <label class="backupFileLabel">Backup file<input id="restoreFile" type="file" accept=".vcvault,application/json"></label>
        <label>Backup Key / Recovery Master Password<input id="restoreSecret" type="password" autocomplete="off" placeholder="Backup Key or recovery Master Password"></label>
      </div>
      <div class="backupPresetRow"><button id="previewRestoreVault" type="button" class="outline">Preview encrypted backup</button><button id="recordRecoveryDrill" type="button" class="outline" disabled>Record Recovery Drill pass</button><button id="restoreVaultButton" type="button" class="outline" disabled>Restore into this vault</button></div>
      <div id="backupRestorePreview" class="migrationPreview backupRestorePreview"><p>Choose the encrypted .vcvault and enter its Backup Key or Disaster Recovery Master Password. Previewing acts as a non-destructive backup test; nothing is restored until you explicitly confirm Restore.</p></div>
    </section>
  </div>`;

  document.querySelectorAll('[data-backup-component]').forEach((input) => input.addEventListener('change', updateBackupSelectionUi));
  $('backupLoginOnly')?.addEventListener('click', () => {
    document.querySelectorAll('[data-backup-component]').forEach((input) => { input.checked = input.dataset.backupComponent === 'logins'; });
    updateBackupSelectionUi();
  });
  $('backupSelectAll')?.addEventListener('click', () => { document.querySelectorAll('[data-backup-component]').forEach((input) => { input.checked = true; }); updateBackupSelectionUi(); });
  $('backupClear')?.addEventListener('click', () => { document.querySelectorAll('[data-backup-component]').forEach((input) => { input.checked = input.dataset.backupComponent === 'logins'; }); updateBackupSelectionUi(); });
  updateBackupSelectionUi();

  $('backupExportVault').addEventListener('click', exportVault);
  $('disasterRecoveryEnabled')?.addEventListener('change', async () => {
    try {
      const enabled = Boolean($('disasterRecoveryEnabled')?.checked);
      const current = await getSettings();
      if (enabled && !validSecurityEmail(current.securityNoticeEmail)) {
        $('disasterRecoveryEnabled').checked = false;
        throw new Error('Set a valid Security notice email in Settings before enabling Disaster Recovery.');
      }
      await setSettings({
        disasterRecoveryEnabled:enabled,
        disasterRecoveryPending:enabled,
        disasterRecoveryDueAt:enabled ? new Date().toISOString() : null,
        disasterRecoveryLastError:enabled ? '' : current.disasterRecoveryLastError
      });
      settingsState = await getSettings();
      if (enabled) {
        await scheduleDisasterRecoveryIfNeeded({ force:true });
        toast('Disaster Recovery enabled. VaultCove is creating the first encrypted recovery backup.');
      } else {
        if (disasterRecoveryTimer) clearTimeout(disasterRecoveryTimer);
        disasterRecoveryTimer = null;
        toast('Automatic Disaster Recovery disabled. Existing recovery files were not deleted.');
      }
      await renderBackup();
    } catch (error) { toast(error.message, true); }
  });
  $('disasterBackupNow')?.addEventListener('click', async () => {
    try {
      await performDisasterRecoveryBackup({ force:true });
      toast('Encrypted Disaster Recovery backup updated.');
      await renderBackup();
    } catch (error) { toast(error.message, true); }
  });
  $('previewRestoreVault').addEventListener('click', previewVaultRestore);
  $('recordRecoveryDrill')?.addEventListener('click', async () => {
    try {
      if (!premiumFeatureAllowed(licenseState, 'guardian')) throw new Error('Recovery Drill requires Premium Guardian.');
      if (!pendingBackupPreview) throw new Error('Preview and verify an encrypted backup first.');
      const passedAt = new Date().toISOString();
      await setSettings({ guardianLastRecoveryDrillAt:passedAt, guardianLastRecoveryDrillFile:String(pendingBackupPreview.fileName || '').slice(0,180) });
      settingsState = await getSettings();
      await appendActivityEvent(vault, 'guardian-recovery-drill-passed', { backupType:pendingBackupPreview.disasterRecovery ? 'disaster-recovery' : 'manual-vcvault' });
      await saveUnlockedVault(vault, { markRecoveryPending:false, markManualBackupPending:false });
      toast('Recovery Drill passed and recorded. No vault data was restored.');
      await renderBackup();
    } catch (error) { toast(error.message, true); }
  });
  $('restoreVaultButton').addEventListener('click', importVault);
  const clearRestorePreview = () => {
    pendingBackupPreview = null;
    const button = $('restoreVaultButton');
    if (button) button.disabled = true;
    const drillButton = $('recordRecoveryDrill');
    if (drillButton) drillButton.disabled = true;
    const mount = $('backupRestorePreview');
    if (mount) mount.innerHTML = '<p>Backup selection or recovery credential changed. Preview this exact .vcvault again before restore.</p>';
  };
  $('restoreFile')?.addEventListener('change', clearRestorePreview);
  $('restoreSecret')?.addEventListener('input', clearRestorePreview);
}

function renderSupport() {
  els.content.innerHTML = `${pageHead('Support VaultCove', 'Support continued development without changing VaultCove\'s offline-first privacy model.')}
    <div class="supportGrid">
      <section class="settingsCard supportHero">
        <span class="supportHeroIcon">${uiIcon('support', 30)}</span>
        <div><h3>VaultCove is offline by design.</h3><p>Your vault, saved credentials, master password, cards, secure notes, TOTP secrets, and other vault contents are not sent to Payhip or PayPal. The links below open external websites only when you choose to click them.</p></div>
      </section>
      <a class="supportCard" href="https://payhip.com/AJCoderDigitalStore" target="_blank" rel="noopener noreferrer">
        <span class="supportCardIcon storeSupport">${uiIcon('store', 28)}</span>
        <span><strong>AJ Coder Digital Store on Payhip</strong><small>Visit the official Payhip store for VaultCove and other digital software products.</small><b>Open Payhip Store</b></span>
      </a>
      <a class="supportCard" href="https://paypal.me/ajleveriza" target="_blank" rel="noopener noreferrer">
        <span class="supportCardIcon decafSupport">${uiIcon('coffee', 28)}</span>
        <span><strong>Buy me a decaf</strong><small>Support me to continue developing and improving more secure and safer apps.</small><b>Support via PayPal</b></span>
      </a>
      <section class="supportCard supportEmailCard">
        <span class="supportCardIcon emailSupport">${uiIcon('mail', 28)}</span>
        <span><strong>Email me for app improvements</strong><small>Have an idea that could make VaultCove safer, easier, or more useful? Email the developer directly. Please never include passwords, license keys, Backup Keys, TOTP secrets, or vault files.</small>
          <span class="supportEmailActions">
            <a href="mailto:leveriza.aj08@gmail.com?subject=VaultCove%20App%20Improvement%20Suggestion">leveriza.aj08@gmail.com</a>
            <button id="copySupportEmail" class="supportCopyEmail" type="button" aria-label="Copy developer email" title="Copy email">${uiIcon('copy', 16)}</button>
          </span>
        </span>
      </section>
      <section class="settingsCard supportPrivacy"><h3>Privacy boundary</h3><p>Payhip and PayPal open only when you choose their links. The improvement link opens your default email app with a subject line only. Copy email writes only the developer email address to your clipboard. VaultCove does not attach your vault contents, security score, saved-site list, passwords, master password, license key, or backup files.</p></section>
    </div>`;

  $('copySupportEmail')?.addEventListener('click', async () => {
    try {
      await navigator.clipboard.writeText('leveriza.aj08@gmail.com');
      toast('Developer email copied.');
    } catch {
      toast('Could not copy the developer email. Select the email address and copy it manually.', true);
    }
  });
}

async function renderSettings() {
  settingsState = await getSettings();
  await refreshHandlerPermissions();
  const origins = handlerPermissionState;
  const broadOrigin = 'https://*/*';
  const broadGranted = await chrome.permissions.contains({ origins: [broadOrigin] });
  const faviconGranted = true;
  const perSiteOrigins = origins.filter((origin) => origin !== broadOrigin);
  const disabledHandlerHosts = Array.isArray(settingsState.handlerDisabledHosts) ? settingsState.handlerDisabledHosts : [];
  const siteRows = disabledHandlerHosts.length
    ? disabledHandlerHosts.map((host) => `<div class="permissionRow"><strong>${escapeHtml(host)}</strong><button type="button" class="miniAction enableHandlerHost" data-host="${escapeAttr(host)}">Turn on</button></div>`).join('')
    : '<div class="emptyState compactEmpty">Always-On Handler is active on every HTTPS website.</div>';
  const protection = vaultTotpProtection();
  const strength = assessPassword('');

  const appearanceCard = `<section class="settingsCard"><h3>Appearance and personalization</h3><p>Choose the local name, optional cropped photo, theme, and density for this installation.</p><div class="profilePhotoRow"><span id="profilePhotoPreview" class="profilePhotoPreview"><img data-avatar-image alt="" draggable="false" hidden><span data-avatar-fallback>${escapeHtml(profileInitials())}</span></span><div><label>Profile photo<input id="profilePhotoInput" type="file" accept="image/png,image/jpeg,image/webp"></label><small class="settingHint">Stored locally only. VaultCove lets you drag, zoom, and crop the image on this device and never uploads or syncs it.</small><button id="removeProfilePhoto" type="button" class="outline miniAction" ${profilePhotoDataUrl() ? '' : 'disabled'}>Remove photo</button></div></div><label>Your display name<input id="profileNameSetting" maxlength="80" value="${escapeAttr(normalizedProfileName(settingsState.profileName) === 'VaultCove User' ? '' : normalizedProfileName(settingsState.profileName))}" placeholder="Your name"></label><button id="saveProfileName" type="button" class="outline">Save display name</button><label>Theme<select id="themeSetting">${Object.entries(THEMES).map(([value,label])=>`<option value="${escapeHtml(value)}" ${settingsState.theme===value?'selected':''}>${escapeHtml(label)}</option>`).join('')}</select></label><label class="check"><input id="compactUiSetting" type="checkbox" ${settingsState.compactUi!==false?'checked':''}> Compact interface</label></section>`;
  const timingCard = `<section class="settingsCard"><h3>Auto-lock and Sensitive Access</h3><p>Vault unlock controls normal use. Viewing, copying, editing, exporting, sharing, or protected Secure Login gets a fresh Sensitive Access check.</p><label>Lock vault after inactivity (minutes)<input id="lockMinutesSetting" type="number" min="1" max="120" value="${settingsState.lockMinutes}"></label><label>Sensitive Access window (seconds)<input id="sensitiveSecondsSetting" type="number" min="5" max="300" value="${settingsState.sensitiveAccessSeconds}"></label><label>Secure Login field-clear fallback (milliseconds)<input id="clearDelaySetting" type="number" min="250" max="5000" step="50" value="${settingsState.secureLoginClearMs || 1200}"></label><label>Clear copied VaultCove secrets after (seconds)<input id="clipboardClearSetting" type="number" min="0" max="300" step="5" value="${Math.max(0,Number(settingsState.clipboardClearSeconds ?? 30))}"></label><p class="settingHint">Use 0 to disable timed clearing. VaultCove clears only when Chrome lets it confirm the clipboard still contains the exact secret VaultCove copied; it never requests broad clipboard-read permission just for this timer.</p><p class="settingHint">Secure Login submits first, then clears the injected password field if it is still present and unchanged.</p><button id="saveSettings">Save security timing</button></section>`;
  const handlerCard = `<section class="settingsCard alwaysOnCard"><h3>Always-On Login Handler</h3><p>Always-On Handler is enabled by default on HTTPS websites. Add only the websites where you do not want VaultCove to show its login handler.</p><div class="integrationStatus"><strong>Always-On Handler enabled by default</strong><span>The Developer build loads the isolated handler automatically on HTTPS pages. A website on the exception list receives no VaultCove handler UI and no automatic login handling.</span></div><div class="handlerExceptionEditor"><input id="handlerOffHost" type="text" placeholder="example.com" autocomplete="off"><button id="addHandlerOffHost" type="button" class="outline">Turn off for website</button></div><p class="settingHint">Enter only a hostname, such as 9gag.com. You can turn the handler back on at any time.</p><div class="permissionList">${siteRows}</div><label class="check"><input id="autoLoginSetting" type="checkbox" ${settingsState.autoLoginEnabled ? 'checked' : ''}> Enable automatic login only for entries individually marked Auto-login</label><label class="check"><input id="newLoginCaptureSetting" type="checkbox" ${settingsState.newLoginCaptureEnabled ? 'checked' : ''}> Detect submitted new logins locally and ask before saving them</label><label class="check"><input id="passwordChangeSetting" type="checkbox" ${settingsState.passwordChangeDetectionEnabled ? 'checked' : ''}> Detect password changes and offer the inline strong-password generator</label></section>`;
  const authenticatorCard = `<section class="settingsCard"><h3>VaultCove authenticator confirmation</h3><p>${protection.enabled ? 'A standard TOTP authenticator code is required with the master password for unlock and Sensitive Access. It also authorizes .vckey-to-TXT conversion.' : 'Set up a standard TOTP authenticator such as Google Authenticator. VaultCove requires it before any encrypted .vckey can be converted to readable TXT.'}</p><div class="integrationStatus"><strong>${protection.enabled ? 'Authenticator protection enabled' : 'Authenticator protection disabled'}</strong><span>Google Authenticator does not receive, sync, store, or have access to your VaultCove passwords. VaultCove verifies a standard TOTP code locally. .vckey-to-TXT conversion still requires that file's separate .vckey password; VaultCove does not create a third TXT-conversion password.</span></div>${protection.enabled ? `<p class="settingHint">${(protection.recoveryCodeHashes || []).length} unused recovery code(s) remain.</p><button id="disableVaultTotp" class="outline">Disable authenticator protection</button>` : '<button id="setupVaultTotp">Set up Google Authenticator-compatible protection</button>'}</section>`;
  const masterCard = `<section class="settingsCard masterPasswordCard"><h3>Change master password</h3><p>VaultCove verifies the current password${protection.enabled ? ' and authenticator code' : ''}, enforces every live strong-password check, atomically re-wraps the same random vault key, then locks the vault so the new password must be used immediately.</p><label>Current master password<input id="currentMaster" type="password" autocomplete="current-password"></label>${protection.enabled ? '<label>Authenticator or recovery code<input id="masterTotp" autocomplete="one-time-code"></label>' : ''}<label>New master password<input id="newMaster" type="password" autocomplete="new-password" minlength="12"></label>${passwordGuideMarkup('newMasterPasswordGuide',12)}<div class="masterStrength"><span>Strength</span><strong id="masterStrengthLabel">${escapeHtml(strength.label)}</strong><div><i id="masterStrengthBar"></i></div></div><label>Confirm new password<input id="newMasterConfirm" type="password" autocomplete="new-password" minlength="12"></label><div class="migrationWarning"><strong>Before changing it:</strong> keep a current encrypted <code>.vcvault</code> backup and its separate unique Backup Key. The .vcvault can also carry the VaultCove authenticator/recovery identity, but the exact Backup Key is required to restore it.</div><button id="changeMaster" class="danger">Change master password and lock VaultCove</button></section>`;
  const updatesCard = `<section class="settingsCard"><h3>Developer updates</h3><p>This Developer Mode build checks only the official public <code>VaultCove-release</code> metadata once per day. No vault, username, password, website list, security score, or browsing data is added to the request.</p><label class="check"><input id="updateCheckSetting" type="checkbox" ${settingsState.updateChecksEnabled ? 'checked' : ''}> Check official developer release metadata daily</label><button id="checkUpdatesNow" class="outline">Check for updates now</button><p class="settingHint">The Chrome Web Store build removes the GitHub updater permission and uses Chrome's official extension update mechanism.</p></section>`;
  const emailCard = `<section class="settingsCard"><h3>Email security notices</h3><p>With active Premium licensing, VaultCove automatically emails the verified license address after a saved password changes, a Card/Bank Account/Identity is updated or removed, or passwords are exported through VCShare. Notices contain event metadata only and never contain the protected secret.</p><label>Security notice / Disaster Recovery email<input id="securityNoticeEmail" type="email" autocomplete="email" value="${escapeHtml(settingsState.securityNoticeEmail || '')}" placeholder="you@example.com"></label><label class="check"><input id="emailNoticeSetting" type="checkbox" ${settingsState.securityEmailNoticeEnabled ? 'checked' : ''}> Send additional background notices for other protected-record activity</label><button id="saveEmailNoticeSettings" type="button" class="outline">Save security notice setup</button><div class="migrationWarning"><strong>Automatic critical notices:</strong> password changes, Card/Bank/Identity updates or removals, and VCShare exports always notify the registered Premium license email. VaultCove never emails the password, card number, bank details, identity details, Master Password, or vault key.</div></section>`;
  const privacyCard = `<section class="settingsCard"><h3>Privacy model</h3><p>No cloud vault, analytics, advertising or telemetry. Secure Login uses verified HTTPS destinations by default. Explicitly saved HTTP credentials are marked Not secure, never auto-login, and require a fresh user warning confirmation before use. Website thumbnails use Chrome's local favicon cache and are enabled by default.</p><p><strong>${escapeHtml(licenseState.message)}</strong></p></section>`;
  const encryptionCard = `<section class="settingsCard"><h3>What encryption can and cannot protect</h3><p>A stolen Chrome profile sees only the encrypted vault. Strict Secure Login has no password Fill button: it verifies the exact top-level HTTPS destination, injects the password only for immediate submission without normal password input/change events, and clears the field on failure or shortly after submission. A malicious website, compromised browser renderer, or compromised PC can still observe a password at the moment the website must receive it; passkeys are the stronger long-term boundary.</p></section>`;

  els.content.innerHTML = `${pageHead()}<div class="settingsColumns">
    <div class="settingsColumn">${appearanceCard}${updatesCard}${privacyCard}</div>
    <div class="settingsColumn">${timingCard}${authenticatorCard}${masterCard}</div>
    <div class="settingsColumn">${handlerCard}${emailCard}${encryptionCard}</div>
  </div>`;
  // The Settings preview is created by the innerHTML above, after render() has already
  // refreshed persistent header avatars. Re-apply the identity now so an existing
  // cropped photo is rendered immediately whenever Settings is opened or re-rendered.
  applyProfileIdentity();

  $('saveSettings').addEventListener('click', async () => {
    const minutes = Math.max(1, Math.min(120, Number($('lockMinutesSetting').value) || 5));
    const sensitiveAccessSeconds = Math.max(5, Math.min(300, Number($('sensitiveSecondsSetting').value) || 30));
    const secureLoginClearMs = Math.max(250, Math.min(5000, Number($('clearDelaySetting').value) || 1200));
    const clipboardClearSeconds = Math.max(0, Math.min(300, Number($('clipboardClearSetting')?.value ?? 30)));
    await setSettings({ lockMinutes: minutes, sensitiveAccessSeconds, secureLoginClearMs, clipboardClearSeconds });
    await markManualBackupPending();
    settingsState = await getSettings();
    await touchSession();
    toast('Security timing saved. Auto-lock countdown restarted from this activity.');
  });

  $('addHandlerOffHost')?.addEventListener('click', async () => {
    const hostname = String($('handlerOffHost')?.value || '').trim().toLowerCase();
    if (!hostname) return toast('Enter a website hostname first.', true);
    try {
      await runtimeMessage({ type: 'SET_HANDLER_SITE_EXCEPTION', hostname, disabled: true });
      await markManualBackupPending();
      settingsState = await getSettings();
      toast(`Always-On Handler is off for ${hostname}.`);
      await renderSettings();
    } catch (error) { toast(error.message, true); }
  });
  document.querySelectorAll('.enableHandlerHost').forEach((button) => button.addEventListener('click', async () => {
    const hostname = button.dataset.host || '';
    try {
      await runtimeMessage({ type: 'SET_HANDLER_SITE_EXCEPTION', hostname, disabled: false });
      await markManualBackupPending();
      settingsState = await getSettings();
      toast(`Always-On Handler is on for ${hostname}.`);
      await renderSettings();
    } catch (error) { toast(error.message, true); }
  }));


  $('saveProfileName')?.addEventListener('click', async () => {
    const profileName = normalizedProfileName($('profileNameSetting')?.value);
    await setSettings({ profileName });
    settingsState = { ...settingsState, profileName };
    applyProfileIdentity();
    toast(profileName === 'VaultCove User' ? 'Default display name restored.' : 'Display name saved locally.');
  });

  $('profilePhotoInput')?.addEventListener('change', async (event) => {
    try {
      const file = event.target.files?.[0];
      if (!file) return;
      const profileImageDataUrl = await localProfileImageFromFile(file);
      if (!profileImageDataUrl) { event.target.value = ''; return; }
      await persistLocalProfilePhoto(profileImageDataUrl);
      const remove = $('removeProfilePhoto');
      if (remove) remove.disabled = false;
      event.target.value = '';
      toast('Profile photo saved locally on this device.');
    } catch (error) { toast(error.message, true); }
  });
  $('removeProfilePhoto')?.addEventListener('click', async () => {
    await persistLocalProfilePhoto('');
    $('removeProfilePhoto').disabled = true;
    toast('Local profile photo removed.');
  });

  $('setupVaultTotp')?.addEventListener('click', () => ensureSensitiveAccess('Re-enter your master password before adding a second factor to VaultCove.', beginVaultTotpSetup).catch((error) => toast(error.message, true)));
  $('disableVaultTotp')?.addEventListener('click', () => ensureSensitiveAccess('Verify your master password and authenticator code before disabling VaultCove authenticator confirmation.', async () => {
    vault.security = vault.security || {};
    vault.security.vaultTotp = { enabled:false, secret:'', recoveryCodeHashes:[], enabledAt:null };
    await saveUnlockedVault(vault); await setSettings({ vaultTotpEnabled:false }); settingsState = await getSettings(); toast('VaultCove authenticator protection disabled.'); await renderSettings();
  }).catch((error) => toast(error.message, true)));

  $('newMaster')?.addEventListener('input', updateMasterStrength);
  bindPasswordGuide({ inputId:'newMaster', confirmId:'newMasterConfirm', guideId:'newMasterPasswordGuide', onChange:(state)=>{ if ($('changeMaster')) $('changeMaster').disabled=!state.valid; } });
  $('changeMaster').addEventListener('click', changeMaster);
  $('autoLoginSetting').addEventListener('change', async () => { await setSettings({ autoLoginEnabled:$('autoLoginSetting').checked }); await markManualBackupPending(); settingsState=await getSettings(); toast($('autoLoginSetting').checked ? 'Automatic login enabled only for opted-in credentials.' : 'Automatic login disabled.'); });
  $('newLoginCaptureSetting').addEventListener('change', async () => { await setSettings({ newLoginCaptureEnabled:$('newLoginCaptureSetting').checked }); await markManualBackupPending(); settingsState=await getSettings(); toast($('newLoginCaptureSetting').checked ? 'New-login capture enabled.' : 'New-login capture disabled.'); });
  $('passwordChangeSetting').addEventListener('change', async () => { await setSettings({ passwordChangeDetectionEnabled:$('passwordChangeSetting').checked }); await markManualBackupPending(); settingsState=await getSettings(); toast($('passwordChangeSetting').checked ? 'Password-change detection and inline generator enabled.' : 'Password-change detection disabled.'); });
  $('saveEmailNoticeSettings')?.addEventListener('click', async () => {
    try {
      const enabled = Boolean($('emailNoticeSetting')?.checked);
      const email = String($('securityNoticeEmail')?.value || '').trim();
      if (enabled && !validSecurityEmail(email)) throw new Error('Enter a valid security notice email or turn email notices off.');
      await setSettings({ securityEmailNoticeEnabled:enabled, securityNoticeEmail:email });
      await markManualBackupPending();
      settingsState=await getSettings();
      toast('Security notice setup saved locally.');
    } catch (error) { toast(error.message, true); }
  });
  $('updateCheckSetting')?.addEventListener('change', async () => { await setSettings({ updateChecksEnabled:$('updateCheckSetting').checked }); settingsState=await getSettings(); toast($('updateCheckSetting').checked ? 'Daily developer update checks enabled.' : 'Automatic update checks disabled.'); });
  $('checkUpdatesNow')?.addEventListener('click', async () => { try { const result=await runtimeMessage({type:'CHECK_FOR_UPDATES',force:true}); toast(result.updateAvailable ? `VaultCove ${result.version} is available.` : `VaultCove ${result.currentVersion} is up to date.`); } catch(error){ toast(error.message,true); } });
  $('themeSetting')?.addEventListener('change', async()=>{
    const theme = $('themeSetting').value;
    await setSettings({ theme });
    settingsState = { ...settingsState, theme };
    applyCurrentTheme();
    toast('Theme updated.');
  });
  $('compactUiSetting')?.addEventListener('change', async()=>{
    const compactUi = $('compactUiSetting').checked;
    await setSettings({ compactUi });
    settingsState = { ...settingsState, compactUi };
    applyCurrentDensity();
    toast('Interface density updated.');
  });
  updateMasterStrength();
}

function updateMasterStrength() {
  const input = $('newMaster'); if (!input || !$('masterStrengthLabel') || !$('masterStrengthBar')) return;
  const result = assessPassword(input.value);
  $('masterStrengthLabel').textContent = result.label;
  $('masterStrengthBar').style.width = `${Math.max(0, Math.min(100, result.score * 25))}%`;
  $('masterStrengthBar').dataset.score = String(result.score);
}

async function beginVaultTotpSetup() {
  const secret = generateTotpSecret();
  const recoveryCodes = generateRecoveryCodes(10);
  pendingTotpSetup = { secret, recoveryCodes };
  $('totpSetupSecret').value = secret;
  $('totpSetupUri').value = buildTotpUri(secret, 'Local Vault', 'VaultCove');
  $('totpSetupCode').value = '';
  $('totpRecoveryPanel').classList.add('hidden');
  $('totpRecoveryCodes').textContent = '';
  els.totpSetupDialog.showModal();
  setTimeout(() => $('totpSetupCode').focus(), 0);
}

async function exportVaultNow(selection) {
  const premiumBackup = Boolean(licenseState?.premium);
  if (premiumBackup) selection = { ...defaultBackupSelection(), ...(selection || {}), logins:true };
  else selection = { logins:true, folders:false, cards:false, banks:false, identities:false, notes:false, totpCodes:false, trash:false, favorites:false, settings:false };
  const chosen = selectedBackupComponents(selection);
  if (!chosen.length) throw new Error('Select at least one backup component.');
  const state = await loadUnlockedVault({ touch: false });
  if (state.state !== 'unlocked' || !state.vaultKey) throw new Error('VaultCove is locked.');
  const currentSettings = await getSettings();
  const deviceRecoveryToken = await ensureDeviceRecoveryToken();
  let snapshot;
  let trashFallbackUsed = false;
  try {
    snapshot = await createBackupSnapshot(vault, currentSettings, selection, { vaultKey: state.vaultKey, deviceRecoveryToken: premiumBackup ? deviceRecoveryToken : '', includeRecoveryMaterial: premiumBackup });
  } catch (error) {
    const message = String(error?.message || error || '');
    const trashAuthFailure = /Trash (?:key|payload) authentication failed|Trash item identity check failed|Trash key is invalid/i.test(message);
    if (!selection?.trash || !trashAuthFailure) throw error;

    // Defense-in-depth: a corrupted deleted Trash record must never prevent
    // healthy active credentials from being exported. Retry the same backup
    // with Trash excluded and tell the user exactly what happened.
    const safeSelection = { ...selection, trash: false };
    snapshot = await createBackupSnapshot(vault, currentSettings, safeSelection, { vaultKey: state.vaultKey, deviceRecoveryToken: premiumBackup ? deviceRecoveryToken : '', includeRecoveryMaterial: premiumBackup });
    snapshot.exclusions = {
      ...(snapshot.exclusions || {}),
      damagedTrashItems: Math.max(1, Number(snapshot.exclusions?.damagedTrashItems || 0))
    };
    trashFallbackUsed = true;
  }
  const { payload, secret } = await createPortableExport(snapshot);
  // A backup is not considered successful until VaultCove can decrypt and parse
  // the exact encrypted payload it is about to save. This catches damaged or
  // incomplete containers before the dashboard clears its backup reminder.
  const verifiedSnapshot = await decryptPortableExport(payload, secret);
  backupSnapshotSummary(verifiedSnapshot);
  await downloadExport(payload);
  await appendActivityEvent(vault, 'backup-created', { components: selectedBackupComponents(selection).map((entry) => entry.key).join(','), excludedUseOnly: Number(snapshot.exclusions?.useOnlySharedLogins || 0), verified:true });
  await saveUnlockedVault(vault, { touch: false, markManualBackupPending:false });
  await recordManualBackupSuccess({ verifiedAt:new Date().toISOString() });
  settingsState = await getSettings();
  els.exportSecret.textContent = secret;
  els.secretDialog.showModal();
  const excluded = Number(snapshot.exclusions?.useOnlySharedLogins || 0);
  const damagedTrash = Number(snapshot.exclusions?.damagedTrashItems || 0);
  const backupNotes = [];
  if (excluded) backupNotes.push(`${excluded} use-only shared login${excluded === 1 ? ' was' : 's were'} excluded because recipient-bound access is not portable`);
  if (damagedTrash) backupNotes.push(`${damagedTrash} damaged Trash item${damagedTrash === 1 ? ' was' : 's were'} skipped; healthy vault data was still backed up`);
  if (trashFallbackUsed) backupNotes.push('Trash was automatically excluded after a legacy authentication failure so the healthy encrypted backup could complete');
  toast(`Encrypted backup created${backupNotes.length ? `. ${backupNotes.join('; ')}.` : '.'}`);
}

async function exportVault() {
  try {
    if (!featureAllowed(licenseState, 'export')) throw new Error('Export is unavailable.');
    if (currentView !== 'backup' || !$('backupExportVault')) {
      currentView = 'backup';
      await render();
      toast('Choose what the encrypted backup should contain. Login credentials are selected by default.');
      return;
    }
    const selection = backupSelectionFromUi();
    const chosen = selectedBackupComponents(selection);
    if (!chosen.length) throw new Error('Select at least one backup component.');
    await ensureSensitiveAccess(
      `Re-enter your master password before exporting: ${chosen.map((entry) => entry.label).join(', ')}. The resulting .vcvault file is encrypted and still requires its separate Backup Key.`,
      () => exportVaultNow(selection)
    );
  } catch (error) { toast(error.message, true); }
}

async function importVaultNow(payloadText, exportSecret, preDecrypted = null) {
  const payload = preDecrypted ? null : JSON.parse(payloadText);
  const decrypted = preDecrypted || await decryptPortableExport(payload, exportSecret);

  if (!isComponentBackupSnapshot(decrypted)) {
    const restored = normalizeVault(decrypted);
    if (!confirm(`This is a legacy full-vault backup. Replace the current vault with ${restored.items.length} restored items?`)) return;
    vault = restored;
    await appendActivityEvent(vault, 'backup-restored', { mode: 'legacy-full-vault', items: restored.items.length });
    await saveUnlockedVault(vault);
    render();
    toast('Legacy encrypted full-vault backup restored.');
    return;
  }

  const chosen = selectedBackupComponents(decrypted.selection || {});
  if (!chosen.length) throw new Error('This component backup contains no restorable components.');
  const label = chosen.map((entry) => entry.label).join(', ');
  if (!confirm(`Restore these encrypted backup components?\n\n${label}\n\nOnly the selected component categories will be replaced. Unselected current-vault data stays unchanged.`)) return;

  const state = await loadUnlockedVault({ touch: false });
  if (state.state !== 'unlocked' || !state.vaultKey) throw new Error('VaultCove is locked.');
  const result = await restoreBackupSnapshot(vault, decrypted, { vaultKey: state.vaultKey });
  vault = result.vault;
  await appendActivityEvent(vault, 'backup-restored', { mode: 'component', components: chosen.map((entry) => entry.key).join(',') });
  await saveUnlockedVault(vault);
  if (result.recoveryMaterial?.deviceRecoveryToken) {
    await setDeviceRecoveryToken(result.recoveryMaterial.deviceRecoveryToken);
  }
  if (result.settings || result.recoveryMaterial?.vaultTotp) {
    await setSettings({
      ...(result.settings || {}),
      ...(result.recoveryMaterial?.vaultTotp ? { vaultTotpEnabled:Boolean(result.recoveryMaterial.vaultTotp.enabled) } : {})
    });
    settingsState = await getSettings();
    applyCurrentTheme();
    applyCurrentDensity();
  }
  render();
  const notes = [];
  if (result.skippedTotp) notes.push(`${result.skippedTotp} TOTP code${result.skippedTotp === 1 ? '' : 's'} could not find a matching login`);
  if (result.expiredTrashSkipped) notes.push(`${result.expiredTrashSkipped} expired Trash item${result.expiredTrashSkipped === 1 ? '' : 's'} stayed deleted`);
  if (result.excludedUseOnly) notes.push(`${result.excludedUseOnly} use-only shared login${result.excludedUseOnly === 1 ? ' was' : 's were'} intentionally absent from the portable backup`);
  if (result.excludedDamagedTrash) notes.push(`${result.excludedDamagedTrash} damaged Trash item${result.excludedDamagedTrash === 1 ? ' was' : 's were'} intentionally absent from the portable backup`);
  toast(`Encrypted component backup restored${notes.length ? `. ${notes.join('; ')}.` : '.'}`);
}

function backupPreviewMarkup(summary) {
  const counts = summary?.counts || {};
  const countRows = [
    ['Logins', counts.logins || 0],
    ['Cards', counts.cards || 0],
    ['Bank accounts', counts.banks || 0],
    ['Identities', counts.identities || 0],
    ['Secure notes', counts.notes || 0],
    ['TOTP codes', counts.totpCodes || 0],
    ['Trash', counts.trash || 0],
    ['Folders', summary?.folders || 0]
  ].filter(([, count]) => Number(count) > 0)
    .map(([label, count]) => `<div class="migrationRow"><strong>${escapeHtml(label)}</strong><span>${Number(count)}</span></div>`).join('');
  const components = (summary?.selected || []).map((label) => `<span class="pill">${escapeHtml(label)}</span>`).join('');
  const created = summary?.createdAt ? new Date(summary.createdAt).toLocaleString() : 'Unknown';
  return `<div class="backupPreviewHeader"><strong>${summary?.legacy ? 'Legacy full-vault backup' : `Backup v${escapeHtml(summary?.version)}`}</strong><span>Created ${escapeHtml(created)}</span></div>
    <div class="backupPreviewSection"><b>Will restore</b><div class="backupPreviewPills">${components || '<span class="settingHint">No recognized components</span>'}</div></div>
    <div class="backupPreviewRows">${countRows || '<p>No item records were found in this backup.</p>'}</div>
    ${summary?.settings ? '<div class="backupPreviewNote">Portable settings are included.</div>' : ''}
    ${summary?.recoveryMaterial ? '<div class="backupPreviewNote goodNote">Encrypted sharing identity, authenticator configuration, and device-recovery material are included in this .vcvault.</div>' : '<div class="backupPreviewNote">This older backup predates unified recovery material. Vault records can still be restored.</div>'}
    ${summary?.excludedUseOnly ? `<div class="migrationWarning">${Number(summary.excludedUseOnly)} recipient-bound use-only shared login(s) were intentionally excluded when this backup was created.</div>` : ''}
    ${summary?.excludedDamagedTrash ? `<div class="migrationWarning">${Number(summary.excludedDamagedTrash)} damaged Trash item(s) could not be authenticated and were intentionally skipped so healthy vault data could still be backed up.</div>` : ''}`;
}

async function verifyDisasterRecoveryEmail(backupId, recoveryEmail) {
  const granted = await ensureLicenseServicePermission();
  if (!granted) throw new Error('VaultCove needs Apps Script network permission to send the Disaster Recovery verification code.');
  const start = await beginDisasterRecoveryRestore({ backupId, email:recoveryEmail });
  const challengeId = String(start.challengeId || '');
  if (!challengeId) throw new Error('Disaster Recovery service did not return a verification challenge.');
  const verified = await requestLicenseOtp({
    title:'Verify Disaster Recovery email',
    subtitle:`Enter the 6-digit code sent to ${start.emailMasked || 'the recovery email'}.`,
    onVerify:(code) => completeDisasterRecoveryRestore({ backupId, challengeId, code })
  });
  if (!verified?.verified) throw new Error('Disaster Recovery email verification was not confirmed.');
  return true;
}

async function previewVaultRestore() {
  try {
    const file = $('restoreFile')?.files?.[0];
    const recoveryCredential = String($('restoreSecret')?.value || '').trim();
    if (!file) throw new Error('Choose a .vcvault file first.');
    if (!recoveryCredential) throw new Error('Enter the matching Backup Key or Disaster Recovery Master Password.');
    if (file.size > 100 * 1024 * 1024) throw new Error('Encrypted backup exceeds the 100 MB restore safety limit.');
    const payloadText = await file.text();
    await ensureSensitiveAccess('Re-enter your current Master Password before previewing encrypted backup contents.', async () => {
      const payload = JSON.parse(payloadText);
      if (isDisasterRecoveryExport(payload)) {
        const recovery = await decryptDisasterRecoveryExport(payload, recoveryCredential);
        await verifyDisasterRecoveryEmail(recovery.backupId, recovery.recoveryEmail);
        const summary = backupSnapshotSummary(recovery.snapshot);
        pendingBackupPreview = {
          fileName:file.name,
          fileSize:file.size,
          lastModified:file.lastModified,
          recoveryCredential,
          payloadText,
          summary,
          disasterRecovery:true,
          backupId:recovery.backupId,
          emailVerified:true,
          decrypted:recovery.snapshot
        };
        const mount = $('backupRestorePreview');
        if (mount) mount.innerHTML = `${backupPreviewMarkup(summary)}<div class="backupPreviewNote goodNote">Disaster Recovery Master Password verified locally and recovery email verified by a fresh six-digit code.</div>`;
        const button = $('restoreVaultButton');
        if (button) button.disabled = false;
        const drillButton = $('recordRecoveryDrill');
        if (drillButton) drillButton.disabled = !premiumFeatureAllowed(licenseState, 'guardian');
        toast('Disaster Recovery verified. Review the backup preview before restoring.');
        return;
      }

      const decrypted = await decryptPortableExport(payload, recoveryCredential);
      const summary = backupSnapshotSummary(decrypted);
      pendingBackupPreview = {
        fileName:file.name,
        fileSize:file.size,
        lastModified:file.lastModified,
        recoveryCredential,
        payloadText,
        summary,
        disasterRecovery:false,
        decrypted:null
      };
      const mount = $('backupRestorePreview');
      if (mount) mount.innerHTML = backupPreviewMarkup(summary);
      const button = $('restoreVaultButton');
      if (button) button.disabled = false;
      const drillButton = $('recordRecoveryDrill');
      if (drillButton) drillButton.disabled = !premiumFeatureAllowed(licenseState, 'guardian');
      toast('Backup Key verified. Review the backup preview before restoring.');
    });
  } catch (error) {
    pendingBackupPreview = null;
    const button = $('restoreVaultButton');
    if (button) button.disabled = true;
    const drillButton = $('recordRecoveryDrill');
    if (drillButton) drillButton.disabled = true;
    const mount = $('backupRestorePreview');
    if (mount) mount.textContent = error.message;
    toast(error.message, true);
  }
}

async function importVault() {
  try {
    const file = $('restoreFile')?.files?.[0];
    const recoveryCredential = String($('restoreSecret')?.value || '').trim();
    if (!file) throw new Error('Choose a .vcvault file first.');
    if (!recoveryCredential) throw new Error('Enter the matching Backup Key or Disaster Recovery Master Password.');
    if (!pendingBackupPreview || pendingBackupPreview.fileName !== file.name || pendingBackupPreview.fileSize !== file.size || pendingBackupPreview.lastModified !== file.lastModified || pendingBackupPreview.recoveryCredential !== recoveryCredential) {
      throw new Error('Preview this exact encrypted backup before restoring it.');
    }
    if (pendingBackupPreview.disasterRecovery && !pendingBackupPreview.emailVerified) {
      throw new Error('Verify the Disaster Recovery email code again before restoring.');
    }
    await guardianAuthorizeCritical('restore-backup', 'Apply verified backup restore');
    await enforceGuardianCriticalCooldown('restore-backup');
    const payloadText = pendingBackupPreview.payloadText;
    const decrypted = pendingBackupPreview.disasterRecovery ? pendingBackupPreview.decrypted : null;
    await ensureSensitiveAccess(
      'Re-enter your current Master Password before applying the verified backup preview to this vault.',
      () => importVaultNow(payloadText, recoveryCredential, decrypted)
    );
    if (pendingBackupPreview.disasterRecovery) {
      await setSettings({ disasterRecoveryEnabled:false, disasterRecoveryPending:false, disasterRecoveryDueAt:null });
      settingsState = await getSettings();
    }
    pendingBackupPreview = null;
  } catch (error) { toast(error.message, true); }
}


async function guardianAuthorizeCritical(operation, label) {
  if (!premiumFeatureAllowed(licenseState, 'guardian')) return true;
  const current = await getSettings();
  if (!current.guardianCriticalTrustedApproval) return true;
  const request = await createGuardianApproval({ operation:String(operation || 'critical-action'), itemId:'', itemLabel:String(label || 'Critical VaultCove action') });
  toast('Guardian approval requested from another same-license device.');
  const deadline = Date.parse(request.expiresAt || '') || (Date.now() + 10 * 60_000);
  while (Date.now() < deadline) {
    await new Promise((resolve) => setTimeout(resolve, 2500));
    const result = await consumeGuardianApproval(request.approvalId);
    if (result?.approved) { toast('Trusted-device approval verified.'); return true; }
  }
  throw new Error('Guardian trusted-device approval expired. Critical action was not performed.');
}

async function enforceGuardianCriticalCooldown(actionLabel) {
  if (!premiumFeatureAllowed(licenseState, 'guardian')) return true;
  const current = await getSettings();
  const minutes = Math.max(0, Math.min(60, Number(current.guardianCriticalCooldownMinutes || 0)));
  if (!minutes) return true;
  const now = Date.now();
  const until = Date.parse(String(current.guardianCooldownUntil || '')) || 0;
  const same = String(current.guardianCooldownAction || '') === String(actionLabel || '');
  if (same && until > now) {
    throw new Error(`Guardian Security Cooldown is active for this action. Try again in ${Math.ceil((until-now)/60000)} minute(s).`);
  }
  if (same && until && until <= now) {
    await setSettings({ guardianCooldownUntil:null, guardianCooldownAction:'' });
    settingsState = await getSettings();
    return true;
  }
  const cooldownUntil = new Date(now + minutes * 60_000).toISOString();
  await setSettings({ guardianCooldownUntil:cooldownUntil, guardianCooldownAction:String(actionLabel || '').slice(0,80) });
  settingsState = await getSettings();
  throw new Error(`Guardian Security Cooldown started for ${minutes} minute(s). Retry this action after ${new Date(cooldownUntil).toLocaleTimeString()}.`);
}

async function changeMaster() {
  try {
    const current = String($('currentMaster')?.value || '');
    const password = String($('newMaster')?.value || '');
    const confirmPassword = String($('newMasterConfirm')?.value || '');
    const secondFactor = String($('masterTotp')?.value || '');
    const strength = assessPassword(password);
    if (!current) throw new Error('Enter the current master password.');
    requirePasswordPolicy(password,12,'New master password');
    if (strength.score < 3) throw new Error('Use a Strong or Very strong new master password.');
    if (password !== confirmPassword) throw new Error('New master passwords do not match.');
    if (current === password) throw new Error('Choose a new master password that is different from the current one.');
    if (settingsState?.vaultTotpEnabled && !secondFactor) throw new Error('Enter the current authenticator or recovery code.');
    await guardianAuthorizeCritical('change-master-password', 'Change VaultCove Master Password');
    await enforceGuardianCriticalCooldown('change-master-password');
    if (!confirm('Change the VaultCove master password now? The vault will immediately lock and require the new password.')) return;
    await rotateMasterPasswordVerified(current, password, secondFactor);
    await markManualBackupPending();
    await clearSensitiveAccess();
    for (const id of ['currentMaster','newMaster','newMasterConfirm','masterTotp']) if ($(id)) $(id).value = '';
    vault = null;
    showGate('unlockPanel');
    els.unlockTotpLabel.classList.toggle('hidden', !settingsState?.vaultTotpEnabled);
    toast('Master password changed safely. VaultCove is locked; unlock again with the new password.');
  } catch (error) { toast(error.message, true); }
}

// 0.7.78 payment-card and input-semantics contract.
// PAN length is not universally 16 digits: payment-card PANs can vary, commonly
// from 8 through 19 digits depending on the network. VaultCove therefore formats
// by detected network without forcing every card into a 16-digit shape.
function paymentCardDigits(value) {
  return String(value || '').replace(/\D/g, '').slice(0, 19);
}

function paymentCardBrand(value) {
  const digits = paymentCardDigits(value);
  const prefix4 = Number(digits.slice(0, 4) || 0);
  const prefix6 = Number(digits.slice(0, 6) || 0);
  if (/^4/.test(digits)) return { id:'visa', label:'Visa', commonLengths:[13,16,19], groups:[4,4,4,4,3] };
  if (/^3[47]/.test(digits)) return { id:'amex', label:'American Express', commonLengths:[15], groups:[4,6,5] };
  if (/^5[1-5]/.test(digits) || (prefix4 >= 2221 && prefix4 <= 2720)) return { id:'mastercard', label:'Mastercard', commonLengths:[16], groups:[4,4,4,4] };
  if (/^6011/.test(digits) || /^65/.test(digits) || /^64[4-9]/.test(digits) || (prefix6 >= 622126 && prefix6 <= 622925)) return { id:'discover', label:'Discover', commonLengths:[16,19], groups:[4,4,4,4,3] };
  if (prefix4 >= 3528 && prefix4 <= 3589) return { id:'jcb', label:'JCB', commonLengths:[16,17,18,19], groups:[4,4,4,4,3] };
  if (/^3(?:0[0-5]|09|6|8|9)/.test(digits)) return { id:'diners', label:'Diners Club', commonLengths:[14,16,19], groups:[4,6,4,5] };
  if (/^62/.test(digits)) return { id:'unionpay', label:'UnionPay', commonLengths:[16,17,18,19], groups:[4,4,4,4,3] };
  if (/^(?:50|5[6-9]|6)/.test(digits)) return { id:'maestro', label:'Maestro', commonLengths:[12,13,14,15,16,17,18,19], groups:[4,4,4,4,3] };
  return { id:'unknown', label:'Card', commonLengths:[], groups:[4,4,4,4,3] };
}

function formatPaymentCardNumber(value) {
  const digits = paymentCardDigits(value);
  const brand = paymentCardBrand(digits);
  const groups = [];
  let offset = 0;
  for (const size of brand.groups) {
    if (offset >= digits.length) break;
    groups.push(digits.slice(offset, offset + size));
    offset += size;
  }
  if (offset < digits.length) groups.push(digits.slice(offset));
  return groups.filter(Boolean).join(' ');
}

function paymentCardLuhnValid(value) {
  const digits = paymentCardDigits(value);
  if (digits.length < 8) return false;
  let sum = 0;
  let doubleDigit = false;
  for (let index = digits.length - 1; index >= 0; index -= 1) {
    let digit = Number(digits[index]);
    if (doubleDigit) { digit *= 2; if (digit > 9) digit -= 9; }
    sum += digit;
    doubleDigit = !doubleDigit;
  }
  return sum % 10 === 0;
}

const INPUT_SEMANTICS = Object.freeze({
  fNumber: { inputMode:'numeric', autocomplete:'cc-number', maxLength:23 },
  fSecurityCode: { inputMode:'numeric', autocomplete:'cc-csc', maxLength:4, digitsOnly:true },
  fExpMonth: { inputMode:'numeric', autocomplete:'cc-exp-month', maxLength:2, digitsOnly:true },
  fExpYear: { inputMode:'numeric', autocomplete:'cc-exp-year', maxLength:4, digitsOnly:true },
  fRouting: { inputMode:'numeric', autocomplete:'off', maxLength:18, digitsOnly:true },
  fPin: { inputMode:'numeric', autocomplete:'off', maxLength:12, digitsOnly:true },
  fPhone: { inputMode:'tel', autocomplete:'tel', maxLength:40 },
  fEmail: { inputMode:'email', autocomplete:'email', maxLength:254 },
  fPostal: { inputMode:'text', autocomplete:'postal-code', maxLength:24 },
  fSwift: { inputMode:'text', autocomplete:'off', maxLength:11, upperAlphaNumeric:true },
  fIban: { inputMode:'text', autocomplete:'off', maxLength:42, upperAlphaNumericSpaces:true },
  fGovernmentId: { inputMode:'text', autocomplete:'off', maxLength:80 }
});

function applyInputSemantics(root = document) {
  // Start with semantic keyboard hints that are safe for every field of the
  // corresponding HTML type. More restrictive filtering is applied only to
  // explicit IDs whose data contract is genuinely numeric/alphanumeric.
  for (const input of root.querySelectorAll?.('input') || []) {
    if (input.type === 'email') input.inputMode = 'email';
    else if (input.type === 'url') input.inputMode = 'url';
    else if (input.type === 'tel') input.inputMode = 'tel';
    else if (input.type === 'number') input.inputMode = 'decimal';
  }
  for (const [id, rule] of Object.entries(INPUT_SEMANTICS)) {
    const input = root.querySelector?.(`#${id}`) || $(id);
    if (!input || input.dataset.vcInputSemantics === '1') continue;
    input.dataset.vcInputSemantics = '1';
    if (rule.inputMode) input.inputMode = rule.inputMode;
    if (rule.autocomplete) input.autocomplete = rule.autocomplete;
    if (rule.maxLength) input.maxLength = rule.maxLength;
    if (rule.digitsOnly) input.addEventListener('input', () => { input.value = String(input.value || '').replace(/\D/g, '').slice(0, rule.maxLength || 64); });
    if (rule.upperAlphaNumeric) input.addEventListener('input', () => { input.value = String(input.value || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, rule.maxLength || 64); });
    if (rule.upperAlphaNumericSpaces) input.addEventListener('input', () => { input.value = String(input.value || '').toUpperCase().replace(/[^A-Z0-9 ]/g, '').replace(/\s+/g, ' ').slice(0, rule.maxLength || 64); });
  }
}

function cardBrandBadgeMarkup(brand = paymentCardBrand('')) {
  const safeId = ['visa','mastercard','amex','discover','jcb','diners','unionpay','maestro'].includes(brand.id) ? brand.id : 'unknown';
  const logoText = ({ visa:'VISA', mastercard:'MC', amex:'AMEX', discover:'DISCOVER', jcb:'JCB', diners:'DINERS', unionpay:'UP', maestro:'MAESTRO' })[safeId] || 'CARD';
  return `<span id="cardBrandLogo" class="cardBrandLogo brand-${safeId}" aria-label="${escapeAttr(brand.label)}">${escapeHtml(logoText)}</span><span id="cardBrandLabel">${escapeHtml(brand.label)}</span>`;
}

function compactCardBrandBadgeMarkup(brand = paymentCardBrand('')) {
  const safeId = ['visa','mastercard','amex','discover','jcb','diners','unionpay','maestro'].includes(brand.id) ? brand.id : 'unknown';
  const logoText = ({ visa:'VISA', mastercard:'MC', amex:'AMEX', discover:'DISCOVER', jcb:'JCB', diners:'DINERS', unionpay:'UP', maestro:'MAESTRO' })[safeId] || 'CARD';
  return `<span class="cardBrandLogo compactCardBrandLogo brand-${safeId}" aria-label="${escapeAttr(brand.label)}">${escapeHtml(logoText)}</span>`;
}

function updatePaymentCardUi() {
  const number = $('fNumber');
  if (!number) return;
  const digits = paymentCardDigits(number.value);
  const brand = paymentCardBrand(digits);
  const formatted = formatPaymentCardNumber(digits);
  if (number.value !== formatted) number.value = formatted;
  const brandInput = $('fBrand');
  if (brandInput) brandInput.value = brand.label === 'Card' ? '' : brand.label;
  const logo = $('cardBrandLogo');
  const label = $('cardBrandLabel');
  if (logo) {
    logo.className = `cardBrandLogo brand-${brand.id}`;
    logo.textContent = ({ visa:'VISA', mastercard:'MC', amex:'AMEX', discover:'DISCOVER', jcb:'JCB', diners:'DINERS', unionpay:'UP', maestro:'MAESTRO' })[brand.id] || 'CARD';
    logo.setAttribute('aria-label', brand.label);
  }
  if (label) label.textContent = brand.label;
  const status = $('cardNumberStatus');
  if (!status) return;
  if (!digits) { status.textContent = 'Card numbers are not always 16 digits. VaultCove accepts 8-19 digits and formats the number as you type.'; status.dataset.state = 'neutral'; return; }
  const commonLength = !brand.commonLengths.length || brand.commonLengths.includes(digits.length);
  const luhn = paymentCardLuhnValid(digits);
  if (digits.length < 8) { status.textContent = `${brand.label}: ${digits.length} digit${digits.length===1?'':'s'} entered - keep typing.`; status.dataset.state='neutral'; return; }
  if (!commonLength && brand.commonLengths.length) { status.textContent = `${brand.label}: this length is uncommon for the detected network. Check the number before saving.`; status.dataset.state='warn'; return; }
  status.textContent = luhn ? `${brand.label} detected - number checksum looks valid.` : `${brand.label} detected - check the number; the checksum does not validate yet.`;
  status.dataset.state = luhn ? 'good' : 'warn';
}

function validatePaymentCardFields() {
  const digits = paymentCardDigits($('fNumber')?.value);
  if (digits && (digits.length < 8 || digits.length > 19)) throw new Error('Card number must contain between 8 and 19 digits. Card numbers are not universally 16 digits.');
  const monthText = String($('fExpMonth')?.value || '').trim();
  if (monthText) { const month = Number(monthText); if (!Number.isInteger(month) || month < 1 || month > 12) throw new Error('Expiry month must be from 1 to 12.'); }
  const yearText = String($('fExpYear')?.value || '').trim();
  if (yearText && !/^\d{2}(?:\d{2})?$/.test(yearText)) throw new Error('Expiry year must use 2 or 4 digits.');
  const securityCode = String($('fSecurityCode')?.value || '').replace(/\D/g, '');
  if (securityCode && !/^\d{3,4}$/.test(securityCode)) throw new Error('Security code must contain 3 or 4 digits.');
  return { digits, brand: paymentCardBrand(digits) };
}


function loginCustomFieldsMarkup(customFields = []) {
  const fields = (Array.isArray(customFields) ? customFields : []).slice(0, 20);
  const rows = fields.map((entry, index) => `<div class="customFieldRow" data-custom-field-row>
    <input data-custom-field-label maxlength="80" value="${escapeAttr(String(entry?.label || ''))}" placeholder="Field name">
    <div class="customFieldValueWrap"><input data-custom-field-value type="${entry?.hidden ? 'password' : 'text'}" maxlength="500" value="${escapeAttr(String(entry?.value || ''))}" placeholder="Value"><button type="button" class="miniAction outline" data-toggle-custom-hidden>${entry?.hidden ? 'Show' : 'Hide'}</button></div>
    <button type="button" class="miniAction danger" data-remove-custom-field>Remove</button>
  </div>`).join('');
  return `<section class="loginAdvancedEditor"><div class="loginAdvancedHead"><strong>Custom fields</strong><span>Stored encrypted with this login</span></div><div id="customFieldsEditor" class="customFieldsEditor">${rows || '<div class="customFieldEmpty" data-custom-field-empty>No custom fields yet.</div>'}</div><button id="addCustomField" type="button" class="outline miniAction">Add custom field</button><p class="fieldHint">Use custom fields for member IDs, account numbers, PIN labels, recovery information, or unusual website fields. Hidden values stay masked until you reveal them.</p></section>`;
}


function guardianLoginEditorMarkup(item = {}) {
  if (!premiumFeatureAllowed(licenseState, 'guardian')) {
    return `<section class="guardianLoginPolicy premiumLockedPanel"><span class="premiumTag">Premium</span><strong>VaultCove Guardian</strong><p>Fortress Mode, Security Zones, Blind Credential Mode, domain pinning, Split-Trust TOTP, breach-date analysis, quarantine, trusted-device approval and security cooldown are Premium Lifetime protections.</p></section>`;
  }
  const policy = guardianPolicy(item);
  const zoneOptions = Object.values(SECURITY_ZONES).map((zone) => `<option value="${escapeAttr(zone.id)}" ${policy.zone===zone.id?'selected':''}>${escapeHtml(zone.label)}</option>`).join('');
  const modeOptions = Object.values(GUARDIAN_MODES).map((mode) => `<option value="${escapeAttr(mode.id)}" ${policy.mode===mode.id?'selected':''}>${escapeHtml(mode.label)}</option>`).join('');
  const totpOptions = [
    ['local','Available on this device'],
    ['approval','Require trusted-device approval'],
    ['disabled','Unavailable on this device']
  ].map(([value,label])=>`<option value="${value}" ${policy.splitTotp===value?'selected':''}>${label}</option>`).join('');
  const passkeyOptions = [
    ['unknown','Unknown / not reviewed'],['available','Passkey available'],['migrated','Passkey active'],['unavailable','Passkey unavailable']
  ].map(([value,label])=>`<option value="${value}" ${policy.passkeyState===value?'selected':''}>${label}</option>`).join('');
  const breachDate = policy.breachAt ? new Date(policy.breachAt).toISOString().slice(0,10) : '';
  return `<section class="guardianLoginPolicy">
    <div class="guardianPolicyHead"><div><strong>VaultCove Guardian</strong><small>Advanced policy for this login</small></div><span class="premiumTag">Premium</span></div>
    <div class="fieldGrid">
      <label>Security Zone<select id="gZone">${zoneOptions}</select></label>
      <label>Protection Level<select id="gMode">${modeOptions}</select></label>
      <label>Split-Trust TOTP<select id="gSplitTotp">${totpOptions}</select></label>
      <label>Passkey status<select id="gPasskeyState">${passkeyOptions}</select></label>
      <label>Reported breach date<input id="gBreachAt" type="date" value="${escapeAttr(breachDate)}"></label>
      <label>Security cooldown<select id="gCooldown"><option value="0" ${policy.cooldownMinutes===0?'selected':''}>Off</option><option value="5" ${policy.cooldownMinutes===5?'selected':''}>5 minutes</option><option value="10" ${policy.cooldownMinutes===10?'selected':''}>10 minutes</option><option value="30" ${policy.cooldownMinutes===30?'selected':''}>30 minutes</option></select></label>
    </div>
    <label class="check"><input id="gExactDomain" type="checkbox" ${policy.exactDomainPinning?'checked':''}> Pin this credential to its exact saved domains</label>
    <label class="check"><input id="gBlind" type="checkbox" ${policy.blindCredential?'checked':''}> Blind Credential Mode - allow Secure Login but block casual reveal/copy</label>
    <label class="check"><input id="gTrustedApproval" type="checkbox" ${policy.trustedDeviceApproval?'checked':''}> Require another same-license trusted device for Guardian-protected actions</label>
    <label class="check"><input id="gQuarantine" type="checkbox" ${policy.quarantine?'checked':''}> Quarantine this credential until I review and disable quarantine</label>
    <p class="fieldHint">Financial and Recovery zones default to Fortress protection. Device approval never sends passwords, vault keys, TOTP secrets, or vault contents to Apps Script.</p>
  </section>`;
}

function fieldsForType(type, item = {}) {
  const field = (id, label, typeAttr = 'text', value = '', attrs = '') => `<label>${label}<input id="${id}" type="${typeAttr}" value="${escapeAttr(value)}" ${attrs}></label>`;
  const protectedField = (id, label, typeAttr = 'password', value = '', { allowReveal = true, attrs = '' } = {}) => `<label class="protectedField">${label}<div class="protectedInput"><input id="${id}" type="${typeAttr}" value="${escapeAttr(value)}" ${attrs}>${allowReveal && typeAttr === 'password' ? `<button type="button" class="fieldAction" data-reveal-field="${id}">Reveal</button>` : ''}<button type="button" class="fieldAction" data-copy-field="${id}">Copy</button></div></label>`;
  if (type === 'login') return `<section class="loginNicknameEditor"><div class="loginNicknameEditorHead"><strong>Login name / nickname (optional)</strong><span>Free Forever + Premium</span></div>${field('fNickname','Nickname (optional)','text',item.nickname || '', 'maxlength="80" placeholder="Personal, Work, Admin, Router..."')}<p class="fieldHint">Use this to distinguish multiple credentials for the same website or IP address. Example: Personal, Work, Admin, Router.</p></section><div class="fieldGrid">${protectedField('fUsername','Username / email','text',item.username,{allowReveal:false})}${protectedField('fPassword','Password','password',item.password)}</div>${field('fUrl','Primary website URL','url',(item.urls||[])[0]||'')}<label>Additional website URLs (optional)<textarea id="fAdditionalUrls" rows="3" placeholder="https://account.example.com&#10;https://login.example.com">${escapeHtml((item.urls||[]).slice(1).join('\n'))}</textarea></label><p class="fieldHint">One login can belong to several exact websites. Enter one HTTP/HTTPS URL per line. VaultCove still applies strict host validation before Secure Login.</p><div id="loginUrlSecurityWarning" class="loginUrlSecurityWarning hidden"></div><label>Additional trusted hosts (advanced)<input id="fTrustedHosts" value="${escapeAttr((item.trustedHosts||[]).join(', '))}" placeholder="login.example.com, account.example.com"></label><p class="fieldHint">Trusted hosts are advanced host aliases. Prefer Additional website URLs above when you know the exact sign-in pages.</p><div class="fieldGrid">${TOTP_MAINTENANCE_MODE ? '<div class="totpMaintenanceInline"><span class="maintenanceTag">Under maintenance</span><strong>TOTP Codes</strong><p>Temporarily unavailable in this release. Existing encrypted TOTP secrets are preserved and will not be deleted or changed.</p></div>' : (premiumFeatureAllowed(licenseState, 'totp') ? protectedField('fTotp','TOTP secret (Base32)','password',item.totpSecret) : '<div class="premiumLockedPanel"><span class="premiumTag">Premium</span><strong>TOTP Codes</strong><p>Website TOTP secrets and locally generated codes require Premium Lifetime.</p></div>')}<label>Password generator<button id="generatePasswordBtn" type="button" class="outline">Generate 20-character password</button></label></div>${loginCustomFieldsMarkup(item.customFields)}${guardianLoginEditorMarkup(item)}<label class="check autoLoginCheck"><input id="fReauthFill" type="checkbox" ${item.requireReauthBeforeFill ? 'checked' : ''}> Require master password before Secure Login for this credential</label><label class="check autoLoginCheck"><input id="fAutoLogin" type="checkbox" ${item.autoLogin ? 'checked' : ''} ${item.requireReauthBeforeFill ? 'disabled' : ''}> Auto-login when this item is opted in and the current HTTPS site has persistent VaultCove access</label><p class="fieldHint">Protected credentials cannot auto-login. HTTP credentials are never auto-login eligible and always require an explicit warning confirmation before use. Imported logins start with Auto-login off.</p>`;
  if (type === 'card') {
    const cardBrand = paymentCardBrand(item.number || '');
    return `<div class="cardDetectionPanel"><div class="cardBrandPreview">${cardBrandBadgeMarkup(cardBrand)}</div><div><strong>Automatic card-network detection</strong><span id="cardNumberStatus">Card numbers are not always 16 digits. VaultCove accepts 8-19 digits and formats the number as you type.</span></div></div><div class="fieldGrid">${field('fCardholder','Cardholder','text',item.cardholder,'autocomplete="cc-name" maxlength="100"')}${field('fBrand','Detected card type','text',item.brand || (cardBrand.label === 'Card' ? '' : cardBrand.label),'readonly aria-readonly="true"')}${protectedField('fNumber','Card number','text',formatPaymentCardNumber(item.number),{allowReveal:false,attrs:'inputmode="numeric" autocomplete="cc-number" maxlength="23" placeholder="1234 5678 9012 3456"'})}${protectedField('fSecurityCode','Security code','password',item.securityCode,{attrs:'inputmode="numeric" autocomplete="cc-csc" maxlength="4" placeholder="3 or 4 digits"'})}${field('fExpMonth','Expiry month','text',item.expMonth,'inputmode="numeric" autocomplete="cc-exp-month" maxlength="2" placeholder="MM"')}${field('fExpYear','Expiry year','text',item.expYear,'inputmode="numeric" autocomplete="cc-exp-year" maxlength="4" placeholder="YY or YYYY"')}</div><label>Billing address<textarea id="fBillingAddress" rows="3" autocomplete="billing street-address">${escapeHtml(item.billingAddress)}</textarea></label>`;
  }
  if (type === 'bank') return `<div class="fieldGrid">${field('fBankName','Bank name','text',item.bankName)}${field('fAccountHolder','Account holder','text',item.accountHolder)}${field('fAccountType','Account type','text',item.accountType)}${protectedField('fAccountNumber','Account number','password',item.accountNumber)}${protectedField('fRouting','Routing number','password',item.routingNumber)}${field('fSwift','SWIFT / BIC','text',item.swiftBic)}${protectedField('fIban','IBAN','password',item.iban)}${field('fBranch','Branch','text',item.branch)}${protectedField('fPin','PIN (optional)','password',item.pin)}</div>`;
  if (type === 'identity') return `<div class="fieldGrid">${field('fFirstName','First name','text',item.firstName)}${field('fMiddleName','Middle name','text',item.middleName)}${field('fLastName','Last name','text',item.lastName)}${field('fCompany','Company','text',item.company)}${protectedField('fEmail','Email','email',item.email,{allowReveal:false})}${protectedField('fPhone','Phone','tel',item.phone,{allowReveal:false})}${field('fAddress1','Address line 1','text',item.address1)}${field('fAddress2','Address line 2','text',item.address2)}${field('fCity','City','text',item.city)}${field('fState','State / Province','text',item.state)}${field('fPostal','Postal code','text',item.postalCode)}${field('fCountry','Country','text',item.country)}${protectedField('fGovernmentId','Government ID (optional)','password',item.governmentId)}</div>`;
  return `<label>Secure text<textarea id="fText" rows="10">${escapeHtml(item.text)}</textarea></label>`;
}

async function createFolderFromItemDialog() {
  const nameInput = $('createItemFolderName');
  const name = String(nameInput?.value || '').trim();
  if (!name) throw new Error('Enter a folder name.');

  // Always mutate the freshest decrypted vault. This prevents an item dialog
  // opened before another VaultCove surface changed folders from overwriting
  // newer state when the inline folder is created.
  const fresh = await loadUnlockedVault({ touch: false });
  if (fresh.state !== 'unlocked') throw new Error('VaultCove is locked. Unlock it and try again.');
  const created = createFolder(fresh.vault, name);
  await saveUnlockedVault(fresh.vault);

  // Do not report success until the newly-created folder survives the encrypted
  // round trip. The same vaultEnvelope change also refreshes every open surface.
  const verified = await loadUnlockedVault({ touch: false });
  if (verified.state !== 'unlocked') throw new Error('VaultCove locked before the new folder could be verified.');
  const persisted = (verified.vault.folders || []).find((folder) => folder.id === created.id);
  if (!persisted) throw new Error('VaultCove could not verify the new folder in encrypted storage.');

  vault = verified.vault;
  if (els.itemFolder) {
    els.itemFolder.innerHTML = folderOptionsMarkup(persisted.id);
    els.itemFolder.value = persisted.id;
  }
  if (nameInput) nameInput.value = '';
  $('createItemFolderPanel')?.classList.add('hidden');
  toast(`Folder "${persisted.name}" created and selected.`);
  return persisted;
}

function wireInlineItemFolderCreator(type) {
  const allowed = ['card','bank','identity','note'].includes(type);
  const show = $('showCreateItemFolder');
  const panel = $('createItemFolderPanel');
  const name = $('createItemFolderName');
  const confirmCreate = $('confirmCreateItemFolder');
  const cancelCreate = $('cancelCreateItemFolder');
  if (!show || !panel) return;

  show.classList.toggle('hidden', !allowed);
  panel.classList.add('hidden');
  if (name) name.value = '';

  show.onclick = () => {
    if (!allowed) return;
    panel.classList.remove('hidden');
    setTimeout(() => name?.focus(), 0);
  };
  cancelCreate.onclick = () => {
    panel.classList.add('hidden');
    if (name) name.value = '';
  };
  confirmCreate.onclick = async () => {
    try {
      confirmCreate.disabled = true;
      await createFolderFromItemDialog();
    } catch (error) {
      toast(error.message, true);
    } finally {
      confirmCreate.disabled = false;
    }
  };
  if (name) name.onkeydown = (event) => {
    if (event.key !== 'Enter' || event.isComposing) return;
    event.preventDefault();
    confirmCreate.click();
  };
}

async function openLoginNicknameEditor(item) {
  if (!item || item.type !== 'login' || isUseOnlySharedLogin(item)) return;
  await openItemDialog(item);
  requestAnimationFrame(() => {
    const input = $('fNickname');
    if (!input || !els.itemDialog?.open) return;
    input.focus();
    input.select();
    input.scrollIntoView({ block: 'center', behavior: 'smooth' });
  });
}

function openItemDialogNow(item = null, type = 'login', prefill = {}) {
  const source = item || createItem(type, prefill);
  els.itemId.value = item?.id || '';
  els.itemType.value = source.type;
  els.itemType.disabled = Boolean(item);
  const cardOption = els.itemType.querySelector('option[value="card"]');
  const noteOption = els.itemType.querySelector('option[value="note"]');
  if (cardOption) cardOption.disabled = !premiumFeatureAllowed(licenseState, 'cards') && source.type !== 'card';
  if (noteOption) noteOption.disabled = !premiumFeatureAllowed(licenseState, 'notes') && source.type !== 'note';
  if (els.itemFavorite) { els.itemFavorite.disabled = !premiumFeatureAllowed(licenseState, 'favorites'); els.itemFavorite.closest('label')?.classList.toggle('premiumBackupLocked', els.itemFavorite.disabled); }
  const itemNameLabel = $('itemNameLabel');
  if (itemNameLabel) itemNameLabel.textContent = source.type === 'login' ? 'Website / login title' : 'Name';
  els.itemName.placeholder = source.type === 'login' ? 'example.com, Router, Microsoft 365...' : '';
  els.itemName.value = source.name || '';
  if (els.itemFolder) {
    els.itemFolder.innerHTML = folderOptionsMarkup(source.folderId || null);
    els.itemFolder.value = source.folderId || '';
  }
  wireInlineItemFolderCreator(source.type);
  els.itemNotes.value = source.notes || '';
  els.itemTags.value = (source.tags || []).join(', ');
  els.itemFavorite.checked = Boolean(source.favorite);
  els.dialogTitle.textContent = item ? `Edit ${source.type === 'login' ? loginDisplayLabel(source) : source.name}` : 'New encrypted item';
  els.deleteItem.classList.toggle('hidden', !item);
  els.dynamicFields.innerHTML = fieldsForType(source.type, source);
  wireDynamicFields(source.type);
  els.itemDialog.showModal();
}

function openItemDialog(item = null, type = 'login', prefill = {}) {
  if (!featureAllowed(licenseState, 'edit')) { toast('Editing is unavailable in this build.', true); return; }
  const gate = item ? premiumGateForItem(item) : ({card:'cards',note:'notes'})[type] || '';
  if (gate && !premiumFeatureAllowed(licenseState, gate)) { toast(`${premiumFeatureTitle(gate)} requires Premium Lifetime.`, true); return; }
  if (item && isUseOnlySharedLogin(item)) { toast('Shared Login Access is use-only. It cannot be revealed, copied, edited, or reshared.', true); return; }
  if (!item) {
    if (['card','bank','identity','note'].includes(type)) return ensureProtectedCategoryAccess(`Enter your master password before adding ${viewNames[type] || 'a protected record'}. Authorization lasts five minutes.`, () => openItemDialogNow(null, type, prefill)).catch((error) => toast(error.message, true));
    return openItemDialogNow(null, type, prefill);
  }
  const protectedType = ['card','bank','identity','note'].includes(item.type);
  const reason = protectedType
    ? `Enter your master password before viewing or editing this encrypted ${viewNames[item.type] || 'protected'} record. Authorization lasts five minutes.`
    : 'Re-enter your master password before viewing or editing decrypted vault fields.';
  const gateAccess = protectedType ? ensureProtectedCategoryAccess : ensureSensitiveAccess;
  return gateAccess(reason, async () => {
    const activityType = protectedViewActivityType(item);
    if (activityType) await appendItemActivity(activityType, item);
    openItemDialogNow(item, type, prefill);
  }).catch((error) => toast(error.message, true));
}


async function guardianAuthorizeOperation(item, operation) {
  if (!item || item.type !== 'login' || !premiumFeatureAllowed(licenseState, 'guardian')) return true;
  const quarantine = guardianQuarantineAssessment(item);
  if (quarantine.quarantine) throw new Error(`Guardian quarantine blocked this action: ${quarantine.reason}`);
  const policy = guardianPolicy(item);
  if (policy.blindCredential && ['reveal','copy'].includes(operation) && !policy.trustedDeviceApproval) {
    throw new Error('Blind Credential Mode blocks password reveal/copy. Use Secure Login, or enable Trusted Device Approval for exceptional reveal/copy access.');
  }
  if (!guardianRequiresApproval(item, operation)) return true;
  const request = await createGuardianApproval({ operation, itemId:item.id, itemLabel:guardianAllowedHosts(item)[0] || 'Protected login' });
  toast(`Guardian approval requested from another same-license device. Request expires in 10 minutes.`);
  const deadline = Date.parse(request.expiresAt || '') || (Date.now() + 10 * 60_000);
  while (Date.now() < deadline) {
    await new Promise((resolve) => setTimeout(resolve, 2500));
    const result = await consumeGuardianApproval(request.approvalId);
    if (result?.approved) {
      toast('Trusted-device approval verified.');
      return true;
    }
  }
  throw new Error('Guardian trusted-device approval expired. Try again when another same-license device is available.');
}

function wireDynamicFields(type) {
  applyInputSemantics(els.dynamicFields || document);
  if (type === 'card') {
    const number = $('fNumber');
    const securityCode = $('fSecurityCode');
    number?.addEventListener('input', updatePaymentCardUi);
    number?.addEventListener('blur', updatePaymentCardUi);
    securityCode?.addEventListener('input', () => { securityCode.value = String(securityCode.value || '').replace(/\D/g, '').slice(0, 4); });
    updatePaymentCardUi();
  }
  if (type === 'login') {
    const urlInput = $('fUrl');
    const warning = $('loginUrlSecurityWarning');
    const auto = $('fAutoLogin');
    const refreshHttpWarning = () => {
      const values = [String(urlInput?.value || '').trim(), ...String($('fAdditionalUrls')?.value || '').split(/[\n,]+/).map((value) => value.trim()).filter(Boolean)];
      const insecure = values.some((value) => /^http:\/\//i.test(value));
      if (warning) {
        warning.classList.toggle('hidden', !insecure);
        warning.textContent = insecure ? 'Not secure: one or more saved websites use HTTP instead of HTTPS. VaultCove will keep them, but Auto-login is disabled and every HTTP use requires an explicit warning confirmation.' : '';
      }
      if (auto && insecure) { auto.checked = false; auto.disabled = true; }
      else if (auto && !$('fReauthFill')?.checked) auto.disabled = false;
    };
    urlInput?.addEventListener('input', refreshHttpWarning);
    urlInput?.addEventListener('change', refreshHttpWarning);
    $('fAdditionalUrls')?.addEventListener('input', refreshHttpWarning);
    $('fAdditionalUrls')?.addEventListener('change', refreshHttpWarning);
    refreshHttpWarning();

    const editor = $('customFieldsEditor');
    const emptyCustomFieldState = () => {
      if (!editor) return;
      const hasRows = Boolean(editor.querySelector('[data-custom-field-row]'));
      editor.querySelector('[data-custom-field-empty]')?.remove();
      if (!hasRows) editor.insertAdjacentHTML('beforeend', '<div class="customFieldEmpty" data-custom-field-empty>No custom fields yet.</div>');
    };
    const addCustomFieldRow = () => {
      if (!editor) return;
      if (editor.querySelectorAll('[data-custom-field-row]').length >= 20) return toast('A login can contain up to 20 custom fields.', true);
      editor.querySelector('[data-custom-field-empty]')?.remove();
      editor.insertAdjacentHTML('beforeend', '<div class="customFieldRow" data-custom-field-row><input data-custom-field-label maxlength="80" placeholder="Field name"><div class="customFieldValueWrap"><input data-custom-field-value type="text" maxlength="500" placeholder="Value"><button type="button" class="miniAction outline" data-toggle-custom-hidden>Hide</button></div><button type="button" class="miniAction danger" data-remove-custom-field>Remove</button></div>');
      editor.querySelectorAll('[data-custom-field-row]')[editor.querySelectorAll('[data-custom-field-row]').length - 1]?.querySelector('[data-custom-field-label]')?.focus();
    };
    $('addCustomField')?.addEventListener('click', addCustomFieldRow);
    editor?.addEventListener('click', (event) => {
      const remove = event.target.closest?.('[data-remove-custom-field]');
      if (remove) { remove.closest('[data-custom-field-row]')?.remove(); emptyCustomFieldState(); return; }
      const toggle = event.target.closest?.('[data-toggle-custom-hidden]');
      if (toggle) {
        const input = toggle.closest('.customFieldValueWrap')?.querySelector('[data-custom-field-value]');
        if (!input) return;
        const hiding = input.type !== 'password';
        input.type = hiding ? 'password' : 'text';
        toggle.textContent = hiding ? 'Show' : 'Hide';
      }
    });
    emptyCustomFieldState();
  }

  if (type === 'login') $('generatePasswordBtn')?.addEventListener('click', () => {
    $('fPassword').value = generatePassword({ length: 20 });
    $('fPassword').type = 'text';
    setTimeout(() => { if ($('fPassword')) $('fPassword').type = 'password'; }, 10000);
  });

  if (type === 'login') $('fReauthFill')?.addEventListener('change', () => { const auto=$('fAutoLogin'); if (!auto) return; const insecure=/^http:\/\//i.test(String($('fUrl')?.value || '').trim()); auto.disabled=$('fReauthFill').checked || insecure; if (auto.disabled) auto.checked=false; });
  if (type === 'login') $('gZone')?.addEventListener('change', () => {
    const current = guardianPolicy({ type:'login', guardian:{
      zone:$('gZone')?.value,
      mode:$('gMode')?.value,
      splitTotp:$('gSplitTotp')?.value,
      exactDomainPinning:Boolean($('gExactDomain')?.checked),
      blindCredential:Boolean($('gBlind')?.checked),
      trustedDeviceApproval:Boolean($('gTrustedApproval')?.checked),
      cooldownMinutes:Number($('gCooldown')?.value || 0)
    }});
    const next = applySecurityZone(current, $('gZone')?.value);
    if ($('gMode')) $('gMode').value = next.mode;
    if ($('gSplitTotp')) $('gSplitTotp').value = next.splitTotp;
    if ($('gExactDomain')) $('gExactDomain').checked = next.exactDomainPinning;
    if ($('gBlind')) $('gBlind').checked = next.blindCredential;
    if ($('gTrustedApproval')) $('gTrustedApproval').checked = next.trustedDeviceApproval;
    if ($('gCooldown')) $('gCooldown').value = String(next.cooldownMinutes);
  });

  document.querySelectorAll('[data-reveal-field]').forEach((button) => button.addEventListener('click', async () => {
    try {
      const existing = (vault?.items || []).find((candidate) => candidate.id === els.itemId.value) || null;
      if (existing) await guardianAuthorizeOperation(existing, 'reveal');
      const action = () => {
        const input = $(button.dataset.revealField);
        if (!input) return;
        const showing = input.type === 'text';
        input.type = showing ? 'password' : 'text';
        button.textContent = showing ? 'Reveal' : 'Hide';
        if (!showing) setTimeout(() => { if (input?.isConnected) { input.type = 'password'; button.textContent = 'Reveal'; } }, Math.max(5, Number(settingsState?.revealTimeoutSeconds) || 10) * 1000);
      };
      if (existing) await ensureSensitiveAccess('Re-enter your master password before revealing this secret.', action); else action();
    } catch (error) { toast(error.message, true); }
  }));

  document.querySelectorAll('[data-copy-field]').forEach((button) => button.addEventListener('click', async () => {
    try {
      const existing = (vault?.items || []).find((candidate) => candidate.id === els.itemId.value) || null;
      if (existing) await guardianAuthorizeOperation(existing, 'copy');
      const action = async () => {
        const input = $(button.dataset.copyField);
        if (!input) return;
        await copyVaultClipboard(input.value || '', { label:'Sensitive value' });
      };
      if (existing) await ensureSensitiveAccess('Re-enter your master password before copying this secret.', action); else await action();
    } catch (error) { toast(error.message, true); }
  }));
}

function readDialogItem(existing) {
  const type = els.itemType.value;
  const typeGate = ({ card:'cards', note:'notes' })[type] || '';
  if (typeGate && !premiumFeatureAllowed(licenseState, typeGate)) throw new Error(`${premiumFeatureTitle(typeGate)} requires Premium Lifetime.`);
  const item = existing ? { ...existing } : createItem(type);
  item.name = els.itemName.value.trim() || item.name;
  item.notes = els.itemNotes.value;
  item.tags = els.itemTags.value.split(',').map((v) => v.trim()).filter(Boolean).slice(0, 20);
  if (premiumFeatureAllowed(licenseState, 'favorites')) item.favorite = els.itemFavorite.checked;
  item.folderId = els.itemFolder?.value || null;
  if (type === 'login') {
    const newPassword = $('fPassword').value;
    if (existing?.password && newPassword !== existing.password) {
      item.passwordHistory = [...(existing.passwordHistory || []), { password: existing.password, changedAt: new Date().toISOString() }].slice(-10);
      item.lastPasswordChangeAt = new Date().toISOString();
    } else if (!existing && newPassword) {
      item.lastPasswordChangeAt = new Date().toISOString();
    }
    item.nickname = String($('fNickname')?.value || '').trim().replace(/\s+/g, ' ').slice(0, 80);
    item.username = $('fUsername').value; item.password = newPassword;
    const rawUrl = String($('fUrl').value || '').trim();
    let savedUrl = '';
    if (rawUrl) {
      try {
        const parsed = new URL(/^[a-z][a-z0-9+.-]*:/i.test(rawUrl) ? rawUrl : `https://${rawUrl}`);
        if (!['http:','https:'].includes(parsed.protocol)) throw new Error('Website URL must use HTTP or HTTPS.');
        savedUrl = parsed.toString();
      } catch (error) { throw new Error(error?.message === 'Website URL must use HTTP or HTTPS.' ? error.message : 'Enter a valid HTTP or HTTPS website URL.'); }
    }
    const additionalUrls = String($('fAdditionalUrls')?.value || '').split(/[\n,]+/).map((value) => value.trim()).filter(Boolean).slice(0, 9);
    const normalizedUrls = [];
    for (const candidate of [savedUrl, ...additionalUrls].filter(Boolean)) {
      try {
        const parsed = new URL(/^[a-z][a-z0-9+.-]*:/i.test(candidate) ? candidate : `https://${candidate}`);
        if (!['http:','https:'].includes(parsed.protocol)) throw new Error('Website URL must use HTTP or HTTPS.');
        if (!normalizedUrls.includes(parsed.toString())) normalizedUrls.push(parsed.toString());
      } catch (error) { throw new Error(error?.message === 'Website URL must use HTTP or HTTPS.' ? error.message : `Enter a valid HTTP or HTTPS website URL: ${candidate}`); }
    }
    item.urls = normalizedUrls.slice(0, 10);
    item.trustedHosts = ($('fTrustedHosts')?.value || '').split(',').map((value)=>value.trim()).filter(Boolean).slice(0,20);
    item.customFields = [...document.querySelectorAll('[data-custom-field-row]')].map((row) => {
      const label = String(row.querySelector('[data-custom-field-label]')?.value || '').trim().replace(/\s+/g, ' ').slice(0,80);
      const valueInput = row.querySelector('[data-custom-field-value]');
      const value = String(valueInput?.value || '').slice(0,500);
      return label ? { label, value, hidden:valueInput?.type === 'password' } : null;
    }).filter(Boolean).slice(0,20);
    if (premiumFeatureAllowed(licenseState, 'guardian') && $('gMode')) {
      const basePolicy = guardianPolicy(item);
      item.guardian = {
        ...basePolicy,
        zone:String($('gZone')?.value || basePolicy.zone),
        mode:String($('gMode')?.value || basePolicy.mode),
        splitTotp:String($('gSplitTotp')?.value || basePolicy.splitTotp),
        passkeyState:String($('gPasskeyState')?.value || basePolicy.passkeyState),
        breachAt:$('gBreachAt')?.value ? new Date(`${$('gBreachAt').value}T00:00:00`).toISOString() : null,
        cooldownMinutes:Math.max(0, Number($('gCooldown')?.value || 0)),
        exactDomainPinning:Boolean($('gExactDomain')?.checked),
        blindCredential:Boolean($('gBlind')?.checked),
        trustedDeviceApproval:Boolean($('gTrustedApproval')?.checked),
        quarantine:Boolean($('gQuarantine')?.checked),
        quarantineReason:Boolean($('gQuarantine')?.checked) ? (basePolicy.quarantineReason || 'Credential placed in Guardian quarantine by the user.') : ''
      };
      if (['protected','strict','fortress'].includes(item.guardian.mode)) item.requireReauthBeforeFill = true;
      if (item.guardian.mode === 'fortress') item.autoLogin = false;
    }
    if (premiumFeatureAllowed(licenseState, 'totp') && $('fTotp')) item.totpSecret = String($('fTotp').value || '').trim(); item.requireReauthBeforeFill = Boolean($('fReauthFill')?.checked) || ['protected','strict','fortress'].includes(String(item.guardian?.mode || '')); item.autoLogin = (item.requireReauthBeforeFill || item.guardian?.mode === 'fortress') ? false : Boolean($('fAutoLogin')?.checked);
    if (loginHasInsecureHttpUrl(item)) item.autoLogin = false;
    if (existing?.pendingPasswordChange?.password === newPassword) item.pendingPasswordChange = null;
  }
  if (type === 'card') {
    const card = validatePaymentCardFields();
    Object.assign(item, { cardholder: $('fCardholder').value.trim(), brand: card.brand.label === 'Card' ? String($('fBrand').value || '').trim() : card.brand.label, number: card.digits, securityCode: String($('fSecurityCode').value || '').replace(/\D/g, '').slice(0,4), expMonth: String($('fExpMonth').value || '').replace(/\D/g, '').slice(0,2), expYear: String($('fExpYear').value || '').replace(/\D/g, '').slice(0,4), billingAddress: $('fBillingAddress').value });
  }
  if (type === 'bank') Object.assign(item, { bankName: $('fBankName').value, accountHolder: $('fAccountHolder').value, accountType: $('fAccountType').value, accountNumber: $('fAccountNumber').value, routingNumber: $('fRouting').value, swiftBic: $('fSwift').value, iban: $('fIban').value, branch: $('fBranch').value, pin: $('fPin').value });
  if (type === 'identity') Object.assign(item, { firstName: $('fFirstName').value, middleName: $('fMiddleName').value, lastName: $('fLastName').value, company: $('fCompany').value, email: $('fEmail').value, phone: $('fPhone').value, address1: $('fAddress1').value, address2: $('fAddress2').value, city: $('fCity').value, state: $('fState').value, postalCode: $('fPostal').value, country: $('fCountry').value, governmentId: $('fGovernmentId').value });
  if (type === 'note') item.text = $('fText').value;
  return item;
}

async function performSaveDialog() {
  const existing = vault.items.find((item) => item.id === els.itemId.value) || null;
  if (existing && isUseOnlySharedLogin(existing)) throw new Error('Shared Login Access is immutable and cannot be edited.');
  const item = readDialogItem(existing);
  upsertItem(vault, item);
  if (existing?.type === 'login' && item.type === 'login' && String(existing.password || '') !== String(item.password || '')) {
    appendGuardianReceipt(vault, createGuardianReceipt({ item, eventKind:'password-changed-manually', deviceLabel:navigator.platform || 'VaultCove device', notification:'local-vault-update' }));
  }
  const activityType = itemSaveActivityType(existing, item);
  if (activityType) await appendActivityEvent(vault, activityType, { itemId:item.id, itemType:item.type, itemName:item.name || itemTypeLabel(item) });
  const savedAt = new Date().toISOString();
  await saveUnlockedVault(vault);
  if (existing && ['card','bank','identity'].includes(item.type)) {
    queueSecurityEventNotice('protected-record-updated', { recordType:item.type, occurredAt:savedAt }).catch(() => {});
  } else if (['card','bank','identity','note'].includes(item.type)) {
    runtimeMessage({ type:'PROTECTED_RECORD_CHANGED' }).catch(() => {});
  }
  els.itemDialog.close();
  render();
  toast('Encrypted item saved.');
}

async function saveDialog(event) {
  event.preventDefault();
  try {
    const existing = vault.items.find((item) => item.id === els.itemId.value) || null;
    if (existing) {
      if (['card','bank','identity','note'].includes(existing.type)) {
        await ensureProtectedCategoryAccess('Enter your master password before saving changes to this protected record. Authorization lasts five minutes.', performSaveDialog);
      } else {
        await ensureSensitiveAccess('Re-enter your master password before saving changes to decrypted sensitive fields.', performSaveDialog);
      }
      return;
    }
    await performSaveDialog();
  } catch (error) { toast(error.message, true); }
}

async function refreshTotpCodes() {
  const logins = visibleItems().filter((item) => {
    if (item.type !== 'login' || !item.totpSecret) return false;
    if (!premiumFeatureAllowed(licenseState, 'guardian')) return true;
    const policy = guardianPolicy(item);
    if (policy.splitTotp === 'disabled') return false;
    if (policy.splitTotp === 'approval' && Date.now() >= Number(guardianTotpGrants.get(item.id) || 0)) return false;
    return true;
  });
  if (!logins.length) return;

  if (!(await hasSensitiveAccess())) {
    document.querySelectorAll('[data-totp-id]').forEach((node) => { node.textContent = '••• ••• - verify master password'; });
    return;
  }

  async function tick() {
    if (!(await hasSensitiveAccess())) {
      clearInterval(totpTimer);
      document.querySelectorAll('[data-totp-id]').forEach((node) => { node.textContent = '••• ••• - Sensitive Access expired'; });
      return;
    }
    for (const item of logins) {
      try {
        const result = await generateTotp(item.totpSecret);
        const direct = document.querySelector(`[data-totp-id="${CSS.escape(item.id)}"]`);
        if (direct) {
          direct.textContent = `${result.code.slice(0, 3)} ${result.code.slice(3)} - ${result.remaining}s`;
          continue;
        }
        const nodes = [...document.querySelectorAll('.vaultItem')];
        const node = nodes.find((candidate) => candidate.querySelector('.name')?.textContent.includes(item.name));
        if (!node) continue;
        let chip = node.querySelector('.totpChip');
        if (!chip) {
          chip = document.createElement('div');
          chip.className = 'chip totpChip';
          node.querySelector('.chips')?.append(chip) || (node.append(Object.assign(document.createElement('div'), { className: 'chips' })), node.querySelector('.chips').append(chip));
        }
        chip.textContent = `TOTP ${result.code} - ${result.remaining}s`;
      } catch {}
    }
  }
  await tick();
  totpTimer = setInterval(tick, 1000);
}

function stopIdentityPrivacyMonitor() {
  if (identityPrivacyTimer) clearInterval(identityPrivacyTimer);
  identityPrivacyTimer = null;
}

function startIdentityPrivacyMonitor() {
  stopIdentityPrivacyMonitor();
  identityPrivacyTimer = setInterval(async () => {
    if (currentView !== 'identity') {
      stopIdentityPrivacyMonitor();
      return;
    }
    if (Date.now() < protectedCategoryAccessUntil) return;
    stopIdentityPrivacyMonitor();
    selectedItemId = null;
    currentView = 'dashboard';
    els.search.value = '';
    await render();
    wireSummaryCards();
    toast('Protected-record access expired after five minutes. Re-enter your master password to continue.');
  }, 1000);
}

async function performViewSwitch(view) {
  if (currentView === 'identity' && view !== 'identity') stopIdentityPrivacyMonitor();
  currentView = view;
  els.search.value = '';
  try {
    await render();
    if (view === 'identity') startIdentityPrivacyMonitor();
    if (view === 'backup' && !$('backupExportVault')) throw new Error('Backup & Restore did not finish rendering.');
    if (view === 'dashboard') wireSummaryCards();
  } catch (error) {
    console.error(`VaultCove view failed: ${view}`, error);
    els.content.innerHTML = `${pageHead()}<section class="settingsCard"><h3>This VaultCove page could not render</h3><p>${escapeHtml(error?.message || String(error))}</p><button id="retryCurrentView" type="button">Retry page</button></section>`;
    $('retryCurrentView')?.addEventListener('click', () => switchView(view));
    toast(`${viewNames[view]} could not open: ${error?.message || error}`, true);
  }
}

async function switchView(view) {
  if (!Object.hasOwn(viewNames, view)) return;
  if (PROTECTED_CATEGORY_VIEWS.has(view) && currentView !== view) {
    const label = viewNames[view] || 'protected records';
    return ensureProtectedCategoryAccess(
      `Enter your master password before viewing ${label}. This authorization lasts five minutes.`,
      () => performViewSwitch(view)
    );
  }
  return performViewSwitch(view);
}

async function lockFromUi() {
  await runtimeMessage({ type: 'LOCK_VAULT' });
  // Centralized hard lock route. This increments uiRouteEpoch so any older async
  // setup/finish callback cannot paint the startup wizard over the lock screen.
  enterLockedUi('Vault locked. Enter your master password to unlock.');
}


function handlerUnlockContext() {
  const params = new URLSearchParams(location.search);
  if (params.get('flow') !== 'handler-unlock') return null;
  const sourceTabId = Number(params.get('sourceTab'));
  const sourceOrigin = String(params.get('sourceOrigin') || '');
  if (!Number.isInteger(sourceTabId) || !sourceOrigin.startsWith('https://')) return null;
  return { sourceTabId, sourceOrigin };
}

async function finishHandlerUnlockIfNeeded() {
  const context = handlerUnlockContext();
  if (!context) return false;
  await runtimeMessage({ type: 'COMPLETE_HANDLER_UNLOCK', sourceTabId: context.sourceTabId, sourceOrigin: context.sourceOrigin });
  return true;
}

function showBootstrapFailure(error) {
  document.documentElement.dataset.vcBootReady = '1';
  const message = String(error?.message || error || 'Unknown startup error');
  if (els.licenseBadge) els.licenseBadge.textContent = 'Startup error';
  document.documentElement.classList.add('vaultLocked');
  document.body.classList.add('lockedState');
  els.app.classList.add('hidden');
  els.gate.classList.remove('hidden');
  els.gate.innerHTML = `<div class="gateCard"><img src="../../assets/brand/vaultcove-mark.svg" alt="VaultCove" class="gateLogo"><h1>VaultCove could not start</h1><p>VaultCove stopped before showing decrypted data. Reload the extension after reviewing the error below.</p><p class="inlineError">${escapeHtml(message)}</p><div class="dialogActions"><button id="retryBootstrap" type="button">Retry startup</button></div></div>`;
  $('retryBootstrap')?.addEventListener('click', () => location.reload());
  console.error('VaultCove startup failed:', error);
}

async function bootstrap() {
  const params = new URLSearchParams(location.search);
  const requestedView = params.get('view');
  if (requestedView && Object.hasOwn(viewNames, requestedView)) currentView = requestedView === 'identity' ? 'dashboard' : requestedView;

  await reconcileFirstRunSetupState();
  [licenseState, settingsState] = await Promise.all([
    getLicenseState(),
    getSettings()
  ]);
  applyCurrentAppearance();
  applyProfileIdentity();
  try { await refreshHandlerPermissions(); } catch (error) { handlerPermissionState = []; console.warn('VaultCove handler-permission status was unavailable during startup:', error); }
  if (els.unlockTotpLabel) els.unlockTotpLabel.classList.toggle('hidden', !settingsState?.vaultTotpEnabled);
  if (els.sensitiveTotpLabel) els.sensitiveTotpLabel.classList.toggle('hidden', !settingsState?.vaultTotpEnabled);
  els.licenseBadge.textContent = licenseBadgeText(licenseState);

  const state = await loadUnlockedVault();
  if (state.state === 'setup') {
    establishedVaultInstallation = false;
    markUiSessionState('setup');
    showUnifiedFirstRunSetup({ vaultReady:false });
    return;
  }
  if (state.state === 'locked') {
    markEstablishedVault();
    enterLockedUi();
    if (state.storageFault && els.unlockError) {
      els.unlockError.textContent = 'VaultCove detected an existing completed installation but could not read the encrypted vault envelope. Reload once; VaultCove will not restart setup or overwrite the existing installation.';
      els.unlockError.classList.remove('hidden');
    }
    return;
  }
  vault = state.vault;
  markEstablishedVault();
  markUiSessionState('unlocked');
  if (organizeReceivedSharedKeys(vault)) await saveUnlockedVault(vault);
  if (!(await reconcileFirstRunSetupState())) { settingsState = await getSettings(); showUnifiedFirstRunSetup({ vaultReady:true }); return; }
  if (await finishHandlerUnlockIfNeeded()) return;
  showApp();

  applyLicenseUiRestrictions();

  await render();
  if (currentView === 'dashboard') wireSummaryCards();
  await scheduleDisasterRecoveryIfNeeded();
  await applyUrlAction();
}

async function applyUrlAction() {
  if (!vault) return;
  const params = new URLSearchParams(location.search);

  if (params.get('action') === 'new-login') {
    const url = params.get('url') || '';
    let name = 'New Login';
    try { name = new URL(url).hostname.replace(/^www\./, ''); } catch {}
    openItemDialog(null, 'login', { name, urls: url ? [url] : [] });
    history.replaceState({}, '', location.pathname);
    return;
  }

  // The popup's "Edit in dashboard" route carries the exact encrypted item id.
  // Open that item directly after unlock/render instead of forcing the user to
  // search for the same login again.
  const requestedItemId = String(params.get('item') || '').trim();
  if (requestedItemId) {
    const targetItem = (vault.items || []).find((item) => item.id === requestedItemId && !item.deletedAt) || null;
    history.replaceState({}, '', location.pathname);
    if (!targetItem) {
      toast('That VaultCove login is no longer available.', true);
      return;
    }
    if (targetItem.type !== 'login') {
      toast('The requested VaultCove item is not a login.', true);
      return;
    }
    currentView = 'login';
    selectedItemId = targetItem.id;
    await Promise.resolve(render());
    await Promise.resolve(openItemDialog(targetItem));
  }
}

chrome.storage.onChanged?.addListener((changes, areaName) => {
  if (areaName !== 'local' || !changes[SETTINGS_STORAGE_KEY]) return;
  const next = changes[SETTINGS_STORAGE_KEY].newValue;
  if (next?.disasterRecoveryEnabled && next?.disasterRecoveryPending && vault) {
    scheduleDisasterRecoveryIfNeeded().catch(() => {});
  }
});

document.querySelectorAll('nav button[data-view]').forEach(button=>button.addEventListener('click',()=>{ if (button.dataset.view === 'security') securityIssueFilter = 'all'; switchView(button.dataset.view).catch((error)=>toast(error.message,true)); }));
els.search.addEventListener('input',()=>{if(currentView==='dashboard'&&els.search.value.trim())currentView='all';Promise.resolve(render()).catch((error)=>toast(error.message,true));});
els.newItem.addEventListener('click',()=>openItemDialog(null,['login','card','bank','identity','note'].includes(currentView)?currentView:'login'));
els.itemType.addEventListener('change',()=>{els.dynamicFields.innerHTML=fieldsForType(els.itemType.value,{});wireDynamicFields(els.itemType.value);wireInlineItemFolderCreator(els.itemType.value);});
els.itemForm.addEventListener('submit',saveDialog);
els.cancelItem.addEventListener('click',()=>els.itemDialog.close());
els.dialogClose.addEventListener('click',()=>els.itemDialog.close());
els.closeVaultSettings?.addEventListener('click',()=>els.vaultSettingsDialog?.close());
els.doneVaultSettings?.addEventListener('click',()=>els.vaultSettingsDialog?.close());
els.deleteItem.addEventListener('click', async () => {
  const id = els.itemId.value;
  if (!id) return;
  try {
    const moved = await moveItemToTrashWithConfirmation(id);
    if (moved) els.itemDialog.close();
  } catch (error) { toast(error.message, true); }
});

setStartupImportIntent('fresh', { resetPending:false });

$('startupChooseVaultBackup')?.addEventListener('click', () => {
  $('startupVaultBackupFile')?.click();
});
$('startupChooseMigration')?.addEventListener('click', () => {
  $('startupMigrationFile')?.click();
});
$('startupCancelImport')?.addEventListener('click', resetStartupImportToFresh);
$('startupCancelMigration')?.addEventListener('click', resetStartupImportToFresh);

els.startupPreviewVaultBackup?.addEventListener('click', previewStartupVaultBackup);
els.startupApplyPreparedImport?.addEventListener('click', async () => {
  try {
    els.startupApplyPreparedImport.disabled = true;
    await applyPreparedImportIntoExistingVault();
  } catch (error) {
    els.startupApplyPreparedImport.disabled = false;
    toast(error.message, true);
  }
});
els.startupVaultBackupFile?.addEventListener('change', () => {
  const file = els.startupVaultBackupFile?.files?.[0];
  if (!file) { resetStartupImportToFresh(); return; }
  setStartupImportIntent('vcvault');
  updateStartupSelectedFile('startupVaultBackupName', file);
  clearPendingStartupImport('Enter this .vcvault Backup Key, then click Verify backup locally.');
  setTimeout(() => $('startupVaultBackupKey')?.focus(), 0);
});
els.startupVaultBackupKey?.addEventListener('input', () => {
  if (pendingStartupImport?.kind === 'vcvault') clearPendingStartupImport(vault ? 'The Backup Key changed. Verify the .vcvault again before merging it.' : 'The Backup Key changed. Verify the .vcvault again before creating the vault.');
});
els.startupMigrationFile?.addEventListener('change', async () => {
  const file = els.startupMigrationFile?.files?.[0];
  if (!file) { resetStartupImportToFresh(); return; }
  setStartupImportIntent('migration');
  updateStartupSelectedFile('startupMigrationName', file, 'Selected export');
  clearPendingStartupImport('Detecting the selected password-manager export locally...');
  await previewStartupMigration();
});

function submitVaultSetupOnEnter(event) {
  if (event.key !== 'Enter' || event.isComposing) return;
  event.preventDefault();
  if (!els.setupSubmit?.disabled) els.setupSubmit.click();
}

els.setupPassword?.addEventListener('keydown', submitVaultSetupOnEnter);
els.setupConfirm?.addEventListener('keydown', submitVaultSetupOnEnter);

els.setupSubmit.addEventListener('click',async()=>{
  const routeEpoch = uiRouteEpoch;
  try {
    const p=els.setupPassword.value;
    requirePasswordPolicy(p,12,'Master password');
    if(p!==els.setupConfirm.value)throw new Error('Master passwords do not match.');
    validateStartupImportReady();
    await beginFirstRunSetup();
    vault=await initializeVault(p);
    markEstablishedVault();
    markUiSessionState('unlocked');
    await setSettings({
      firstRunSecurityComplete:false,
      lockMinutes:5,
      alwaysOnHandlerEnabled:true,
      newLoginCaptureEnabled:true,
      passwordChangeDetectionEnabled:true,
      securityEmailNoticeEnabled:true,
      securityNoticeEmail:'',
      websiteIconsEnabled:true,
      websiteIconsPremiumDefaultApplied:true,
      vaultViewMode:'grid'
    });
    const startupImportResult = await applyPendingStartupImport();
    if (startupImportResult.applied) clearCompletedStartupImportSelection();
    await setSettings({ firstRunSecurityComplete:false });
    settingsState=await getSettings();
    els.setupPassword.value='';
    els.setupConfirm.value='';
    currentView='dashboard';
    if (routeEpoch !== uiRouteEpoch || !vault) {
      enterLockedUi('Vault locked. Enter your master password to continue.');
      return;
    }
    showUnifiedFirstRunSetup({ vaultReady:true, preserveInputs:true });
    if (startupImportResult.applied) toast(startupImportResult.message);
    else toast('Encrypted vault created. Finish the security settings in this window.');
  }catch(e){toast(e.message,true);}
});

els.firstRunAuthenticator?.addEventListener('click', async () => {
  try {
    beginVaultTotpSetup();
  } catch (error) { toast(error.message, true); }
});


els.firstRunProfilePhoto?.addEventListener('change', async (event) => {
  try {
    const file = event.target.files?.[0];
    if (!file) return;
    const profileImageDataUrl = await localProfileImageFromFile(file);
    if (!profileImageDataUrl) { event.target.value = ''; return; }
    await persistLocalProfilePhoto(profileImageDataUrl);
    event.target.value = '';
    toast('Profile photo saved locally on this device.');
  } catch (error) { toast(error.message, true); }
});

els.startupLicenseDeviceLabel && (els.startupLicenseDeviceLabel.value = navigator.platform || 'Chrome device');
els.startupActivateLicense?.addEventListener('click', async () => {
  const button=els.startupActivateLicense;
  try {
    const serial=String(els.startupLicenseSerial?.value||'').trim(); const email=String(els.startupLicenseEmail?.value||'').trim();
    if(!serial&&!email){toast('Enter the Premium serial and license email, or leave this optional section blank.');return;}
    button.disabled=true;button.innerHTML='<span class="licenseButtonSpinner"></span><span>Activating...</span>';
    if(!(await ensureLicenseServicePermission()))throw new Error('VaultCove license-service permission was not granted.');
    const result=await beginLicenseActivation({serial,email,deviceLabel:els.startupLicenseDeviceLabel?.value||navigator.platform});
    const challengeId=String(result.challengeId||'');if(!challengeId)throw new Error('License service did not return a verification challenge.');
    let activationResult=await requestLicenseOtp({title:'Verify Premium license email',subtitle:`Enter the 6-digit code sent to ${result.emailMasked||'the license email'}.`,onVerify:(code)=>completeLicenseActivation({challengeId,code,serial,physicalDeviceLinkCode:els.startupPhysicalDeviceLinkCode?.value||''})});
    if(activationResult?.reclaimRequired) activationResult=await requestLicenseReclaim(activationResult,els.startupLicenseDeviceLabel?.value||navigator.platform,serial);
    licenseState=await getLicenseState(); if(els.startupLicenseStatus)els.startupLicenseStatus.textContent=`Premium activated. Device role: ${escapeHtml(licenseState.managementRole||'regular')}.`; button.textContent='Activated'; button.disabled=true;
    if(els.firstRunSecurityEmail&&!els.firstRunSecurityEmail.value)els.firstRunSecurityEmail.value=email; updateFirstRunFinishAvailability();
  } catch(error){button.disabled=false;button.textContent='Verify and activate Premium';if(error?.message!=='Cancelled.')toast(error.message,true);}
});

els.firstRunSecurityEmail?.addEventListener('input', updateFirstRunFinishAvailability);
els.firstRunSecurityEmail?.addEventListener('change', updateFirstRunFinishAvailability);
els.firstRunMasterAck?.addEventListener('change', updateFirstRunFinishAvailability);
els.firstRunRemovalAck?.addEventListener('change', updateFirstRunFinishAvailability);

els.firstRunFinish?.addEventListener('click', async () => {
  const originalLabel = els.firstRunFinish.textContent;
  const routeEpoch = uiRouteEpoch;
  let setupDurablyCommitted = false;
  try {
    const profileName = normalizedProfileName(els.firstRunProfileName?.value);
    const emailEnabled = Boolean(els.firstRunEmailNotice.checked);
    const email = String(els.firstRunSecurityEmail.value || '').trim();
    const lockMinutes = Number(els.firstRunLockMinutes.value) || 5;
    if (!validSecurityEmail(email)) throw new Error('Enter a valid security notice email before finishing setup.');
    if (!els.firstRunMasterAck.checked) throw new Error('Confirm that you understand VaultCove cannot recover a forgotten master password.');
    if (!els.firstRunRemovalAck?.checked) {
      throw new Error('Confirm that you understand removing VaultCove permanently deletes its locally stored vault and that you should export an encrypted .vcvault backup first if you want a separate copy.');
    }

    // Finish Setup is a critical transaction. Refresh the active session before any
    // optional import/merge work. An already-expired session must go to the Master
    // password gate rather than trying to continue onboarding with a dead key.
    if (!(await touchSession())) {
      clearDecryptedUi();
      showGate('unlockPanel');
      throw new Error('VaultCove locked before setup could be committed. Enter the existing master password, then finish once more.');
    }

    const startupProfileImageDataUrl = String(settingsState?.profileImageDataUrl || '');
    const startupVaultTotp = vaultTotpProtection().enabled ? cloneForMergePreview(vaultTotpProtection()) : null;
    const startupVaultTotpEnabled = Boolean(startupVaultTotp?.enabled);
    const startupSettingsPatch = {
      profileName,
      profileImageDataUrl:startupProfileImageDataUrl,
      securityEmailNoticeEnabled:emailEnabled,
      securityNoticeEmail:email,
      lockMinutes:Math.max(1,Math.min(120,lockMinutes)),
      vaultTotpEnabled:startupVaultTotpEnabled || Boolean(settingsState?.vaultTotpEnabled),
      alwaysOnHandlerEnabled:true,
      newLoginCaptureEnabled:true,
      passwordChangeDetectionEnabled:true,
      websiteIconsEnabled:true,
      websiteIconsPremiumDefaultApplied:true,
      vaultViewMode:'grid'
    };

    els.firstRunFinish.disabled = true;
    els.firstRunFinish.textContent = pendingStartupImport || startupImportIntent !== 'fresh' ? 'Applying setup & import...' : 'Applying setup...';
    if (els.firstRunSecurityError) {
      els.firstRunSecurityError.textContent = '';
      els.firstRunSecurityError.classList.add('hidden');
    }

    // DURABILITY BOUNDARY: commit the validated startup settings and permanent
    // setup marker in one chrome.storage.local.set() before any optional import.
    // Auto-lock after this point can only route to Master password, never setup.
    settingsState = await completeFirstRunSetup(startupSettingsPatch);
    setupDurablyCommitted = true;

    const startupImportResult = await applySelectedStartupImportBeforeFinish();

    // Startup choices always win over portable backup settings.
    if (startupVaultTotpEnabled) {
      vault.security = vault.security || {};
      vault.security.vaultTotp = startupVaultTotp;
      await saveUnlockedVault(vault);
    }
    await setSettings({ ...startupSettingsPatch, firstRunSecurityComplete:true });
    settingsState=await getSettings();

    if (routeEpoch !== uiRouteEpoch || !vault || !(await touchSession().catch(() => false))) {
      enterLockedUi('Setup is saved. Vault locked; enter your master password to continue.');
      return;
    }
    licenseState = await getLicenseState();
    applyProfileIdentity();
    showApp();
    applyLicenseUiRestrictions();
    await render();
    wireSummaryCards();
    const missing=[];
    if(!vaultTotpProtection().enabled)missing.push('Authenticator');
    missing.push('create a fresh .vcvault backup and save its unique Backup Key separately');
    const appliedPrefix = startupImportResult.applied ? `${startupImportResult.message} ` : '';
    toast(`${appliedPrefix}Setup finished. Recommended next: ${missing.join(' and ')}.`);
  } catch(error) {
    if (setupDurablyCommitted || await reconcileFirstRunSetupState().catch(() => false)) {
      settingsState = await getSettings().catch(() => settingsState);
      const state = await loadUnlockedVault({ touch:false }).catch(() => ({ state:'locked', vault:null }));
      if (state.state === 'unlocked' && state.vault) {
        vault = state.vault;
        showApp();
        applyLicenseUiRestrictions();
        await render().catch(() => {});
        if (currentView === 'dashboard') wireSummaryCards();
        toast(`Setup was saved permanently. Optional startup work stopped: ${error.message}`, true);
        return;
      }
      clearDecryptedUi();
      showGate('unlockPanel');
      if (els.unlockError) {
        els.unlockError.textContent = 'Setup is already saved permanently. The vault locked while optional startup work was finishing. Enter your existing master password to continue.';
        els.unlockError.classList.remove('hidden');
      }
      toast('Setup saved. Vault locked; enter your master password to continue.', true);
      return;
    }
    els.firstRunSecurityError.textContent=error.message;
    els.firstRunSecurityError.classList.remove('hidden');
    toast(error.message,true);
  } finally {
    if (!els.app.classList.contains('hidden')) return;
    els.firstRunFinish.textContent = originalLabel || 'Finish Setup';
    updateFirstRunFinishAvailability();
  }
});

function startUnlockCooldown(blockedUntil) {
  unlockCooldownUntil = Math.max(Date.now(), Number(blockedUntil || 0));
  clearInterval(unlockCooldownTimer);
  const tick = () => {
    const remainingMs = Math.max(0, unlockCooldownUntil - Date.now());
    if (remainingMs <= 0) {
      clearInterval(unlockCooldownTimer);
      unlockCooldownTimer = null;
      unlockCooldownUntil = 0;
      els.unlockSubmit.disabled = false;
      els.unlockPassword.disabled = false;
      if (els.unlockTotp) els.unlockTotp.disabled = false;
      if (els.unlockError) { els.unlockError.textContent = ''; els.unlockError.classList.add('hidden'); }
      setTimeout(() => els.unlockPassword.focus(), 0);
      return;
    }
    const seconds = Math.ceil(remainingMs / 1000);
    els.unlockSubmit.disabled = true;
    els.unlockPassword.disabled = true;
    if (els.unlockTotp) els.unlockTotp.disabled = true;
    els.unlockSubmit.textContent = `Try again in ${seconds}s`;
    if (els.unlockError) {
      els.unlockError.textContent = `Too many incorrect Master Password attempts. VaultCove will allow another attempt in ${seconds} second${seconds === 1 ? '' : 's'}.`;
      els.unlockError.classList.remove('hidden');
    }
  };
  tick();
  unlockCooldownTimer = setInterval(tick, 250);
}

els.unlockSubmit.addEventListener('click',async()=>{
  if (unlockBusy) return;
  const password = els.unlockPassword.value;
  unlockBusy = true;
  els.unlockSubmit.disabled = true;
  els.unlockSubmit.classList.add('busy');
  els.unlockPassword.disabled = true;
  if (els.unlockError) { els.unlockError.textContent = ''; els.unlockError.classList.add('hidden'); }
  try {
    await runtimeMessage({ type: 'UNLOCK_VAULT', masterPassword: password, secondFactor: String(els.unlockTotp?.value || '') });
    const unlockedState = await loadUnlockedVault();
    if (unlockedState.state !== 'unlocked' || !unlockedState.vault) throw new Error('VaultCove unlocked, but the local vault session could not be loaded.');
    vault = unlockedState.vault;
    markEstablishedVault();
    markUiSessionState('unlocked');
    els.unlockPassword.value = '';
    if (els.unlockTotp) els.unlockTotp.value = '';
    currentView = 'dashboard';
    if (!(await reconcileFirstRunSetupState())) { settingsState = await getSettings(); showUnifiedFirstRunSetup({ vaultReady:true }); return; }
    if (await finishHandlerUnlockIfNeeded()) return;
    showApp();
    applyLicenseUiRestrictions();
    await render();
    if (currentView === 'dashboard') wireSummaryCards();
    await scheduleDisasterRecoveryIfNeeded();
    await applyUrlAction();
    } catch (e) {
    els.unlockPassword.value = '';
    if (els.unlockTotp) els.unlockTotp.value = '';
    if (Number(e?.blockedUntil || 0) > Date.now() || Number(e?.retryAfterMs || 0) > 0) startUnlockCooldown(Number(e.blockedUntil || (Date.now() + Number(e.retryAfterMs || 0))));
    else if (els.unlockError) { els.unlockError.textContent = e.message; els.unlockError.classList.remove('hidden'); }
    toast(e.message, true);
  } finally {
    unlockBusy = false;
    const coolingDown = unlockCooldownUntil > Date.now();
    if (!coolingDown) { els.unlockSubmit.disabled = false; els.unlockSubmit.textContent = 'Unlock vault'; }
    els.unlockSubmit.classList.remove('busy');
    if (!coolingDown) els.unlockPassword.disabled = false;
    if (els.unlockTotp && !coolingDown) els.unlockTotp.disabled = false;
    if (!vault && !coolingDown) setTimeout(() => els.unlockPassword.focus(), 0);
  }
});
els.unlockPassword.addEventListener('input',()=>{if(els.unlockError){els.unlockError.textContent='';els.unlockError.classList.add('hidden');}});
els.unlockPassword.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();els.unlockSubmit.click();}});
els.unlockTotp?.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();els.unlockSubmit.click();}});
els.lockButton.addEventListener('click',lockFromUi);
els.copyExportSecret.addEventListener('click',async()=>{await copyVaultClipboard(els.exportSecret.textContent,{label:'Backup Key'});});
els.closeSecret.addEventListener('click',()=>els.secretDialog.close());
els.cancelSensitive.addEventListener('click', closeSensitiveDialog);
els.confirmSensitive.addEventListener('click', async () => {
  if (sensitiveVerifyBusy) return;
  const action = pendingSensitiveAction;
  const password = els.sensitivePassword.value;
  if (!action) return closeSensitiveDialog();
  sensitiveVerifyBusy = true;
  els.confirmSensitive.disabled = true;
  els.confirmSensitive.classList.add('busy');
  els.sensitivePassword.disabled = true;
  if (els.sensitiveError) { els.sensitiveError.textContent = ''; els.sensitiveError.classList.add('hidden'); }
  try {
    await runtimeMessage({ type: 'VERIFY_SENSITIVE_ACCESS', masterPassword: password, secondFactor: String(els.sensitiveTotp?.value || '') });
    pendingSensitiveAction = null;
    els.sensitivePassword.value = '';
    if (els.sensitiveTotp) els.sensitiveTotp.value = '';
    if (els.sensitiveDialog.open) els.sensitiveDialog.close();
    await action();
    if (currentView === 'totp' && !TOTP_MAINTENANCE_MODE) refreshTotpCodes().catch(() => {});
  } catch (error) {
    els.sensitivePassword.value = '';
    if (els.sensitiveTotp) els.sensitiveTotp.value = '';
    if (els.sensitiveError) { els.sensitiveError.textContent = error.message; els.sensitiveError.classList.remove('hidden'); }
    toast(error.message, true);
  } finally {
    sensitiveVerifyBusy = false;
    els.confirmSensitive.disabled = false;
    els.confirmSensitive.classList.remove('busy');
    els.sensitivePassword.disabled = false;
    if (els.sensitiveDialog.open) setTimeout(() => els.sensitivePassword.focus(), 0);
  }
});
els.sensitivePassword.addEventListener('keydown', (event) => {
  if (event.key === 'Enter') {
    event.preventDefault();
    els.confirmSensitive.click();
  }
});
els.sensitiveTotp?.addEventListener('keydown', (event) => { if (event.key === 'Enter') { event.preventDefault(); els.confirmSensitive.click(); } });


els.closeVckeyDialog?.addEventListener('click', () => closeVckeyDialog(new Error('Cancelled.')));
els.cancelVckey?.addEventListener('click', () => closeVckeyDialog(new Error('Cancelled.')));
els.confirmVckey?.addEventListener('click', async () => {
  const pending = pendingVckeyOperation;
  if (!pending) return closeVckeyDialog();
  const password = $('vckeyPassword').value;
  const confirmPassword = $('vckeyPasswordConfirm').value;
  try {
    if (pending.mode === 'export') requirePasswordPolicy(password,14,'.vckey password');
    if (pending.mode === 'export' && password !== confirmPassword) throw new Error('.vckey passwords do not match.');
    if (pending.mode === 'export') {
      const comparison = await runtimeMessage({ type: 'CHECK_MASTER_PASSWORD_MATCH', candidate: password });
      if (comparison.matches) throw new Error('The .vckey password must be different from your VaultCove master password.');
    }
    const resolve = pending.resolve;
    pendingVckeyOperation = null;
    $('vckeyPassword').value = '';
    $('vckeyPasswordConfirm').value = '';
    if (els.vckeyDialog.open) els.vckeyDialog.close();
    resolve(password);
  } catch (error) {
    $('vckeyError').textContent = error.message;
    $('vckeyError').classList.remove('hidden');
  }
});
els.vckeyPassword?.addEventListener('keydown', (event) => { if (event.key === 'Enter') { event.preventDefault(); els.confirmVckey.click(); } });
els.vckeyPasswordConfirm?.addEventListener('keydown', (event) => { if (event.key === 'Enter') { event.preventDefault(); els.confirmVckey.click(); } });



els.closeLicenseReclaim?.addEventListener('click', () => closeLicenseReclaimDialog(new Error('Cancelled.')));
els.cancelLicenseReclaim?.addEventListener('click', () => closeLicenseReclaimDialog(new Error('Cancelled.')));
els.confirmLicenseReclaim?.addEventListener('click', async () => {
  const pending = pendingLicenseReclaim;
  if (!pending) return closeLicenseReclaimDialog();
  const targetInstallationId = $('licenseReclaimSelect').value;
  if (!targetInstallationId) {
    $('licenseReclaimError').textContent = 'Choose a retained device record or a new device slot.';
    $('licenseReclaimError').classList.remove('hidden');
    return;
  }
  els.confirmLicenseReclaim.disabled = true;
  try {
    const result = await completeRetainedDeviceRecovery({
      reclaimToken: pending.result.reclaimToken,
      targetInstallationId,
      deviceLabel: pending.deviceLabel,
      serial: pending.serial
    });
    const resolve = pending.resolve;
    pendingLicenseReclaim = null;
    if (els.licenseReclaimDialog.open) els.licenseReclaimDialog.close();
    resolve(result);
  } catch (error) {
    $('licenseReclaimError').textContent = error.message;
    $('licenseReclaimError').classList.remove('hidden');
  } finally {
    els.confirmLicenseReclaim.disabled = false;
  }
});

els.closeLicenseOtp?.addEventListener('click', () => closeLicenseOtpDialog(new Error('Cancelled.')));
els.cancelLicenseOtp?.addEventListener('click', () => closeLicenseOtpDialog(new Error('Cancelled.')));
els.confirmLicenseOtp?.addEventListener('click', async () => {
  const pending = pendingLicenseOtp;
  if (!pending) return closeLicenseOtpDialog();
  const code = $('licenseOtpCode').value.replace(/\D/g, '').slice(0, 6);
  if (code.length !== 6) {
    $('licenseOtpError').textContent = 'Enter the complete 6-digit email verification code.';
    $('licenseOtpError').classList.remove('hidden');
    return;
  }
  els.confirmLicenseOtp.disabled = true;
  try {
    const result = await pending.onVerify(code);
    const resolve = pending.resolve;
    pendingLicenseOtp = null;
    $('licenseOtpCode').value = '';
    if (els.licenseOtpDialog.open) els.licenseOtpDialog.close();
    resolve(result);
  } catch (error) {
    $('licenseOtpError').textContent = error.message;
    $('licenseOtpError').classList.remove('hidden');
  } finally {
    els.confirmLicenseOtp.disabled = false;
  }
});
els.licenseOtpCode?.addEventListener('keydown', (event) => { if (event.key === 'Enter') { event.preventDefault(); els.confirmLicenseOtp.click(); } });

els.closeTotpSetup?.addEventListener('click', () => { pendingTotpSetup = null; if (els.totpSetupDialog.open) els.totpSetupDialog.close(); });
els.copyTotpSecret?.addEventListener('click', async () => { await copyVaultClipboard($('totpSetupSecret').value,{label:'Authenticator setup key'}); });
els.copyTotpUri?.addEventListener('click', async () => { await copyVaultClipboard($('totpSetupUri').value,{label:'Authenticator URI'}); });
els.confirmTotpSetup?.addEventListener('click', async () => {
  try {
    if (!pendingTotpSetup) throw new Error('Start authenticator setup again.');
    const code = String($('totpSetupCode').value || '').trim();
    if (!(await verifyTotp(pendingTotpSetup.secret, code))) throw new Error('The authenticator code is incorrect. Check the device time and try again.');
    const recoveryCodeHashes = await hashRecoveryCodes(pendingTotpSetup.recoveryCodes);
    vault.security = vault.security || {};
    vault.security.vaultTotp = { enabled:true, secret:pendingTotpSetup.secret, recoveryCodeHashes, enabledAt:new Date().toISOString() };
    await saveUnlockedVault(vault);
    await setSettings({ vaultTotpEnabled:true });
    settingsState = await getSettings();
    await clearSensitiveAccess();
    $('totpRecoveryCodes').textContent = pendingTotpSetup.recoveryCodes.join('\n');
    $('totpRecoveryPanel').classList.remove('hidden');
    $('confirmTotpSetup').disabled = true;
    $('totpSetupCode').disabled = true;
    updateFirstRunSecurityStatus();
    toast('VaultCove authenticator confirmation enabled. Save the recovery codes now.');
  } catch (error) { toast(error.message, true); }
});
els.copyRecoveryCodes?.addEventListener('click', async () => { if (!pendingTotpSetup?.recoveryCodes) return; await copyVaultClipboard(pendingTotpSetup.recoveryCodes.join('\n'),{label:'Recovery codes'}); });


// Premium-style live password setup guidance. Creation buttons stay unavailable until every
// required character class is present and confirmation matches. Existing passwords being opened
// are never rejected by the new creation policy.
bindPasswordGuide({ inputId:'setupPassword', confirmId:'setupConfirm', guideId:'setupPasswordGuide', onChange:(state)=>{ els.setupSubmit.disabled=Boolean(vault)||!state.valid; } });
bindPasswordGuide({ inputId:'vckeyPassword', confirmId:'vckeyPasswordConfirm', guideId:'vckeyPasswordGuide', onChange:(state)=>{ if (pendingVckeyOperation?.mode === 'export') els.confirmVckey.disabled=!state.valid; } });

document.addEventListener('keydown',(event)=>{if((event.ctrlKey||event.metaKey)&&event.key.toLowerCase()==='k'&&vault){event.preventDefault();els.search.classList.remove('hidden');els.search.focus();}});
document.addEventListener('pointerdown', markVaultActivity, { passive: true });
document.addEventListener('pointermove', markVaultActivity, { passive: true });
document.addEventListener('keydown', markVaultActivity);
document.addEventListener('wheel', markVaultActivity, { passive: true });
document.addEventListener('scroll', markVaultActivity, { passive: true, capture: true });
document.addEventListener('touchstart', markVaultActivity, { passive: true });
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') markVaultActivityAfterExpiryCheck().catch(() => {}); });
window.addEventListener('focus', () => markVaultActivityAfterExpiryCheck().catch(() => {}));
setInterval(() => enforceUiAutoLock().catch(() => {}), 2000);
setInterval(() => enforceSensitiveUiExpiry().catch(() => {}), 2000);


// Live entitlement propagation across already-open VaultCove pages. Activation,
// refresh, release, or revocation updates the account label/navigation without a
// manual extension-page refresh.
chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName !== 'local' || !changes.vaultcoveLicenseClient) return;
  (async () => {
    licenseState = await getLicenseState();
    syncPremiumNavigation();
    applyProfileIdentity();
    if (currentView === 'license' || currentView === 'premium') await render();
  })().catch(() => {});
});

// 0.7.74 system-wide live-state invariant. Settings changed in another open
// VaultCove surface are applied immediately to this page as well. Vault data and
// licensing have their own listeners below/above; together these cover every
// persistent user-facing state family without requiring a page refresh.
let liveSettingsUiRefreshTimer = null;
chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName !== 'local' || !changes?.[SETTINGS_STORAGE_KEY]) return;
  clearTimeout(liveSettingsUiRefreshTimer);
  liveSettingsUiRefreshTimer = setTimeout(() => {
    (async () => {
      settingsState = await getSettings();
      applyTheme(settingsState?.theme || 'ivory');
      applyProfileIdentity();
      if (vault && !document.querySelector('dialog[open]')) await Promise.resolve(render());
    })().catch(() => {});
  }, 80);
});

// 0.7.72 real-time vault UI invariant. Background/content-handler writes use the
// same encrypted vaultEnvelope as dashboard writes. When that envelope changes,
// immediately reload the decrypted in-memory vault so a detected-login Add appears
// in Vault/Dashboard without refreshing the extension page. Do not tear down an
// open dialog while the user is editing; the refreshed vault object is still kept
// in memory and the next view/render uses it.
let liveVaultUiRefreshTimer = null;
chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName !== 'local' || !changes?.[VAULT_STORAGE_KEY]) return;
  clearTimeout(liveVaultUiRefreshTimer);
  liveVaultUiRefreshTimer = setTimeout(() => {
    (async () => {
      const state = await loadUnlockedVault({ touch: false });
      if (state.state !== 'unlocked') return;
      vault = state.vault;
      if (!document.querySelector('dialog[open]')) await Promise.resolve(render());
    })().catch(() => {});
  }, 80);
});

applyInputSemantics(document);
bootstrap().catch(showBootstrapFailure);
