import {
  assertMasterAuthAllowed,
  beginFirstRunSetup,
  clearMasterAuthFailures,
  clearSession,
  ensureDeviceId,
  getSessionExpiry,
  getSettings,
  hardenStorageAccess,
  recordMasterAuthFailure,
  reconcileFirstRunSetupState,
  hasSensitiveAccess,
  scheduleSessionAutoLock,
  setSettings,
  touchSession
} from './core/storage.js';
import { initializeVault, loadUnlockedVault, matchesCurrentMasterPassword, saveUnlockedVault, unlockVault, verifySensitiveAccess } from './core/vault.js';
import { featureAllowed, getLicenseState } from './core/license.js';
import { loginMatchesSearch, publicLoginSummary } from './core/redaction.js';
import { createGenericSecurityNotice } from './core/security-events.js';
import { canonicalHostname, insecureHttpLoginMatchesUrl, loginHasInsecureHttpUrl, loginMatchesTrustedHost, permissionOriginForHost, resolveLoginNavigationTarget, secureLoginMatchesUrl } from './core/site-match.js';
import { checkForUpdates } from './core/updates.js';
import { createPendingLoginCapture, findExistingLoginForCapture, prunePendingLoginCaptures, samePendingLoginCapture } from './core/login-capture.js';
import { discardLockedCapture, sealCaptureWhileLocked } from './core/capture-inbox.js';
import { getLicenseClientState, refreshLicenseLease, sendSecurityNotice } from './core/license-service.js';
import { BUILD_CHANNEL } from './core/build.js';
import { isUseOnlySharedLogin, openSharedLoginForFill, sharedAccessIsExpired } from './core/shared-access.js';
import { bytesToBase64Url, randomBytes } from './core/encoding.js';
import { validateRuntimeMessage, runtimeMessageSourceAllowed } from './core/message-schema.js';
import { applyCaptureRateLimit, validateCaptureCandidate } from './core/capture-policy.js';
import { appendActivityEvent } from './core/activity-log.js';
import { clearLegacyTrialMetadata } from './core/product-plan.js';
import { createItem, upsertItem } from './core/model.js';
import { appendGuardianReceipt, createGuardianReceipt, guardianOriginAllowed, guardianQuarantineAssessment, guardianRequiresReauth } from './core/guardian.js';
import { SETTINGS_STORAGE_KEY, VAULT_STORAGE_KEY } from './core/constants.js';

function assertGuardianLoginUse(item, pageUrl) {
  if (!item || item.type !== 'login') return true;
  const quarantine = guardianQuarantineAssessment(item);
  if (quarantine.quarantine) throw new Error(`Guardian quarantine blocked this login: ${quarantine.reason}`);
  if (!guardianOriginAllowed(item, pageUrl)) throw new Error('Guardian blocked this login because the exact domain is not pinned to the credential.');
  return true;
}

let masterAuthQueue = Promise.resolve();
function queueMasterAuth(operation) {
  const run = masterAuthQueue.then(operation, operation);
  masterAuthQueue = run.catch(() => undefined);
  return run;
}

async function runMasterAuthGuarded(operation, { countMismatch = true } = {}) {
  await assertMasterAuthAllowed();
  try {
    const result = await operation();
    await clearMasterAuthFailures();
    return result;
  } catch (error) {
    const message = String(error?.message || '');
    const mismatch = /incorrect master password/i.test(message) || (countMismatch && /matches?\s*===?\s*false/i.test(message));
    if (/incorrect master password/i.test(message)) {
      const throttle = await recordMasterAuthFailure();
      if (throttle.retryAfterMs > 0) {
        const cooldown = new Error(`Too many incorrect Master Password attempts. Try again in ${Math.ceil(throttle.retryAfterMs / 1000)} seconds.`);
        cooldown.code = 'MASTER_AUTH_COOLDOWN';
        cooldown.retryAfterMs = throttle.retryAfterMs;
        cooldown.blockedUntil = throttle.blockedUntil;
        throw cooldown;
      }
    }
    throw error;
  }
}

function authErrorResponse(error) {
  return {
    ok: false,
    error: String(error?.message || 'Master-password verification failed.'),
    code: String(error?.code || ''),
    retryAfterMs: Math.max(0, Number(error?.retryAfterMs || 0)),
    blockedUntil: Math.max(0, Number(error?.blockedUntil || 0))
  };
}

let vaultMutationQueue = Promise.resolve();
function queueVaultMutation(operation) {
  const run = vaultMutationQueue.then(operation, operation);
  vaultMutationQueue = run.catch(() => undefined);
  return run;
}

let browserIntegrationQueue = Promise.resolve();
function queueBrowserIntegration(operation) {
  const run = browserIntegrationQueue.then(operation, operation);
  browserIntegrationQueue = run.catch(() => undefined);
  return run;
}

let secureCapabilityQueue = Promise.resolve();
function queueSecureCapability(operation) {
  const run = secureCapabilityQueue.then(operation, operation);
  secureCapabilityQueue = run.catch(() => undefined);
  return run;
}
const UPDATE_CHECK_ALARM = 'vaultcove-update-check';
const LICENSE_REFRESH_ALARM = 'vaultcove-license-refresh';
const EMAIL_NOTICE_RETRY_ALARM = 'vaultcove-security-email-retry';
const HANDLER_SCRIPT_ID = 'vaultcove-inline-handler';
const LEGACY_BROAD_HANDLER_ORIGIN = 'https://*/*';
const DEV_HANDLER_ORIGINS = Object.freeze([LEGACY_BROAD_HANDLER_ORIGIN]);
const UPDATE_METADATA_ORIGIN = 'https://raw.githubusercontent.com/*';
const EMAIL_NOTICE_QUEUE_KEY = 'securityEmailNoticeQueue';
const PASSWORD_NOTICE_PREFIX = 'vaultcove-password-change:';
const NEW_LOGIN_NOTICE_PREFIX = 'vaultcove-new-login:';
const ON_DEMAND_HANDLER_TABS_KEY = 'onDemandHandlerTabs';
const PENDING_SECURE_LAUNCH_KEY = 'pendingSecureLaunches';
const HANDLER_UNLOCK_FLOW = 'handler-unlock';
const ON_DEMAND_HANDLER_TTL_MS = 30 * 60 * 1000;
const SECURE_LOGIN_CAPABILITIES_KEY = 'secureLoginCapabilities';
const SECURE_LOGIN_CAPABILITY_TTL_MS = 5000;
const CAPTURE_RATE_STATE_KEY = 'captureRateState';
const NEW_LOGIN_PROMPT_STATE_KEY = 'newLoginPromptByTab';
const NEW_LOGIN_PROMPT_TTL_MS = 2 * 60 * 1000;
const ACCEPTED_NEW_LOGIN_SAVES_KEY = 'acceptedNewLoginSaves';
const ACCEPTED_NEW_LOGIN_SAVE_TTL_MS = 7 * 24 * 60 * 60 * 1000;
const ACCEPTED_NEW_LOGIN_SAVE_MAX = 100;




async function getAcceptedNewLoginSaves() {
  const result = await chrome.storage.local.get(ACCEPTED_NEW_LOGIN_SAVES_KEY);
  const raw = result[ACCEPTED_NEW_LOGIN_SAVES_KEY];
  const now = Date.now();
  const entries = raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : {};
  const kept = Object.fromEntries(Object.entries(entries).filter(([, record]) => now - Number(record?.acceptedAt || 0) <= ACCEPTED_NEW_LOGIN_SAVE_TTL_MS));
  if (Object.keys(kept).length !== Object.keys(entries).length) await saveAcceptedNewLoginSaves(kept);
  return kept;
}

async function saveAcceptedNewLoginSaves(value) {
  const ordered = Object.entries(value || {})
    .sort((a, b) => Number(a[1]?.acceptedAt || 0) - Number(b[1]?.acceptedAt || 0))
    .slice(-ACCEPTED_NEW_LOGIN_SAVE_MAX);
  const kept = Object.fromEntries(ordered);
  if (ordered.length) await chrome.storage.local.set({ [ACCEPTED_NEW_LOGIN_SAVES_KEY]: kept });
  else await chrome.storage.local.remove(ACCEPTED_NEW_LOGIN_SAVES_KEY);
}

async function acceptNewLoginSave(captureId) {
  const id = String(captureId || '').trim();
  if (!id) throw new Error('Missing new-login capture ID.');
  const accepted = await getAcceptedNewLoginSaves();
  accepted[id] = { acceptedAt: Date.now() };
  await saveAcceptedNewLoginSaves(accepted);
  return { captureId: id, acceptedAt: accepted[id].acceptedAt };
}

async function clearAcceptedNewLoginSave(captureId) {
  const id = String(captureId || '').trim();
  if (!id) return;
  const accepted = await getAcceptedNewLoginSaves();
  if (!(id in accepted)) return;
  delete accepted[id];
  await saveAcceptedNewLoginSaves(accepted);
}

async function getNewLoginPromptState() {
  const result = await chrome.storage.session.get(NEW_LOGIN_PROMPT_STATE_KEY);
  const raw = result[NEW_LOGIN_PROMPT_STATE_KEY];
  return raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : {};
}

async function saveNewLoginPromptState(value) {
  const now = Date.now();
  const kept = Object.fromEntries(Object.entries(value || {}).filter(([, prompt]) => now - Number(prompt?.createdAt || 0) <= NEW_LOGIN_PROMPT_TTL_MS));
  if (Object.keys(kept).length) await chrome.storage.session.set({ [NEW_LOGIN_PROMPT_STATE_KEY]: kept });
  else await chrome.storage.session.remove(NEW_LOGIN_PROMPT_STATE_KEY);
}

async function setNewLoginPrompt(tabId, capture, { queuedWhileLocked = false } = {}) {
  if (!Number.isInteger(tabId) || !capture?.id) return null;
  const all = await getNewLoginPromptState();
  const prompt = {
    captureId: String(capture.id),
    hostname: String(capture.hostname || '').slice(0, 253),
    createdAt: Date.now(),
    queuedWhileLocked: Boolean(queuedWhileLocked),
    saveRequested: false
  };
  all[String(tabId)] = prompt;
  await saveNewLoginPromptState(all);
  return prompt;
}

async function pendingNewLoginPrompt(tabId) {
  if (!Number.isInteger(tabId)) return null;
  const all = await getNewLoginPromptState();
  const prompt = all[String(tabId)] || null;
  if (!prompt) return null;
  if (Date.now() - Number(prompt.createdAt || 0) > NEW_LOGIN_PROMPT_TTL_MS) {
    delete all[String(tabId)];
    await saveNewLoginPromptState(all);
    return null;
  }
  return prompt;
}

async function updateNewLoginPrompt(tabId, captureId, changes = {}) {
  if (!Number.isInteger(tabId)) return null;
  const all = await getNewLoginPromptState();
  const prompt = all[String(tabId)];
  if (!prompt || String(prompt.captureId || '') !== String(captureId || '')) return null;
  all[String(tabId)] = { ...prompt, ...changes };
  await saveNewLoginPromptState(all);
  return all[String(tabId)];
}

async function clearNewLoginPrompt(tabId, captureId = '') {
  if (!Number.isInteger(tabId)) return;
  const all = await getNewLoginPromptState();
  const prompt = all[String(tabId)];
  if (!prompt) return;
  if (captureId && String(prompt.captureId || '') !== String(captureId)) return;
  delete all[String(tabId)];
  await saveNewLoginPromptState(all);
}

function captureBelongsToPrompt(prompt, captureId) {
  return Boolean(prompt && String(prompt.captureId || '') === String(captureId || ''));
}

async function savePendingLoginCaptureToVault(vault, capture) {
  if (!capture?.password || !capture?.username) throw new Error('This new-login candidate is no longer pending.');
  const existing = findExistingLoginForCapture((vault.items || []).filter((item) => !isUseOnlySharedLogin(item)), capture.hostname, capture.username, capture.origin);
  if (existing) {
    vault.pendingLoginCaptures = (vault.pendingLoginCaptures || []).filter((candidate) => candidate.id !== capture.id);
    return { saved: false, duplicate: true, itemId: existing.id };
  }
  const item = createItem('login', {
    name: capture.name || capture.hostname || 'New Login',
    username: capture.username,
    password: capture.password,
    urls: [capture.origin || `https://${capture.hostname}`],
    autoLogin: false,
    requireReauthBeforeFill: false,
    lastPasswordChangeAt: new Date().toISOString()
  });
  upsertItem(vault, item);
  vault.pendingLoginCaptures = (vault.pendingLoginCaptures || []).filter((candidate) => candidate.id !== capture.id);
  await appendActivityEvent(vault, 'new-login-saved', { itemId: item.id, host: String(capture.hostname || '') });
  return { saved: true, itemId: item.id };
}

async function handleSaveNewLoginCapture(message, sender) {
  const tabId = sender?.tab?.id;
  const captureId = String(message.captureId || '');
  const prompt = await pendingNewLoginPrompt(tabId);
  if (!captureBelongsToPrompt(prompt, captureId)) throw new Error('This VaultCove save prompt is no longer active.');

  const result = await queueVaultMutation(async () => {
    const state = await loadUnlockedVault({ touch: false });
    if (state.state !== 'unlocked') {
      // The user already approved Add. Never convert that approval into a second
      // master-password challenge. The locked capture remains sealed locally and
      // is promoted into the encrypted vault after the next normal unlock.
      await acceptNewLoginSave(captureId);
      return { saved: false, queued: true, captureId };
    }

    // Always resolve the capture from a fresh decrypted vault inside the mutation
    // queue. This prevents a handler refresh holding an older vault snapshot from
    // winning a last-writer race over the user's explicit Add action.
    const capture = (state.vault.pendingLoginCaptures || []).find((candidate) => candidate.id === captureId);
    if (!capture) return { saved: false, missing: true, captureId };

    const committed = await savePendingLoginCaptureToVault(state.vault, capture);
    if (committed.saved || committed.duplicate) await saveUnlockedVault(state.vault, { touch: false });

    if (committed.saved) {
      // Prove the new item is actually present in the persisted encrypted envelope
      // before telling the webpage that Add succeeded.
      const verified = await loadUnlockedVault({ touch: false });
      if (verified.state !== 'unlocked' || !(verified.vault.items || []).some((item) => item.id === committed.itemId && item.type === 'login' && !item.deletedAt)) {
        throw new Error('VaultCove could not verify the newly saved login. Nothing was reported as saved.');
      }
    }
    return { ...committed, captureId };
  });

  if (result.missing) {
    throw new Error('VaultCove could not recover this detected login. Submit the website login once more and choose Add to VaultCove again.');
  }

  await clearAcceptedNewLoginSave(captureId);
  await clearNewLoginPrompt(tabId, captureId);
  if (result.saved || result.duplicate) await discardLockedCapture(captureId);

  if (result.saved || result.duplicate) {
    // Refresh the originating page before returning success, then refresh every
    // other open handler. No webpage reload is required.
    if (Number.isInteger(tabId)) await notifyHandlerTabSession(tabId, 'vault-changed', 3);
    await broadcastHandlerSessionChanged('vault-changed');
  }
  return result;
}

async function handleDismissNewLoginCapture(message, sender) {
  const tabId = sender?.tab?.id;
  const captureId = String(message.captureId || '');
  const prompt = await pendingNewLoginPrompt(tabId);
  if (!captureBelongsToPrompt(prompt, captureId)) return { dismissed: false };

  const dismissed = await queueVaultMutation(async () => {
    const state = await loadUnlockedVault({ touch: false });
    if (state.state === 'unlocked') {
      const before = (state.vault.pendingLoginCaptures || []).length;
      state.vault.pendingLoginCaptures = (state.vault.pendingLoginCaptures || []).filter((candidate) => candidate.id !== captureId);
      const changed = state.vault.pendingLoginCaptures.length !== before;
      if (changed) await saveUnlockedVault(state.vault, { touch: false });
      return changed;
    }
    return Boolean((await discardLockedCapture(captureId)).discarded);
  });

  await clearAcceptedNewLoginSave(captureId);
  await clearNewLoginPrompt(tabId, captureId);
  return { dismissed };
}

async function fulfillRequestedNewLoginSaves(vault) {
  const [accepted, all] = await Promise.all([getAcceptedNewLoginSaves(), getNewLoginPromptState()]);
  // Migrate any 0.7.68 session-only Save requests into the durable accepted set.
  for (const prompt of Object.values(all)) {
    if (prompt?.saveRequested && prompt?.captureId) accepted[String(prompt.captureId)] = { acceptedAt: Number(prompt.createdAt || Date.now()) };
  }

  let changed = false;
  for (const captureId of Object.keys(accepted)) {
    const capture = (vault.pendingLoginCaptures || []).find((candidate) => candidate.id === captureId);
    if (capture) {
      const result = await savePendingLoginCaptureToVault(vault, capture);
      if (result.saved || result.duplicate) changed = true;
    }
    delete accepted[captureId];
  }
  for (const [tabKey, prompt] of Object.entries(all)) {
    if (prompt?.saveRequested) delete all[tabKey];
  }
  if (changed) await saveUnlockedVault(vault, { touch: false });
  await Promise.all([saveAcceptedNewLoginSaves(accepted), saveNewLoginPromptState(all)]);
  return { changed };
}

function trustedExtensionSender(sender) {
  const base = chrome.runtime.getURL('');
  return typeof sender?.url === 'string' && sender.url.startsWith(base);
}

async function getPendingSecureLaunches() {
  const result = await chrome.storage.session.get(PENDING_SECURE_LAUNCH_KEY);
  return result[PENDING_SECURE_LAUNCH_KEY] || {};
}
async function savePendingSecureLaunches(value) { await chrome.storage.session.set({ [PENDING_SECURE_LAUNCH_KEY]: value }); }
async function clearPendingSecureLaunch(tabId) {
  const all = await getPendingSecureLaunches();
  if (String(tabId) in all) { delete all[String(tabId)]; await savePendingSecureLaunches(all); }
}
async function pendingSecureLaunch(tabId) {
  const all = await getPendingSecureLaunches(); const record = all[String(tabId)];
  if (!record) return null;
  if (Date.now() > Number(record.expiresAt || 0)) { await clearPendingSecureLaunch(tabId); return null; }
  return record;
}

async function getOnDemandHandlerTabs() {
  const result = await chrome.storage.session.get(ON_DEMAND_HANDLER_TABS_KEY);
  const raw = result[ON_DEMAND_HANDLER_TABS_KEY];
  return raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : {};
}

async function saveOnDemandHandlerTabs(value) {
  const entries = Object.fromEntries(Object.entries(value || {}).filter(([, record]) => Number(record?.expiresAt || 0) > Date.now()));
  await chrome.storage.session.set({ [ON_DEMAND_HANDLER_TABS_KEY]: entries });
}

async function markOnDemandHandlerTab(tabId, pageUrl) {
  if (!Number.isInteger(tabId) || !pageUrl) return;
  const tabs = await getOnDemandHandlerTabs();
  tabs[String(tabId)] = {
    origin: pageUrl.origin,
    expiresAt: Date.now() + ON_DEMAND_HANDLER_TTL_MS
  };
  await saveOnDemandHandlerTabs(tabs);
}

async function clearOnDemandHandlerTab(tabId) {
  if (!Number.isInteger(tabId)) return;
  const tabs = await getOnDemandHandlerTabs();
  if (!(String(tabId) in tabs)) return;
  delete tabs[String(tabId)];
  await saveOnDemandHandlerTabs(tabs);
}

async function isOnDemandHandlerTab(tabId, pageUrl) {
  if (!Number.isInteger(tabId) || !pageUrl) return false;
  const tabs = await getOnDemandHandlerTabs();
  const record = tabs[String(tabId)];
  if (!record || Number(record.expiresAt || 0) <= Date.now()) {
    if (record) await clearOnDemandHandlerTab(tabId);
    return false;
  }
  return record.origin === pageUrl.origin;
}

async function injectOnDemandHandler(tabId) {
  if (!Number.isInteger(tabId)) throw new Error('No active tab is available.');
  const tab = await chrome.tabs.get(tabId);
  const pageUrl = parseWebUrl(tab?.url || '');
  if (!pageUrl) return { enabled: false, reason: 'unsupported-page' };

  if (BUILD_CHANNEL === 'dev' && pageUrl.protocol === 'https:') {
    // The Developer build already has one manifest-declared handler on every
    // HTTPS page. Do not mark this tab for later script injection; just tell
    // the existing handler to refresh its locked/unlocked state.
    try { await chrome.tabs.sendMessage(tabId, { type: 'VAULTCOVE_SESSION_CHANGED' }); } catch {}
    return { enabled: true, mode: 'manifest', origin: pageUrl.origin };
  }

  await markOnDemandHandlerTab(tabId, pageUrl);
  try {
    try {
      await chrome.scripting.executeScript({
        target: { tabId, frameIds: [0] },
        world: 'ISOLATED',
        files: ['src/content/handler.js']
      });
    } catch {
      throw new Error('VaultCove could not attach its top-frame login handler to this page.');
    }
    return { enabled: true, mode: 'activeTab', origin: pageUrl.origin };
  } catch (error) {
    await clearOnDemandHandlerTab(tabId);
    throw new Error(`VaultCove could not attach the on-demand login handler to this page: ${error?.message || error}`);
  }
}

function parseWebUrl(value) {
  try {
    const url = new URL(value);
    return ['http:','https:'].includes(url.protocol) ? url : null;
  } catch {
    return null;
  }
}

function parseHttpsUrl(value) {
  const url = parseWebUrl(value);
  return url?.protocol === 'https:' ? url : null;
}

function handlerPermissionOriginForUrl(pageUrl) {
  if (!pageUrl || pageUrl.protocol !== 'https:') throw new Error('A valid HTTPS page is required.');
  return `https://${pageUrl.hostname}/*`;
}

function loginMatchesSite(item, hostname) {
  return loginMatchesTrustedHost(item, hostname);
}

function frameUrlFromSender(sender) {
  return parseWebUrl(sender?.url || sender?.tab?.url || '');
}

function runtimeSenderKind(sender) {
  if (trustedExtensionSender(sender)) return 'extension';
  if (Number.isInteger(sender?.tab?.id) && frameUrlFromSender(sender)) return 'web-handler';
  return 'unknown';
}

async function getSecureLoginCapabilities() {
  const result = await chrome.storage.session.get(SECURE_LOGIN_CAPABILITIES_KEY);
  const raw = result[SECURE_LOGIN_CAPABILITIES_KEY];
  const now = Date.now();
  const entries = Object.fromEntries(Object.entries(raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : {})
    .filter(([, record]) => Number(record?.expiresAt || 0) > now));
  return entries;
}

async function saveSecureLoginCapabilities(entries) {
  await chrome.storage.session.set({ [SECURE_LOGIN_CAPABILITIES_KEY]: entries });
}

async function revokeSecureLoginCapabilities() {
  await chrome.storage.session.remove(SECURE_LOGIN_CAPABILITIES_KEY);
}

async function issueSecureLoginCapability(message, sender) {
  const pageUrl = frameUrlFromSender(sender);
  const tabId = sender?.tab?.id;
  const frameId = sender?.frameId ?? 0;
  if (!pageUrl || pageUrl.protocol !== 'https:' || !Number.isInteger(tabId) || frameId !== 0) throw new Error('Strict Secure Login authorization is available only to the trusted top-level HTTPS handler.');

  const [licenseState, settings, state] = await Promise.all([getLicenseState(), getSettings(), loadUnlockedVault({ touch: false })]);
  if (!featureAllowed(licenseState, 'autofill')) throw new Error('Secure Login is unavailable for this license state.');
  if (state.state !== 'unlocked') throw new Error('VaultCove is locked.');
  const persistentHandlerEnabled = Boolean((await hasHandlerPermissionForUrl(pageUrl)) && !handlerDisabledForHost(settings, pageUrl.hostname));
  const onDemandHandlerEnabled = await isOnDemandHandlerTab(tabId, pageUrl);
  if (!persistentHandlerEnabled && !onDemandHandlerEnabled) throw new Error('VaultCove login handling is disabled for this website.');

  const item = state.vault.items.find((candidate) => candidate.id === message.itemId && !candidate.deletedAt);
  if (!item || !secureLoginMatchesUrl(item, pageUrl)) throw new Error('Blocked: the saved login is not trusted for this exact HTTPS origin.');
  const guardianQuarantine = guardianQuarantineAssessment(item);
  if (guardianQuarantine.quarantine) throw new Error(`Guardian quarantine blocked Secure Login: ${guardianQuarantine.reason}`);
  if (!guardianOriginAllowed(item, pageUrl)) throw new Error('Guardian blocked Secure Login because this exact domain is not pinned to the credential.');
  if (isUseOnlySharedLogin(item) && sharedAccessIsExpired(item)) throw new Error('This shared login access has expired.');
  if (guardianRequiresReauth(item) && !(await hasSensitiveAccess())) throw new Error('Sensitive Access required before Secure Login for this protected credential.');

  const automatic = Boolean(message.automatic);
  if (automatic) {
    if (!settings.autoLoginEnabled || !item.autoLogin) throw new Error('Automatic login is not enabled for this item.');
    if (!persistentHandlerEnabled) throw new Error('Automatic login requires persistent access to this website.');
  }
  const stage = message.stage === 'username' ? 'username' : 'password';
  const token = `sc_${bytesToBase64Url(randomBytes(24))}`;
  const expiresAt = Date.now() + SECURE_LOGIN_CAPABILITY_TTL_MS;
  await queueSecureCapability(async () => {
    const all = await getSecureLoginCapabilities();
    all[token] = { itemId: item.id, tabId, frameId, origin: pageUrl.origin, automatic, stage, expiresAt };
    await saveSecureLoginCapabilities(all);
  });
  return { capability: token, expiresAt };
}

async function consumeSecureLoginCapability(token, sender) {
  return queueSecureCapability(async () => {
    const value = String(token || '');
    if (!/^sc_[A-Za-z0-9_-]{32,}$/.test(value)) throw new Error('Invalid or expired Secure Login authorization.');
    const all = await getSecureLoginCapabilities();
    const record = all[value];
    if (record) delete all[value];
    await saveSecureLoginCapabilities(all);
    if (!record || Date.now() >= Number(record.expiresAt || 0)) throw new Error('Secure Login authorization expired. Try again.');
    const pageUrl = frameUrlFromSender(sender);
    if (!pageUrl || pageUrl.protocol !== 'https:' || sender?.tab?.id !== record.tabId || (sender?.frameId ?? 0) !== record.frameId || pageUrl.origin !== record.origin) {
      throw new Error('Secure Login authorization does not match this tab, frame, or HTTPS origin.');
    }
    return record;
  });
}

async function consumeCaptureBudget(origin) {
  const result = await chrome.storage.session.get(CAPTURE_RATE_STATE_KEY);
  const limited = applyCaptureRateLimit(result[CAPTURE_RATE_STATE_KEY] || {}, origin, Date.now());
  await chrome.storage.session.set({ [CAPTURE_RATE_STATE_KEY]: limited.state });
  return limited;
}

async function grantedHandlerOrigins() {
  const all = await chrome.permissions.getAll();
  return (all.origins || []).filter((origin) => origin.startsWith('https://') && origin !== UPDATE_METADATA_ORIGIN);
}

async function hasHandlerPermissionForUrl(pageUrl) {
  if (!pageUrl) return false;
  try {
    if (pageUrl.protocol !== 'https:') return false;
    if (await chrome.permissions.contains({ origins: [LEGACY_BROAD_HANDLER_ORIGIN] })) return true;
    return chrome.permissions.contains({ origins: [handlerPermissionOriginForUrl(pageUrl)] });
  } catch {
    return false;
  }
}

async function notifyHandlerTabSession(tabId, state = 'unknown', retries = 5) {
  if (!Number.isInteger(tabId)) return false;
  for (let attempt = 0; attempt < Math.max(1, retries); attempt += 1) {
    try {
      const response = await chrome.tabs.sendMessage(
        tabId,
        { type: 'VAULTCOVE_SESSION_CHANGED', state },
        { frameId: 0 }
      );
      if (response?.ok && (state !== 'unlocked' || response.unlocked === true)) return true;
    } catch {}
    await new Promise((resolve) => setTimeout(resolve, 120 + attempt * 80));
  }
  return false;
}

async function broadcastHandlerSessionChanged(state = 'unknown') {
  let tabs = [];
  try { tabs = await chrome.tabs.query({}); } catch { return; }
  await Promise.allSettled(
    tabs
      .filter((tab) => Number.isInteger(tab.id))
      .map((tab) => notifyHandlerTabSession(tab.id, state, 2))
  );
}

async function refreshOpenWebsiteHandlers(state = 'vault-changed') {
  // Real-time invariant: after any encrypted vault mutation (manual save,
  // migration import/merge, detected-login Add, folder edit, share update), every
  // currently-open page that is already authorized for VaultCove must immediately
  // see the new state. If its handler is missing because the extension/service
  // worker reloaded, inject the current handler without requiring a page refresh.
  let tabs = [];
  try { tabs = await chrome.tabs.query({}); } catch { return; }
  await Promise.allSettled(tabs.filter((tab) => Number.isInteger(tab.id)).map(async (tab) => {
    const pageUrl = parseWebUrl(tab.url || '');
    if (!pageUrl || pageUrl.protocol !== 'https:') return;
    const permitted = await hasHandlerPermissionForUrl(pageUrl) || await isOnDemandHandlerTab(tab.id, pageUrl);
    if (!permitted) return;

    if (await notifyHandlerTabSession(tab.id, state, 1)) return;
    try {
      await chrome.scripting.executeScript({ target: { tabId: tab.id, frameIds: [0] }, world: 'ISOLATED', files: ['src/content/handler.js'] });
    } catch { return; }
    await notifyHandlerTabSession(tab.id, state, 3);
  }));
}

async function injectHandlerIntoOpenTabs(origins) {
  if (!origins?.length) return;
  try {
    const tabs = await chrome.tabs.query({ url: origins });
    await Promise.allSettled(tabs.filter((tab) => Number.isInteger(tab.id)).map((tab) =>
      chrome.tabs.sendMessage(tab.id, { type: 'VAULTCOVE_SESSION_CHANGED' })
    ));
  } catch {}
}

async function safeRegisteredHandler() {
  try { return await chrome.scripting.getRegisteredContentScripts({ ids: [HANDLER_SCRIPT_ID] }); }
  catch { return []; }
}

async function removeLegacyDynamicHandlerRegistration() {
  const registered = await safeRegisteredHandler();
  if (!registered.length) return false;
  try { await chrome.scripting.unregisterContentScripts({ ids: [HANDLER_SCRIPT_ID] }); }
  catch (error) {
    // Another extension worker may have removed it between the read and unregister.
    const message = String(error?.message || error || '');
    if (!/not found|no script|does not exist/i.test(message)) throw error;
  }
  return true;
}

async function syncBrowserIntegration({ injectExisting = false } = {}) {
  return queueBrowserIntegration(async () => {
    // Clean any registration created by VaultCove 0.6.x/0.7.0. The Developer
    // build never calls registerContentScripts; its handler is declared once in
    // manifest.json and Chrome owns that lifecycle.
    await removeLegacyDynamicHandlerRegistration();

    if (BUILD_CHANNEL === 'dev') {
      if (injectExisting) {
        try {
          const tabs = await chrome.tabs.query({ url: [...DEV_HANDLER_ORIGINS] });
          await Promise.allSettled(tabs.filter((tab) => Number.isInteger(tab.id)).map((tab) =>
            chrome.tabs.sendMessage(tab.id, { type: 'VAULTCOVE_SESSION_CHANGED' })
          ));
        } catch {}
      }
      return { enabled: true, origins: [...DEV_HANDLER_ORIGINS], mode: 'manifest' };
    }

    // Store-preflight intentionally remains permission-minimal while this repair
    // is being validated. User-invoked Strict Secure Login continues to work. A
    // future audited Store release can re-introduce optional persistent dynamic
    // registration after browser-level regression coverage is in place.
    const origins = await grantedHandlerOrigins();
    return { enabled: false, origins, mode: 'on-demand' };
  });
}

async function syncAlwaysOnHandlerSetting() {
  const broad = BUILD_CHANNEL === 'dev'
    ? true
    : await chrome.permissions.contains({ origins: [LEGACY_BROAD_HANDLER_ORIGIN] });
  await setSettings({ alwaysOnHandlerEnabled: Boolean(broad), inlineHandlerEnabled: Boolean(broad) });
  return broad;
}

let initializePromise = null;
async function initialize() {
  if (initializePromise) return initializePromise;
  initializePromise = (async () => {
    await hardenStorageAccess();
    await ensureDeviceId();
    const premiumSettings = await getSettings();
    if (!premiumSettings.websiteIconsPremiumDefaultApplied) {
      await setSettings({ websiteIconsEnabled: true, websiteIconsPremiumDefaultApplied: true });
    }
    await syncAlwaysOnHandlerSetting();
    await reconcileFirstRunSetupState();
    await scheduleSessionAutoLock();
    chrome.alarms.create(UPDATE_CHECK_ALARM, { periodInMinutes: 24 * 60 });
    chrome.alarms.create(LICENSE_REFRESH_ALARM, { periodInMinutes: 12 * 60 });
    chrome.alarms.create(EMAIL_NOTICE_RETRY_ALARM, { periodInMinutes: 5 });
    await clearLegacyTrialMetadata();
    await syncBrowserIntegration();
  })();
  try { await initializePromise; } finally { initializePromise = null; }
}

let vaultEnvelopeBroadcastTimer = null;
chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName !== 'local' || (!changes?.[VAULT_STORAGE_KEY] && !changes?.[SETTINGS_STORAGE_KEY])) return;
  clearTimeout(vaultEnvelopeBroadcastTimer);
  vaultEnvelopeBroadcastTimer = setTimeout(() => {
    const reason = changes?.[VAULT_STORAGE_KEY] ? 'vault-changed' : 'settings-changed';
    const propagate = changes?.[VAULT_STORAGE_KEY] ? refreshOpenWebsiteHandlers : broadcastHandlerSessionChanged;
    propagate(reason).catch(() => {});
  }, 60);
});

chrome.runtime.onInstalled.addListener(() => initialize().catch(console.error));
chrome.runtime.onStartup.addListener(() => initialize().catch(console.error));
chrome.permissions.onAdded.addListener(() => { syncAlwaysOnHandlerSetting().then(() => syncBrowserIntegration({ injectExisting: true })).catch(console.error); });
chrome.permissions.onRemoved.addListener(() => { syncAlwaysOnHandlerSetting().then(() => syncBrowserIntegration()).catch(console.error); });
chrome.tabs.onRemoved.addListener((tabId) => { clearOnDemandHandlerTab(tabId).catch(() => {}); clearPendingSecureLaunch(tabId).catch(() => {}); clearNewLoginPrompt(tabId).catch(() => {}); });
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  (async () => {
    const tabs = await getOnDemandHandlerTabs();
    const record = tabs[String(tabId)];
    if (!record) return;
    if (changeInfo.url) {
      const pageUrl = parseWebUrl(changeInfo.url);
      if (!pageUrl || pageUrl.origin !== record.origin) { await clearOnDemandHandlerTab(tabId); return; }
    }
    if (changeInfo.status === 'complete') {
      const pageUrl = parseWebUrl(tab?.url || '');
      if (pageUrl?.origin === record.origin) {
        try {
          await chrome.scripting.executeScript({ target: { tabId, frameIds: [0] }, world: 'ISOLATED', files: ['src/content/handler.js'] });
        } catch {}
      }
    }
  })().catch(() => {});
});

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === 'vaultcove-auto-lock') {
    const expiresAt = await getSessionExpiry();
    if (!expiresAt || Date.now() >= expiresAt) {
      await clearSession();
      await revokeSecureLoginCapabilities();
      await broadcastHandlerSessionChanged('locked');
    } else {
      await scheduleSessionAutoLock(expiresAt);
    }
    return;
  }
  if (alarm.name === UPDATE_CHECK_ALARM) {
    const settings = await getSettings();
    if (settings.updateChecksEnabled) checkForUpdates().catch(() => {});
    return;
  }
  if (alarm.name === LICENSE_REFRESH_ALARM) {
    const client = await getLicenseClientState();
    if (client.refreshToken) refreshLicenseLease().then(() => flushSecurityEmailQueue()).catch(() => {});
    return;
  }
  if (alarm.name === EMAIL_NOTICE_RETRY_ALARM) {
    flushSecurityEmailQueue().catch(() => {});
    return;
  }
});

async function openLoginItem(message, sender) {
  if (!trustedExtensionSender(sender)) throw new Error('Untrusted open-login request.');
  const state = await loadUnlockedVault({ touch: true });
  if (state.state !== 'unlocked') throw new Error('Unlock VaultCove before opening a saved login.');
  const item = state.vault.items.find((candidate) => candidate.id === String(message.itemId || '') && candidate.type === 'login' && !candidate.deletedAt);
  if (!item) throw new Error('Saved login was not found.');
  const guardianQuarantine = guardianQuarantineAssessment(item);
  if (guardianQuarantine.quarantine) throw new Error(`Guardian quarantine blocked this login: ${guardianQuarantine.reason}`);
  if (isUseOnlySharedLogin(item) && sharedAccessIsExpired(item)) throw new Error('This shared login access has expired. Ask the sender to create a new package.');
  if (guardianRequiresReauth(item) && !(await hasSensitiveAccess())) throw new Error('This login requires a fresh master-password check before Secure Login.');
  const target = resolveLoginNavigationTarget(item, { allowHttp: message.allowInsecureHttp === true });
  if (!target) throw new Error('VaultCove could not determine a saved website for this login. Edit the login and add an HTTP or HTTPS website URL.');
  if (target.insecureHttp && message.allowInsecureHttp !== true) throw new Error('Opening an HTTP-only login requires explicit confirmation because the connection is not encrypted.');
  const tab = await chrome.tabs.create({ url: 'about:blank', active: true });
  if (!Number.isInteger(tab.id)) throw new Error('Chrome did not create the login tab.');
  if (!target.insecureHttp) {
    // Arm the one-time credential selection before HTTPS navigation so an extremely
    // fast page cannot query the handler before the selected item is recorded.
    const all = await getPendingSecureLaunches();
    all[String(tab.id)] = { itemId:item.id, expectedHostname:target.url.hostname, createdAt:Date.now(), expiresAt:Date.now()+120000 };
    await savePendingSecureLaunches(all);
  }
  await chrome.tabs.update(tab.id, { url: target.url.toString(), active: true });
  return { tabId:tab.id, hostname:target.url.hostname, insecureHttp:target.insecureHttp };
}

function handlerDisabledForHost(settings, hostname) {
  const host = canonicalHostname(hostname);
  const disabled = Array.isArray(settings?.handlerDisabledHosts) ? settings.handlerDisabledHosts : [];
  return Boolean(host && disabled.some((value) => canonicalHostname(value) === host));
}

async function setHandlerSiteException(hostname, disabled) {
  const host = canonicalHostname(hostname);
  if (!host) throw new Error('Enter a valid website hostname.');
  const settings = await getSettings();
  const current = new Set((settings.handlerDisabledHosts || []).map(canonicalHostname).filter(Boolean));
  if (disabled) current.add(host);
  else current.delete(host);
  const handlerDisabledHosts = [...current].sort();
  await setSettings({ handlerDisabledHosts, alwaysOnHandlerEnabled: true, inlineHandlerEnabled: true });
  await injectHandlerIntoOpenTabs([`https://${host}/*`, `https://www.${host}/*`]);
  return { hostname: host, disabled: Boolean(disabled), handlerDisabledHosts };
}

async function buildPageLoginState(pageUrl, { handlerRequest = false, tabId = null, query = '' } = {}) {
  if (!pageUrl) return { ok: true, supported: false, unlocked: false, matches: [], handlerEnabled: false };

  const [settings, licenseState, state, permission] = await Promise.all([
    getSettings(),
    getLicenseState(),
    loadUnlockedVault({ touch: false }),
    hasHandlerPermissionForUrl(pageUrl)
  ]);
  const newLoginPrompt = Number.isInteger(tabId) ? await pendingNewLoginPrompt(tabId) : null;
  const siteDisabled = handlerDisabledForHost(settings, pageUrl.hostname);
  const isHttps = pageUrl.protocol === 'https:';
  const persistentHandlerEnabled = Boolean(permission && !siteDisabled);
  const onDemandHandlerEnabled = handlerRequest ? await isOnDemandHandlerTab(tabId, pageUrl) : false;
  const handlerEnabled = persistentHandlerEnabled || onDemandHandlerEnabled;

  if (!featureAllowed(licenseState, 'autofill')) {
    return {
      ok: true,
      supported: true,
      unlocked: state.state === 'unlocked',
      enabled: handlerRequest ? handlerEnabled : true,
      handlerEnabled: persistentHandlerEnabled,
      siteDisabled,
      handlerMode: onDemandHandlerEnabled ? 'activeTab' : persistentHandlerEnabled ? 'persistent' : 'off',
      matches: [],
      secureLoginAllowed: isHttps,
      insecureHttp: !isHttps,
      passwordChangeDetectionEnabled: Boolean(settings.passwordChangeDetectionEnabled),
      newLoginCaptureEnabled: Boolean(settings.newLoginCaptureEnabled),
      newLoginPrompt
    };
  }
  if (state.state !== 'unlocked') {
    return {
      ok: true,
      supported: true,
      unlocked: false,
      enabled: handlerRequest ? handlerEnabled : true,
      handlerEnabled: persistentHandlerEnabled,
      siteDisabled,
      handlerMode: onDemandHandlerEnabled ? 'activeTab' : persistentHandlerEnabled ? 'persistent' : 'off',
      matches: [],
      secureLoginAllowed: isHttps,
      insecureHttp: !isHttps,
      passwordChangeDetectionEnabled: Boolean(settings.passwordChangeDetectionEnabled),
      newLoginCaptureEnabled: Boolean(settings.newLoginCaptureEnabled),
      newLoginPrompt
    };
  }

  // GET_PAGE_LOGINS is deliberately read-only. A live handler refresh must never
  // write an older decrypted vault snapshot back over a just-completed Add/import.
  // Stale pending captures are ignored in-memory and are cleaned by normal vault
  // mutation paths instead of by page-state queries.
  const freshCaptures = prunePendingLoginCaptures(state.vault.pendingLoginCaptures);
  void freshCaptures;

  const siteMatchedItems = state.vault.items
    .filter((item) => isHttps ? loginMatchesSite(item, pageUrl.hostname) : insecureHttpLoginMatchesUrl(item, pageUrl))
    .sort((a, b) => Number(Boolean(b.favorite)) - Number(Boolean(a.favorite)) || String(a.name).localeCompare(String(b.name)));

  const search = String(query || '').trim().toLowerCase().slice(0, 160);
  const matchedItems = search
    ? siteMatchedItems.filter((item) => loginMatchesSearch(item, search))
    : siteMatchedItems;

  // Do not mutate siteVisual here. MARK_VISITED_SAVED_SITE owns that write path.
  // Keeping handler-state reads side-effect free is required for lossless real-time
  // refresh after detected-login Add, dashboard edits, and imports.

  const matches = matchedItems.slice(0, 50).map(publicLoginSummary);
  const autoCandidates = isHttps && persistentHandlerEnabled && settings.autoLoginEnabled ? matches.filter((item) => item.autoLogin) : [];
  const launch = Number.isInteger(tabId) ? await pendingSecureLaunch(tabId) : null;
  const launchItem = launch && (!launch.expectedHostname || loginMatchesTrustedHost({ type:'login', urls:[`https://${launch.expectedHostname}/`] }, pageUrl.hostname))
    ? state.vault.items.find((item) => item.id === launch.itemId && loginMatchesSite(item, pageUrl.hostname))
    : null;
  const explicitSecureLoginItemId = launchItem?.id || null;
  return {
    ok: true,
    supported: true,
    unlocked: true,
    enabled: handlerRequest ? handlerEnabled : true,
    handlerEnabled: persistentHandlerEnabled,
    siteDisabled,
    handlerMode: onDemandHandlerEnabled ? 'activeTab' : persistentHandlerEnabled ? 'persistent' : 'off',
    hostname: pageUrl.hostname,
    matchCount: siteMatchedItems.length,
    filteredMatchCount: matchedItems.length,
    matches,
    autoLoginItemId: explicitSecureLoginItemId || (autoCandidates.length === 1 ? autoCandidates[0].id : null),
    explicitSecureLogin: Boolean(explicitSecureLoginItemId),
    secureLoginAllowed: isHttps,
      insecureHttp: !isHttps,
    autoLoginEnabled: Boolean(isHttps && persistentHandlerEnabled && settings.autoLoginEnabled),
    passwordChangeDetectionEnabled: Boolean(settings.passwordChangeDetectionEnabled),
    newLoginCaptureEnabled: Boolean(settings.newLoginCaptureEnabled),
    newLoginPrompt
  };
}
async function pageLoginState(message, sender) {
  if ((sender?.frameId ?? 0) !== 0) {
    return { ok: true, supported: false, unlocked: false, enabled: false, handlerEnabled: false, matches: [], strictSecureLogin: true };
  }
  return buildPageLoginState(frameUrlFromSender(sender), {
    handlerRequest: true,
    tabId: sender?.tab?.id ?? null,
    query: String(message?.query || '')
  });
}

async function activeTabLoginState(message) {
  if (!Number.isInteger(message.tabId)) throw new Error('No active web tab is available.');
  const tab = await chrome.tabs.get(message.tabId);
  return buildPageLoginState(parseWebUrl(tab?.url || ''), { handlerRequest: false, tabId: message.tabId, query: String(message?.query || '') });
}

async function markVisitedSavedSite(sender) {
  const pageUrl = frameUrlFromSender(sender);
  if (!pageUrl) return { marked: 0 };
  if (!(await hasHandlerPermissionForUrl(pageUrl)) && !(await isOnDemandHandlerTab(sender?.tab?.id ?? null, pageUrl))) return { marked: 0 };
  return queueVaultMutation(async () => {
    const state = await loadUnlockedVault({ touch: false });
    if (state.state !== 'unlocked') return { marked: 0 };

    const now = Date.now();
    let marked = 0;
    for (const item of state.vault.items || []) {
      if (!loginMatchesSite(item, pageUrl.hostname)) continue;
      const previous = Date.parse(item.siteVisual?.visitedAt || 0);
      if (item.siteVisual?.host === pageUrl.hostname && previous && now - previous <= 24 * 60 * 60 * 1000) continue;
      item.siteVisual = { host: pageUrl.hostname, visitedAt: new Date(now).toISOString() };
      marked += 1;
    }
    if (marked) await saveUnlockedVault(state.vault, { touch: false });
    return { marked };
  });
}

async function fillCredentialIntoFrame(tabId, frameId, item, { clearAfterMs = 1200 } = {}) {
  if (Number.isInteger(frameId) && frameId !== 0) throw new Error('Strict Secure Login is blocked inside frames. Open the trusted login page in the top-level tab.');
  const target = { tabId, frameIds: [0] };
  const results = await chrome.scripting.executeScript({
    target,
    world: 'ISOLATED',
    func: async (username, password, clearDelayMs) => {
      function visible(el) {
        const rect = el.getBoundingClientRect();
        const style = getComputedStyle(el);
        return rect.width > 0 && rect.height > 0 && style.visibility !== 'hidden' && style.display !== 'none' && !el.disabled && !el.readOnly;
      }
      function setNativeValue(input, value, dispatchEvents) {
        const prototype = input instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
        const descriptor = Object.getOwnPropertyDescriptor(prototype, 'value');
        descriptor?.set?.call(input, value);
        if (input.value !== value) input.value = value;
        if (dispatchEvents) {
          try { input.dispatchEvent(new InputEvent('input', { bubbles: true, composed: true, inputType: 'insertText', data: null })); }
          catch { input.dispatchEvent(new Event('input', { bubbles: true, composed: true })); }
          input.dispatchEvent(new Event('change', { bubbles: true, composed: true }));
        }
      }
      function token(el) {
        return `${el.type || ''} ${el.name || ''} ${el.id || ''} ${el.autocomplete || ''} ${el.placeholder || ''} ${el.getAttribute('aria-label') || ''}`.toLowerCase();
      }
      function openRoots() {
        const roots = [document];
        for (let index = 0; index < roots.length && index < 64; index += 1) {
          for (const node of roots[index].querySelectorAll('*')) {
            if (node.shadowRoot && !roots.includes(node.shadowRoot)) roots.push(node.shadowRoot);
          }
        }
        return roots;
      }
      function queryAll(selector) {
        return openRoots().flatMap((root) => [...root.querySelectorAll(selector)]);
      }
      function findUsername(inputs, passwordInput) {
        const candidates = inputs.filter((el) => el !== passwordInput && ['text', 'email', 'tel', ''].includes((el.type || '').toLowerCase()));
        return candidates.find((el) => {
          const type = (el.type || '').toLowerCase();
          const autocomplete = String(el.autocomplete || '').toLowerCase();
          return type === 'email' || ['username', 'email'].includes(autocomplete) || /(user(?:name)?|e[-_\s]*mail|mail|login|account|identifier|member|phone|mobile|customer|client)/.test(token(el));
        }) || (() => {
          const passwordIndex = inputs.indexOf(passwordInput);
          return passwordIndex > 0 ? [...inputs.slice(0, passwordIndex)].reverse().find((el) => candidates.includes(el)) : candidates[0];
        })();
      }
      function findSubmitControl() {
        const candidates = queryAll('button,input[type="submit"],input[type="button"],a[role="button"]').filter(visible);
        return candidates.find((el) => {
          const label = `${el.textContent || ''} ${el.value || ''} ${el.getAttribute('aria-label') || ''}`.toLowerCase();
          return /(log\s*in|login|sign\s*in|signin|continue|next|submit|proceed)/.test(label);
        }) || null;
      }
      async function submitFrom(field) {
        // Give React/Angular/Vue-style controlled inputs one turn to consume the
        // synthetic input/change events before the site's own click handler runs.
        await new Promise((resolve) => setTimeout(resolve, 0));
        const button = findSubmitControl();
        if (button) { button.click(); return { submitted: true, method: 'button-click' }; }
        const form = field?.form || field?.closest?.('form');
        if (form?.requestSubmit) { form.requestSubmit(); return { submitted: true, method: 'request-submit' }; }
        return { submitted: false, method: 'none' };
      }

      const inputs = queryAll('input').filter(visible);
      const passwordInput = inputs.find((el) => (el.type || '').toLowerCase() === 'password');
      const usernameInput = findUsername(inputs, passwordInput);
      if (!passwordInput && !usernameInput) return { ok: false, reason: 'No supported visible login field was found.' };

      if (usernameInput && username) {
        usernameInput.focus();
        setNativeValue(usernameInput, username, true);
      }
      if (passwordInput) {
        passwordInput.focus();
        // Compatibility events are emitted only inside this one-shot Secure Login
        // transaction and are followed immediately by submit + aggressive clearing.
        setNativeValue(passwordInput, password || '', true);
      }
      const focusTarget = passwordInput || usernameInput;
      const submitResult = await submitFrom(focusTarget);
      if (!submitResult.submitted) {
        if (passwordInput) setNativeValue(passwordInput, '', false);
        return { ok: false, reason: 'Strict Secure Login could not find a safe submit control. The password was cleared instead of being left in the page.' };
      }

      if (passwordInput && password) {
        const injectedPassword = password;
        const clear = () => {
          try {
            if (passwordInput.isConnected && passwordInput.value === injectedPassword) setNativeValue(passwordInput, '', false);
          } catch {}
        };
        document.addEventListener('visibilitychange', () => { if (document.visibilityState !== 'visible') clear(); }, { once: true });
        addEventListener('pagehide', clear, { once: true });
        setTimeout(clear, Math.max(150, Math.min(3000, Number(clearDelayMs) || 650)));
      }
      return {
        ok: true,
        usernameFilled: Boolean(usernameInput && username),
        passwordInjectedForSubmit: Boolean(passwordInput),
        submitted: true,
        submitMethod: submitResult.method,
        strict: true,
        compatibilityEvents: true
      };
    },
    args: [item.username || '', item.password || '', clearAfterMs]
  });
  return results?.[0]?.result || { ok: false, reason: 'Strict Secure Login did not return a result.' };
}

async function handlePageFill(message, sender) {
  if (!Boolean(message.submit)) throw new Error('Password Fill was removed. Use Secure Login so the credential is injected only for immediate submission.');
  const capability = await consumeSecureLoginCapability(message.capability, sender);
  const pageUrl = frameUrlFromSender(sender);
  if (!pageUrl || !sender?.tab?.id || pageUrl.protocol !== 'https:') throw new Error('VaultCove Secure Login works only on HTTPS web pages.');

  const [licenseState, settings, state] = await Promise.all([
    getLicenseState(),
    getSettings(),
    loadUnlockedVault({ touch: false })
  ]);
  if (!featureAllowed(licenseState, 'autofill')) throw new Error('Secure Login is unavailable for this license state.');
  if (state.state !== 'unlocked') throw new Error('VaultCove is locked.');

  const item = state.vault.items.find((candidate) => candidate.id === capability.itemId && !candidate.deletedAt);
  if (!item || !secureLoginMatchesUrl(item, pageUrl)) throw new Error('Blocked: the saved login is not trusted for this exact HTTPS origin.');
  assertGuardianLoginUse(item, pageUrl);
  if (isUseOnlySharedLogin(item) && sharedAccessIsExpired(item)) throw new Error('This shared login access has expired.');
  if (guardianRequiresReauth(item) && !(await hasSensitiveAccess())) throw new Error('Sensitive Access required before Secure Login for this protected credential. Open VaultCove and verify your master password.');

  const automatic = Boolean(capability.automatic);
  if (automatic) {
    if (!settings.autoLoginEnabled || !item.autoLogin) throw new Error('Automatic login is not enabled for this item.');
    if (!(await hasHandlerPermissionForUrl(pageUrl))) throw new Error('Persistent access is not enabled for this website.');
    const stage = capability.stage === 'password' ? 'password' : 'username';
    const guardKey = `autoLoginGuard:${sender.tab.id}:${sender.frameId ?? 0}:${pageUrl.hostname}:${pageUrl.pathname}:${stage}`;
    const guard = await chrome.storage.session.get(guardKey);
    if (Date.now() - Number(guard[guardKey] || 0) < 20000) throw new Error('Automatic login was already attempted on this page recently.');
    await chrome.storage.session.set({ [guardKey]: Date.now() });
  }

  const credential = isUseOnlySharedLogin(item) ? await openSharedLoginForFill(item, state.vaultKey) : item;
  const result = await fillCredentialIntoFrame(sender.tab.id, sender.frameId, credential, { clearAfterMs: settings.secureLoginClearMs });
  if (!automatic) {
    await appendActivityEvent(state.vault, 'secure-login-used', { itemId: item.id, host: pageUrl.hostname, shared: isUseOnlySharedLogin(item) });
    await saveUnlockedVault(state.vault, { touch: false });
    await touchSession();
  }
  return result;
}


async function fillActiveTabLogin(message) {
  if (!Boolean(message.submit)) throw new Error('Password Fill was removed. Use Secure Login.');
  if (!Number.isInteger(message.tabId)) throw new Error('No active tab is available.');
  const tab = await chrome.tabs.get(message.tabId);
  const pageUrl = parseWebUrl(tab?.url || '');
  if (!pageUrl) throw new Error('VaultCove login use is available only on HTTP or HTTPS web pages.');
  const isHttps = pageUrl.protocol === 'https:';
  const [licenseState, settings, state] = await Promise.all([getLicenseState(), getSettings(), loadUnlockedVault({ touch: false })]);
  if (!featureAllowed(licenseState, 'autofill')) throw new Error('Secure Login is unavailable for this license state.');
  if (state.state !== 'unlocked') throw new Error('VaultCove is locked.');
  const item = state.vault.items.find((candidate) => candidate.id === message.itemId && !candidate.deletedAt);
  if (!item) throw new Error('Saved login was not found.');
  if (isHttps) {
    if (!secureLoginMatchesUrl(item, pageUrl)) throw new Error('Blocked: the saved login is not trusted for this exact HTTPS origin.');
  assertGuardianLoginUse(item, pageUrl);
  } else {
    if (message.allowInsecureHttp !== true) throw new Error('HTTP login requires explicit confirmation because the connection is not encrypted.');
    if (isUseOnlySharedLogin(item)) throw new Error('Sender-controlled shared credentials cannot be released to an HTTP page.');
    if (!insecureHttpLoginMatchesUrl(item, pageUrl)) throw new Error('Blocked: HTTP use requires an exact explicitly saved http:// origin.');
    assertGuardianLoginUse(item, pageUrl);
  }
  if (guardianRequiresReauth(item) && !(await hasSensitiveAccess())) throw new Error('Sensitive Access required before login for this protected credential.');
  const credential = isUseOnlySharedLogin(item) ? await openSharedLoginForFill(item, state.vaultKey) : item;
  const result = await fillCredentialIntoFrame(message.tabId, 0, credential, { clearAfterMs: settings.secureLoginClearMs });
  await appendActivityEvent(state.vault, isHttps ? 'secure-login-used' : 'insecure-http-login-used', {
    itemId: item.id,
    host: pageUrl.hostname,
    shared: isUseOnlySharedLogin(item),
    source: 'popup',
    transport: isHttps ? 'https' : 'http'
  });
  await saveUnlockedVault(state.vault, { touch: false });
  await touchSession();
  return result;
}

async function getSensitiveLoginField(message) {
  if (!(await hasSensitiveAccess())) throw new Error('Sensitive Access expired. Re-enter your master password.');
  if (!Number.isInteger(message.tabId)) throw new Error('No active tab is available.');
  const tab = await chrome.tabs.get(message.tabId);
  const pageUrl = parseWebUrl(tab?.url || '');
  if (!pageUrl) throw new Error('Sensitive login values are available only for HTTP or HTTPS web pages.');

  const state = await loadUnlockedVault({ touch: false });
  if (state.state !== 'unlocked') throw new Error('VaultCove is locked.');
  const item = state.vault.items.find((candidate) => candidate.id === message.itemId && !candidate.deletedAt);
  const trusted = item && (pageUrl.protocol === 'https:' ? loginMatchesSite(item, pageUrl.hostname) : insecureHttpLoginMatchesUrl(item, pageUrl));
  if (!trusted) throw new Error('Blocked: this login is not trusted for the active website.');
  if (isUseOnlySharedLogin(item)) throw new Error('This shared credential is use-only. It can sign in through Secure Login but cannot be revealed or copied.');
  if (!['username', 'password'].includes(message.field)) throw new Error('Unsupported sensitive field.');
  await touchSession();
  return { value: String(item[message.field] || '') };
}

async function setSiteHandler(message) {
  if (!Number.isInteger(message.tabId)) throw new Error('No active tab is available.');
  const tab = await chrome.tabs.get(message.tabId);
  const pageUrl = parseHttpsUrl(tab?.url || '');
  if (!pageUrl) throw new Error('Persistent VaultCove access is available only for HTTPS websites.');
  const origin = permissionOriginForHost(pageUrl.hostname);
  if (!message.enabled) {
    await chrome.permissions.remove({ origins: [origin] });
    await syncBrowserIntegration();
    return { enabled: false, origin };
  }
  const granted = await chrome.permissions.contains({ origins: [origin] });
  if (!granted) throw new Error('Website permission must be granted by the user from the VaultCove popup.');
  await syncBrowserIntegration({ injectExisting: true });
  return { enabled: true, origin };
}

async function siteHandlerState(message) {
  if (!Number.isInteger(message.tabId)) return { enabled: false, supported: false };
  const tab = await chrome.tabs.get(message.tabId);
  const pageUrl = parseHttpsUrl(tab?.url || '');
  if (!pageUrl) return { enabled: false, supported: false };
  const settings = await getSettings();
  const siteDisabled = handlerDisabledForHost(settings, pageUrl.hostname);
  return { enabled: (await hasHandlerPermissionForUrl(pageUrl)) && !siteDisabled, siteDisabled, supported: true, origin: permissionOriginForHost(pageUrl.hostname), hostname: pageUrl.hostname };
}

async function removeAllSiteHandlers() {
  const origins = await grantedHandlerOrigins();
  if (origins.length) await chrome.permissions.remove({ origins });
  await setSettings({ autoLoginEnabled: false });
  await syncBrowserIntegration();
  return { removed: origins.length };
}

function normalizeUsername(value) {
  return String(value || '').trim().toLowerCase();
}

async function showPasswordChangeNotification(itemId) {
  await chrome.notifications.create(`${PASSWORD_NOTICE_PREFIX}${itemId}`, {
    type: 'basic',
    iconUrl: 'icons/icon128.png',
    title: 'VaultCove password change detected',
    message: 'A saved login appears to have a new password. Review it in VaultCove. No password or account details are sent by email.',
    buttons: [{ title: 'Review in VaultCove' }],
    priority: 2
  });
}

async function handlePasswordChangeCandidate(message, sender) {
  const pageUrl = frameUrlFromSender(sender);
  if (!pageUrl || !sender?.tab?.id) return { detected: false };
  const settings = await getSettings();
  const persistentHandlerEnabled = Boolean((await hasHandlerPermissionForUrl(pageUrl)) && !handlerDisabledForHost(settings, pageUrl.hostname));
  const onDemandHandlerEnabled = await isOnDemandHandlerTab(sender.tab.id, pageUrl);
  if (!settings.passwordChangeDetectionEnabled || (!persistentHandlerEnabled && !onDemandHandlerEnabled)) return { detected: false };

  const candidate = validateCaptureCandidate(message, { requireUsername: false });
  if (!candidate.ok || !['high', 'submitted-login'].includes(candidate.confidence)) return { detected: false, reason: candidate.reason || 'invalid-candidate' };
  const limited = await consumeCaptureBudget(pageUrl.origin);
  if (!limited.allowed) return { detected: false, reason: limited.reason };

  return queueVaultMutation(async () => {
    const state = await loadUnlockedVault({ touch: false });
    if (state.state !== 'unlocked') return { detected: false };
    let matches = state.vault.items.filter((item) => (pageUrl.protocol === 'https:' ? loginMatchesSite(item, pageUrl.hostname) : insecureHttpLoginMatchesUrl(item, pageUrl)) && !isUseOnlySharedLogin(item));
    const username = normalizeUsername(candidate.username);
    let usernameMatches = [];
    if (username) {
      usernameMatches = matches.filter((item) => normalizeUsername(item.username) === username);
      if (usernameMatches.length) matches = usernameMatches;
    }
    if (candidate.confidence === 'submitted-login' && (!username || usernameMatches.length !== 1)) return { detected: false };
    if (matches.length !== 1) return { detected: false };

    const item = matches[0];
    if (item.password === candidate.password || item.pendingPasswordChange?.password === candidate.password) return { detected: false };
    const changedAt = new Date().toISOString();

    // Only high-confidence password-change forms are accepted automatically.
    // Ordinary login submissions remain review candidates so a typo or failed
    // sign-in cannot silently replace the saved credential.
    if (candidate.confidence === 'high') {
      if (item.password) {
        item.passwordHistory = [...(Array.isArray(item.passwordHistory) ? item.passwordHistory : []), {
          password: item.password,
          changedAt
        }].slice(-10);
      }
      item.password = candidate.password;
      item.pendingPasswordChange = null;
      item.lastPasswordChangeAt = changedAt;
      await appendActivityEvent(state.vault, 'password-change-auto-updated', {
        itemId: item.id,
        host: pageUrl.hostname,
        source: candidate.reason || 'high-confidence-password-form'
      });
      appendGuardianReceipt(state.vault, createGuardianReceipt({
        item,
        eventKind:'password-changed',
        occurredAt:changedAt,
        deviceLabel:`${navigator.platform || 'Browser'} / Chrome`,
        host:pageUrl.hostname,
        notification:'security-email-queued'
      }));
      await saveUnlockedVault(state.vault, { touch: false });
      const emailNotice = await queueGenericEmailNotice('password-changed', {
        siteHost: pageUrl.hostname,
        occurredAt: changedAt
      });
      return {
        detected: true,
        autoUpdated: true,
        itemId: item.id,
        changedAt,
        emailQueued: Boolean(emailNotice.queued)
      };
    }

    item.pendingPasswordChange = {
      password: candidate.password,
      detectedAt: changedAt,
      hostname: pageUrl.hostname,
      source: candidate.reason || 'submitted-login-password',
      confidence: candidate.confidence
    };
    await appendActivityEvent(state.vault, 'password-change-candidate', { itemId: item.id, host: pageUrl.hostname, confidence: candidate.confidence });
    await saveUnlockedVault(state.vault, { touch: false });
    await showPasswordChangeNotification(item.id);
    return { detected: true, itemId: item.id, reviewRequired: true };
  });
}

async function showNewLoginNotification(captureId) {
  await chrome.notifications.create(`${NEW_LOGIN_NOTICE_PREFIX}${captureId}`, {
    type: 'basic',
    iconUrl: 'icons/icon128.png',
    title: 'VaultCove new login detected',
    message: 'A submitted login is not yet saved in VaultCove. Review it before adding it to your encrypted vault.',
    buttons: [{ title: 'Review in VaultCove' }],
    priority: 1
  });
}

async function handleNewLoginCandidate(message, sender) {
  const pageUrl = frameUrlFromSender(sender);
  if (!pageUrl || !sender?.tab?.id) return { detected: false };
  const settings = await getSettings();
  const persistentHandlerEnabled = Boolean((await hasHandlerPermissionForUrl(pageUrl)) && !handlerDisabledForHost(settings, pageUrl.hostname));
  const onDemandHandlerEnabled = await isOnDemandHandlerTab(sender.tab.id, pageUrl);
  if (!settings.newLoginCaptureEnabled || (!persistentHandlerEnabled && !onDemandHandlerEnabled)) return { detected: false };

  const candidate = validateCaptureCandidate(message);
  if (!candidate.ok) return { detected: false, reason: candidate.reason };
  const limited = await consumeCaptureBudget(pageUrl.origin);
  if (!limited.allowed) return { detected: false, reason: limited.reason };

  const state = await loadUnlockedVault({ touch: false });
  if (state.state !== 'unlocked') {
    const capture = createPendingLoginCapture({
      hostname: pageUrl.hostname,
      origin: pageUrl.origin,
      username: candidate.username,
      password: candidate.password,
      name: candidate.pageTitle || pageUrl.hostname,
      source: candidate.reason || 'submitted-credential'
    });
    const queued = await sealCaptureWhileLocked(capture);
    if (!queued.queued) return { detected: false, reason: queued.reason || 'locked-capture-unavailable' };
    const prompt = await setNewLoginPrompt(sender.tab.id, capture, { queuedWhileLocked: true });
    return { detected: true, captureId: capture.id, queuedWhileLocked: true, newLoginPrompt: prompt };
  }
  return queueVaultMutation(async () => {
    // Re-load after entering the mutation queue. The state captured before waiting
    // may already be obsolete if another tab just edited/imported the vault.
    const fresh = await loadUnlockedVault({ touch: false });
    if (fresh.state !== 'unlocked') return { detected: false, reason: 'vault-locked-during-capture' };

    const sharedMatches = pageUrl.protocol === 'https:' ? fresh.vault.items.filter((item) => isUseOnlySharedLogin(item) && loginMatchesSite(item, pageUrl.hostname)) : [];
    for (const sharedItem of sharedMatches) {
      try {
        const credential = await openSharedLoginForFill(sharedItem, fresh.vaultKey);
        if (normalizeUsername(credential.username) === normalizeUsername(candidate.username) && String(credential.password || '') === candidate.password) {
          return { detected: false, reason: 'shared-use-only-login' };
        }
      } catch {}
    }
    if (findExistingLoginForCapture(fresh.vault.items.filter((item) => !isUseOnlySharedLogin(item)), pageUrl.hostname, candidate.username, pageUrl.origin)) {
      return { detected: false, reason: 'existing-login' };
    }

    const capture = createPendingLoginCapture({
      hostname: pageUrl.hostname,
      origin: pageUrl.origin,
      username: candidate.username,
      password: candidate.password,
      name: candidate.pageTitle || pageUrl.hostname,
      source: candidate.reason || 'submitted-credential'
    });

    // Keep a short-lived RSA/AES sealed fallback for the exact candidate even while
    // the vault is currently unlocked. loadUnlockedVault() drains this fallback into
    // pendingLoginCaptures before Add is processed. If another extension context
    // replaced an older encrypted envelope between detection and click, the user's
    // explicit Add can still recover the candidate instead of falsely succeeding.
    await sealCaptureWhileLocked(capture);
    const pending = prunePendingLoginCaptures(fresh.vault.pendingLoginCaptures);
    const duplicate = pending.find((entry) => samePendingLoginCapture(entry, capture));
    if (duplicate) return { detected: false, reason: 'already-pending', captureId: duplicate.id };

    fresh.vault.pendingLoginCaptures = [...pending, capture].slice(-50);
    await appendActivityEvent(fresh.vault, 'new-login-candidate', { captureId: capture.id, host: pageUrl.hostname });
    await saveUnlockedVault(fresh.vault, { touch: false });
    const prompt = await setNewLoginPrompt(sender.tab.id, capture);
    return { detected: true, captureId: capture.id, newLoginPrompt: prompt };
  });
}

async function flushSecurityEmailQueue() {
  const settings = await getSettings();
  const client = await getLicenseClientState();
  const existing = await chrome.storage.local.get(EMAIL_NOTICE_QUEUE_KEY);
  const queue = Array.isArray(existing[EMAIL_NOTICE_QUEUE_KEY]) ? existing[EMAIL_NOTICE_QUEUE_KEY] : [];
  if (!queue.length) return { sent: 0, remaining: 0 };

  const remaining = [];
  let sent = 0;
  for (const notice of queue) {
    const mandatorySecurityNotice = ['password-changed','protected-record-updated','protected-record-removed','passwords-shared'].includes(notice.kind);
    if (!mandatorySecurityNotice && !settings.securityEmailNoticeEnabled) continue;
    try {
      await sendSecurityNotice({
        noticeId: notice.id,
        eventKind: notice.kind,
        occurredAt: notice.occurredAt,
        siteHost: notice.siteHost || '',
        timeZone: notice.timeZone || '',
        recordType: notice.recordType || '',
        shareCount: Number(notice.shareCount || 0),
        recipientHint: notice.recipientHint || ''
      });
      sent += 1;
    } catch {
      // Keep the notice for retry when the signed license transport or network is
      // temporarily unavailable. Password-change alerts are never discarded just
      // because the legacy raw serial wrapper cannot be reopened.
      if (client.lease || client.refreshToken || client.hasEncryptedRefreshToken) remaining.push(notice);
    }
  }
  await chrome.storage.local.set({ [EMAIL_NOTICE_QUEUE_KEY]: remaining.slice(-100) });
  return { sent, remaining: remaining.length };
}

function currentIanaTimeZone() {
  try { return String(Intl.DateTimeFormat().resolvedOptions().timeZone || '').slice(0, 64); }
  catch { return ''; }
}

async function queueGenericEmailNotice(kind = 'password-changed', { siteHost = '', occurredAt = '', recordType = '', shareCount = 0, recipientHint = '' } = {}) {
  const settings = await getSettings();
  const mandatorySecurityNotice = ['password-changed','protected-record-updated','protected-record-removed','passwords-shared'].includes(kind);
  if (!mandatorySecurityNotice && !settings.securityEmailNoticeEnabled) return { queued: false, reason: 'disabled' };
  if (!mandatorySecurityNotice) {
    const recipientEmail = String(settings.securityNoticeEmail || '').trim();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(recipientEmail) || recipientEmail.length > 254) {
      return { queued: false, reason: 'email-not-configured' };
    }
  }
  const deviceId = await ensureDeviceId();
  const notice = createGenericSecurityNotice(kind, occurredAt || new Date().toISOString());
  const existing = await chrome.storage.local.get(EMAIL_NOTICE_QUEUE_KEY);
  const queue = Array.isArray(existing[EMAIL_NOTICE_QUEUE_KEY]) ? existing[EMAIL_NOTICE_QUEUE_KEY] : [];
  queue.push({
    ...notice,
    deviceId,
    siteHost: kind === 'password-changed' ? String(siteHost || '').trim().toLowerCase().slice(0, 253) : '',
    timeZone: currentIanaTimeZone(),
    recordType: ['card','bank','identity'].includes(String(recordType || '').toLowerCase()) ? String(recordType).toLowerCase() : '',
    shareCount: Math.max(0, Math.min(50, Number(shareCount) || 0)),
    recipientHint: String(recipientHint || '').trim().slice(0, 120)
  });
  await chrome.storage.local.set({ [EMAIL_NOTICE_QUEUE_KEY]: queue.slice(-100) });
  // Best-effort immediate background delivery. If offline or Apps Script is
  // temporarily unavailable, the alarm retries every five minutes.
  flushSecurityEmailQueue().catch(() => {});
  return { queued: true, transport: 'background-license-service' };
}

async function openPasswordReview(itemId = '') {
  const params = new URLSearchParams({ view: 'security' });
  if (itemId) params.set('passwordChange', itemId);
  await chrome.tabs.create({ url: chrome.runtime.getURL(`src/vault/vault.html?${params}`) });
}

async function openNewLoginReview(captureId = '') {
  const params = new URLSearchParams({ view: 'security' });
  if (captureId) params.set('newLogin', captureId);
  await chrome.tabs.create({ url: chrome.runtime.getURL(`src/vault/vault.html?${params}`) });
}

chrome.notifications.onClicked.addListener((notificationId) => {
  if (notificationId.startsWith(PASSWORD_NOTICE_PREFIX)) {
    openPasswordReview(notificationId.slice(PASSWORD_NOTICE_PREFIX.length)).catch(console.error);
  } else if (notificationId.startsWith(NEW_LOGIN_NOTICE_PREFIX)) {
    openNewLoginReview(notificationId.slice(NEW_LOGIN_NOTICE_PREFIX.length)).catch(console.error);
  }
});
chrome.notifications.onButtonClicked.addListener((notificationId) => {
  if (notificationId.startsWith(PASSWORD_NOTICE_PREFIX)) {
    openPasswordReview(notificationId.slice(PASSWORD_NOTICE_PREFIX.length)).catch(console.error);
  } else if (notificationId.startsWith(NEW_LOGIN_NOTICE_PREFIX)) {
    openNewLoginReview(notificationId.slice(NEW_LOGIN_NOTICE_PREFIX.length)).catch(console.error);
  }
});


async function openHandlerUnlock(sender) {
  const sourceTabId = sender?.tab?.id;
  const sourceUrl = frameUrlFromSender(sender);
  if (!Number.isInteger(sourceTabId) || !sourceUrl) throw new Error('VaultCove could not identify the login tab requesting unlock.');
  const url = new URL(chrome.runtime.getURL('src/vault/vault.html'));
  url.searchParams.set('flow', HANDLER_UNLOCK_FLOW);
  url.searchParams.set('sourceTab', String(sourceTabId));
  url.searchParams.set('sourceOrigin', sourceUrl.origin);
  const tab = await chrome.tabs.create({ url: url.toString(), active: true });
  return { opened: true, tabId: tab.id };
}

async function completeHandlerUnlock(message, sender) {
  if (!trustedExtensionSender(sender)) throw new Error('Untrusted handler unlock completion request.');
  const sourceTabId = Number(message?.sourceTabId);
  const expectedOrigin = String(message?.sourceOrigin || '');
  if (!Number.isInteger(sourceTabId)) throw new Error('The original login tab is unavailable.');
  const sourceTab = await chrome.tabs.get(sourceTabId);
  const sourceUrl = parseHttpsUrl(sourceTab?.url || '');
  if (!sourceUrl || (expectedOrigin && sourceUrl.origin !== expectedOrigin)) throw new Error('The original login page changed before VaultCove was unlocked.');
  let acknowledged = await notifyHandlerTabSession(sourceTabId, 'unlocked', 6);
  if (!acknowledged) {
    // If Chrome suspended/reloaded the content script while the unlock tab was
    // open, re-attach the guarded handler once and require a fresh handshake.
    try {
      await chrome.scripting.executeScript({ target: { tabId: sourceTabId, frameIds: [0] }, world: 'ISOLATED', files: ['src/content/handler.js'] });
    } catch {}
    acknowledged = await notifyHandlerTabSession(sourceTabId, 'unlocked', 4);
  }
  if (!acknowledged) throw new Error('VaultCove unlocked, but the original login page did not acknowledge the new session. Keep this tab open and try again.');
  const unlockTabId = sender?.tab?.id;
  if (Number.isInteger(unlockTabId) && unlockTabId !== sourceTabId) {
    setTimeout(() => chrome.tabs.remove(unlockTabId).catch(() => {}), 80);
  }
  return { completed: true, sourceTabId, handlerAcknowledged: true };
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const validation = validateRuntimeMessage(message);
  if (!validation.ok) {
    sendResponse({ ok: false, error: validation.error });
    return false;
  }
  const senderKind = runtimeSenderKind(sender);
  if (!runtimeMessageSourceAllowed(message.type, senderKind)) {
    sendResponse({ ok: false, error: 'VaultCove rejected a runtime message from an untrusted source.' });
    return false;
  }
  if (message?.type === 'LOCK_VAULT') {
    clearSession()
      .then(() => revokeSecureLoginCapabilities())
      .then(() => broadcastHandlerSessionChanged('locked'))
      .then(() => sendResponse({ ok: true }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'GET_VAULT_STATE') {
    loadUnlockedVault({ touch: false }).then((state) => sendResponse({ ok: true, state: state.state })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'INITIALIZE_VAULT') {
    beginFirstRunSetup()
      .then(() => initializeVault(String(message.masterPassword || '')))
      .then(async () => {
        await setSettings({
          firstRunSecurityComplete: false,
          lockMinutes: 5,
          alwaysOnHandlerEnabled: true,
          newLoginCaptureEnabled: true,
          passwordChangeDetectionEnabled: true,
          securityEmailNoticeEnabled: true,
          securityNoticeEmail: '',
          websiteIconsEnabled: true,
          websiteIconsPremiumDefaultApplied: true
        });
        sendResponse({ ok: true, firstRunSecurityRequired: true });
      })
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'UNLOCK_VAULT') {
    queueMasterAuth(() => runMasterAuthGuarded(async () => {
      const unlockedVault = await unlockVault(String(message.masterPassword || ''), String(message.secondFactor || ''));
      await fulfillRequestedNewLoginSaves(unlockedVault);
      await broadcastHandlerSessionChanged('unlocked');
    })).then(() => sendResponse({ ok: true })).catch((error) => sendResponse(authErrorResponse(error)));
    return true;
  }
  if (message?.type === 'FILL_ACTIVE_TAB_LOGIN') {
    fillActiveTabLogin(message).then((result) => sendResponse({ ok: true, ...result })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'ENABLE_ONDEMAND_HANDLER') {
    if (!trustedExtensionSender(sender)) { sendResponse({ ok: false, error: 'Untrusted handler request.' }); return false; }
    injectOnDemandHandler(message.tabId).then((result) => sendResponse({ ok: true, ...result })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'SYNC_BROWSER_INTEGRATION') {
    syncBrowserIntegration({ injectExisting: Boolean(message.injectExisting) }).then((result) => sendResponse({ ok: true, ...result })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'VAULT_DATA_CHANGED') {
    // The encrypted vault changed in an extension page (manual add/edit/import).
    // Refresh existing content handlers in-place so current webpages immediately
    // recognize newly available login matches without a browser-page reload.
    refreshOpenWebsiteHandlers('vault-changed')
      .then(() => sendResponse({ ok: true }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'MARK_VISITED_SAVED_SITE') {
    markVisitedSavedSite(sender).then((result) => sendResponse({ ok: true, ...result })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'GET_PAGE_LOGINS') {
    pageLoginState(message, sender).then(sendResponse).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'GET_ACTIVE_TAB_LOGINS') {
    activeTabLoginState(message).then(sendResponse).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'ISSUE_SECURE_LOGIN_CAPABILITY') {
    issueSecureLoginCapability(message, sender).then((result) => sendResponse({ ok: true, ...result })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'FILL_PAGE_LOGIN') {
    handlePageFill(message, sender).then((result) => sendResponse({ ok: true, ...result })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'VERIFY_SENSITIVE_ACCESS') {
    queueMasterAuth(() => runMasterAuthGuarded(() => verifySensitiveAccess(String(message.masterPassword || ''), null, String(message.secondFactor || '')))).then((until) => sendResponse({ ok: true, until })).catch((error) => sendResponse(authErrorResponse(error)));
    return true;
  }
  if (message?.type === 'CHECK_MASTER_PASSWORD_MATCH') {
    if (!trustedExtensionSender(sender)) { sendResponse({ ok: false, error: 'Untrusted master-password comparison request.' }); return false; }
    queueMasterAuth(async () => { await assertMasterAuthAllowed(); const matches = await matchesCurrentMasterPassword(String(message.candidate || '')); if (!matches) { const throttle = await recordMasterAuthFailure(); if (throttle.retryAfterMs > 0) { const error = new Error(`Too many incorrect Master Password attempts. Try again in ${Math.ceil(throttle.retryAfterMs / 1000)} seconds.`); error.code='MASTER_AUTH_COOLDOWN'; error.retryAfterMs=throttle.retryAfterMs; error.blockedUntil=throttle.blockedUntil; throw error; } return false; } await clearMasterAuthFailures(); return true; }).then((matches) => sendResponse({ ok: true, matches })).catch((error) => sendResponse(authErrorResponse(error)));
    return true;
  }
  if (message?.type === 'SENSITIVE_ACCESS_STATUS') {
    hasSensitiveAccess().then((active) => sendResponse({ ok: true, active })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'GET_SENSITIVE_LOGIN_FIELD') {
    getSensitiveLoginField(message).then((result) => sendResponse({ ok: true, ...result })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'NEW_LOGIN_CANDIDATE') {
    handleNewLoginCandidate(message, sender).then((result) => sendResponse({ ok: true, ...result })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'SAVE_NEW_LOGIN_CAPTURE') {
    handleSaveNewLoginCapture(message, sender).then((result) => sendResponse({ ok: true, ...result })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'DISMISS_NEW_LOGIN_CAPTURE') {
    handleDismissNewLoginCapture(message, sender).then((result) => sendResponse({ ok: true, ...result })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'PASSWORD_CHANGE_CANDIDATE') {
    handlePasswordChangeCandidate(message, sender).then((result) => sendResponse({ ok: true, ...result })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'PROTECTED_RECORD_CHANGED') {
    queueGenericEmailNotice('protected-record-changed')
      .then((notice) => sendResponse({ ok: true, ...notice }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'SECURITY_EVENT_NOTICE') {
    queueGenericEmailNotice(String(message.eventKind || ''), {
      recordType:String(message.recordType || ''),
      shareCount:Number(message.shareCount || 0),
      recipientHint:String(message.recipientHint || ''),
      occurredAt:String(message.occurredAt || '')
    })
      .then((notice) => sendResponse({ ok: true, ...notice }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'PASSWORD_CHANGE_CONFIRMED') {
    queueGenericEmailNotice('password-changed', { siteHost:String(message.hostname || ''), occurredAt:String(message.occurredAt || '') })
      .then((notice) => sendResponse({ ok: true, ...notice }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'SET_SITE_HANDLER') {
    setSiteHandler(message).then((result) => sendResponse({ ok: true, ...result })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'GET_SITE_HANDLER_STATE') {
    siteHandlerState(message).then((result) => sendResponse({ ok: true, ...result })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'LIST_SITE_HANDLERS') {
    grantedHandlerOrigins().then((origins) => sendResponse({ ok: true, origins })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'REMOVE_ALL_SITE_HANDLERS') {
    removeAllSiteHandlers().then((result) => sendResponse({ ok: true, ...result })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'SYNC_ALWAYS_ON_HANDLER') {
    syncAlwaysOnHandlerSetting().then(async (enabled) => {
      const result = await syncBrowserIntegration({ injectExisting: Boolean(message.injectExisting) });
      sendResponse({ ok: true, enabled, ...result });
    }).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'SET_HANDLER_SITE_EXCEPTION') {
    setHandlerSiteException(String(message.hostname || ''), Boolean(message.disabled))
      .then((result) => sendResponse({ ok: true, ...result }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'LIST_HANDLER_SITE_EXCEPTIONS') {
    getSettings().then((settings) => sendResponse({ ok: true, handlerDisabledHosts: settings.handlerDisabledHosts || [] }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'CHECK_FOR_UPDATES') {
    checkForUpdates({ force: Boolean(message.force) }).then((result) => sendResponse({ ok: true, ...result })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'OPEN_LOGIN_ITEM') {
    openLoginItem(message, sender).then((result) => sendResponse({ ok: true, ...result })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'OPEN_HANDLER_UNLOCK') {
    openHandlerUnlock(sender).then((result) => sendResponse({ ok: true, ...result })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'COMPLETE_HANDLER_UNLOCK') {
    completeHandlerUnlock(message, sender).then((result) => sendResponse({ ok: true, ...result })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'OPEN_DASHBOARD') {
    chrome.tabs.create({ url: chrome.runtime.getURL('src/vault/vault.html') }).then(() => sendResponse({ ok: true })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  return false;
});

initialize().catch(console.error);
