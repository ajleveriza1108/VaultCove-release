export const BUILD_CHANNEL = 'dev';
export const DEV_UPDATE_ENABLED = BUILD_CHANNEL === 'dev';
export const UPDATE_METADATA_URL = 'https://raw.githubusercontent.com/ajleveriza1108/VaultCove-release/main/latest.json';
export const UPDATE_REPOSITORY = 'ajleveriza1108/VaultCove-release';

export const OFFICIAL_CHROME_WEB_STORE_ID = 'dpbmpmnibbpimedfmanoabihipdfdfko';
