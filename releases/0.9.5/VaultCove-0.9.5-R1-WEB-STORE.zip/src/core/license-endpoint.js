// VaultCove production licensing transport.
// The Apps Script /exec endpoint is public client configuration, not a secret.
// Payhip Product Secret, license pepper, RSA private key, and owner/admin raw key remain server-side only.
export const LICENSE_SERVICE_ENDPOINT = 'https://script.google.com/macros/s/AKfycbxXQklcX0X54lz8ygXsWyE7oPQAYQSKhNHO3BO3GQecS99vBhhIPbAovP7NEjP0MG71iw/exec';
