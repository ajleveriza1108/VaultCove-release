import { bytesToBase64Url, base64UrlToBytes, randomBytes } from './encoding.js';

const PUBLIC_KEY_STORAGE = 'vaultcoveCaptureInboxPublicKey';
const QUEUE_STORAGE = 'vaultcoveLockedCaptureInbox';
const AAD = new TextEncoder().encode('VaultCove locked capture inbox v1');
const MAX_QUEUE = 50;

function jsonClone(value) {
  return JSON.parse(JSON.stringify(value));
}

async function importPublicKey(jwk) {
  return crypto.subtle.importKey('jwk', jwk, { name: 'RSA-OAEP', hash: 'SHA-256' }, false, ['encrypt']);
}

async function importPrivateKey(jwk) {
  return crypto.subtle.importKey('jwk', jwk, { name: 'RSA-OAEP', hash: 'SHA-256' }, false, ['decrypt']);
}

async function importAesKey(raw, usages) {
  return crypto.subtle.importKey('raw', raw, { name: 'AES-GCM' }, false, usages);
}

export async function ensureCaptureInboxIdentity(vault) {
  vault.security = { ...(vault.security || {}) };
  const current = vault.security.captureInbox;
  if (current?.privateJwk && current?.publicJwk) {
    await chrome.storage.local.set({ [PUBLIC_KEY_STORAGE]: jsonClone(current.publicJwk) });
    return { changed: false, identity: current };
  }

  const pair = await crypto.subtle.generateKey(
    { name: 'RSA-OAEP', modulusLength: 2048, publicExponent: new Uint8Array([1, 0, 1]), hash: 'SHA-256' },
    true,
    ['encrypt', 'decrypt']
  );
  const identity = {
    version: 1,
    publicJwk: await crypto.subtle.exportKey('jwk', pair.publicKey),
    privateJwk: await crypto.subtle.exportKey('jwk', pair.privateKey),
    createdAt: new Date().toISOString()
  };
  vault.security.captureInbox = identity;
  await chrome.storage.local.set({ [PUBLIC_KEY_STORAGE]: jsonClone(identity.publicJwk) });
  return { changed: true, identity };
}

export async function sealCaptureWhileLocked(capture) {
  const stored = await chrome.storage.local.get(PUBLIC_KEY_STORAGE);
  const publicJwk = stored[PUBLIC_KEY_STORAGE];
  if (!publicJwk) return { queued: false, reason: 'capture-inbox-not-initialized' };

  const publicKey = await importPublicKey(publicJwk);
  const aesRaw = randomBytes(32);
  const aesKey = await importAesKey(aesRaw, ['encrypt']);
  const iv = randomBytes(12);
  const plaintext = new TextEncoder().encode(JSON.stringify(capture));
  const cipher = new Uint8Array(await crypto.subtle.encrypt({ name: 'AES-GCM', iv, additionalData: AAD }, aesKey, plaintext));
  const wrappedKey = new Uint8Array(await crypto.subtle.encrypt({ name: 'RSA-OAEP' }, publicKey, aesRaw));
  const envelope = {
    version: 1,
    captureId: String(capture?.id || '').slice(0, 200),
    wrappedKey: bytesToBase64Url(wrappedKey),
    iv: bytesToBase64Url(iv),
    cipher: bytesToBase64Url(cipher),
    queuedAt: new Date().toISOString()
  };
  const result = await chrome.storage.local.get(QUEUE_STORAGE);
  const queue = Array.isArray(result[QUEUE_STORAGE]) ? result[QUEUE_STORAGE] : [];
  await chrome.storage.local.set({ [QUEUE_STORAGE]: [...queue, envelope].slice(-MAX_QUEUE) });
  return { queued: true };
}


export async function discardLockedCapture(captureId) {
  const id = String(captureId || '').trim();
  if (!id) return { discarded: false };
  const result = await chrome.storage.local.get(QUEUE_STORAGE);
  const queue = Array.isArray(result[QUEUE_STORAGE]) ? result[QUEUE_STORAGE] : [];
  const filtered = queue.filter((entry) => String(entry?.captureId || '') !== id);
  const discarded = filtered.length !== queue.length;
  if (discarded) {
    if (filtered.length) await chrome.storage.local.set({ [QUEUE_STORAGE]: filtered.slice(-MAX_QUEUE) });
    else await chrome.storage.local.remove(QUEUE_STORAGE);
  }
  return { discarded };
}

export async function drainLockedCaptureInbox(vault) {
  const result = await chrome.storage.local.get(QUEUE_STORAGE);
  const queue = Array.isArray(result[QUEUE_STORAGE]) ? result[QUEUE_STORAGE] : [];
  if (!queue.length) return { captures: [], changed: false };
  const identity = vault?.security?.captureInbox;
  if (!identity?.privateJwk) return { captures: [], changed: false };

  const privateKey = await importPrivateKey(identity.privateJwk);
  const captures = [];
  const failed = [];
  for (const envelope of queue) {
    try {
      if (Number(envelope?.version) !== 1) throw new Error('Unsupported capture inbox envelope.');
      const aesRaw = new Uint8Array(await crypto.subtle.decrypt({ name: 'RSA-OAEP' }, privateKey, base64UrlToBytes(envelope.wrappedKey)));
      const aesKey = await importAesKey(aesRaw, ['decrypt']);
      const clear = await crypto.subtle.decrypt(
        { name: 'AES-GCM', iv: base64UrlToBytes(envelope.iv), additionalData: AAD },
        aesKey,
        base64UrlToBytes(envelope.cipher)
      );
      const capture = JSON.parse(new TextDecoder().decode(clear));
      captures.push(capture);
    } catch {
      failed.push(envelope);
    }
  }
  if (failed.length) await chrome.storage.local.set({ [QUEUE_STORAGE]: failed.slice(-MAX_QUEUE) });
  else await chrome.storage.local.remove(QUEUE_STORAGE);
  return { captures, changed: captures.length > 0, failed: failed.length };
}

export async function lockedCaptureInboxCount() {
  const result = await chrome.storage.local.get(QUEUE_STORAGE);
  return Array.isArray(result[QUEUE_STORAGE]) ? result[QUEUE_STORAGE].length : 0;
}
