import { TESTING_FULL_ACCESS } from './constants.js';
import { ensureDeviceId } from './storage.js';
import { getLicenseClientState } from './license-service.js';
import {
  CORE_FEATURES,
  FREE_PLAN,
  PREMIUM_MAX_DEVICES,
  PREMIUM_PLAN,
  isPremiumFeature
} from './product-plan.js';

function leaseIsUsable(client, deviceId) {
  const lease = client?.lease;
  if (!lease || String(lease.product || '') !== 'VaultCove') return false;
  if (String(lease.installationId || '') !== String(deviceId || '')) return false;
  if (String(lease.status || '').toLowerCase() !== 'active') return false;
  const expiresAt = Date.parse(lease.expiresAt || '');
  if (!Number.isFinite(expiresAt) || expiresAt <= Date.now()) return false;
  return Boolean(client.leaseVerified);
}

export async function getLicenseState() {
  const deviceId = await ensureDeviceId();
  const client = await getLicenseClientState();

  if (leaseIsUsable(client, deviceId)) {
    const licenseType = String(client.lease.licenseType || 'standard').toLowerCase();
    const unlimitedDevices = licenseType === 'admin';
    return {
      mode: 'production',
      status: 'full',
      plan: PREMIUM_PLAN,
      premium: true,
      deviceId,
      maxDevices: unlimitedDevices ? 0 : (Number(client.lease.maxDevices || PREMIUM_MAX_DEVICES) || PREMIUM_MAX_DEVICES),
      unlimitedDevices,
      licensedDevices: Number(client.lease.usedDevices ?? client.lease.activeDevices ?? 0),
      emailMasked: String(client.lease.emailMasked || ''),
      leaseExpiresAt: client.lease.expiresAt,
      licenseType,
      managementRole: String(client.lease.managementRole || (unlimitedDevices ? 'owner-admin' : 'regular')),
      managerLimit: Number(client.lease.managerLimit || (unlimitedDevices ? 0 : 3)),
      message: 'Premium Lifetime is active on this device. The encrypted vault remains local.'
    };
  }

  if (TESTING_FULL_ACCESS) {
    const licenseType = String(client.lease?.licenseType || 'testing').toLowerCase();
    const unlimitedDevices = licenseType === 'admin';
    return {
      mode: 'testing',
      status: 'full',
      plan: PREMIUM_PLAN,
      premium: true,
      deviceId,
      licensedDevices: Number(client.lease?.usedDevices ?? client.lease?.activeDevices ?? 0) || null,
      maxDevices: unlimitedDevices ? 0 : (Number(client.lease?.maxDevices || PREMIUM_MAX_DEVICES) || PREMIUM_MAX_DEVICES),
      unlimitedDevices,
      activationPresent: Boolean(client.refreshToken || client.hasEncryptedRefreshToken),
      emailMasked: String(client.emailMasked || ''),
      licenseType,
      managementRole: String(client.lease?.managementRole || (unlimitedDevices ? 'owner-admin' : 'regular')),
      managerLimit: Number(client.lease?.managerLimit || (unlimitedDevices ? 0 : 3)),
      message: 'Testing build: Premium feature access is enabled.'
    };
  }

  const activationPresent = Boolean(client.refreshToken || client.hasEncryptedRefreshToken);
  return {
    mode: 'free',
    status: 'full',
    plan: FREE_PLAN,
    premium: false,
    deviceId,
    maxDevices: PREMIUM_MAX_DEVICES,
    licensedDevices: Number(client.lease?.usedDevices ?? client.lease?.activeDevices ?? 0) || 0,
    activationPresent,
    emailMasked: String(client.emailMasked || ''),
    licenseType: String(client.lease?.licenseType || ''),
    managementRole: String(client.lease?.managementRole || ''),
    managerLimit: Number(client.lease?.managerLimit || 3),
    message: activationPresent
      ? 'Free Forever remains active. The previous Premium session is unavailable; refresh or reactivate Premium when convenient.'
      : 'Free Forever is active. Premium Lifetime is optional and never required to open, edit, back up, restore, import, export, or use your local vault.'
  };
}

export function licenseBadgeText(state) {
  if (!state) return 'Checking...';
  if (state.plan === PREMIUM_PLAN) return state.mode === 'testing' ? 'Testing - Premium' : 'Premium Lifetime';
  if (state.plan === FREE_PLAN) return 'Free Forever';
  return 'VaultCove';
}

export function featureAllowed(licenseState, feature) {
  const name = String(feature || '');
  if (CORE_FEATURES.has(name)) return true;
  if (isPremiumFeature(name)) return Boolean(licenseState?.premium || licenseState?.plan === PREMIUM_PLAN);
  return false;
}

export function premiumFeatureAllowed(licenseState, feature) {
  return isPremiumFeature(feature) && featureAllowed(licenseState, feature);
}
