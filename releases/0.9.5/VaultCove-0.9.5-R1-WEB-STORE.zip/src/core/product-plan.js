export const FREE_PLAN = 'free';
export const PREMIUM_PLAN = 'premium';
export const PREMIUM_MAX_DEVICES = 7;

export const CORE_FEATURES = Object.freeze(new Set([
  'edit',
  'import',
  'export',
  'backup',
  'restore',
  'autofill',
  'generator',
  'sharing',
  'license'
]));

export const PREMIUM_FEATURES = Object.freeze(new Set([
  'cards',
  'notes',
  'totp',
  'favorites',
  'security-center',
  'security-advanced',
  'vckey-txt',
  'sharing-unlimited',
  'guardian'
]));

export const PREMIUM_FEATURE_CATALOG = Object.freeze([
  Object.freeze({
    id: 'guardian',
    gate: 'guardian',
    title: 'VaultCove Guardian',
    purpose: 'Adds Fortress Mode, Security Zones, Blind Credential Mode, trusted-device approval, Recovery Drill, Backup Confidence, Security Ledger, quarantine, breach-date intelligence, passkey coaching, and advanced recovery controls.'
  }),
  Object.freeze({
    id: 'payment-cards',
    gate: 'cards',
    title: 'Cards',
    purpose: 'Stores and manages encrypted payment-card records inside the local vault.'
  }),
  Object.freeze({
    id: 'secure-notes',
    gate: 'notes',
    title: 'Secure Notes',
    purpose: 'Stores private encrypted text records inside the local vault.'
  }),
  Object.freeze({
    id: 'totp-codes',
    gate: 'totp',
    title: 'TOTP Codes',
    purpose: 'Generates standard six-digit TOTP codes locally from encrypted website authenticator secrets, with Guardian Split-Trust controls available in Premium.'
  }),
  Object.freeze({
    id: 'favorites',
    gate: 'favorites',
    title: 'Favorites',
    purpose: 'Marks important owned vault records for quick access without changing encryption.'
  }),
  Object.freeze({
    id: 'security-center',
    gate: 'security-center',
    title: 'Security Center',
    purpose: 'Unlocks local password-health scoring, weak/reused analysis, password-age review, and encrypted activity history.'
  }),
  Object.freeze({
    id: 'vckey-to-txt',
    gate: 'vckey-txt',
    title: 'Convert encrypted .vckey to TXT',
    purpose: 'Allows authorized plaintext conversion of an encrypted public-identity .vckey file.'
  }),
  Object.freeze({
    id: 'password-age-review',
    gate: 'security-advanced',
    title: 'Password age review',
    purpose: 'Highlights saved passwords that are 90 days old or older and separates credentials whose true change date is unknown.'
  }),
  Object.freeze({
    id: 'encrypted-activity-history',
    gate: 'security-advanced',
    title: 'Encrypted activity history',
    purpose: 'Shows a tamper-evident local history of security-sensitive VaultCove events without exposing passwords or secret values.'
  }),
  Object.freeze({
    id: 'unlimited-email-recipients',
    gate: 'sharing-unlimited',
    title: 'Unlimited email recipients',
    purpose: 'Removes the Free Forever limit of five saved email recipients while keeping the same local encrypted recipient list and .vcshare workflow.'
  }),
  Object.freeze({
    id: 'premium-devices',
    gate: 'license',
    title: 'Up to 7 Premium devices',
    purpose: 'Uses one Lifetime Premium entitlement across up to seven licensed VaultCove devices, with up to three Device Admins for the shared license ledger after registered-email OTP verification, while each encrypted vault remains local.'
  })
]);

export const LEGACY_TRIAL_STORAGE_KEYS = Object.freeze([
  'vaultcoveTrialStateV1',
  'vaultcoveTrialAnchorV1'
]);

export function isPremiumFeature(feature) {
  return PREMIUM_FEATURES.has(String(feature || ''));
}

export function uninstallDataDisclosure() {
  return 'Removing the extension permanently deletes the vault stored in Chrome extension-local storage. Export an encrypted .vcvault backup first if you want to keep a separate copy.';
}

export async function clearLegacyTrialMetadata() {
  await chrome.storage.local.remove([...LEGACY_TRIAL_STORAGE_KEYS]);
}
