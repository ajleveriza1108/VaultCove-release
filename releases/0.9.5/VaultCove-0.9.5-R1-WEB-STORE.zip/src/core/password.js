import { analyzePasswordIntelligence } from './password-intelligence.js';

const LOWER = 'abcdefghijklmnopqrstuvwxyz';
const UPPER = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
const DIGITS = '0123456789';
const SYMBOLS = '!@#$%^&*()-_=+[]{};:,.?/';

function randomIndex(max) {
  if (max <= 0 || max > 256) throw new Error('Invalid random range.');
  const limit = Math.floor(256 / max) * max;
  const array = new Uint8Array(1);
  do crypto.getRandomValues(array); while (array[0] >= limit);
  return array[0] % max;
}

export function generatePassword(options = {}) {
  const length = Math.min(128, Math.max(12, Number(options.length || 20)));
  const sets = [];
  if (options.lower !== false) sets.push(LOWER);
  if (options.upper !== false) sets.push(UPPER);
  if (options.digits !== false) sets.push(DIGITS);
  if (options.symbols !== false) sets.push(SYMBOLS);
  if (!sets.length) throw new Error('Choose at least one character set.');

  const password = [];
  for (const set of sets) password.push(set[randomIndex(set.length)]);
  const combined = sets.join('');
  while (password.length < length) password.push(combined[randomIndex(combined.length)]);

  for (let i = password.length - 1; i > 0; i -= 1) {
    const j = randomIndex(i + 1);
    [password[i], password[j]] = [password[j], password[i]];
  }
  return password.join('');
}

function hasObviousSequence(value) {
  const compact = String(value || '').toLowerCase().replace(/\s+/g, '');
  if (!compact) return false;
  const weakTerms = ['password', 'passw0rd', 'qwerty', 'letmein', 'welcome', 'admin', 'vaultcove', 'abc123', '123456'];
  if (weakTerms.some((term) => compact.includes(term))) return true;
  const sequences = ['0123456789', '9876543210', 'abcdefghijklmnopqrstuvwxyz', 'zyxwvutsrqponmlkjihgfedcba'];
  return sequences.some((sequence) => {
    for (let index = 0; index <= sequence.length - 4; index += 1) {
      if (compact.includes(sequence.slice(index, index + 4))) return true;
    }
    return false;
  });
}

export function passwordPolicy(password, minLength = 12) {
  const value = String(password || '');
  const minimum = Math.max(8, Math.min(128, Number(minLength) || 12));
  const rules = {
    length: value.length >= minimum,
    lower: /[a-z]/.test(value),
    upper: /[A-Z]/.test(value),
    number: /\d/.test(value),
    special: /[^A-Za-z0-9\s]/.test(value),
    repeat: value.length > 0 && !/(.)\1{2,}/.test(value),
    common: value.length > 0 && !hasObviousSequence(value),
    variety: value.length > 0 && new Set(value).size >= 8
  };
  const passed = Object.values(rules).filter(Boolean).length;
  return { minimum, rules, passed, total: Object.keys(rules).length, complete: passed === Object.keys(rules).length };
}

export function assessPassword(password, context = []) {
  return analyzePasswordIntelligence(password, context);
}

export function vaultHealth(items) {
  const logins = items.filter((item) => item.type === 'login' && !item.deletedAt);
  const groups = new Map();
  for (const item of logins) {
    if (!item.password) continue;
    if (!groups.has(item.password)) groups.set(item.password, []);
    groups.get(item.password).push(item.id);
  }

  const reusedIds = new Set([...groups.values()].filter((ids) => ids.length > 1).flat());
  const weakIds = new Set();
  let strong = 0;

  for (const item of logins) {
    const assessment = assessPassword(item.password);
    if (assessment.score < 3) weakIds.add(item.id);
    else strong += 1;
  }

  const atRiskIds = new Set([...weakIds, ...reusedIds]);
  const total = logins.length;
  const weak = weakIds.size;
  const reused = reusedIds.size;
  const atRisk = atRiskIds.size;
  const riskFindings = weak + reused;

  // A weak or reused credential is always counted as risk. A credential that
  // is both weak and reused appears once in atRisk but contributes both findings.
  const uniqueRiskRate = total ? atRisk / total : 0;
  const weakRate = total ? weak / total : 0;
  const reuseRate = total ? reused / total : 0;
  const penalty = uniqueRiskRate * 70 + weakRate * 10 + reuseRate * 20;
  const score = total ? Math.max(0, Math.min(100, Math.round(100 - penalty))) : 100;

  return {
    total,
    weak,
    reused,
    strong,
    atRisk,
    riskFindings,
    score
  };
}
