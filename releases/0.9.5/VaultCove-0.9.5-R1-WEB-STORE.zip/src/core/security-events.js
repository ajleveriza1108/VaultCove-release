import { randomId } from './encoding.js';

export function createGenericSecurityNotice(kind, occurredAt = new Date().toISOString()) {
  if (!['password-change-detected', 'password-changed', 'protected-record-changed', 'protected-record-updated', 'protected-record-removed', 'passwords-shared'].includes(kind)) throw new Error('Unsupported security notice type.');
  return {
    id: randomId('notice'),
    kind,
    occurredAt,
    privacyClass: 'metadata-only',
    payload: {
      event: ({
        'password-change-detected':'password_change_detected',
        'password-changed':'password_changed',
        'protected-record-changed':'protected_record_changed',
        'protected-record-updated':'protected_record_updated',
        'protected-record-removed':'protected_record_removed',
        'passwords-shared':'passwords_shared'
      })[kind] || 'security_event'
    }
  };
}

export function securityEmailBody() {
  return [
    'VaultCove security notice',
    '',
    'VaultCove detected a security-sensitive vault change on one of your devices.',
    '',
    'VaultCove did not send the changed record or secret in this email. For privacy, this notice contains no website, username, account name, old password, or new password; it also contains no card number, bank detail, identity detail, secure-note text, or vault secret.',
    '',
    'Open VaultCove on your device to review the local encrypted record.'
  ].join('\n');
}
