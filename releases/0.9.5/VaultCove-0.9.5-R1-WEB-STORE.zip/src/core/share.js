import { bytesToBase64Url, base64UrlToBytes, randomBytes, randomId, utf8ToBytes, bytesToUtf8 } from './encoding.js';
import { createItem } from './model.js';
import { saveBlob } from './file-save.js';

export const SHARE_IDENTITY_MAGIC = 'VAULTCOVE-PUBLIC-IDENTITY';
export const SHARE_PACKAGE_MAGIC = 'VAULTCOVE-SECURE-SHARE';
export const SHARE_VERSION = 4;
export const LEGACY_PASSWORD_SHARE_VERSION = 3;
export const EMAIL_SHARE_KDF_ITERATIONS = 1200000;
export const SHARE_PACKAGE_PASSWORD_ITERATIONS = 1200000;
const RECIPIENT_LAYER_VERSION = 2;
const SHARE_PASSWORD_AAD = 'VaultCove:vcshare:password:v3';
const EMAIL_SHARE_AAD = 'VaultCove:vcshare:email:v4';

async function digestBytes(bytes) {
  return new Uint8Array(await crypto.subtle.digest('SHA-256', bytes));
}

async function fingerprintJwk(jwk) {
  const stable = JSON.stringify({ kty: jwk.kty, crv: jwk.crv, x: jwk.x, y: jwk.y });
  const digest = await digestBytes(utf8ToBytes(stable));
  const hex = [...digest].map((byte) => byte.toString(16).padStart(2, '0').toUpperCase()).join('');
  return hex.match(/.{1,4}/g).slice(0, 8).join(' ');
}

function shareIdFromFingerprint(fingerprint) {
  return `VC-${fingerprint.replace(/\s+/g, '').slice(0, 16).match(/.{1,4}/g).join('-')}`;
}

async function exportPair(pair) {
  return {
    publicJwk: await crypto.subtle.exportKey('jwk', pair.publicKey),
    privateJwk: await crypto.subtle.exportKey('jwk', pair.privateKey)
  };
}

export async function ensureSharingIdentity(vault) {
  if (vault.sharingIdentity?.encryption?.privateJwk && vault.sharingIdentity?.signing?.privateJwk) return vault.sharingIdentity;

  const encryptionPair = await crypto.subtle.generateKey({ name: 'ECDH', namedCurve: 'P-256' }, true, ['deriveBits']);
  const signingPair = await crypto.subtle.generateKey({ name: 'ECDSA', namedCurve: 'P-256' }, true, ['sign', 'verify']);
  const encryption = await exportPair(encryptionPair);
  const signing = await exportPair(signingPair);
  const fingerprint = await fingerprintJwk(encryption.publicJwk);
  const identity = {
    shareId: shareIdFromFingerprint(fingerprint),
    fingerprint,
    createdAt: new Date().toISOString(),
    encryption,
    signing
  };
  vault.sharingIdentity = identity;
  vault.trustedShareContacts = Array.isArray(vault.trustedShareContacts) ? vault.trustedShareContacts : [];
  vault.shareHistory = Array.isArray(vault.shareHistory) ? vault.shareHistory : [];
  return identity;
}

export async function exportPublicSharingIdentity(vault, displayName = 'VaultCove User') {
  const identity = await ensureSharingIdentity(vault);
  return {
    magic: SHARE_IDENTITY_MAGIC,
    version: RECIPIENT_LAYER_VERSION,
    shareId: identity.shareId,
    fingerprint: identity.fingerprint,
    displayName: String(displayName || 'VaultCove User').slice(0, 80),
    encryptionPublicJwk: identity.encryption.publicJwk,
    signingPublicJwk: identity.signing.publicJwk,
    exportedAt: new Date().toISOString()
  };
}

export async function validatePublicSharingIdentity(value) {
  if (!value || value.magic !== SHARE_IDENTITY_MAGIC || ![RECIPIENT_LAYER_VERSION, SHARE_VERSION].includes(Number(value.version))) {
    throw new Error('Unsupported VaultCove sharing identity.');
  }
  if (!value.encryptionPublicJwk || !value.signingPublicJwk) throw new Error('Sharing identity is incomplete.');
  const fingerprint = await fingerprintJwk(value.encryptionPublicJwk);
  if (fingerprint !== value.fingerprint || shareIdFromFingerprint(fingerprint) !== value.shareId) throw new Error('Sharing identity fingerprint does not match its public key.');
  await crypto.subtle.importKey('jwk', value.encryptionPublicJwk, { name: 'ECDH', namedCurve: 'P-256' }, true, []);
  await crypto.subtle.importKey('jwk', value.signingPublicJwk, { name: 'ECDSA', namedCurve: 'P-256' }, true, ['verify']);
  return {
    shareId: value.shareId,
    fingerprint,
    displayName: String(value.displayName || value.shareId).slice(0, 80),
    encryptionPublicJwk: value.encryptionPublicJwk,
    signingPublicJwk: value.signingPublicJwk,
    trustedAt: new Date().toISOString()
  };
}

function sharePayloadFromItem(item) {
  if (!item || item.type !== 'login' || item.deletedAt) throw new Error('VaultCove shared access supports login credentials only.');
  if (item.sharedAccess?.mode === 'use-only') throw new Error('Received use-only credentials cannot be reshared. Ask the original owner to create a new share package.');
  if (!String(item.username || '') && !String(item.password || '')) throw new Error('The login must contain a username or password.');
  return {
    type: 'login',
    name: String(item.name || 'Shared Login').slice(0, 160),
    username: String(item.username || ''),
    password: String(item.password || ''),
    urls: Array.isArray(item.urls) ? item.urls.slice(0, 10) : [],
    trustedHosts: Array.isArray(item.trustedHosts) ? item.trustedHosts.slice(0, 20) : [],
    sourceItemId: String(item.id || '')
  };
}

async function deriveShareAesKey(privateKey, publicKey, salt, version = RECIPIENT_LAYER_VERSION) {
  const bits = new Uint8Array(await crypto.subtle.deriveBits({ name: 'ECDH', public: publicKey }, privateKey, 256));
  const material = await crypto.subtle.importKey('raw', bits, 'HKDF', false, ['deriveKey']);
  return crypto.subtle.deriveKey(
    { name: 'HKDF', hash: 'SHA-256', salt, info: utf8ToBytes(`VaultCove:VCShare:v${version}`) },
    material,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt']
  );
}

async function derivePackagePasswordKey(password, salt, iterations = SHARE_PACKAGE_PASSWORD_ITERATIONS) {
  const value = String(password || '');
  if (value.length < 12) throw new Error('Shared-package password must be at least 12 characters.');
  const material = await crypto.subtle.importKey('raw', utf8ToBytes(value), 'PBKDF2', false, ['deriveKey']);
  return crypto.subtle.deriveKey(
    { name: 'PBKDF2', hash: 'SHA-256', salt, iterations },
    material,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt']
  );
}

function canonicalHeader(pkg) {
  const header = {
    magic: pkg.magic,
    version: pkg.version,
    senderShareId: pkg.senderShareId,
    recipientShareId: pkg.recipientShareId,
    createdAt: pkg.createdAt,
    expiresAt: pkg.expiresAt,
    ephemeralPublicJwk: pkg.ephemeralPublicJwk,
    hkdfSalt: pkg.hkdfSalt,
    iv: pkg.iv,
    ciphertext: pkg.ciphertext
  };
  if (Number(pkg.version) >= 2) header.itemCount = Number(pkg.itemCount || 0);
  return JSON.stringify(header);
}

async function createRecipientLayer(vault, recipient, items, options = {}) {
  const sender = await ensureSharingIdentity(vault);
  const trusted = await validatePublicSharingIdentity(recipient);
  const selected = (Array.isArray(items) ? items : [items]).filter(Boolean);
  if (!selected.length) throw new Error('Select at least one login to share.');
  if (selected.length > 50) throw new Error('A secure share can contain at most 50 login items.');
  const payloadItems = selected.map(sharePayloadFromItem);

  const recipientPublic = await crypto.subtle.importKey('jwk', trusted.encryptionPublicJwk, { name: 'ECDH', namedCurve: 'P-256' }, true, []);
  const ephemeral = await crypto.subtle.generateKey({ name: 'ECDH', namedCurve: 'P-256' }, true, ['deriveBits']);
  const ephemeralPublicJwk = await crypto.subtle.exportKey('jwk', ephemeral.publicKey);
  const salt = randomBytes(16);
  const key = await deriveShareAesKey(ephemeral.privateKey, recipientPublic, salt, RECIPIENT_LAYER_VERSION);
  const iv = randomBytes(12);
  const createdAt = options.createdAt || new Date().toISOString();
  const expiresAt = options.expiresAt || null;
  const aad = utf8ToBytes(`${SHARE_PACKAGE_MAGIC}|${RECIPIENT_LAYER_VERSION}|${sender.shareId}|${trusted.shareId}`);
  const plaintext = utf8ToBytes(JSON.stringify({ kind: 'login-bundle', count: payloadItems.length, items: payloadItems }));
  const ciphertext = new Uint8Array(await crypto.subtle.encrypt({ name: 'AES-GCM', iv, additionalData: aad, tagLength: 128 }, key, plaintext));

  const pkg = {
    magic: SHARE_PACKAGE_MAGIC,
    version: RECIPIENT_LAYER_VERSION,
    senderShareId: sender.shareId,
    senderFingerprint: sender.fingerprint,
    senderSigningPublicJwk: sender.signing.publicJwk,
    recipientShareId: trusted.shareId,
    itemCount: payloadItems.length,
    createdAt,
    expiresAt,
    ephemeralPublicJwk,
    hkdfSalt: bytesToBase64Url(salt),
    iv: bytesToBase64Url(iv),
    ciphertext: bytesToBase64Url(ciphertext)
  };
  const signingKey = await crypto.subtle.importKey('jwk', sender.signing.privateJwk, { name: 'ECDSA', namedCurve: 'P-256' }, false, ['sign']);
  const signature = new Uint8Array(await crypto.subtle.sign({ name: 'ECDSA', hash: 'SHA-256' }, signingKey, utf8ToBytes(canonicalHeader(pkg))));
  pkg.signature = bytesToBase64Url(signature);
  return pkg;
}

async function createLegacySecureShareV3(vault, recipient, items, options = {}) {
  const packagePassword = String(options.packagePassword || '');
  if (packagePassword.length < 12) throw new Error('Create a shared-package password with at least 12 characters.');
  const createdAt = new Date().toISOString();
  const expiresAt = options.expiresAt || null;
  const inner = await createRecipientLayer(vault, recipient, items, { createdAt, expiresAt });
  const packageId = randomId('shared');
  const salt = randomBytes(16);
  const key = await derivePackagePasswordKey(packagePassword, salt);
  const iv = randomBytes(12);
  const aadText = `${SHARE_PASSWORD_AAD}|${packageId}`;
  const ciphertext = new Uint8Array(await crypto.subtle.encrypt(
    { name: 'AES-GCM', iv, additionalData: utf8ToBytes(aadText), tagLength: 128 },
    key,
    utf8ToBytes(JSON.stringify(inner))
  ));
  return {
    magic: SHARE_PACKAGE_MAGIC,
    version: SHARE_VERSION,
    kind: 'shared-login-access',
    packageId,
    policy: { mode: 'use-only', immutable: true, loginOnly: true },
    itemCount: inner.itemCount,
    createdAt,
    expiresAt,
    passwordKdf: {
      name: 'PBKDF2-HMAC-SHA-256',
      hash: 'SHA-256',
      iterations: SHARE_PACKAGE_PASSWORD_ITERATIONS,
      salt: bytesToBase64Url(salt)
    },
    passwordEnvelope: {
      algorithm: 'AES-256-GCM',
      aad: aadText,
      iv: bytesToBase64Url(iv),
      ciphertext: bytesToBase64Url(ciphertext)
    }
  };
}

function importedItemFromPayload(payload) {
  if (payload.type !== 'login') throw new Error('Unsupported shared item type.');
  return createItem('login', {
    name: String(payload.name || 'Shared Login').slice(0, 160),
    username: String(payload.username || ''),
    password: String(payload.password || ''),
    urls: Array.isArray(payload.urls) ? payload.urls.slice(0, 10) : [],
    trustedHosts: Array.isArray(payload.trustedHosts) ? payload.trustedHosts.slice(0, 20) : [],
    notes: '',
    totpSecret: '',
    tags: ['Shared Access'],
    autoLogin: false,
    requireReauthBeforeFill: true
  });
}

async function openRecipientLayer(vault, pkg) {
  if (!pkg || pkg.magic !== SHARE_PACKAGE_MAGIC || ![1, RECIPIENT_LAYER_VERSION].includes(Number(pkg.version))) throw new Error('Unsupported or invalid recipient-encrypted share layer.');
  const identity = await ensureSharingIdentity(vault);
  if (pkg.recipientShareId !== identity.shareId) throw new Error('This secure share was encrypted for a different VaultCove recipient.');
  if (pkg.expiresAt && Date.now() > Date.parse(pkg.expiresAt)) throw new Error('This secure share has expired.');

  const senderSigning = await crypto.subtle.importKey('jwk', pkg.senderSigningPublicJwk, { name: 'ECDSA', namedCurve: 'P-256' }, false, ['verify']);
  const signatureValid = await crypto.subtle.verify({ name: 'ECDSA', hash: 'SHA-256' }, senderSigning, base64UrlToBytes(pkg.signature), utf8ToBytes(canonicalHeader(pkg)));
  if (!signatureValid) throw new Error('Secure-share signature verification failed. The package may have been changed.');

  const recipientPrivate = await crypto.subtle.importKey('jwk', identity.encryption.privateJwk, { name: 'ECDH', namedCurve: 'P-256' }, false, ['deriveBits']);
  const ephemeralPublic = await crypto.subtle.importKey('jwk', pkg.ephemeralPublicJwk, { name: 'ECDH', namedCurve: 'P-256' }, false, []);
  const key = await deriveShareAesKey(recipientPrivate, ephemeralPublic, base64UrlToBytes(pkg.hkdfSalt), Number(pkg.version));
  const aad = utf8ToBytes(`${SHARE_PACKAGE_MAGIC}|${pkg.version}|${pkg.senderShareId}|${pkg.recipientShareId}`);
  const plaintext = new Uint8Array(await crypto.subtle.decrypt({ name: 'AES-GCM', iv: base64UrlToBytes(pkg.iv), additionalData: aad, tagLength: 128 }, key, base64UrlToBytes(pkg.ciphertext)));
  const decoded = JSON.parse(bytesToUtf8(plaintext));
  const payloads = Number(pkg.version) === 1 ? [decoded] : (decoded.kind === 'login-bundle' && Array.isArray(decoded.items) ? decoded.items : []);
  if (!payloads.length) throw new Error('Secure share contains no supported login items.');

  const trustedContact = (vault.trustedShareContacts || []).find((contact) => contact.shareId === pkg.senderShareId);
  return {
    items: payloads.map(importedItemFromPayload),
    sender: {
      shareId: pkg.senderShareId,
      fingerprint: String(pkg.senderFingerprint || ''),
      trusted: Boolean(trustedContact),
      displayName: trustedContact?.displayName || pkg.senderShareId
    },
    expiresAt: pkg.expiresAt || null
  };
}

async function openLegacySecureShare(vault, pkg, options = {}) {
  if (!pkg || pkg.magic !== SHARE_PACKAGE_MAGIC) throw new Error('Unsupported or invalid .vcshare package.');
  if ([1, RECIPIENT_LAYER_VERSION].includes(Number(pkg.version))) {
    const legacy = await openRecipientLayer(vault, pkg);
    return { ...legacy, packageId: '', policy: { mode: 'legacy-import', immutable: false, loginOnly: false } };
  }
  if (Number(pkg.version) !== LEGACY_PASSWORD_SHARE_VERSION || pkg.kind !== 'shared-login-access') throw new Error('Unsupported or invalid .vcshare package.');
  if (pkg.expiresAt && Date.now() > Date.parse(pkg.expiresAt)) throw new Error('This shared-access package has expired.');
  if (pkg.policy?.mode !== 'use-only' || pkg.policy?.immutable !== true || pkg.policy?.loginOnly !== true) throw new Error('The shared-access policy is invalid.');
  const password = String(options.packagePassword || '');
  if (!password) throw new Error('Enter the shared-package password provided by the sender.');
  const salt = base64UrlToBytes(pkg.passwordKdf?.salt || '');
  const iterations = Number(pkg.passwordKdf?.iterations || 0);
  if (salt.length !== 16 || iterations < 300000 || iterations > 2000000) throw new Error('Shared-package password protection is invalid.');
  const key = await derivePackagePasswordKey(password, salt, iterations);
  let inner;
  try {
    const plaintext = new Uint8Array(await crypto.subtle.decrypt(
      {
        name: 'AES-GCM',
        iv: base64UrlToBytes(pkg.passwordEnvelope?.iv || ''),
        additionalData: utf8ToBytes(`${SHARE_PASSWORD_AAD}|${String(pkg.packageId || '')}`),
        tagLength: 128
      },
      key,
      base64UrlToBytes(pkg.passwordEnvelope?.ciphertext || '')
    ));
    inner = JSON.parse(bytesToUtf8(plaintext));
  } catch {
    throw new Error('The shared-package password is incorrect or the file was modified.');
  }
  const opened = await openRecipientLayer(vault, inner);
  return {
    ...opened,
    packageId: String(pkg.packageId || ''),
    expiresAt: pkg.expiresAt || opened.expiresAt || null,
    policy: { mode: 'use-only', immutable: true, loginOnly: true }
  };
}


function normalizeShareEmail(value) {
  const email = String(value || '').trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254) throw new Error('Enter a valid recipient email address.');
  return email;
}

async function deriveEmailShareKey(email, salt, iterations = EMAIL_SHARE_KDF_ITERATIONS) {
  const material = await crypto.subtle.importKey('raw', utf8ToBytes(normalizeShareEmail(email)), 'PBKDF2', false, ['deriveKey']);
  return crypto.subtle.deriveKey(
    { name:'PBKDF2', hash:'SHA-256', salt, iterations },
    material,
    { name:'AES-GCM', length:256 },
    false,
    ['encrypt','decrypt']
  );
}

async function emailBindingDigest(email, salt) {
  const digest = await digestBytes(utf8ToBytes(`${bytesToBase64Url(salt)}|${normalizeShareEmail(email)}`));
  return bytesToBase64Url(digest);
}

function canonicalEmailPayload(payload) {
  return JSON.stringify({
    kind: payload.kind,
    packageId: payload.packageId,
    senderShareId: payload.senderShareId,
    senderFingerprint: payload.senderFingerprint,
    senderSigningPublicJwk: payload.senderSigningPublicJwk,
    senderDisplayName: payload.senderDisplayName,
    createdAt: payload.createdAt,
    expiresAt: payload.expiresAt,
    itemCount: payload.itemCount,
    items: payload.items
  });
}

async function createEmailSignedPayload(vault, items, options = {}) {
  const sender = await ensureSharingIdentity(vault);
  const selected = (Array.isArray(items) ? items : [items]).filter(Boolean);
  if (!selected.length) throw new Error('Select at least one login to share.');
  if (selected.length > 50) throw new Error('A secure share can contain at most 50 login items.');
  const payload = {
    kind: 'email-bound-login-bundle',
    packageId: randomId('shared'),
    senderShareId: sender.shareId,
    senderFingerprint: sender.fingerprint,
    senderSigningPublicJwk: sender.signing.publicJwk,
    senderDisplayName: String(options.senderDisplayName || 'VaultCove sender').slice(0,80),
    createdAt: options.createdAt || new Date().toISOString(),
    expiresAt: options.expiresAt || null,
    itemCount: selected.length,
    items: selected.map(sharePayloadFromItem)
  };
  const signingKey = await crypto.subtle.importKey('jwk', sender.signing.privateJwk, { name:'ECDSA', namedCurve:'P-256' }, false, ['sign']);
  payload.signature = bytesToBase64Url(new Uint8Array(await crypto.subtle.sign(
    { name:'ECDSA', hash:'SHA-256' }, signingKey, utf8ToBytes(canonicalEmailPayload(payload))
  )));
  return payload;
}

export async function createSecureShare(vault, recipient, items, options = {}) {
  const recipientEmail = normalizeShareEmail(recipient?.email || recipient?.recipientEmail);
  const createdAt = new Date().toISOString();
  const expiresAt = options.expiresAt || null;
  const inner = await createEmailSignedPayload(vault, items, { createdAt, expiresAt, senderDisplayName:options.senderDisplayName });
  const bindingSalt = randomBytes(16);
  const binding = await emailBindingDigest(recipientEmail, bindingSalt);
  const kdfSalt = randomBytes(16);
  const key = await deriveEmailShareKey(recipientEmail, kdfSalt);
  const iv = randomBytes(12);
  const aad = `${EMAIL_SHARE_AAD}|${inner.packageId}|${binding}`;
  const ciphertext = new Uint8Array(await crypto.subtle.encrypt(
    { name:'AES-GCM', iv, additionalData:utf8ToBytes(aad), tagLength:128 },
    key,
    utf8ToBytes(JSON.stringify(inner))
  ));
  return {
    magic: SHARE_PACKAGE_MAGIC,
    version: SHARE_VERSION,
    kind: 'email-bound-login-access',
    packageId: inner.packageId,
    policy: { mode:'use-only', immutable:true, loginOnly:true },
    itemCount: inner.itemCount,
    createdAt,
    expiresAt,
    recipientBinding: { algorithm:'SHA-256', salt:bytesToBase64Url(bindingSalt), digest:binding },
    emailKdf: { name:'PBKDF2-HMAC-SHA-256', hash:'SHA-256', iterations:EMAIL_SHARE_KDF_ITERATIONS, salt:bytesToBase64Url(kdfSalt) },
    envelope: { algorithm:'AES-256-GCM', aad, iv:bytesToBase64Url(iv), ciphertext:bytesToBase64Url(ciphertext) }
  };
}

async function openEmailBoundShare(vault, pkg, recipientEmail) {
  if (!pkg || pkg.magic !== SHARE_PACKAGE_MAGIC || Number(pkg.version) !== SHARE_VERSION || pkg.kind !== 'email-bound-login-access') {
    throw new Error('Unsupported or invalid email-bound .vcshare package.');
  }
  if (pkg.expiresAt && Date.now() > Date.parse(pkg.expiresAt)) throw new Error('This shared-access package has expired.');
  if (pkg.policy?.mode !== 'use-only' || pkg.policy?.immutable !== true || pkg.policy?.loginOnly !== true) throw new Error('The shared-access policy is invalid.');
  const email = normalizeShareEmail(recipientEmail);
  const bindingSalt = base64UrlToBytes(String(pkg.recipientBinding?.salt || ''));
  if (bindingSalt.length !== 16) throw new Error('Recipient email binding is invalid.');
  const expectedBinding = await emailBindingDigest(email, bindingSalt);
  if (expectedBinding !== String(pkg.recipientBinding?.digest || '')) throw new Error('Email address does not match this shared file.');
  const iterations = Number(pkg.emailKdf?.iterations || 0);
  const kdfSalt = base64UrlToBytes(String(pkg.emailKdf?.salt || ''));
  if (pkg.emailKdf?.name !== 'PBKDF2-HMAC-SHA-256' || iterations < 600000 || iterations > 2000000 || kdfSalt.length !== 16) {
    throw new Error('Shared-file email protection is invalid.');
  }
  const key = await deriveEmailShareKey(email, kdfSalt, iterations);
  let inner;
  try {
    const plaintext = new Uint8Array(await crypto.subtle.decrypt(
      { name:'AES-GCM', iv:base64UrlToBytes(String(pkg.envelope?.iv || '')), additionalData:utf8ToBytes(String(pkg.envelope?.aad || '')), tagLength:128 },
      key,
      base64UrlToBytes(String(pkg.envelope?.ciphertext || ''))
    ));
    inner = JSON.parse(bytesToUtf8(plaintext));
  } catch {
    throw new Error('Email address does not match this shared file, or the file was modified.');
  }
  if (inner?.kind !== 'email-bound-login-bundle' || String(inner.packageId || '') !== String(pkg.packageId || '')) throw new Error('Shared-file payload is invalid.');
  const senderSigning = await crypto.subtle.importKey('jwk', inner.senderSigningPublicJwk, { name:'ECDSA', namedCurve:'P-256' }, false, ['verify']);
  const signatureValid = await crypto.subtle.verify(
    { name:'ECDSA', hash:'SHA-256' }, senderSigning, base64UrlToBytes(String(inner.signature || '')), utf8ToBytes(canonicalEmailPayload(inner))
  );
  if (!signatureValid) throw new Error('Secure-share signature verification failed. The package may have been changed.');
  const payloads = Array.isArray(inner.items) ? inner.items : [];
  if (!payloads.length) throw new Error('Secure share contains no supported login items.');
  const trustedContact = (vault.trustedShareContacts || []).find((contact) => contact.shareId === inner.senderShareId);
  return {
    items: payloads.map(importedItemFromPayload),
    sender: {
      shareId:String(inner.senderShareId || ''),
      fingerprint:String(inner.senderFingerprint || ''),
      trusted:Boolean(trustedContact),
      displayName:String(inner.senderDisplayName || trustedContact?.displayName || 'VaultCove sender').slice(0,80)
    },
    packageId:String(pkg.packageId || ''),
    expiresAt:pkg.expiresAt || inner.expiresAt || null,
    policy:{ mode:'use-only', immutable:true, loginOnly:true }
  };
}

export async function openSecureShare(vault, pkg, options = {}) {
  if (!pkg || pkg.magic !== SHARE_PACKAGE_MAGIC) throw new Error('Unsupported or invalid .vcshare package.');
  if (Number(pkg.version) === SHARE_VERSION) return openEmailBoundShare(vault, pkg, options.recipientEmail);
  return openLegacySecureShare(vault, pkg, options);
}

export function addTrustedShareContact(vault, contact) {
  vault.trustedShareContacts = Array.isArray(vault.trustedShareContacts) ? vault.trustedShareContacts : [];
  const index = vault.trustedShareContacts.findIndex((candidate) => candidate.shareId === contact.shareId);
  if (index >= 0) vault.trustedShareContacts[index] = { ...vault.trustedShareContacts[index], ...contact };
  else vault.trustedShareContacts.push(contact);
  return contact;
}

export function recordShareHistory(vault, entry) {
  vault.shareHistory = Array.isArray(vault.shareHistory) ? vault.shareHistory : [];
  const now = Date.now();
  vault.shareHistory.unshift({ id: randomId('share'), occurredAt: new Date(now).toISOString(), ...entry });
  const cutoff = now - 30 * 24 * 60 * 60 * 1000;
  vault.shareHistory = vault.shareHistory.filter((item) => Date.parse(String(item?.occurredAt || '')) >= cutoff).slice(0, 500);
}

export async function downloadJsonFile(value, filename, mime = 'application/octet-stream') {
  const blob = new Blob([JSON.stringify(value, null, 2)], { type: mime });
  return saveBlob(blob, filename, { description: 'VaultCove encrypted file', mime });
}
