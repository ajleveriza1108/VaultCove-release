import {
  canApexCoverSubdomain,
  isUsableTrustHostname,
  normalizeTrustHostname,
  registrableTrustDomain
} from './origin-trust.js';

function normalizeHostname(value) { return normalizeTrustHostname(value); }

function looksLikeUsableHost(host) { return isUsableTrustHostname(host); }

// Explicit first-party login families. These are deliberately narrow allowlists,
// not registrable-domain or suffix matching. A host must be listed verbatim.
const TRUSTED_SITE_FAMILIES = Object.freeze([
  Object.freeze({
    id: 'google-account',
    hosts: Object.freeze([
      'accounts.google.com',
      'mail.google.com',
      'myaccount.google.com',
      'gmail.com',
      'www.gmail.com'
    ])
  })
]);

const SITE_FAMILY_BY_HOST = new Map(
  TRUSTED_SITE_FAMILIES.flatMap((family) => family.hosts.map((host) => [host, family.id]))
);

function registrableDomain(hostname) { return registrableTrustDomain(hostname); }

function apexSubdomainAlias(saved, current) { return canApexCoverSubdomain(saved, current); }

export function canonicalHostname(value) {
  const host = normalizeHostname(value);
  return host.startsWith('www.') ? host.slice(4) : host;
}

export function registrableSite(value) { return registrableDomain(value); }

export function trustedSiteFamily(value) {
  return SITE_FAMILY_BY_HOST.get(normalizeHostname(value)) || '';
}

export function permissionOriginForHost(hostname) {
  const host = normalizeHostname(hostname);
  if (!host) throw new Error('A valid HTTPS hostname is required.');
  return `https://${host}/*`;
}

function inferredHostFromLoginName(item) {
  const host = normalizeHostname(item?.name || '');
  return looksLikeUsableHost(host) ? host : '';
}

export function savedHostsForLogin(item) {
  if (!item || item.type !== 'login') return [];
  const values = [...(item.urls || []), ...(item.trustedHosts || [])];
  const hosts = values.map(normalizeHostname).filter(looksLikeUsableHost);
  const inferred = inferredHostFromLoginName(item);
  if (inferred) hosts.push(inferred);
  return [...new Set(hosts)];
}

function hostsAreSafeAliases(saved, current) {
  if (saved === current) return true;

  // Generic convenience alias: www.example.com <-> example.com only.
  const genericWwwAlias = canonicalHostname(saved) === canonicalHostname(current)
    && (saved.startsWith('www.') || current.startsWith('www.'));
  if (genericWwwAlias) return true;
  if (apexSubdomainAlias(saved, current)) return true;

  // Selected first-party services intentionally use separate login/application
  // hosts. Both sides must be explicit members of the same reviewed family.
  const savedFamily = trustedSiteFamily(saved);
  return Boolean(savedFamily && savedFamily === trustedSiteFamily(current));
}

export function loginMatchesTrustedHost(item, currentHostname) {
  if (!item || item.type !== 'login' || item.deletedAt) return false;
  if (item.sharedAccess?.mode === 'use-only') {
    const expiresAt = Date.parse(String(item.sharedAccess?.expiresAt || ''));
    if (Number.isFinite(expiresAt) && Date.now() > expiresAt) return false;
  }
  const current = normalizeHostname(currentHostname);
  if (!looksLikeUsableHost(current)) return false;
  return savedHostsForLogin(item).some((saved) => hostsAreSafeAliases(saved, current));
}

export function siteMatchKind(item, currentHostname) {
  const current = normalizeHostname(currentHostname);
  if (!looksLikeUsableHost(current)) return 'none';
  const hosts = savedHostsForLogin(item);
  if (hosts.includes(current)) return 'exact';
  if (hosts.some((saved) => canonicalHostname(saved) === canonicalHostname(current) && (saved.startsWith('www.') || current.startsWith('www.')))) return 'www-alias';
  if (hosts.some((saved) => apexSubdomainAlias(saved, current))) return 'apex-subdomain';
  const family = trustedSiteFamily(current);
  if (family && hosts.some((saved) => trustedSiteFamily(saved) === family)) return 'trusted-family';
  return 'none';
}

function httpsOriginFromCandidate(value) {
  const raw = String(value || '').trim();
  if (!raw) return '';
  try {
    const url = new URL(/^[a-z][a-z0-9+.-]*:/i.test(raw) ? raw : `https://${raw}`);
    if (url.protocol === 'http:') url.protocol = 'https:';
    if (url.protocol !== 'https:' || !looksLikeUsableHost(url.hostname)) return '';
    return url.origin.toLowerCase();
  } catch {
    return '';
  }
}

export function secureLoginMatchesUrl(item, currentValue) {
  if (!item || item.type !== 'login' || item.deletedAt) return false;
  let current;
  try { current = currentValue instanceof URL ? currentValue : new URL(String(currentValue || '')); } catch { return false; }
  if (current.protocol !== 'https:' || !looksLikeUsableHost(current.hostname)) return false;

  const candidates = [...(item.urls || []), ...(item.trustedHosts || [])];
  const inferred = inferredHostFromLoginName(item);
  if (inferred) candidates.push(inferred);
  const currentOrigin = current.origin.toLowerCase();
  const currentHost = normalizeHostname(current.hostname);
  const currentPort = current.port || '443';

  for (const candidate of candidates) {
    const origin = httpsOriginFromCandidate(candidate);
    if (!origin) continue;
    if (origin === currentOrigin) return true;
    try {
      const savedUrl = new URL(origin);
      const savedHost = normalizeHostname(savedUrl.hostname);
      const savedPort = savedUrl.port || '443';
      if (savedPort !== currentPort) continue;
      const wwwAlias = canonicalHostname(savedHost) === canonicalHostname(currentHost)
        && (savedHost.startsWith('www.') || currentHost.startsWith('www.'));
      if (wwwAlias) return true;
      if (savedPort === '443' && currentPort === '443' && apexSubdomainAlias(savedHost, currentHost)) return true;
      const family = trustedSiteFamily(currentHost);
      if (family && savedPort === '443' && currentPort === '443' && family === trustedSiteFamily(savedHost)) return true;
    } catch {}
  }
  return false;
}

export function resolveLoginHttpsTarget(item) {
  if (!item || item.type !== 'login') return null;
  const candidates = [...(item.urls || []), ...(item.trustedHosts || [])];
  const inferred = inferredHostFromLoginName(item);
  if (inferred) candidates.push(inferred);

  for (const candidate of candidates) {
    const raw = String(candidate || '').trim();
    if (!raw) continue;
    try {
      const url = new URL(/^https?:\/\//i.test(raw) ? raw : `https://${raw}`);
      if (!looksLikeUsableHost(url.hostname) || url.protocol !== 'https:') continue;
      return url;
    } catch {}
  }
  return null;
}

export function loginHasInsecureHttpUrl(item) {
  if (!item || item.type !== 'login') return false;
  return (item.urls || []).some((value) => {
    try { return new URL(String(value || '')).protocol === 'http:'; }
    catch { return /^http:\/\//i.test(String(value || '').trim()); }
  });
}

export function insecureHttpLoginMatchesUrl(item, currentValue) {
  if (!item || item.type !== 'login' || item.deletedAt) return false;
  let current;
  try { current = currentValue instanceof URL ? currentValue : new URL(String(currentValue || '')); } catch { return false; }
  if (current.protocol !== 'http:' || !looksLikeUsableHost(current.hostname)) return false;
  // HTTP is an explicit exception: no www aliases, apex/subdomain inheritance,
  // trusted families, inferred hosts, or trustedHosts are accepted. The saved URL
  // itself must explicitly name this exact unencrypted origin.
  const currentOrigin = current.origin.toLowerCase();
  return (item.urls || []).some((value) => {
    try {
      const saved = new URL(String(value || '').trim());
      return saved.protocol === 'http:' && saved.origin.toLowerCase() === currentOrigin;
    } catch { return false; }
  });
}

export function resolveLoginNavigationTarget(item, { allowHttp = false } = {}) {
  const https = resolveLoginHttpsTarget(item);
  if (https) return { url: https, insecureHttp: false };
  if (!allowHttp || !item || item.type !== 'login') return null;
  for (const value of item.urls || []) {
    try {
      const url = new URL(String(value || '').trim());
      if (url.protocol === 'http:' && looksLikeUsableHost(url.hostname)) return { url, insecureHttp: true };
    } catch {}
  }
  return null;
}

export function normalizeImportedLoginUrl(value, fallbackName = '') {
  const raw = String(value || '').trim();
  if (!raw) return '';
  try {
    const url = new URL(/^[a-z][a-z0-9+.-]*:/i.test(raw) ? raw : `https://${raw}`);
    if (!looksLikeUsableHost(url.hostname) || !['http:','https:'].includes(url.protocol)) return '';
    // Preserve an explicitly exported HTTP URL so VaultCove can warn rather than
    // silently pretending the legacy site is protected by TLS. Bare domains still
    // default to HTTPS.
    return url.toString();
  } catch {
    const pseudo = { type: 'login', name: fallbackName, urls: [], trustedHosts: [] };
    const resolved = resolveLoginHttpsTarget(pseudo);
    return resolved ? resolved.toString() : '';
  }
}
