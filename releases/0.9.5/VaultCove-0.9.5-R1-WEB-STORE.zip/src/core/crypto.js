import {
  CRYPTO_PROFILE,
  CRYPTO_PROFILE_VERSION,
  MASTER_AAD,
  PBKDF2_ITERATIONS,
  SCHEMA_VERSION,
  VAULT_AAD
} from './constants.js';
import {
  base64UrlToBytes,
  bytesToBase64Url,
  bytesToUtf8,
  randomBytes,
  utf8ToBytes
} from './encoding.js';

export async function deriveMasterKey(masterPassword, salt, iterations = PBKDF2_ITERATIONS) {
  if (typeof masterPassword !== 'string' || masterPassword.length < 1) {
    throw new Error('A master password is required.');
  }
  const material = await crypto.subtle.importKey(
    'raw',
    utf8ToBytes(masterPassword),
    'PBKDF2',
    false,
    ['deriveKey']
  );
  return crypto.subtle.deriveKey(
    { name: 'PBKDF2', hash: 'SHA-256', salt, iterations },
    material,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt']
  );
}

export async function importAesKey(rawBytes, extractable = false) {
  return crypto.subtle.importKey('raw', rawBytes, { name: 'AES-GCM' }, extractable, ['encrypt', 'decrypt']);
}

export async function exportAesKey(key) {
  return new Uint8Array(await crypto.subtle.exportKey('raw', key));
}

async function aesGcmEncrypt(key, plaintextBytes, aadText) {
  const iv = randomBytes(12);
  const encrypted = await crypto.subtle.encrypt(
    { name: 'AES-GCM', iv, additionalData: utf8ToBytes(aadText), tagLength: 128 },
    key,
    plaintextBytes
  );
  return {
    iv: bytesToBase64Url(iv),
    ciphertext: bytesToBase64Url(new Uint8Array(encrypted))
  };
}

async function aesGcmDecrypt(key, encrypted, aadText) {
  const decrypted = await crypto.subtle.decrypt(
    {
      name: 'AES-GCM',
      iv: base64UrlToBytes(encrypted.iv),
      additionalData: utf8ToBytes(aadText),
      tagLength: 128
    },
    key,
    base64UrlToBytes(encrypted.ciphertext)
  );
  return new Uint8Array(decrypted);
}

function constantTimeEqual(left, right) {
  if (!(left instanceof Uint8Array) || !(right instanceof Uint8Array) || left.length !== right.length) return false;
  let diff = 0;
  for (let i = 0; i < left.length; i += 1) diff |= left[i] ^ right[i];
  return diff === 0;
}

export async function encryptJson(key, value, aadText = VAULT_AAD) {
  return aesGcmEncrypt(key, utf8ToBytes(JSON.stringify(value)), aadText);
}

export async function decryptJson(key, encrypted, aadText = VAULT_AAD) {
  const bytes = await aesGcmDecrypt(key, encrypted, aadText);
  return JSON.parse(bytesToUtf8(bytes));
}

export async function createVaultEnvelope(masterPassword, vaultData) {
  const salt = randomBytes(16);
  const masterKey = await deriveMasterKey(masterPassword, salt);
  const rawVaultKey = randomBytes(32);
  const vaultKey = await importAesKey(rawVaultKey, true);
  const wrappedVaultKey = await aesGcmEncrypt(masterKey, rawVaultKey, MASTER_AAD);
  const encryptedVault = await encryptJson(vaultKey, vaultData, VAULT_AAD);

  return {
    envelope: {
      schemaVersion: SCHEMA_VERSION,
      cryptoProfile: { name: CRYPTO_PROFILE, version: CRYPTO_PROFILE_VERSION },
      kdf: {
        version: 1,
        name: 'PBKDF2-HMAC-SHA-256',
        iterations: PBKDF2_ITERATIONS,
        salt: bytesToBase64Url(salt)
      },
      keyWrap: {
        version: 1,
        algorithm: 'AES-256-GCM',
        ...wrappedVaultKey
      },
      vault: {
        version: 1,
        algorithm: 'AES-256-GCM',
        ...encryptedVault
      },
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    },
    vaultKey,
    rawVaultKey
  };
}

function validateVaultKeyWrapEnvelope(envelope) {
  if (!envelope || envelope.schemaVersion !== SCHEMA_VERSION) {
    throw new Error('Unsupported or invalid vault format.');
  }
  const profile = envelope.cryptoProfile || { name: CRYPTO_PROFILE, version: CRYPTO_PROFILE_VERSION };
  if (profile.name !== CRYPTO_PROFILE || Number(profile.version) !== CRYPTO_PROFILE_VERSION) {
    throw new Error('Unsupported VaultCove cryptographic profile.');
  }
  if (!envelope.kdf?.salt || !envelope.keyWrap?.iv || !envelope.keyWrap?.ciphertext) {
    throw new Error('Vault key-wrap envelope is incomplete.');
  }
  if (envelope.kdf.name !== 'PBKDF2-HMAC-SHA-256' || Number(envelope.kdf.iterations) < 600000) {
    throw new Error('Vault KDF parameters are unsupported or too weak.');
  }
  if (envelope.keyWrap.algorithm !== 'AES-256-GCM') {
    throw new Error('Unsupported VaultCove key-wrap algorithm.');
  }
}

async function unwrapVaultKey(masterPassword, envelope) {
  validateVaultKeyWrapEnvelope(envelope);
  const salt = base64UrlToBytes(envelope.kdf.salt);
  const masterKey = await deriveMasterKey(masterPassword, salt, envelope.kdf.iterations);
  try {
    return await aesGcmDecrypt(masterKey, envelope.keyWrap, MASTER_AAD);
  } catch {
    throw new Error('Incorrect master password.');
  }
}

export async function unlockVaultKeyWrap(masterPassword, envelope) {
  const rawVaultKey = await unwrapVaultKey(masterPassword, envelope);
  const vaultKey = await importAesKey(rawVaultKey, true);
  return { rawVaultKey, vaultKey };
}

export async function verifyMasterPasswordForVaultKey(masterPassword, envelope, expectedRawVaultKey) {
  const unwrapped = await unwrapVaultKey(masterPassword, envelope);
  return constantTimeEqual(unwrapped, expectedRawVaultKey);
}

export async function unlockVaultEnvelope(masterPassword, envelope) {
  const rawVaultKey = await unwrapVaultKey(masterPassword, envelope);
  const vaultKey = await importAesKey(rawVaultKey, true);
  let vaultData;
  try {
    vaultData = await decryptJson(vaultKey, envelope.vault, VAULT_AAD);
  } catch {
    throw new Error('Vault authentication failed. The stored vault may be damaged.');
  }
  return { vaultKey, rawVaultKey, vaultData };
}

export async function reencryptVault(envelope, vaultKey, vaultData) {
  const encryptedVault = await encryptJson(vaultKey, vaultData, VAULT_AAD);
  return {
    ...envelope,
    cryptoProfile: envelope.cryptoProfile || { name: CRYPTO_PROFILE, version: CRYPTO_PROFILE_VERSION },
    vault: { version: 1, algorithm: 'AES-256-GCM', ...encryptedVault },
    updatedAt: new Date().toISOString()
  };
}

export async function changeMasterPassword(envelope, rawVaultKey, newMasterPassword) {
  const salt = randomBytes(16);
  const newMasterKey = await deriveMasterKey(newMasterPassword, salt);
  const wrapped = await aesGcmEncrypt(newMasterKey, rawVaultKey, MASTER_AAD);
  return {
    ...envelope,
    cryptoProfile: { name: CRYPTO_PROFILE, version: CRYPTO_PROFILE_VERSION },
    kdf: {
      version: 1,
      name: 'PBKDF2-HMAC-SHA-256',
      iterations: PBKDF2_ITERATIONS,
      salt: bytesToBase64Url(salt)
    },
    keyWrap: { version: 1, algorithm: 'AES-256-GCM', ...wrapped },
    updatedAt: new Date().toISOString()
  };
}

export function validateEnvelope(envelope) {
  validateVaultKeyWrapEnvelope(envelope);
  if (!envelope.vault?.iv || !envelope.vault?.ciphertext) throw new Error('Vault envelope is incomplete.');
  if (envelope.vault.algorithm !== 'AES-256-GCM') throw new Error('Unsupported VaultCove encryption algorithm.');
}
