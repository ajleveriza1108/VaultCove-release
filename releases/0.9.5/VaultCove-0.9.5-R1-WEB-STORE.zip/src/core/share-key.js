import { base64UrlToBytes, bytesToBase64Url, bytesToUtf8, randomBytes, utf8ToBytes } from './encoding.js';
import { exportPublicSharingIdentity, validatePublicSharingIdentity } from './share.js';

export const VCKEY_MAGIC = 'VAULTCOVE-ENCRYPTED-PUBLIC-IDENTITY';
export const VCKEY_VERSION = 2;
export const VCKEY_PBKDF2_ITERATIONS = 1200000;
const VCKEY_AAD = 'VaultCove:encrypted-vckey:v2';

function validatePassword(password) {
  const value = String(password || '');
  if (value.length < 12) throw new Error('The .vckey password must be at least 12 characters long.');
  if (value.length > 1024) throw new Error('The .vckey password is too long.');
  return value;
}

async function deriveVckeyKey(password, salt, iterations = VCKEY_PBKDF2_ITERATIONS) {
  const material = await crypto.subtle.importKey('raw', utf8ToBytes(validatePassword(password)), 'PBKDF2', false, ['deriveKey']);
  return crypto.subtle.deriveKey(
    { name: 'PBKDF2', hash: 'SHA-256', salt, iterations },
    material,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt']
  );
}

export function isEncryptedVckey(value) {
  return Boolean(value && value.magic === VCKEY_MAGIC && Number(value.version) === VCKEY_VERSION);
}

export async function createEncryptedVckey(vault, password, displayName = 'VaultCove User') {
  const publicIdentity = await exportPublicSharingIdentity(vault, displayName);
  const salt = randomBytes(16);
  const iv = randomBytes(12);
  const key = await deriveVckeyKey(password, salt);
  const plaintext = utf8ToBytes(JSON.stringify(publicIdentity));
  const ciphertext = new Uint8Array(await crypto.subtle.encrypt(
    { name: 'AES-GCM', iv, additionalData: utf8ToBytes(VCKEY_AAD), tagLength: 128 },
    key,
    plaintext
  ));
  return {
    magic: VCKEY_MAGIC,
    version: VCKEY_VERSION,
    createdAt: new Date().toISOString(),
    kdf: {
      name: 'PBKDF2-HMAC-SHA-256',
      iterations: VCKEY_PBKDF2_ITERATIONS,
      salt: bytesToBase64Url(salt)
    },
    cipher: {
      name: 'AES-256-GCM',
      iv: bytesToBase64Url(iv),
      aad: VCKEY_AAD,
      ciphertext: bytesToBase64Url(ciphertext)
    }
  };
}

export async function openEncryptedVckey(value, password) {
  if (!isEncryptedVckey(value)) throw new Error('This is not a supported encrypted VaultCove .vckey file.');
  if (value.kdf?.name !== 'PBKDF2-HMAC-SHA-256' || value.cipher?.name !== 'AES-256-GCM') throw new Error('Unsupported .vckey encryption parameters.');
  const iterations = Number(value.kdf?.iterations || 0);
  if (iterations < 300000 || iterations > 2000000) throw new Error('Invalid .vckey KDF work factor.');
  const salt = base64UrlToBytes(String(value.kdf?.salt || ''));
  const iv = base64UrlToBytes(String(value.cipher?.iv || ''));
  if (salt.length !== 16 || iv.length !== 12 || !value.cipher?.ciphertext) throw new Error('Encrypted .vckey file is incomplete.');
  const key = await deriveVckeyKey(password, salt, iterations);
  let plaintext;
  try {
    plaintext = new Uint8Array(await crypto.subtle.decrypt(
      { name: 'AES-GCM', iv, additionalData: utf8ToBytes(VCKEY_AAD), tagLength: 128 },
      key,
      base64UrlToBytes(value.cipher.ciphertext)
    ));
  } catch {
    throw new Error('Incorrect .vckey password or damaged .vckey file.');
  }
  let publicIdentity;
  try {
    publicIdentity = JSON.parse(bytesToUtf8(plaintext));
  } catch {
    throw new Error('The decrypted .vckey identity is invalid.');
  }
  return validatePublicSharingIdentity(publicIdentity);
}

export function maskedShareId(shareId) {
  const value = String(shareId || '');
  if (value.length <= 8) return '••••••••';
  return `${value.slice(0, 4)}-${'•'.repeat(Math.max(8, value.length - 9))}-${value.slice(-4)}`;
}

export function maskedFingerprint(fingerprint) {
  const chunks = String(fingerprint || '').trim().split(/\s+/).filter(Boolean);
  if (!chunks.length) return '•••• •••• •••• ••••';
  if (chunks.length <= 2) return chunks.map(() => '••••').join(' ');
  return `${chunks[0]} ${chunks[1]} ${Array(Math.max(1, chunks.length - 3)).fill('••••').join(' ')} ${chunks[chunks.length - 1]}`;
}
