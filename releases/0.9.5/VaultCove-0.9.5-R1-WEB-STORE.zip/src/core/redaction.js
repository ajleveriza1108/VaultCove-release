export function maskIdentifier(value) {
  const raw = String(value || '').trim();
  if (!raw) return '(no username)';
  const at = raw.indexOf('@');
  if (at > 0) {
    const local = raw.slice(0, at);
    const domain = raw.slice(at + 1);
    const shown = local.length <= 2 ? local[0] || '•' : local.slice(0, 2);
    return `${shown}${'•'.repeat(Math.max(3, Math.min(8, local.length - shown.length || 3)))}@${domain}`;
  }
  if (raw.length <= 4) return `${raw[0] || '•'}•••`;
  return `${raw.slice(0, 2)}${'•'.repeat(Math.min(8, raw.length - 4))}${raw.slice(-2)}`;
}

export function maskSecret(value, { keepLast = 0, minBullets = 8 } = {}) {
  const raw = String(value || '');
  if (!raw) return '';
  const tail = keepLast > 0 ? raw.slice(-keepLast) : '';
  const bullets = '•'.repeat(Math.max(minBullets, Math.min(16, raw.length - tail.length || minBullets)));
  return `${bullets}${tail}`;
}

export function loginMatchesSearch(item, query) {
  const search = String(query || '').trim().toLowerCase().slice(0, 160);
  if (!search) return true;
  const haystack = [
    item?.name,
    item?.nickname,
    item?.username,
    ...(Array.isArray(item?.tags) ? item.tags : []),
    ...(Array.isArray(item?.urls) ? item.urls : [])
  ].map((value) => String(value || '').toLowerCase()).join('\n');
  return haystack.includes(search);
}

export function publicLoginSummary(item) {
  const useOnlySharedAccess = Boolean(item?.sharedAccess?.mode === 'use-only' && item?.sharedAccess?.immutable === true);
  return {
    id: item.id,
    name: item.name,
    nickname: String(item.nickname || '').trim().slice(0, 80),
    usernameMasked: useOnlySharedAccess ? 'Shared access - credential hidden' : maskIdentifier(item.username),
    hasUsername: useOnlySharedAccess || Boolean(item.username),
    favorite: useOnlySharedAccess ? false : Boolean(item.favorite),
    autoLogin: useOnlySharedAccess ? false : Boolean(item.autoLogin),
    requireReauthBeforeFill: useOnlySharedAccess ? true : Boolean(item.requireReauthBeforeFill),
    pendingPasswordChange: useOnlySharedAccess ? false : Boolean(item.pendingPasswordChange),
    insecureHttp: useOnlySharedAccess ? false : (item.urls || []).some((value) => /^http:\/\//i.test(String(value || '').trim())),
    useOnlySharedAccess
  };
}
