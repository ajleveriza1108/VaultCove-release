import { createItem } from './model.js';
import { normalizeImportedLoginUrl } from './site-match.js';
import { parseTrustedPasswordChangeDate } from './password-age.js';
import { guardianQuarantineAssessment, normalizeGuardianPolicy } from './guardian.js';


export const MIGRATION_LIMITS = Object.freeze({
  maxBytes: 25 * 1024 * 1024,
  maxRows: 50000,
  maxColumns: 256,
  maxFieldChars: 65536,
  maxHeaderChars: 160
});

function validateMigrationSource(text) {
  const source = String(text ?? '').replace(/^\uFEFF/, '');
  const bytes = new TextEncoder().encode(source).length;
  if (bytes > MIGRATION_LIMITS.maxBytes) throw new Error('Migration file exceeds the 25 MB safety limit.');
  return source;
}

function normalizedHeader(value) {
  return String(value ?? '').replace(/^\uFEFF/, '').trim().toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
}

function csvRows(text) {
  const rows = [];
  let row = [];
  let field = '';
  let quoted = false;
  const source = validateMigrationSource(text);

  function pushField() {
    if (field.length > MIGRATION_LIMITS.maxFieldChars) throw new Error('Migration field exceeds the 65,536-character safety limit.');
    row.push(field.replace(/\r$/, ''));
    if (row.length > MIGRATION_LIMITS.maxColumns) throw new Error('Migration CSV has too many columns.');
    field = '';
  }
  function pushRow() {
    if (rows.length >= MIGRATION_LIMITS.maxRows + 1) throw new Error('Migration CSV exceeds the 50,000-row safety limit.');
    rows.push(row);
    row = [];
  }

  for (let i = 0; i < source.length; i += 1) {
    const ch = source[i];
    if (quoted) {
      if (ch === '"') {
        if (source[i + 1] === '"') { field += '"'; i += 1; }
        else quoted = false;
      } else field += ch;
      if (field.length > MIGRATION_LIMITS.maxFieldChars) throw new Error('Migration field exceeds the 65,536-character safety limit.');
      continue;
    }
    if (ch === '"') quoted = true;
    else if (ch === ',') pushField();
    else if (ch === '\n') { pushField(); pushRow(); }
    else {
      field += ch;
      if (field.length > MIGRATION_LIMITS.maxFieldChars) throw new Error('Migration field exceeds the 65,536-character safety limit.');
    }
  }
  if (quoted) throw new Error('Migration CSV contains an unterminated quoted field.');
  if (field.length || row.length) { pushField(); pushRow(); }
  return rows.filter((candidate) => candidate.some((value) => String(value).trim() !== ''));
}

export function parseCsv(text) {
  const rows = csvRows(text);
  if (rows.length < 2) throw new Error('The CSV does not contain any data rows.');
  if (rows[0].length > MIGRATION_LIMITS.maxColumns) throw new Error('Migration CSV has too many columns.');
  const originalHeaders = rows[0].map((header, index) => {
    const value = String(header || `Column ${index + 1}`).replace(/^\uFEFF/, '').trim();
    if (value.length > MIGRATION_LIMITS.maxHeaderChars) throw new Error('Migration CSV contains an excessively long column header.');
    return value;
  });
  const headers = originalHeaders.map(normalizedHeader);
  const records = rows.slice(1).map((values) => {
    const record = { __headers: originalHeaders };
    headers.forEach((header, index) => { record[header || `column ${index + 1}`] = String(values[index] ?? ''); });
    return record;
  }).filter((record) => headers.some((header) => String(record[header] ?? '').trim() !== ''));
  return { headers, originalHeaders, records };
}

function valueOf(row, ...aliases) {
  for (const alias of aliases) {
    const key = normalizedHeader(alias);
    if (Object.prototype.hasOwnProperty.call(row, key) && String(row[key]).trim() !== '') return String(row[key]).trim();
  }
  return '';
}

function boolValue(value) {
  return /^(1|true|yes|y|favorite|fav)$/i.test(String(value ?? '').trim());
}

function safeUrl(value) {
  const text = String(value ?? '').trim();
  if (!text || /^http:\/\/sn\/?$/i.test(text)) return '';
  return text;
}

function extractTotpSecret(value) {
  const raw = String(value ?? '').trim();
  if (!raw || /^\d{6,8}$/.test(raw)) return '';
  if (/^otpauth:\/\//i.test(raw)) {
    try { return new URL(raw).searchParams.get('secret')?.replace(/[\s-]/g, '').toUpperCase() || ''; } catch { return ''; }
  }
  const compact = raw.replace(/[\s-]/g, '').toUpperCase();
  return /^[A-Z2-7]+=*$/.test(compact) && compact.length >= 16 ? compact.replace(/=+$/, '') : '';
}

function withSourceTags(tags, source, folder = '') {
  const out = ['Imported', source];
  if (folder) out.push(`Folder: ${folder}`);
  for (const tag of tags || []) if (tag && !out.includes(tag)) out.push(tag);
  return out.slice(0, 20);
}

function appendUnmappedFields(row, usedHeaders, notes = '') {
  const extras = [];
  const used = new Set([...usedHeaders].map(normalizedHeader));
  for (const header of row.__headers || []) {
    const key = normalizedHeader(header);
    const value = String(row[key] ?? '').trim();
    if (value && !used.has(key)) extras.push(`${header}: ${value}`);
  }
  if (!extras.length) return notes;
  return [notes, 'Imported fields:', ...extras].filter(Boolean).join('\n');
}

export function detectMigrationFormat(csv) {
  const h = new Set(csv.headers);
  if (h.has('url') && h.has('username') && h.has('password') && h.has('name') && (h.has('extra') || h.has('grouping') || h.has('fav'))) return 'lastpass';
  if (h.has('password name') || h.has('password url') || (h.has('username') && h.has('password') && h.has('category'))) return 'zoho';
  if (h.has('login username') && h.has('login password')) return 'bitwarden';
  if (h.has('login_username') && h.has('login_password')) return 'bitwarden';
  if (h.has('title') && h.has('username') && h.has('password') && (h.has('url') || h.has('website'))) return 'generic';
  if (h.has('name') && h.has('username') && h.has('password') && (h.has('url') || h.has('website'))) return 'generic';
  if (h.has('username') && h.has('password') && (h.has('url') || h.has('website') || h.has('login url') || h.has('uri'))) return 'generic';
  return 'unknown';
}

export function importLastPassCsv(text) {
  const csv = parseCsv(text);
  const required = ['url','username','password','extra','name'];
  if (required.filter((key) => csv.headers.includes(key)).length < 4) throw new Error('This does not look like a LastPass CSV export.');
  const warnings = [];
  const items = [];

  for (const row of csv.records) {
    const name = valueOf(row, 'name') || 'Imported LastPass item';
    const rawUrl = safeUrl(valueOf(row, 'url'));
    const url = normalizeImportedLoginUrl(rawUrl, name);
    const username = valueOf(row, 'username');
    const password = valueOf(row, 'password');
    const extra = valueOf(row, 'extra');
    const grouping = valueOf(row, 'grouping');
    const favorite = boolValue(valueOf(row, 'fav'));
    const lastPasswordChangeAt = parseTrustedPasswordChangeDate(valueOf(row, 'password changed at', 'password changed', 'last password change', 'password modified', 'password updated'));
    const rawTotp = valueOf(row, 'totp');
    const totpSecret = extractTotpSecret(rawTotp);
    const isNote = /^http:\/\/sn\/?$/i.test(valueOf(row, 'url')) || (!url && !username && !password && Boolean(extra));

    if (isNote) {
      items.push(createItem('note', { name, text: extra, favorite, tags: withSourceTags([], 'LastPass', grouping) }));
      continue;
    }

    let notes = extra;
    if (rawTotp && !totpSecret) {
      notes = [notes, 'LastPass TOTP field was preserved but not activated because it was not a recognizable secret:', rawTotp].filter(Boolean).join('\n');
      warnings.push(`TOTP for “${name}” could not be safely recognized as a secret and was kept in Notes.`);
    }
    items.push(createItem('login', {
      name,
      username,
      password,
      urls: url ? [url] : [],
      totpSecret,
      notes,
      favorite,
      lastPasswordChangeAt,
      importedAt: new Date().toISOString(),
      tags: withSourceTags([], 'LastPass', grouping)
    }));
  }
  return { source: 'LastPass CSV', format: 'lastpass', items, warnings };
}

function zohoCategory(row) {
  return valueOf(row, 'category', 'password category', 'type', 'secret type').toLowerCase();
}

function zohoItem(row) {
  const category = zohoCategory(row);
  const name = valueOf(row, 'password name', 'name', 'title', 'secret name') || 'Imported Zoho Vault item';
  const folder = valueOf(row, 'folder', 'folder name');
  const favorite = boolValue(valueOf(row, 'favorite', 'fav'));
  const tags = withSourceTags(valueOf(row, 'tags').split(/[;,]/).map((v) => v.trim()).filter(Boolean), 'Zoho Vault', folder);
  const noteText = valueOf(row, 'notes', 'note', 'description', 'secure note', 'comments');

  if (/bank|financial/.test(category)) {
    const used = ['password name','name','title','secret name','category','password category','type','secret type','folder','folder name','favorite','fav','tags','notes','note','description','comments','bank name','bank','account holder','account holder name','account type','account number','routing number','aba routing number','iban','swift','swift bic','bic','branch','pin'];
    return createItem('bank', {
      name,
      bankName: valueOf(row, 'bank name', 'bank'),
      accountHolder: valueOf(row, 'account holder', 'account holder name'),
      accountType: valueOf(row, 'account type'),
      accountNumber: valueOf(row, 'account number'),
      routingNumber: valueOf(row, 'routing number', 'aba routing number'),
      iban: valueOf(row, 'iban'),
      swiftBic: valueOf(row, 'swift', 'swift bic', 'bic'),
      branch: valueOf(row, 'branch'),
      pin: valueOf(row, 'pin'),
      notes: appendUnmappedFields(row, used, noteText), favorite, tags
    });
  }

  if (/card|payment/.test(category)) {
    const used = ['password name','name','title','secret name','category','password category','type','secret type','folder','folder name','favorite','fav','tags','notes','note','description','comments','cardholder','card holder','name on card','brand','card type','card number','number','security code','cvv','cvc','expiry month','expiration month','exp month','expiry year','expiration year','exp year','billing address'];
    return createItem('card', {
      name,
      cardholder: valueOf(row, 'cardholder', 'card holder', 'name on card'),
      brand: valueOf(row, 'brand', 'card type'),
      number: valueOf(row, 'card number', 'number'),
      securityCode: valueOf(row, 'security code', 'cvv', 'cvc'),
      expMonth: valueOf(row, 'expiry month', 'expiration month', 'exp month'),
      expYear: valueOf(row, 'expiry year', 'expiration year', 'exp year'),
      billingAddress: valueOf(row, 'billing address'),
      notes: appendUnmappedFields(row, used, noteText), favorite, tags
    });
  }

  if (/address|identity|personal/.test(category)) {
    const used = ['password name','name','title','secret name','category','password category','type','secret type','folder','folder name','favorite','fav','tags','notes','note','description','comments','first name','middle name','last name','company','email','phone','telephone','address 1','address line 1','address 2','address line 2','city','state','province','postal code','zip','country','government id','id number'];
    return createItem('identity', {
      name,
      firstName: valueOf(row, 'first name'), middleName: valueOf(row, 'middle name'), lastName: valueOf(row, 'last name'),
      company: valueOf(row, 'company'), email: valueOf(row, 'email'), phone: valueOf(row, 'phone', 'telephone'),
      address1: valueOf(row, 'address 1', 'address line 1'), address2: valueOf(row, 'address 2', 'address line 2'),
      city: valueOf(row, 'city'), state: valueOf(row, 'state', 'province'), postalCode: valueOf(row, 'postal code', 'zip'), country: valueOf(row, 'country'),
      governmentId: valueOf(row, 'government id', 'id number'), notes: appendUnmappedFields(row, used, noteText), favorite, tags
    });
  }

  if (/note/.test(category)) {
    return createItem('note', { name, text: appendUnmappedFields(row, ['password name','name','title','secret name','category','password category','type','secret type','folder','folder name','favorite','fav','tags','notes','note','description','secure note','comments'], noteText), favorite, tags });
  }

  const rawUrl = safeUrl(valueOf(row, 'password url', 'url', 'website', 'login url'));
  const url = normalizeImportedLoginUrl(rawUrl, name);
  const username = valueOf(row, 'username', 'user name', 'login');
  const password = valueOf(row, 'password');
  const rawTotp = valueOf(row, 'totp', 'totp secret', 'otp secret');
  const totpSecret = extractTotpSecret(rawTotp);
  const lastPasswordChangeAt = parseTrustedPasswordChangeDate(valueOf(row, 'password changed at', 'password changed', 'last password change', 'password modified', 'password updated'));
  const used = ['password name','name','title','secret name','category','password category','type','secret type','folder','folder name','favorite','fav','tags','notes','note','description','comments','password url','url','website','login url','username','user name','login','password','totp','totp secret','otp secret','password changed at','password changed','last password change','password modified','password updated'];
  let notes = appendUnmappedFields(row, used, noteText);
  if (rawTotp && !totpSecret) notes = [notes, `Unrecognized TOTP field: ${rawTotp}`].filter(Boolean).join('\n');
  return createItem('login', { name, username, password, urls: url ? [url] : [], totpSecret, notes, favorite, tags, lastPasswordChangeAt, importedAt: new Date().toISOString() });
}

export function importZohoVaultCsv(text) {
  const csv = parseCsv(text);
  const looksZoho = csv.headers.includes('password name') || csv.headers.includes('password url') || (csv.headers.includes('username') && csv.headers.includes('password'));
  if (!looksZoho) throw new Error('This does not look like a Zoho Vault CSV export.');
  return { source: 'Zoho Vault CSV', format: 'zoho', items: csv.records.map(zohoItem), warnings: [] };
}


function genericSourceName(csv) {
  const h = new Set(csv.headers);
  if (h.has('login username') || h.has('login password') || h.has('login_username') || h.has('login_password')) return 'Bitwarden-compatible CSV';
  if (h.has('name') && h.has('url') && h.has('username') && h.has('password')) return 'Chrome / Google Password Manager-compatible CSV';
  if (h.has('title') && (h.has('url') || h.has('website')) && h.has('username') && h.has('password')) return '1Password-compatible CSV';
  return 'Password-manager CSV';
}

export function importGenericLoginCsv(text) {
  const csv = parseCsv(text);
  const format = detectMigrationFormat(csv);
  if (!['generic','bitwarden'].includes(format)) throw new Error('VaultCove could not recognize a supported login CSV layout.');
  const source = genericSourceName(csv);
  const warnings = [];
  const items = [];

  for (const row of csv.records) {
    const name = valueOf(row, 'name', 'title', 'item name', 'login name') || 'Imported login';
    const rawUrl = safeUrl(valueOf(row, 'url', 'website', 'login url', 'uri', 'login uri', 'login_uri'));
    const url = normalizeImportedLoginUrl(rawUrl, name);
    const username = valueOf(row, 'username', 'user name', 'login', 'login username', 'login_username');
    const password = valueOf(row, 'password', 'login password', 'login_password');
    const noteText = valueOf(row, 'notes', 'note', 'extra', 'comments');
    const rawTotp = valueOf(row, 'totp', 'otp', 'otp secret', 'totp secret', 'login totp', 'login_totp', 'one time password', 'one-time password');
    const totpSecret = extractTotpSecret(rawTotp);
    const folder = valueOf(row, 'folder', 'folder name');
    const favorite = boolValue(valueOf(row, 'favorite', 'fav'));
    const lastPasswordChangeAt = parseTrustedPasswordChangeDate(valueOf(row, 'password changed at', 'password changed', 'last password change', 'password modified', 'password updated'));
    const used = [
      'name','title','item name','login name','url','website','login url','uri','login uri','login_uri',
      'username','user name','login','login username','login_username','password','login password','login_password',
      'notes','note','extra','comments','totp','otp','otp secret','totp secret','login totp','login_totp','one time password','one-time password',
      'folder','folder name','favorite','fav','password changed at','password changed','last password change','password modified','password updated'
    ];
    let notes = appendUnmappedFields(row, used, noteText);
    if (rawTotp && !totpSecret) {
      notes = [notes, 'An imported TOTP field was preserved in Notes because VaultCove could not safely recognize it as a TOTP secret.', rawTotp].filter(Boolean).join('\n');
      warnings.push(`TOTP for “${name}” could not be safely recognized and was preserved in Notes.`);
    }
    if (!username && !password && !url) continue;
    items.push(createItem('login', {
      name,
      username,
      password,
      urls: url ? [url] : [],
      totpSecret,
      notes,
      favorite,
      lastPasswordChangeAt,
      importedAt: new Date().toISOString(),
      tags: withSourceTags([], source.replace(/-compatible CSV$/,'').replace(/ CSV$/,''), folder)
    }));
  }

  if (!items.length) throw new Error('VaultCove recognized the CSV but found no importable login records.');
  return { source, format, items, warnings };
}

export function importMigrationCsv(text) {
  const csv = parseCsv(text);
  const format = detectMigrationFormat(csv);
  let result;
  if (format === 'lastpass') result = importLastPassCsv(text);
  else if (format === 'zoho') result = importZohoVaultCsv(text);
  else if (format === 'generic' || format === 'bitwarden') result = importGenericLoginCsv(text);
  else throw new Error('VaultCove could not automatically identify this password-manager CSV. Export logins as CSV with recognizable name/title, URL, username, and password columns.');

  result.items = (result.items || []).map((item) => {
    if (item?.type !== 'login') return item;
    const guardian = normalizeGuardianPolicy(item.guardian || {}, item);
    const assessment = guardianQuarantineAssessment({ ...item, guardian });
    if (assessment.quarantine) {
      guardian.quarantine = true;
      guardian.quarantineReason = assessment.reason;
    }
    return { ...item, guardian };
  });
  return result;
}

function mergeToken(value) {
  return String(value ?? '').trim().toLowerCase().replace(/\s+/g, ' ');
}

function canonicalImportHost(value) {
  const raw = String(value ?? '').trim();
  if (!raw) return '';
  try {
    const url = new URL(/^https?:\/\//i.test(raw) ? raw : `https://${raw}`);
    return url.hostname.toLowerCase().replace(/^www\./, '');
  } catch {
    return raw.toLowerCase()
      .replace(/^https?:\/\//, '')
      .split(/[/?#]/)[0]
      .replace(/^www\./, '');
  }
}

function compactDigits(value) {
  return String(value ?? '').replace(/\D/g, '');
}

function uniqueTextValues(values = []) {
  const out = [];
  const seen = new Set();
  for (const value of values || []) {
    const text = String(value ?? '').trim();
    if (!text) continue;
    const key = text.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(text);
  }
  return out;
}

function itemDuplicateFingerprints(item = {}) {
  const type = String(item.type || '');
  const name = mergeToken(item.name);
  const out = [];
  const id = String(item.id || '').trim();
  if (id) out.push(`${type}|id:${id}`);

  if (type === 'login') {
    const username = mergeToken(item.username);
    const hosts = uniqueTextValues((item.urls || []).map(canonicalImportHost)).filter(Boolean);
    if (username && hosts.length) {
      for (const host of hosts) out.push(`login|user:${username}|host:${host}`);
    } else if (username && name) {
      out.push(`login|name:${name}|user:${username}`);
    } else if (hosts.length && name) {
      for (const host of hosts) out.push(`login|name:${name}|host:${host}`);
    }
    if (!out.length && name) out.push(`login|name:${name}`);
    return out;
  }

  if (type === 'card') {
    const number = compactDigits(item.number);
    if (number.length >= 8) out.push(`card|number:${number}`);
    const holder = mergeToken(item.cardholder);
    if (!out.length && name && holder) out.push(`card|name:${name}|holder:${holder}`);
    return out.length ? out : (name ? [`card|name:${name}`] : []);
  }

  if (type === 'bank') {
    const account = mergeToken(item.accountNumber).replace(/\s+/g, '');
    const bank = mergeToken(item.bankName);
    if (account) out.push(`bank|account:${account}`);
    if (!out.length && bank && name) out.push(`bank|bank:${bank}|name:${name}`);
    return out.length ? out : (name ? [`bank|name:${name}`] : []);
  }

  if (type === 'identity') {
    const email = mergeToken(item.email);
    const governmentId = mergeToken(item.governmentId);
    if (email) out.push(`identity|email:${email}`);
    if (governmentId) out.push(`identity|gov:${governmentId}`);
    return out.length ? out : (name ? [`identity|name:${name}`] : []);
  }

  if (type === 'note') {
    const text = mergeToken(item.text).slice(0, 512);
    if (name && text) return [`note|name:${name}|text:${text}`];
    return name ? [`note|name:${name}`] : [];
  }

  return name ? [`${type}|name:${name}`] : [];
}

function mergedText(existingValue, incomingValue) {
  const existing = String(existingValue ?? '').trim();
  const incoming = String(incomingValue ?? '').trim();
  if (!incoming) return { value: existingValue, changed:false };
  if (!existing) return { value: incoming, changed:true };
  if (existing === incoming || existing.includes(incoming)) return { value: existingValue, changed:false };
  if (incoming.includes(existing)) return { value: incoming, changed:true };
  return { value: `${existing}\n\n--- Imported merge ---\n${incoming}`, changed:true };
}

function mergeArrayByJson(existingValue, incomingValue) {
  const existing = Array.isArray(existingValue) ? existingValue : [];
  const incoming = Array.isArray(incomingValue) ? incomingValue : [];
  const out = [...existing];
  const seen = new Set(existing.map((value) => JSON.stringify(value)));
  let changed = false;
  for (const value of incoming) {
    const key = JSON.stringify(value);
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(value);
    changed = true;
  }
  return { value: out, changed };
}

const MERGE_NEVER_COPY = new Set([
  'id', 'type', 'createdAt', 'updatedAt', 'deletedAt',
  'sharedAccess', 'trashSealed', 'trashEnvelope',
  'pendingPasswordChange', 'passwordHistory', 'siteVisual'
]);

const MERGE_SENSITIVE_FIELDS = new Set([
  'password', 'totpSecret',
  'number', 'securityCode',
  'accountNumber', 'routingNumber', 'iban', 'swiftBic', 'pin',
  'governmentId'
]);

function mergeDuplicateItem(existing, incoming) {
  let changed = false;
  let conflicts = 0;

  if (incoming.favorite && !existing.favorite) {
    existing.favorite = true;
    changed = true;
  }

  for (const key of ['urls', 'trustedHosts', 'tags', 'customFields']) {
    const merged = mergeArrayByJson(existing[key], incoming[key]);
    if (merged.changed) {
      existing[key] = merged.value;
      changed = true;
    }
  }

  for (const key of ['notes', 'text']) {
    if (!Object.prototype.hasOwnProperty.call(incoming, key)) continue;
    const merged = mergedText(existing[key], incoming[key]);
    if (merged.changed) {
      existing[key] = merged.value;
      changed = true;
    }
  }

  if (!existing.folderId && incoming.folderId) {
    existing.folderId = incoming.folderId;
    changed = true;
  }

  if (!existing.importedAt && incoming.importedAt) {
    existing.importedAt = incoming.importedAt;
    changed = true;
  }

  if (incoming.lastPasswordChangeAt) {
    const currentTime = Date.parse(existing.lastPasswordChangeAt || '') || 0;
    const incomingTime = Date.parse(incoming.lastPasswordChangeAt || '') || 0;
    if (incomingTime > currentTime) {
      existing.lastPasswordChangeAt = incoming.lastPasswordChangeAt;
      changed = true;
    }
  }

  if (incoming.requireReauthBeforeFill && !existing.requireReauthBeforeFill) {
    existing.requireReauthBeforeFill = true;
    changed = true;
  }

  for (const [key, incomingValue] of Object.entries(incoming || {})) {
    if (MERGE_NEVER_COPY.has(key)) continue;
    if (['favorite', 'urls', 'trustedHosts', 'tags', 'customFields', 'notes', 'text', 'folderId', 'importedAt', 'lastPasswordChangeAt', 'requireReauthBeforeFill'].includes(key)) continue;
    if (incomingValue == null || incomingValue === '') continue;
    if (Array.isArray(incomingValue) || typeof incomingValue === 'object') continue;

    const existingValue = existing[key];
    const existingEmpty = existingValue == null || existingValue === '';
    if (existingEmpty) {
      existing[key] = incomingValue;
      changed = true;
      continue;
    }

    if (MERGE_SENSITIVE_FIELDS.has(key) && String(existingValue) !== String(incomingValue)) {
      conflicts += 1;
    }
  }

  if (changed) existing.updatedAt = new Date().toISOString();
  return { changed, conflicts };
}

export function mergeImportedItems(existingItems, importedItems, { skipDuplicates = true, mergeDuplicates = false } = {}) {
  const activeExisting = (existingItems || []).filter((item) => !item.deletedAt);
  const fingerprintMap = new Map();

  for (const item of activeExisting) {
    for (const fingerprint of itemDuplicateFingerprints(item)) {
      if (!fingerprintMap.has(fingerprint)) fingerprintMap.set(fingerprint, item);
    }
  }

  const accepted = [];
  const merged = [];
  let unchanged = 0;
  let conflicts = 0;
  let skipped = 0;

  for (const item of importedItems || []) {
    if (!item || item.deletedAt) continue;

    let duplicate = null;
    for (const fingerprint of itemDuplicateFingerprints(item)) {
      duplicate = fingerprintMap.get(fingerprint) || null;
      if (duplicate) break;
    }

    if (duplicate && skipDuplicates) {
      if (mergeDuplicates) {
        const result = mergeDuplicateItem(duplicate, item);
        conflicts += result.conflicts;
        if (result.changed) merged.push(duplicate);
        else unchanged += 1;
      } else {
        skipped += 1;
      }
      continue;
    }

    accepted.push(item);
    for (const fingerprint of itemDuplicateFingerprints(item)) {
      if (!fingerprintMap.has(fingerprint)) fingerprintMap.set(fingerprint, item);
    }
  }

  return {
    accepted,
    merged,
    mergedCount: merged.length,
    unchanged,
    conflicts,
    skipped
  };
}
