import { randomId } from './encoding.js';
import { insecureHttpLoginMatchesUrl, loginMatchesTrustedHost } from './site-match.js';

export function normalizeLoginIdentifier(value) {
  return String(value || '').trim().toLowerCase();
}

export function findExistingLoginForCapture(items, hostname, username, origin = '') {
  const normalized = normalizeLoginIdentifier(username);
  if (!normalized) return null;
  return (items || []).find((item) =>
    item?.type === 'login' &&
    !item.deletedAt &&
    (String(origin || '').startsWith('http://') ? insecureHttpLoginMatchesUrl(item, origin) : loginMatchesTrustedHost(item, hostname)) &&
    normalizeLoginIdentifier(item.username) === normalized
  ) || null;
}

export function prunePendingLoginCaptures(captures, now = Date.now(), maxAgeMs = 7 * 24 * 60 * 60 * 1000) {
  return (Array.isArray(captures) ? captures : []).filter((entry) => {
    const time = Date.parse(entry?.detectedAt || '');
    return Number.isFinite(time) && now - time <= maxAgeMs;
  }).slice(-50);
}

export function createPendingLoginCapture({ hostname, origin, username, password, name, source = 'submitted-credential' }) {
  const cleanHost = String(hostname || '').trim().toLowerCase();
  const cleanOrigin = String(origin || '').trim();
  const cleanUsername = String(username || '').trim().slice(0, 512);
  const cleanPassword = String(password || '');
  if (!cleanHost || !/^https?:\/\//i.test(cleanOrigin)) throw new Error('An HTTP or HTTPS website is required for login capture.');
  if (!cleanUsername) throw new Error('A username, email, phone, or account identifier is required for login capture.');
  if (cleanPassword.length < 4 || cleanPassword.length > 4096) throw new Error('Captured password length is outside the supported range.');
  return {
    id: randomId('capture'),
    type: 'login',
    hostname: cleanHost,
    origin: cleanOrigin,
    name: String(name || cleanHost).trim().slice(0, 120) || cleanHost,
    username: cleanUsername,
    password: cleanPassword,
    source: String(source || 'submitted-credential').slice(0, 80),
    detectedAt: new Date().toISOString()
  };
}

export function samePendingLoginCapture(left, right) {
  return Boolean(left && right &&
    String(left.hostname || '').toLowerCase() === String(right.hostname || '').toLowerCase() &&
    String(left.origin || '').toLowerCase() === String(right.origin || '').toLowerCase() &&
    normalizeLoginIdentifier(left.username) === normalizeLoginIdentifier(right.username) &&
    String(left.password || '') === String(right.password || ''));
}
