import { TESTING_FULL_ACCESS } from './constants.js';
import { ensureDeviceId, ensureDeviceRecoveryToken } from './storage.js';
import { LICENSE_LEASE_PUBLIC_KEY_SPKI_BASE64 } from './license-key.js';
import { LICENSE_SERVICE_ENDPOINT } from './license-endpoint.js';
import { sealLicenseCredential, openLicenseCredential, clearLicenseCredentialKey } from './license-credential-store.js';

const STORAGE_KEY = 'vaultcoveLicenseClient';
const DEVICE_SNAPSHOT_STORAGE_KEY = 'vaultcoveLicenseDeviceSnapshot';
const DEVICE_SNAPSHOT_CACHE_VERSION = 1;
const DEVICE_SNAPSHOT_MAX_AGE_MS = 7 * 24 * 60 * 60 * 1000;
const LICENSE_HOSTS = ['https://script.google.com/*', 'https://script.googleusercontent.com/*'];
const MAX_DEVICE_LABEL = 80;
const LICENSE_PROTOCOL_VERSION = 3;
const LICENSE_RESPONSE_MAX_CHARS = 64 * 1024;
const LICENSE_REQUEST_TIMEOUT_MS = 15_000;

function normalizeEmail(value) {
  return String(value || '').trim().toLowerCase();
}

function validateEmail(value) {
  const email = normalizeEmail(value);
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254) throw new Error('Enter a valid license email address.');
  return email;
}

export function detectRuntimePlatform() {
  const ua = String(globalThis.navigator?.userAgent || '');
  const uaPlatform = String(globalThis.navigator?.userAgentData?.platform || '');
  const legacyPlatform = String(globalThis.navigator?.platform || '');
  const source = `${uaPlatform} ${legacyPlatform} ${ua}`.toLowerCase();

  if (/\bcros\b|chrome\s?os|chromebook/.test(source)) return 'Chrome OS / Chrome';
  if (/windows|win32|win64|winnt|win\d/.test(source)) return 'Windows / Chrome';
  if (/macintosh|macintel|mac\s?os|macos/.test(source)) return 'macOS / Chrome';
  if (/linux/.test(source)) return 'Linux / Chrome';

  const platform = uaPlatform || legacyPlatform || 'Unknown platform';
  return `${platform} / Chrome`;
}

export function validateLicenseServiceUrl(value) {
  const text = String(value || '').trim();
  if (!text || text === 'UNCONFIGURED') throw new Error('VaultCove licensing transport is not configured in this build yet.');
  let url;
  try { url = new URL(text); } catch { throw new Error('License-service URL is invalid.'); }
  if (url.protocol !== 'https:' || url.hostname !== 'script.google.com' || !/^\/macros\/s\/[^/]+\/exec$/.test(url.pathname)) {
    throw new Error('Use the HTTPS Apps Script Web App /macros/s/.../exec URL.');
  }
  return url.toString();
}

export async function ensureLicenseServicePermission() {
  const has = await chrome.permissions.contains({ origins: LICENSE_HOSTS });
  if (has) return true;
  return chrome.permissions.request({ origins: LICENSE_HOSTS });
}

export async function getLicenseClientState() {
  const installationId = await ensureDeviceId();
  const result = await chrome.storage.local.get(STORAGE_KEY);
  const stored = result[STORAGE_KEY] && typeof result[STORAGE_KEY] === 'object' ? result[STORAGE_KEY] : {};
  let refreshToken = '';
  let licenseSerial = '';
  let credentialError = '';

  // One-time migration from the pre-0.7.27 plaintext client state. The plaintext
  // values are rewritten as AES-GCM ciphertext immediately and then removed.
  if (stored.refreshToken || stored.licenseSerial) {
    try {
      const refreshTokenCipher = stored.refreshToken ? await sealLicenseCredential(String(stored.refreshToken), installationId, 'refresh-token') : stored.refreshTokenCipher || null;
      const licenseSerialCipher = stored.licenseSerial ? await sealLicenseCredential(String(stored.licenseSerial), installationId, 'license-serial') : stored.licenseSerialCipher || null;
      const migrated = { ...stored, clientStateVersion: 3, refreshTokenCipher, licenseSerialCipher };
      delete migrated.refreshToken;
      delete migrated.licenseSerial;
      await chrome.storage.local.set({ [STORAGE_KEY]: migrated });
      Object.assign(stored, migrated);
      delete stored.refreshToken;
      delete stored.licenseSerial;
    } catch (error) {
      credentialError = error?.message || 'Could not migrate the protected license credential.';
    }
  }

  const credentialErrors = [];
  if (stored.refreshTokenCipher) {
    try { refreshToken = await openLicenseCredential(stored.refreshTokenCipher, installationId, 'refresh-token'); }
    catch (error) { credentialErrors.push(`Refresh token: ${error?.message || 'could not be decrypted'}`); }
  }
  if (stored.licenseSerialCipher) {
    try { licenseSerial = await openLicenseCredential(stored.licenseSerialCipher, installationId, 'license-serial'); }
    catch (error) { credentialErrors.push(`License key: ${error?.message || 'could not be decrypted'}`); }
  }
  if (credentialErrors.length) credentialError = credentialErrors.join(' ');

  // The signed lease remains independently verifiable even when this Chrome
  // profile can no longer open an older wrapped refresh-token/serial key.
  // Re-verify the stored signature on every client-state read instead of trusting
  // a stale boolean. This lets an already-valid owner-admin installation recover
  // its Premium/device-management UI without forcing a needless reactivation.
  let leaseVerifiedNow = false;
  let leaseVerificationError = '';
  if (stored.lease && stored.leaseSignature) {
    try {
      const verification = await verifySignedLicenseLease(stored.lease, stored.leaseSignature);
      leaseVerifiedNow = Boolean(verification.verified);
    } catch (error) {
      leaseVerificationError = String(error?.message || error || 'Signed license verification failed.');
    }
  }

  return {
    clientStateVersion: Number(stored.clientStateVersion || 3),
    hasEncryptedRefreshToken: Boolean(stored.refreshTokenCipher),
    hasEncryptedLicenseSerial: Boolean(stored.licenseSerialCipher),
    lease: null,
    leaseSignature: '',
    emailMasked: '',
    serialHint: '',
    lastValidatedAt: null,
    ...stored,
    refreshToken,
    licenseSerial,
    credentialEncryptionOk: !credentialError,
    credentialError,
    leaseVerified: leaseVerifiedNow,
    leaseVerificationError
  };
}

export async function clearLicenseClientState() {
  await chrome.storage.local.remove([STORAGE_KEY, DEVICE_SNAPSHOT_STORAGE_KEY]);
  await clearLicenseCredentialKey();
}

function strictRequest(action, input = {}) {
  const allowed = {
    beginActivation: ['serial', 'email', 'installationId', 'deviceRecoveryToken', 'deviceLabel', 'platform', 'appVersion'],
    completeActivation: ['challengeId', 'code', 'serial', 'installationId', 'deviceRecoveryToken', 'physicalDeviceLinkCode'],
    completeRecoveryActivation: ['reclaimToken', 'serial', 'installationId', 'deviceRecoveryToken', 'targetInstallationId', 'deviceLabel', 'platform', 'appVersion'],
    refreshLease: ['installationId', 'refreshToken', 'serial'],
    beginManageDevices: ['installationId', 'refreshToken', 'serial'],
    beginManageDevicesByLease: ['installationId', 'lease', 'leaseSignature'],
    completeManageDevices: ['challengeId', 'code', 'installationId'],
    beginCurrentDeviceAdmin: ['installationId', 'lease', 'leaseSignature'],
    completeCurrentDeviceAdmin: ['challengeId', 'code', 'installationId'],
    syncCurrentDeviceLease: ['installationId', 'lease', 'leaseSignature'],
    listOwnDevices: ['installationId', 'refreshToken', 'serial'],
    listOwnDevicesByLease: ['installationId', 'lease', 'leaseSignature'],
    listDevices: ['managementToken', 'installationId'],
    deviceAction: ['managementToken', 'installationId', 'targetInstallationId', 'deviceAction'],
    deleteReleasedDevices: ['managementToken', 'installationId'],
    beginPhysicalDeviceLink: ['installationId', 'lease', 'leaseSignature'],
    completePhysicalDeviceLink: ['challengeId', 'code', 'installationId'],
    sendSecurityNotice: ['installationId', 'refreshToken', 'serial', 'noticeId', 'eventKind', 'occurredAt', 'siteHost', 'timeZone', 'recordType', 'shareCount', 'recipientHint'],
    sendSecurityNoticeByLease: ['installationId', 'lease', 'leaseSignature', 'noticeId', 'eventKind', 'occurredAt', 'siteHost', 'timeZone', 'recordType', 'shareCount', 'recipientHint'],
    beginBackupRestoreOtp: ['installationId', 'backupId', 'email'],
    completeBackupRestoreOtp: ['installationId', 'backupId', 'challengeId', 'code'],
    createGuardianApproval: ['installationId', 'lease', 'leaseSignature', 'operation', 'itemId', 'itemLabel'],
    listGuardianApprovals: ['installationId', 'lease', 'leaseSignature'],
    decideGuardianApproval: ['installationId', 'lease', 'leaseSignature', 'approvalId', 'decision'],
    consumeGuardianApproval: ['installationId', 'lease', 'leaseSignature', 'approvalId']
  };
  if (!allowed[action]) throw new Error('Unsupported license-service action.');
  const requestBytes = crypto.getRandomValues(new Uint8Array(18));
  const nonce = Array.from(requestBytes, (byte) => byte.toString(16).padStart(2, '0')).join('');
  const output = {
    action,
    protocolVersion: LICENSE_PROTOCOL_VERSION,
    product: 'VaultCove',
    requestId: crypto.randomUUID(),
    nonce,
    clientTime: new Date().toISOString()
  };
  for (const key of allowed[action]) if (Object.prototype.hasOwnProperty.call(input, key)) output[key] = input[key];
  return output;
}

async function postLicense(action, input = {}) {
  const endpoint = validateLicenseServiceUrl(LICENSE_SERVICE_ENDPOINT);
  const payload = strictRequest(action, input);
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), LICENSE_REQUEST_TIMEOUT_MS);
  try {
    const response = await fetch(endpoint, {
      method: 'POST',
      redirect: 'follow',
      headers: { 'Content-Type': 'text/plain;charset=utf-8' },
      body: JSON.stringify(payload),
      cache: 'no-store',
      credentials: 'omit',
      referrerPolicy: 'no-referrer',
      signal: controller.signal
    });
    if (!response.ok) throw new Error(`License service returned HTTP ${response.status}.`);
    const declaredLength = Number(response.headers.get('content-length') || 0);
    if (declaredLength > LICENSE_RESPONSE_MAX_CHARS) throw new Error('License service response is unexpectedly large.');
    const responseText = await response.text();
    if (responseText.length > LICENSE_RESPONSE_MAX_CHARS) throw new Error('License service response is unexpectedly large.');
    let value;
    try { value = JSON.parse(responseText); } catch { throw new Error('License service returned invalid JSON.'); }
    if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error('License service returned an invalid response object.');
    if (!value.ok) {
      const serviceError = String(value.error || 'License service rejected the request.').slice(0, 240);
      if (action === 'deleteReleasedDevices' && /unsupported license action/i.test(serviceError)) {
        throw new Error('VaultCove licensing backend is out of date. Deploy the matching 0.9.5 Code.gs as a new version of the existing Web App, then try again. No license or device record was changed.');
      }
      if (['createGuardianApproval','listGuardianApprovals','decideGuardianApproval','consumeGuardianApproval'].includes(action) && /unsupported license action/i.test(serviceError)) {
        throw new Error('VaultCove Guardian needs the matching 0.9.5 licensing backend. Deploy the provided 0.9.5 Code.gs as a new version of the existing Web App and keep the same /exec URL.');
      }
      if (['beginPhysicalDeviceLink','completePhysicalDeviceLink'].includes(action) && /unsupported license action/i.test(serviceError)) {
        throw new Error('Same-computer browser linking needs the matching 0.9.5 licensing backend. Deploy the provided 0.9.5 Code.gs as a new version of the existing Web App and keep the same /exec URL.');
      }
      throw new Error(serviceError);
    }
    return value;
  } catch (error) {
    if (error?.name === 'AbortError') throw new Error('License service request timed out.');
    throw error;
  } finally {
    clearTimeout(timeout);
  }
}

function base64UrlToBytes(value) {
  const normalized = String(value || '').replace(/-/g, '+').replace(/_/g, '/');
  const padded = normalized + '='.repeat((4 - normalized.length % 4) % 4);
  const binary = atob(padded);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

function base64ToBytes(value) {
  const binary = atob(String(value || '').replace(/\s+/g, ''));
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

function canonicalLeaseCurrent(lease) {
  return JSON.stringify({
    protocolVersion: Number(lease.protocolVersion || 1),
    product: String(lease.product || ''),
    licenseId: String(lease.licenseId || ''),
    installationId: String(lease.installationId || ''),
    status: String(lease.status || ''),
    licenseType: String(lease.licenseType || 'standard'),
    maxDevices: Number(lease.maxDevices || 0),
    managementRole: String(lease.managementRole || ''),
    managerLimit: Number(lease.managerLimit || 0),
    activeDevices: Number(lease.activeDevices || 0),
    retainedDevices: Number(lease.retainedDevices || 0),
    usedDevices: Number(lease.usedDevices || 0),
    emailMasked: String(lease.emailMasked || ''),
    issuedAt: String(lease.issuedAt || ''),
    expiresAt: String(lease.expiresAt || '')
  });
}

function canonicalLeaseLegacyProtocol3(lease) {
  // Protocol-3 leases issued before the management-device model did not sign
  // managementRole/managerLimit. This exact historical shape remains
  // cryptographically verifiable during backend rollout compatibility.
  return JSON.stringify({
    protocolVersion: Number(lease.protocolVersion || 1),
    product: String(lease.product || ''),
    licenseId: String(lease.licenseId || ''),
    installationId: String(lease.installationId || ''),
    status: String(lease.status || ''),
    licenseType: String(lease.licenseType || 'standard'),
    maxDevices: Number(lease.maxDevices || 0),
    activeDevices: Number(lease.activeDevices || 0),
    retainedDevices: Number(lease.retainedDevices || 0),
    usedDevices: Number(lease.usedDevices || 0),
    emailMasked: String(lease.emailMasked || ''),
    issuedAt: String(lease.issuedAt || ''),
    expiresAt: String(lease.expiresAt || '')
  });
}

export function licenseLeaseCanonicalCandidates(lease) {
  if (!lease || typeof lease !== 'object' || Array.isArray(lease)) return [];
  const current = { version: 2, text: canonicalLeaseCurrent(lease) };
  const hasManagementFields = Object.prototype.hasOwnProperty.call(lease, 'managementRole') ||
    Object.prototype.hasOwnProperty.call(lease, 'managerLimit');
  // Never permit a current-format lease to downgrade into the legacy verifier.
  // Legacy is allowed only when BOTH newer fields are genuinely absent.
  if (hasManagementFields || Number(lease.protocolVersion || 0) !== 3) return [current];
  return [current, { version: 1, text: canonicalLeaseLegacyProtocol3(lease) }];
}

export async function verifySignedLicenseLease(lease, signature) {
  if (LICENSE_LEASE_PUBLIC_KEY_SPKI_BASE64 === 'UNCONFIGURED') {
    if (TESTING_FULL_ACCESS) return { verified: false, testingUnconfiguredKey: true };
    throw new Error('Production license verification public key is not configured.');
  }
  const publicKey = await crypto.subtle.importKey(
    'spki',
    base64ToBytes(LICENSE_LEASE_PUBLIC_KEY_SPKI_BASE64),
    { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' },
    false,
    ['verify']
  );
  const signatureBytes = base64UrlToBytes(signature);
  for (const candidate of licenseLeaseCanonicalCandidates(lease)) {
    const valid = await crypto.subtle.verify(
      { name: 'RSASSA-PKCS1-v1_5' },
      publicKey,
      signatureBytes,
      new TextEncoder().encode(candidate.text)
    );
    if (valid) return { verified: true, canonicalVersion: candidate.version };
  }
  throw new Error('License lease signature verification failed. The extension and licensing backend may be using different lease-signing versions.');
}

async function saveLeaseResponse(result, serial = '', { allowMissingSerial = false } = {}) {
  if (!result.lease || !result.leaseSignature || !result.refreshToken) throw new Error('License service returned an incomplete activation response.');
  const verification = await verifySignedLicenseLease(result.lease, result.leaseSignature);
  const installationId = await ensureDeviceId();
  const current = await getLicenseClientState();
  const effectiveSerial = String(serial || current.licenseSerial || '').trim();

  const refreshTokenCipher = await sealLicenseCredential(String(result.refreshToken), installationId, 'refresh-token');
  let licenseSerialCipher = current.licenseSerialCipher || null;
  let serialHint = String(current.serialHint || '');
  if (effectiveSerial) {
    licenseSerialCipher = await sealLicenseCredential(effectiveSerial, installationId, 'license-serial');
    serialHint = effectiveSerial.slice(-4);
  } else if (!allowMissingSerial || !licenseSerialCipher) {
    throw new Error('The license key is required to protect this device credential. Reactivate the license.');
  }

  if (String(current?.lease?.licenseId || '') && String(current.lease.licenseId) !== String(result.lease.licenseId || '')) {
    await chrome.storage.local.remove(DEVICE_SNAPSHOT_STORAGE_KEY);
  }

  const next = {
    clientStateVersion: 3,
    refreshTokenCipher,
    licenseSerialCipher,
    lease: result.lease,
    leaseSignature: String(result.leaseSignature),
    leaseVerified: Boolean(verification.verified),
    leaseCanonicalVersion: Number(verification.canonicalVersion || result.leaseCanonicalVersion || 0),
    emailMasked: String(result.lease.emailMasked || ''),
    serialHint,
    lastValidatedAt: new Date().toISOString()
  };
  await chrome.storage.local.set({ [STORAGE_KEY]: next });
  return { ...result, verification };
}

async function saveLeaseOnlyResponse(result) {
  if (!result.lease || !result.leaseSignature) throw new Error('License service returned an incomplete signed entitlement.');
  const verification = await verifySignedLicenseLease(result.lease, result.leaseSignature);
  const storedResult = await chrome.storage.local.get(STORAGE_KEY);
  const stored = storedResult[STORAGE_KEY] && typeof storedResult[STORAGE_KEY] === 'object' ? storedResult[STORAGE_KEY] : {};
  const next = {
    ...stored,
    clientStateVersion: 3,
    lease: result.lease,
    leaseSignature: String(result.leaseSignature),
    leaseVerified: Boolean(verification.verified),
    leaseCanonicalVersion: Number(verification.canonicalVersion || result.leaseCanonicalVersion || 0),
    emailMasked: String(result.lease.emailMasked || ''),
    lastValidatedAt: new Date().toISOString()
  };
  delete next.refreshToken;
  delete next.licenseSerial;
  await chrome.storage.local.set({ [STORAGE_KEY]: next });
  return { ...result, verification };
}

export async function beginLicenseActivation({ serial, email, deviceLabel = '' }) {
  const installationId = await ensureDeviceId();
  const deviceRecoveryToken = await ensureDeviceRecoveryToken();
  const key = String(serial || '').trim();
  if (key.length < 8 || key.length > 200) throw new Error('Enter a valid VaultCove serial/license key.');
  const normalizedEmail = validateEmail(email);
  return postLicense('beginActivation', {
    serial: key,
    email: normalizedEmail,
    installationId,
    deviceRecoveryToken,
    deviceLabel: String(deviceLabel || '').trim().slice(0, MAX_DEVICE_LABEL),
    platform: detectRuntimePlatform(),
    appVersion: chrome.runtime.getManifest().version
  });
}

export async function completeLicenseActivation({ challengeId, code, serial, physicalDeviceLinkCode = '' }) {
  const installationId = await ensureDeviceId();
  const deviceRecoveryToken = await ensureDeviceRecoveryToken();
  const result = await postLicense('completeActivation', {
    challengeId: String(challengeId || ''),
    code: String(code || '').replace(/\D/g, '').slice(0, 6),
    serial: String(serial || '').trim(),
    installationId,
    deviceRecoveryToken,
    physicalDeviceLinkCode: String(physicalDeviceLinkCode || '').trim().toUpperCase().slice(0, 40)
  });
  if (result.reclaimRequired) return result;
  return saveLeaseResponse(result, serial);
}

export async function completeRetainedDeviceRecovery({ reclaimToken, targetInstallationId, deviceLabel = '', serial }) {
  const installationId = await ensureDeviceId();
  const deviceRecoveryToken = await ensureDeviceRecoveryToken();
  const result = await postLicense('completeRecoveryActivation', {
    reclaimToken: String(reclaimToken || ''),
    serial: String(serial || '').trim(),
    installationId,
    deviceRecoveryToken,
    targetInstallationId: String(targetInstallationId || '__new__'),
    deviceLabel: String(deviceLabel || '').trim().slice(0, MAX_DEVICE_LABEL),
    platform: detectRuntimePlatform(),
    appVersion: chrome.runtime.getManifest().version
  });
  return saveLeaseResponse(result, serial);
}

export async function refreshLicenseLease() {
  const installationId = await ensureDeviceId();
  const client = await getLicenseClientState();
  if (!client.refreshToken || !client.licenseSerial) throw new Error(client.credentialError || 'This installation is not activated.');
  const result = await postLicense('refreshLease', { installationId, refreshToken: client.refreshToken, serial: client.licenseSerial });
  return saveLeaseResponse({ ...result, refreshToken: client.refreshToken }, client.licenseSerial);
}

export async function beginCurrentDeviceAdmin() {
  const installationId = await ensureDeviceId();
  const client = await getLicenseClientState();
  const proof = signedLeaseProof(client, installationId);
  return postLicense('beginCurrentDeviceAdmin', { installationId, ...proof });
}

export async function completeCurrentDeviceAdmin(challengeId, code) {
  const installationId = await ensureDeviceId();
  const client = await getLicenseClientState();
  const result = await postLicense('completeCurrentDeviceAdmin', {
    challengeId: String(challengeId || ''),
    code: String(code || '').replace(/\D/g, '').slice(0, 6),
    installationId
  });
  // Promotion rotates the refresh token. A valid server-side promotion must not
  // fail merely because an older local serial wrapper cannot be opened at this
  // exact moment; preserve that ciphertext and commit the newly signed admin lease.
  return saveLeaseResponse(result, client.licenseSerial, { allowMissingSerial: true });
}

export async function syncCurrentDeviceLease() {
  const installationId = await ensureDeviceId();
  const client = await getLicenseClientState();
  const proof = signedLeaseProof(client, installationId);
  const result = await postLicense('syncCurrentDeviceLease', { installationId, ...proof });
  return saveLeaseOnlyResponse(result);
}

export async function beginDeviceManagement() {
  const installationId = await ensureDeviceId();
  const client = await getLicenseClientState();

  // Prefer the current signed entitlement. A fresh email OTP is still required
  // for standard Premium device actions, but an unreadable legacy local transport
  // credential must not make the Verify email button unusable.
  try {
    const proof = signedLeaseProof(client, installationId);
    return await postLicense('beginManageDevicesByLease', { installationId, ...proof });
  } catch (leaseError) {
    if (!client.refreshToken || !client.licenseSerial) {
      throw new Error(client.credentialError || leaseError?.message || 'Activate this installation first.');
    }
    return postLicense('beginManageDevices', { installationId, refreshToken: client.refreshToken, serial: client.licenseSerial });
  }
}

export async function completeDeviceManagement(challengeId, code) {
  const installationId = await ensureDeviceId();
  return postLicense('completeManageDevices', {
    challengeId: String(challengeId || ''),
    code: String(code || '').replace(/\D/g, '').slice(0, 6),
    installationId
  });
}

function sanitizeLicensedDeviceSnapshot(result = {}) {
  const devices = (Array.isArray(result.devices) ? result.devices : []).slice(0, 200).map((device = {}) => ({
    installationId: String(device.installationId || '').slice(0, 200),
    deviceLabel: String(device.deviceLabel || '').slice(0, MAX_DEVICE_LABEL),
    platform: String(device.platform || '').slice(0, 120),
    appVersion: String(device.appVersion || '').slice(0, 40),
    status: String(device.status || 'active').slice(0, 24),
    storedManagementRole: String(device.storedManagementRole || '').slice(0, 24),
    managementRole: String(device.managementRole || 'regular').slice(0, 24),
    physicalDeviceGroupHint: String(device.physicalDeviceGroupHint || '').slice(0, 32),
    samePhysicalDeviceInstallations: Math.max(1, Math.min(50, Number(device.samePhysicalDeviceInstallations || 1))),
    firstSeenAt: String(device.firstSeenAt || '').slice(0, 64),
    lastSeenAt: String(device.lastSeenAt || '').slice(0, 64)
  }));

  return {
    devices,
    maxDevices: Math.max(0, Math.min(1000, Number(result.maxDevices || 0))),
    unlimitedDevices: Boolean(result.unlimitedDevices),
    licenseType: String(result.licenseType || 'standard').slice(0, 32),
    ownerAdminAcrossLicense: Boolean(result.ownerAdminAcrossLicense),
    sameKeyDeviceCount: Math.max(0, Math.min(200, Number(result.sameKeyDeviceCount ?? devices.length))),
    physicalDeviceCount: Math.max(0, Math.min(200, Number(result.physicalDeviceCount || 0))),
    activeBrowserInstallations: Math.max(0, Math.min(200, Number(result.activeBrowserInstallations || 0))),
    retainedBrowserInstallations: Math.max(0, Math.min(200, Number(result.retainedBrowserInstallations || 0))),
    platforms: (Array.isArray(result.platforms) ? result.platforms : []).map((value) => String(value || '').slice(0, 120)).filter(Boolean).slice(0, 32),
    managerLimit: Math.max(0, Math.min(1000, Number(result.managerLimit || 0))),
    managerDevices: Math.max(0, Math.min(200, Number(result.managerDevices || 0))),
    activeDevices: Math.max(0, Math.min(200, Number(result.activeDevices || 0))),
    retainedDevices: Math.max(0, Math.min(200, Number(result.retainedDevices || 0)))
  };
}

async function cacheLicensedDeviceSnapshot(result, client, installationId) {
  const licenseId = String(client?.lease?.licenseId || '');
  if (!licenseId || !client?.leaseVerified) return { ...result, cachedAt: '', fromCache: false };
  const cachedAt = new Date().toISOString();
  const snapshot = sanitizeLicensedDeviceSnapshot(result);
  await chrome.storage.local.set({
    [DEVICE_SNAPSHOT_STORAGE_KEY]: {
      version: DEVICE_SNAPSHOT_CACHE_VERSION,
      licenseId,
      installationId: String(installationId || ''),
      cachedAt,
      snapshot
    }
  });
  return { ...result, cachedAt, fromCache: false };
}

export async function getCachedLicensedDevices() {
  const installationId = await ensureDeviceId();
  const client = await getLicenseClientState();
  const licenseId = String(client?.lease?.licenseId || '');
  if (!client?.leaseVerified || !licenseId || String(client?.lease?.installationId || '') !== String(installationId || '')) return null;

  const storedResult = await chrome.storage.local.get(DEVICE_SNAPSHOT_STORAGE_KEY);
  const stored = storedResult[DEVICE_SNAPSHOT_STORAGE_KEY];
  if (!stored || typeof stored !== 'object' || Number(stored.version || 0) !== DEVICE_SNAPSHOT_CACHE_VERSION) return null;
  if (String(stored.licenseId || '') !== licenseId || String(stored.installationId || '') !== String(installationId || '')) return null;

  const cachedAtMs = Date.parse(String(stored.cachedAt || ''));
  if (!Number.isFinite(cachedAtMs) || Date.now() - cachedAtMs > DEVICE_SNAPSHOT_MAX_AGE_MS) return null;
  const snapshot = sanitizeLicensedDeviceSnapshot(stored.snapshot || {});
  return {
    ...snapshot,
    cachedAt: new Date(cachedAtMs).toISOString(),
    cacheAgeMs: Math.max(0, Date.now() - cachedAtMs),
    fromCache: true
  };
}

function signedLeaseProof(client, installationId, { requireAdmin = false } = {}) {
  const lease = client?.lease;
  const signature = String(client?.leaseSignature || '');
  if (!lease || !signature || !client?.leaseVerified) throw new Error('This installation does not have a verified signed license entitlement.');
  if (String(lease.product || '') !== 'VaultCove' || String(lease.installationId || '') !== String(installationId || '')) throw new Error('The signed license entitlement does not belong to this installation.');
  if (String(lease.status || '').toLowerCase() !== 'active') throw new Error('This installation is not currently licensed.');
  const expiry = Date.parse(String(lease.expiresAt || ''));
  if (!Number.isFinite(expiry) || expiry <= Date.now()) throw new Error('The signed license entitlement has expired. Reactivate or refresh Premium.');
  if (requireAdmin && !['admin'].includes(String(lease.licenseType || '').toLowerCase()) && !['manager','owner-admin'].includes(String(lease.managementRole || ''))) throw new Error('This installation is not authorized to manage Licensed Devices.');
  return { lease, leaseSignature: signature };
}

export async function listOwnLicensedDevices() {
  const installationId = await ensureDeviceId();
  const client = await getLicenseClientState();
  // Read-only device discovery must not disappear just because this Chrome profile
  // cannot reopen the AES-GCM wrapped refresh token/serial. A verified server-signed
  // lease is sufficient proof for a read-only snapshot of this license's device ledger.
  let result;
  let proof = null;
  let leaseProofError = null;
  try { proof = signedLeaseProof(client, installationId); }
  catch (error) { leaseProofError = error; }
  if (proof) {
    // A valid signed lease is the preferred read-only proof. If this request fails
    // because the network/backend is unavailable, surface that failure immediately
    // so the UI can keep the cached snapshot instead of issuing a second remote call.
    result = await postLicense('listOwnDevicesByLease', { installationId, ...proof });
  } else {
    if (!client.refreshToken || !client.licenseSerial) throw new Error(client.credentialError || leaseProofError?.message || 'Activate this installation first.');
    result = await postLicense('listOwnDevices', {
      installationId,
      refreshToken: client.refreshToken,
      serial: client.licenseSerial
    });
  }
  return cacheLicensedDeviceSnapshot(result, client, installationId);
}

export async function changeLicensedDevice(managementToken, targetInstallationId, deviceAction) {
  if (!['release', 'revoke', 'restore', 'delete'].includes(deviceAction)) throw new Error('Unsupported device action.');
  const installationId = await ensureDeviceId();
  return postLicense('deviceAction', {
    managementToken: String(managementToken || ''),
    installationId,
    targetInstallationId: String(targetInstallationId || ''),
    deviceAction
  });
}

export async function deleteReleasedLicensedDevices(managementToken) {
  const installationId = await ensureDeviceId();
  return postLicense('deleteReleasedDevices', {
    managementToken: String(managementToken || ''),
    installationId
  });
}


export async function beginPhysicalDeviceLink() {
  const installationId = await ensureDeviceId();
  const client = await getLicenseClientState();
  const proof = signedLeaseProof(client, installationId);
  return postLicense('beginPhysicalDeviceLink', { installationId, ...proof });
}

export async function completePhysicalDeviceLink(challengeId, code) {
  const installationId = await ensureDeviceId();
  return postLicense('completePhysicalDeviceLink', {
    challengeId: String(challengeId || ''),
    code: String(code || '').replace(/\D/g, '').slice(0, 6),
    installationId
  });
}

export async function beginDisasterRecoveryRestore({ backupId, email }) {
  const installationId = await ensureDeviceId();
  const normalizedEmail = normalizeEmail(email);
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalizedEmail) || normalizedEmail.length > 254) throw new Error('Enter a valid Disaster Recovery email address.');
  const id = String(backupId || '').trim();
  if (!/^[0-9a-f-]{20,64}$/i.test(id)) throw new Error('Disaster Recovery backup ID is invalid.');
  return postLicense('beginBackupRestoreOtp', { installationId, backupId: id, email: normalizedEmail });
}

export async function completeDisasterRecoveryRestore({ backupId, challengeId, code }) {
  const installationId = await ensureDeviceId();
  const id = String(backupId || '').trim();
  if (!/^[0-9a-f-]{20,64}$/i.test(id)) throw new Error('Disaster Recovery backup ID is invalid.');
  return postLicense('completeBackupRestoreOtp', {
    installationId,
    backupId: id,
    challengeId: String(challengeId || ''),
    code: String(code || '').replace(/\D/g, '').slice(0, 6)
  });
}

export async function sendSecurityNotice({ noticeId, eventKind, occurredAt, siteHost = '', timeZone = '', recordType = '', shareCount = 0, recipientHint = '' }) {
  const installationId = await ensureDeviceId();
  const client = await getLicenseClientState();
  const kind = String(eventKind || 'protected-record-changed');
  if (!['password-change-detected','password-changed','protected-record-changed','protected-record-updated','protected-record-removed','passwords-shared'].includes(kind)) throw new Error('Unsupported VaultCove security notice type.');
  const safeRecordType = String(recordType || '').trim().toLowerCase();
  if (safeRecordType && !['card','bank','identity'].includes(safeRecordType)) throw new Error('Unsupported protected-record notice type.');
  const safeShareCount = Math.max(0, Math.min(50, Number(shareCount) || 0));
  const metadata = {
    noticeId: String(noticeId || '').slice(0, 120),
    eventKind: kind,
    occurredAt: String(occurredAt || new Date().toISOString()).slice(0, 40),
    siteHost: String(siteHost || '').trim().slice(0, 253),
    timeZone: String(timeZone || '').trim().slice(0, 64),
    recordType: safeRecordType,
    shareCount: Math.floor(safeShareCount),
    recipientHint: String(recipientHint || '').trim().slice(0, 120)
  };

  // Prefer the independently verified signed entitlement. This keeps security
  // alerts working after a Device Admin promotion even if an older local serial
  // wrapper is temporarily unreadable; no raw license key is needed here.
  try {
    const proof = signedLeaseProof(client, installationId);
    return await postLicense('sendSecurityNoticeByLease', { installationId, ...proof, ...metadata });
  } catch (leaseError) {
    if (!client.refreshToken || !client.licenseSerial) {
      throw new Error(client.credentialError || leaseError?.message || 'Premium licensing transport is not active on this installation.');
    }
    return postLicense('sendSecurityNotice', {
      installationId,
      refreshToken: client.refreshToken,
      serial: client.licenseSerial,
      ...metadata
    });
  }
}

export function licensePrivacyContract() {
  return {
    sent: ['license key during activation and signed-lease refresh when required (decrypted only in memory on the device)', 'license email', 'random installation ID', 'random physical-device group ID and a short-lived one-time same-computer link code only when you request browser linking', 'user device label', 'platform/app version', 'OTP/challenge responses', 'Disaster Recovery email + random backup ID only when requesting restore verification', 'license refresh token only when a legacy token-authenticated request is required', 'device recovery token during activation/recovery only', 'website hostname + password-change timestamp/time zone only for the requested password-change security email', 'protected-record category + action timestamp for card/bank/identity update or removal notices', 'shared-login count + locally masked recipient hint for password-sharing notices', 'Guardian approval ID + operation + opaque item ID + safe account host/critical-action label + same-license installation IDs only when Trusted Device Approval is used'],
    neverSent: ['master password', 'vault key', 'full saved URLs or page contents', 'usernames', 'passwords or password history', 'TOTP secrets for websites', 'cards', 'bank accounts', 'secure notes', 'VCShare private keys', 'Disaster Recovery encrypted vault contents']
  };
}


export async function createGuardianApproval({ operation = 'protected-action', itemId = '', itemLabel = '' } = {}) {
  const installationId = await ensureDeviceId();
  const client = await getLicenseClientState();
  const proof = signedLeaseProof(client, installationId);
  return postLicense('createGuardianApproval', {
    installationId,
    ...proof,
    operation:String(operation || 'protected-action').slice(0,80),
    itemId:String(itemId || '').slice(0,160),
    itemLabel:String(itemLabel || '').slice(0,120)
  });
}

export async function listGuardianApprovals() {
  const installationId = await ensureDeviceId();
  const client = await getLicenseClientState();
  const proof = signedLeaseProof(client, installationId);
  return postLicense('listGuardianApprovals', { installationId, ...proof });
}

export async function decideGuardianApproval(approvalId, decision) {
  const value = String(decision || '').toLowerCase();
  if (!['approve','deny'].includes(value)) throw new Error('Guardian approval decision must be approve or deny.');
  const installationId = await ensureDeviceId();
  const client = await getLicenseClientState();
  const proof = signedLeaseProof(client, installationId);
  return postLicense('decideGuardianApproval', {
    installationId, ...proof, approvalId:String(approvalId || ''), decision:value
  });
}

export async function consumeGuardianApproval(approvalId) {
  const installationId = await ensureDeviceId();
  const client = await getLicenseClientState();
  const proof = signedLeaseProof(client, installationId);
  return postLicense('consumeGuardianApproval', {
    installationId, ...proof, approvalId:String(approvalId || '')
  });
}
