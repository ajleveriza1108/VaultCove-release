import {
  AUTO_LOCK_ALARM,
  DEFAULT_LOCK_MINUTES,
  DEFAULT_SENSITIVE_ACCESS_SECONDS,
  DEVICE_STORAGE_KEY,
  SESSION_EXPIRES_KEY,
  SESSION_KEY,
  SESSION_LAST_ACTIVITY_KEY,
  SENSITIVE_ACCESS_UNTIL_KEY,
  MASTER_AUTH_THROTTLE_KEY,
  MASTER_AUTH_MAX_FAILURES,
  MASTER_AUTH_COOLDOWN_MS,
  SETTINGS_STORAGE_KEY,
  SETUP_COMPLETE_STORAGE_KEY,
  VAULT_STORAGE_KEY,
  VAULT_MIRROR_STORAGE_KEY
} from './constants.js';
import { base64UrlToBytes, bytesToBase64Url, randomBytes } from './encoding.js';
import { importAesKey } from './crypto.js';


export async function getMasterAuthThrottle(nowMs = Date.now()) {
  const result = await chrome.storage.local.get(MASTER_AUTH_THROTTLE_KEY);
  const raw = result[MASTER_AUTH_THROTTLE_KEY] || {};
  const blockedUntil = Math.max(0, Number(raw.blockedUntil || 0));
  const failures = Math.max(0, Math.min(MASTER_AUTH_MAX_FAILURES, Number(raw.failures || 0)));
  if (blockedUntil && nowMs >= blockedUntil) {
    await chrome.storage.local.remove(MASTER_AUTH_THROTTLE_KEY);
    return { failures: 0, blockedUntil: 0, retryAfterMs: 0 };
  }
  return { failures, blockedUntil, retryAfterMs: Math.max(0, blockedUntil - nowMs) };
}

export async function assertMasterAuthAllowed(nowMs = Date.now()) {
  const state = await getMasterAuthThrottle(nowMs);
  if (state.retryAfterMs > 0) {
    const error = new Error(`Too many incorrect Master Password attempts. Try again in ${Math.ceil(state.retryAfterMs / 1000)} seconds.`);
    error.code = 'MASTER_AUTH_COOLDOWN';
    error.retryAfterMs = state.retryAfterMs;
    error.blockedUntil = state.blockedUntil;
    throw error;
  }
  return state;
}

export async function recordMasterAuthFailure(nowMs = Date.now()) {
  const state = await getMasterAuthThrottle(nowMs);
  if (state.retryAfterMs > 0) return state;
  const failures = state.failures + 1;
  if (failures >= MASTER_AUTH_MAX_FAILURES) {
    const blockedUntil = nowMs + MASTER_AUTH_COOLDOWN_MS;
    const next = { failures: 0, blockedUntil };
    await chrome.storage.local.set({ [MASTER_AUTH_THROTTLE_KEY]: next });
    return { ...next, retryAfterMs: MASTER_AUTH_COOLDOWN_MS };
  }
  const next = { failures, blockedUntil: 0 };
  await chrome.storage.local.set({ [MASTER_AUTH_THROTTLE_KEY]: next });
  return { ...next, retryAfterMs: 0 };
}

export async function clearMasterAuthFailures() {
  await chrome.storage.local.remove(MASTER_AUTH_THROTTLE_KEY);
}

export async function hardenStorageAccess() {
  if (chrome.storage?.local?.setAccessLevel) {
    await chrome.storage.local.setAccessLevel({ accessLevel: 'TRUSTED_CONTEXTS' });
  }
  if (chrome.storage?.session?.setAccessLevel) {
    await chrome.storage.session.setAccessLevel({ accessLevel: 'TRUSTED_CONTEXTS' });
  }
}

export async function getVaultEnvelope() {
  const result = await chrome.storage.local.get([VAULT_STORAGE_KEY, VAULT_MIRROR_STORAGE_KEY]);
  const primary = result[VAULT_STORAGE_KEY] ?? null;
  const mirror = result[VAULT_MIRROR_STORAGE_KEY] ?? null;

  if (primary) {
    // Existing installations gain the redundant encrypted mirror lazily on first read.
    // The mirror contains only the same already-encrypted envelope.
    if (!mirror) await chrome.storage.local.set({ [VAULT_MIRROR_STORAGE_KEY]: primary });
    return primary;
  }

  if (mirror) {
    // A missing primary envelope must never make an established installation look
    // like a fresh install. Restore the encrypted primary from its local mirror.
    await chrome.storage.local.set({ [VAULT_STORAGE_KEY]: mirror });
    return mirror;
  }

  return null;
}

export async function setVaultEnvelope(envelope) {
  if (!envelope || typeof envelope !== 'object') throw new Error('VaultCove refused to store an invalid encrypted vault envelope.');
  await chrome.storage.local.set({
    [VAULT_STORAGE_KEY]: envelope,
    [VAULT_MIRROR_STORAGE_KEY]: envelope
  });
}

export async function vaultExists() {
  return Boolean(await getVaultEnvelope());
}

export async function getSettings() {
  const result = await chrome.storage.local.get(SETTINGS_STORAGE_KEY);
  const stored = result[SETTINGS_STORAGE_KEY] || {};
  const merged = {
    lockMinutes: DEFAULT_LOCK_MINUTES,
    sensitiveAccessSeconds: DEFAULT_SENSITIVE_ACCESS_SECONDS,
    requireReauthForSecrets: true,
    clipboardWarning: true,
    clipboardClearSeconds: 30,
    revealTimeoutSeconds: 10,
    secureLoginClearMs: 1200,
    profileName: 'VaultCove User',
    profileImageDataUrl: '',
    inlineHandlerEnabled: true,
    alwaysOnHandlerEnabled: true,
    handlerDisabledHosts: [],
    autoLoginEnabled: false,
    vaultTotpEnabled: false,
    websiteIconsEnabled: true,
    websiteIconsPremiumDefaultApplied: false,
    vaultViewMode: 'grid',
    theme: 'ivory',
    compactUi: true,
    updateChecksEnabled: true,
    passwordChangeDetectionEnabled: true,
    newLoginCaptureEnabled: true,
    securityEmailNoticeEnabled: false,
    securityNoticeEmail: '',
    firstRunSecurityComplete: true,
    disasterRecoveryEnabled: false,
    disasterRecoveryPending: false,
    disasterRecoveryDueAt: null,
    disasterRecoveryLastSuccessAt: null,
    disasterRecoveryLastError: '',
    disasterRecoveryLastBackupId: '',
    disasterRecoveryLastFile: '',
    manualBackupPending: true,
    manualBackupPendingSince: null,
    manualBackupPendingCount: 0,
    manualBackupReminderDueAt: null,
    manualBackupLastSuccessAt: null,
    manualBackupLastVerifiedAt: null,
    guardianEnabled: true,
    guardianLastRecoveryDrillAt: null,
    guardianLastRecoveryDrillFile: '',
    guardianOffDeviceBackupConfirmed: false,
    guardianCooldownUntil: null,
    guardianCooldownAction: '',
    guardianCriticalCooldownMinutes: 0,
    guardianCriticalTrustedApproval: false,
    guardianDrDailyAt: null,
    guardianDrWeeklyAt: null,
    guardianDrMonthlyAt: null,
    ...stored,
    websiteIconsEnabled: true,
    websiteIconsPremiumDefaultApplied: true
  };
  if (merged.manualBackupPending && !merged.manualBackupReminderDueAt) {
    merged.manualBackupReminderDueAt = manualBackupReminderDueAt();
  }
  return merged;
}

export async function setSettings(settings) {
  const current = await getSettings();
  const requested = { ...(settings || {}) };
  if (requested.firstRunSecurityComplete === false) {
    const marker = await chrome.storage.local.get(SETUP_COMPLETE_STORAGE_KEY);
    if (marker[SETUP_COMPLETE_STORAGE_KEY] === true) requested.firstRunSecurityComplete = true;
  }
  await chrome.storage.local.set({ [SETTINGS_STORAGE_KEY]: { ...current, ...requested } });
}



function manualBackupReminderDueAt(nowMs = Date.now()) {
  const now = new Date(nowMs);
  // Start the monthly reminder during the final three calendar days. If the
  // month is shorter, this still resolves correctly because day 0 means the
  // last day of the current month.
  const monthEnd = new Date(now.getFullYear(), now.getMonth() + 1, 0, 9, 0, 0, 0);
  const reminder = new Date(monthEnd);
  reminder.setDate(Math.max(1, monthEnd.getDate() - 2));
  // A change made during the reminder window is due immediately rather than
  // being postponed until the next month.
  return new Date(Math.max(nowMs, reminder.getTime())).toISOString();
}

export async function markManualBackupPending({ increment = true, nowMs = Date.now() } = {}) {
  const current = await getSettings();
  const alreadyPending = Boolean(current.manualBackupPending);
  const dueAt = alreadyPending && current.manualBackupReminderDueAt
    ? current.manualBackupReminderDueAt
    : manualBackupReminderDueAt(nowMs);
  await chrome.storage.local.set({
    [SETTINGS_STORAGE_KEY]: {
      ...current,
      manualBackupPending: true,
      manualBackupPendingSince: current.manualBackupPendingSince || new Date(nowMs).toISOString(),
      manualBackupPendingCount: Math.max(1, Number(current.manualBackupPendingCount || 0) + (increment ? 1 : 0)),
      manualBackupReminderDueAt: dueAt
    }
  });
  return true;
}

export async function recordManualBackupSuccess({ verifiedAt = new Date().toISOString() } = {}) {
  const current = await getSettings();
  await chrome.storage.local.set({
    [SETTINGS_STORAGE_KEY]: {
      ...current,
      manualBackupPending: false,
      manualBackupPendingSince: null,
      manualBackupPendingCount: 0,
      manualBackupReminderDueAt: null,
      manualBackupLastSuccessAt: verifiedAt,
      manualBackupLastVerifiedAt: verifiedAt
    }
  });
  return true;
}

export async function markDisasterRecoveryPending(delayMs = 60_000) {
  const current = await getSettings();
  if (!current.disasterRecoveryEnabled) return false;
  const dueAt = new Date(Date.now() + Math.max(0, Number(delayMs || 0))).toISOString();
  await chrome.storage.local.set({
    [SETTINGS_STORAGE_KEY]: {
      ...current,
      disasterRecoveryPending: true,
      disasterRecoveryDueAt: dueAt
    }
  });
  return true;
}

export async function beginFirstRunSetup() {
  const [current, envelope, markerResult] = await Promise.all([
    getSettings(),
    getVaultEnvelope(),
    chrome.storage.local.get(SETUP_COMPLETE_STORAGE_KEY)
  ]);
  if (envelope || markerResult[SETUP_COMPLETE_STORAGE_KEY] === true) {
    throw new Error('First-run setup cannot restart on an existing VaultCove installation. Lock and unlock with the current master password instead.');
  }
  await chrome.storage.local.set({
    [SETUP_COMPLETE_STORAGE_KEY]: false,
    [SETTINGS_STORAGE_KEY]: { ...current, firstRunSecurityComplete: false }
  });
}

export async function completeFirstRunSetup(settingsPatch = {}) {
  const [current, envelope] = await Promise.all([getSettings(), getVaultEnvelope()]);
  if (!envelope) throw new Error('VaultCove cannot mark setup complete until the encrypted local vault exists.');
  const completedSettings = {
    ...current,
    ...(settingsPatch || {}),
    firstRunSecurityComplete: true
  };
  // One local-storage transaction is the durability boundary. The permanent
  // installation marker and the validated setup settings can never diverge
  // because auto-lock fired between two separate writes.
  await chrome.storage.local.set({
    [SETUP_COMPLETE_STORAGE_KEY]: true,
    [SETTINGS_STORAGE_KEY]: completedSettings
  });
  return completedSettings;
}

export async function markFirstRunSetupComplete() {
  await completeFirstRunSetup();
  return true;
}

export async function isFirstRunSetupComplete() {
  const result = await chrome.storage.local.get(SETUP_COMPLETE_STORAGE_KEY);
  return result[SETUP_COMPLETE_STORAGE_KEY] === true;
}

export async function reconcileFirstRunSetupState() {
  const [markerResult, envelope, settings] = await Promise.all([
    chrome.storage.local.get(SETUP_COMPLETE_STORAGE_KEY),
    getVaultEnvelope(),
    getSettings()
  ]);
  const hasMarker = Object.prototype.hasOwnProperty.call(markerResult, SETUP_COMPLETE_STORAGE_KEY);
  const marker = markerResult[SETUP_COMPLETE_STORAGE_KEY];

  if (marker === true) {
    if (settings.firstRunSecurityComplete !== true) {
      await chrome.storage.local.set({
        [SETTINGS_STORAGE_KEY]: { ...settings, firstRunSecurityComplete: true }
      });
    }
    // Completion is a durable installation fact. A normal lock may remove only
    // chrome.storage.session data; it must never reopen onboarding. getVaultEnvelope()
    // above also self-heals the primary encrypted envelope from the local mirror.
    return true;
  }

  // 0.7.60+ recovery for the old split-write race. Older builds wrote
  // firstRunSecurityComplete=true before writing the permanent marker. If an
  // auto-lock happened in that narrow window, marker=false became a permanent
  // onboarding loop even though setup had already been validated and saved.
  // A real encrypted vault plus the already-completed setting is definitive
  // evidence of that partial commit, so promote it to the durable marker.
  if (envelope && settings.firstRunSecurityComplete === true) {
    await chrome.storage.local.set({ [SETUP_COMPLETE_STORAGE_KEY]: true });
    return true;
  }

  if (marker === false) return false;

  // Fresh/migration state with no completion evidence stays in setup.
  if (!hasMarker && envelope && settings.firstRunSecurityComplete === true) {
    await chrome.storage.local.set({ [SETUP_COMPLETE_STORAGE_KEY]: true });
    return true;
  }
  return false;
}

const DEVICE_RECOVERY_TOKEN_KEY = 'vaultcoveDeviceRecoveryToken';

export async function ensureDeviceRecoveryToken() {
  const result = await chrome.storage.local.get(DEVICE_RECOVERY_TOKEN_KEY);
  if (result[DEVICE_RECOVERY_TOKEN_KEY]) return result[DEVICE_RECOVERY_TOKEN_KEY];
  const token = `vcrt_${bytesToBase64Url(randomBytes(24))}`;
  await chrome.storage.local.set({ [DEVICE_RECOVERY_TOKEN_KEY]: token });
  return token;
}

export async function setDeviceRecoveryToken(token) {
  const value = String(token || '').trim();
  if (!/^vcrt_[A-Za-z0-9_-]{20,}$/.test(value)) throw new Error('Invalid VaultCove device recovery token.');
  await chrome.storage.local.set({ [DEVICE_RECOVERY_TOKEN_KEY]: value });
  return value;
}

export async function ensureDeviceId() {
  const result = await chrome.storage.local.get(DEVICE_STORAGE_KEY);
  if (result[DEVICE_STORAGE_KEY]) return result[DEVICE_STORAGE_KEY];
  const id = `vcdev_${bytesToBase64Url(randomBytes(18))}`;
  await chrome.storage.local.set({ [DEVICE_STORAGE_KEY]: id });
  return id;
}

export async function scheduleSessionAutoLock(expiresAt = null) {
  if (!chrome.alarms?.create) return 0;
  let deadline = Number(expiresAt || 0);
  if (!deadline) {
    const session = await chrome.storage.session.get([SESSION_KEY, SESSION_EXPIRES_KEY]);
    if (!session[SESSION_KEY]) {
      await chrome.alarms.clear?.(AUTO_LOCK_ALARM);
      return 0;
    }
    deadline = Number(session[SESSION_EXPIRES_KEY] || 0);
  }
  if (!deadline || deadline <= Date.now()) {
    await chrome.alarms.clear?.(AUTO_LOCK_ALARM);
    return 0;
  }
  chrome.alarms.create(AUTO_LOCK_ALARM, { when: deadline });
  return deadline;
}

export async function saveSessionKey(rawVaultKey) {
  const settings = await getSettings();
  const now = Date.now();
  const expiresAt = now + Math.max(1, settings.lockMinutes) * 60_000;
  await chrome.storage.session.set({
    [SESSION_KEY]: bytesToBase64Url(rawVaultKey),
    [SESSION_EXPIRES_KEY]: expiresAt,
    [SESSION_LAST_ACTIVITY_KEY]: now,
    [SENSITIVE_ACCESS_UNTIL_KEY]: 0
  });
  await scheduleSessionAutoLock(expiresAt);
  return expiresAt;
}

export async function touchSession() {
  const result = await chrome.storage.session.get([SESSION_KEY, SESSION_EXPIRES_KEY]);
  if (!result[SESSION_KEY]) return false;
  const now = Date.now();
  const currentExpiry = Number(result[SESSION_EXPIRES_KEY] || 0);
  if (!currentExpiry || now >= currentExpiry) {
    await clearSession();
    return false;
  }
  const settings = await getSettings();
  const expiresAt = now + Math.max(1, settings.lockMinutes) * 60_000;
  await chrome.storage.session.set({
    [SESSION_LAST_ACTIVITY_KEY]: now,
    [SESSION_EXPIRES_KEY]: expiresAt
  });
  await scheduleSessionAutoLock(expiresAt);
  return true;
}

export async function getSessionKey() {
  const result = await chrome.storage.session.get([SESSION_KEY, SESSION_EXPIRES_KEY, SESSION_LAST_ACTIVITY_KEY]);
  if (!result[SESSION_KEY]) return null;
  const expiresAt = Number(result[SESSION_EXPIRES_KEY] || 0);
  if (!expiresAt || Date.now() >= expiresAt) {
    await clearSession();
    return null;
  }
  const rawVaultKey = base64UrlToBytes(result[SESSION_KEY]);
  return {
    rawVaultKey,
    vaultKey: await importAesKey(rawVaultKey, true),
    expiresAt,
    lastActivityAt: Number(result[SESSION_LAST_ACTIVITY_KEY] || 0)
  };
}

export async function grantSensitiveAccess(seconds = null) {
  const settings = await getSettings();
  const ttl = Math.max(5, Math.min(300, Number(seconds ?? settings.sensitiveAccessSeconds) || DEFAULT_SENSITIVE_ACCESS_SECONDS));
  const until = Date.now() + ttl * 1000;
  await chrome.storage.session.set({ [SENSITIVE_ACCESS_UNTIL_KEY]: until });
  return until;
}

export async function hasSensitiveAccess() {
  const result = await chrome.storage.session.get([SESSION_KEY, SESSION_EXPIRES_KEY, SENSITIVE_ACCESS_UNTIL_KEY]);
  if (!result[SESSION_KEY] || !result[SESSION_EXPIRES_KEY] || Date.now() >= result[SESSION_EXPIRES_KEY]) return false;
  return Number(result[SENSITIVE_ACCESS_UNTIL_KEY] || 0) > Date.now();
}

export async function clearSensitiveAccess() {
  await chrome.storage.session.remove(SENSITIVE_ACCESS_UNTIL_KEY);
}

export async function clearSession() {
  await chrome.storage.session.remove([
    SESSION_KEY,
    SESSION_EXPIRES_KEY,
    SESSION_LAST_ACTIVITY_KEY,
    SENSITIVE_ACCESS_UNTIL_KEY
  ]);
  if (chrome.alarms?.clear) await chrome.alarms.clear(AUTO_LOCK_ALARM);
}

export async function getSessionExpiry() {
  const result = await chrome.storage.session.get([SESSION_KEY, SESSION_EXPIRES_KEY]);
  if (!result[SESSION_KEY]) return 0;
  const expiresAt = Number(result[SESSION_EXPIRES_KEY] || 0);
  if (!expiresAt || Date.now() >= expiresAt) {
    await clearSession();
    return 0;
  }
  return expiresAt;
}
