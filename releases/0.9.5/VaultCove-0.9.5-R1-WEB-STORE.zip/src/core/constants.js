export const APP_NAME = 'VaultCove';
export const SCHEMA_VERSION = 1;
export const CRYPTO_PROFILE = 'VC-PBKDF2-SHA256-AES256GCM';
export const CRYPTO_PROFILE_VERSION = 1;
export const PBKDF2_ITERATIONS = 1200000;
export const MASTER_AAD = 'VaultCove:vault-key:v1';
export const VAULT_AAD = 'VaultCove:vault-data:v1';
export const EXPORT_MAGIC = 'VAULTCOVE-EXPORT';
export const EXPORT_VERSION = 1;
export const EXPORT_AAD = 'VaultCove:portable-export:v1';

export const VAULT_STORAGE_KEY = 'vaultEnvelope';
export const VAULT_MIRROR_STORAGE_KEY = 'vaultEnvelopeMirror';
export const SETTINGS_STORAGE_KEY = 'vaultSettings';
export const SETUP_COMPLETE_STORAGE_KEY = 'vaultcoveSetupComplete';
export const LICENSE_STORAGE_KEY = 'licenseState';
export const DEVICE_STORAGE_KEY = 'deviceId';

export const SESSION_KEY = 'unlockedVaultKey';
export const SESSION_EXPIRES_KEY = 'unlockExpiresAt';
export const SESSION_LAST_ACTIVITY_KEY = 'lastActivityAt';
export const AUTO_LOCK_ALARM = 'vaultcove-auto-lock';
export const SENSITIVE_ACCESS_UNTIL_KEY = 'sensitiveAccessUntil';
export const MASTER_AUTH_THROTTLE_KEY = 'masterAuthThrottle';

export const DEFAULT_LOCK_MINUTES = 5;
export const DEFAULT_SENSITIVE_ACCESS_SECONDS = 30;
export const MASTER_AUTH_MAX_FAILURES = 5;
export const MASTER_AUTH_COOLDOWN_MS = 60_000;
export const TESTING_FULL_ACCESS = false;
