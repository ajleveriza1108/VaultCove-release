export function resolveVaultGatePanel(requestedPanel, {
  establishedVault = false,
  hasUnlockedVault = false,
  sessionState = 'unknown'
} = {}) {
  const requested = String(requestedPanel || '');
  if (requested !== 'setupPanel') return requested;

  // Hard invariant: an established vault with no active decrypted session is a
  // LOCKED vault, never a first-run vault. This also blocks stale async setup
  // callbacks that arrive after manual/idle lock.
  if (sessionState === 'locked') return 'unlockPanel';
  if (establishedVault && !hasUnlockedVault) return 'unlockPanel';
  return requested;
}
