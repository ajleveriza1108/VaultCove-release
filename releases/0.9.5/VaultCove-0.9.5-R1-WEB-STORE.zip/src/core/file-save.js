function sanitizeFilename(filename) {
  return String(filename || 'VaultCove-file').replace(/[\\/:*?"<>|]+/g, '-').slice(0, 180) || 'VaultCove-file';
}

function extensionOf(filename) {
  const match = String(filename || '').match(/(\.[a-z0-9]+)$/i);
  return match ? match[1].toLowerCase() : '';
}

function beginVisiblePointerState() {
  document.documentElement.classList.add('vcFilePickerActive');
  document.body?.classList.add('vcFilePickerActive');
  try { if (document.pointerLockElement && document.exitPointerLock) document.exitPointerLock(); } catch {}
  try { window.focus(); } catch {}
}

function endVisiblePointerState() {
  document.documentElement.classList.remove('vcFilePickerActive');
  document.body?.classList.remove('vcFilePickerActive');
  try { window.focus(); } catch {}
  try { document.body?.focus?.({ preventScroll: true }); } catch {}
}

function chromeDownloadsAvailable() {
  return Boolean(globalThis.chrome?.downloads?.download);
}

function downloadWithSaveAs(url, filename) {
  return new Promise((resolve, reject) => {
    chrome.downloads.download({
      url,
      filename: sanitizeFilename(filename),
      saveAs: true,
      conflictAction: 'uniquify'
    }, (downloadId) => {
      const error = chrome.runtime?.lastError;
      if (error) {
        reject(new Error(error.message || 'The browser could not open the Save As dialog.'));
        return;
      }
      if (typeof downloadId !== 'number') {
        reject(new Error('Save was cancelled.'));
        return;
      }
      resolve(downloadId);
    });
  });
}

// Use the browser downloads API for security-key exports. On Chromium/Windows this opens the
// browser-owned Save As path instead of the File System Access picker. That avoids the invisible
// pointer/compositor regression observed only while showSaveFilePicker() was open from an extension.
export async function saveBlobWithBrowserSaveAs(blob, filename) {
  const safeName = sanitizeFilename(filename);
  if (!chromeDownloadsAvailable()) {
    // Non-Chromium fallback. VaultCove's Chrome build declares the downloads permission, so this
    // branch is not used for normal Chrome/Brave operation.
    return saveBlob(blob, safeName);
  }

  try { if (document.pointerLockElement && document.exitPointerLock) document.exitPointerLock(); } catch {}
  const url = URL.createObjectURL(blob);
  try {
    const downloadId = await downloadWithSaveAs(url, safeName);
    return { saved: true, method: 'browser-save-as', downloadId };
  } catch (error) {
    if (/cancel/i.test(String(error?.message || ''))) return { saved: false, cancelled: true, method: 'browser-save-as' };
    throw error;
  } finally {
    // The downloads API has consumed the URL by the time its callback runs. Delay revocation
    // slightly for Chromium variants that schedule the read on the next task.
    setTimeout(() => URL.revokeObjectURL(url), 30000);
  }
}


function sanitizeRelativeDownloadPath(filename) {
  const parts = String(filename || '').replace(/\\/g, '/').split('/').filter(Boolean);
  if (!parts.length) return 'VaultCove-file';
  return parts.map((part) => sanitizeFilename(part)).join('/');
}

export async function saveBlobSilentlyToDownloads(blob, relativeFilename, { conflictAction = 'overwrite' } = {}) {
  if (!chromeDownloadsAvailable()) throw new Error('Automatic Disaster Recovery requires the Chrome downloads permission.');
  const safePath = sanitizeRelativeDownloadPath(relativeFilename);
  const action = ['overwrite', 'uniquify', 'prompt'].includes(conflictAction) ? conflictAction : 'overwrite';
  const url = URL.createObjectURL(blob);
  try {
    const downloadId = await new Promise((resolve, reject) => {
      chrome.downloads.download({
        url,
        filename: safePath,
        saveAs: false,
        conflictAction: action
      }, (id) => {
        const error = chrome.runtime?.lastError;
        if (error) return reject(new Error(error.message || 'Automatic Disaster Recovery backup could not be saved.'));
        if (typeof id !== 'number') return reject(new Error('Automatic Disaster Recovery backup could not be saved.'));
        resolve(id);
      });
    });
    return { saved: true, method: 'browser-downloads', downloadId, filename: safePath };
  } finally {
    setTimeout(() => URL.revokeObjectURL(url), 30000);
  }
}

export async function chooseSaveHandle(filename, { description = 'VaultCove file', mime = 'application/octet-stream' } = {}) {
  const safeName = sanitizeFilename(filename);
  if (typeof window.showSaveFilePicker !== 'function') return { handle: null, filename: safeName, method: 'download' };
  beginVisiblePointerState();
  try {
    const extension = extensionOf(safeName);
    const types = extension ? [{ description, accept: { [mime]: [extension] } }] : undefined;
    const handle = await window.showSaveFilePicker({ suggestedName: safeName, types });
    return { handle, filename: safeName, method: 'picker' };
  } catch (error) {
    if (error?.name === 'AbortError') return { handle: null, filename: safeName, method: 'cancelled' };
    return { handle: null, filename: safeName, method: 'download', pickerError: error };
  } finally {
    endVisiblePointerState();
  }
}

export async function writeBlobToSaveTarget(target, blob) {
  if (!target || target.method === 'cancelled') return { saved: false, cancelled: true };
  if (target.handle) {
    beginVisiblePointerState();
    try {
      const writable = await target.handle.createWritable();
      await writable.write(blob);
      await writable.close();
      return { saved: true, method: 'picker' };
    } finally {
      endVisiblePointerState();
    }
  }

  const url = URL.createObjectURL(blob);
  try {
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = sanitizeFilename(target.filename);
    document.body.append(anchor);
    anchor.click();
    anchor.remove();
    return { saved: true, method: 'download' };
  } finally {
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
}

export async function saveBlob(blob, filename, options = {}) {
  const target = await chooseSaveHandle(filename, options);
  return writeBlobToSaveTarget(target, blob);
}
