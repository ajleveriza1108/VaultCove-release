const DB_NAME = 'vaultcoveLicenseCredentialStore';
const DB_VERSION = 1;
const KEY_STORE = 'keys';
const DEVICE_KEY_ID = 'device-license-aes-gcm-v1';
const ENVELOPE_VERSION = 1;
const AAD_PREFIX = 'VaultCove|license-credential|v1';

function openDb() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(KEY_STORE)) db.createObjectStore(KEY_STORE);
    };
    request.onerror = () => reject(request.error || new Error('Could not open the local license credential store.'));
    request.onsuccess = () => resolve(request.result);
  });
}

function runRequest(db, mode, callback) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(KEY_STORE, mode);
    const store = tx.objectStore(KEY_STORE);
    let request;
    try { request = callback(store); }
    catch (error) { reject(error); return; }
    request.onerror = () => reject(request.error || new Error('Local license credential storage failed.'));
    request.onsuccess = () => resolve(request.result);
    tx.onabort = () => reject(tx.error || new Error('Local license credential transaction was aborted.'));
  });
}

async function getOrCreateDeviceKey() {
  const db = await openDb();
  try {
    let key = await runRequest(db, 'readonly', (store) => store.get(DEVICE_KEY_ID));
    if (key instanceof CryptoKey) {
      if (key.extractable) throw new Error('Stored license credential key is unexpectedly extractable.');
      return key;
    }
    key = await crypto.subtle.generateKey({ name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
    await runRequest(db, 'readwrite', (store) => store.put(key, DEVICE_KEY_ID));
    return key;
  } finally {
    db.close();
  }
}

function bytesToBase64Url(bytes) {
  let binary = '';
  for (let offset = 0; offset < bytes.length; offset += 0x8000) {
    binary += String.fromCharCode(...bytes.subarray(offset, Math.min(bytes.length, offset + 0x8000)));
  }
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
}

function base64UrlToBytes(value) {
  const normalized = String(value || '').replace(/-/g, '+').replace(/_/g, '/');
  const padded = normalized + '='.repeat((4 - normalized.length % 4) % 4);
  let binary;
  try { binary = atob(padded); }
  catch { throw new Error('Encrypted license credential is malformed.'); }
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

function aadBytes(installationId, purpose) {
  const id = String(installationId || '').trim();
  const label = String(purpose || '').trim();
  if (!/^vcdev_[A-Za-z0-9_-]{20,80}$/.test(id)) throw new Error('Cannot protect a license credential without a valid installation ID.');
  if (!/^[a-z][a-z0-9-]{2,40}$/.test(label)) throw new Error('Invalid license credential purpose.');
  return new TextEncoder().encode(`${AAD_PREFIX}|${label}|${id}`);
}

export async function sealLicenseCredential(value, installationId, purpose) {
  const text = String(value || '');
  if (!text) throw new Error('Cannot encrypt an empty license credential.');
  const key = await getOrCreateDeviceKey();
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ciphertext = new Uint8Array(await crypto.subtle.encrypt({
    name: 'AES-GCM',
    iv,
    additionalData: aadBytes(installationId, purpose),
    tagLength: 128
  }, key, new TextEncoder().encode(text)));
  return {
    version: ENVELOPE_VERSION,
    algorithm: 'AES-GCM-256',
    iv: bytesToBase64Url(iv),
    ciphertext: bytesToBase64Url(ciphertext)
  };
}

export async function openLicenseCredential(envelope, installationId, purpose) {
  if (!envelope || Number(envelope.version) !== ENVELOPE_VERSION || envelope.algorithm !== 'AES-GCM-256') {
    throw new Error('Encrypted license credential format is unsupported.');
  }
  const iv = base64UrlToBytes(envelope.iv);
  const ciphertext = base64UrlToBytes(envelope.ciphertext);
  if (iv.length !== 12 || ciphertext.length < 17 || ciphertext.length > 4096) throw new Error('Encrypted license credential is malformed.');
  const key = await getOrCreateDeviceKey();
  try {
    const plaintext = await crypto.subtle.decrypt({
      name: 'AES-GCM',
      iv,
      additionalData: aadBytes(installationId, purpose),
      tagLength: 128
    }, key, ciphertext);
    return new TextDecoder().decode(plaintext);
  } catch {
    throw new Error('This device could not decrypt its protected license credential. Reactivate the license on this installation.');
  }
}

export async function clearLicenseCredentialKey() {
  const db = await openDb();
  try { await runRequest(db, 'readwrite', (store) => store.delete(DEVICE_KEY_ID)); }
  finally { db.close(); }
}

export function licenseCredentialEncryptionContract() {
  return {
    algorithm: 'AES-GCM-256',
    keyExtractable: false,
    keyStorage: 'extension-origin IndexedDB CryptoKey',
    ciphertextStorage: 'chrome.storage.local',
    bindsToInstallationId: true,
    plaintextPersisted: false
  };
}
