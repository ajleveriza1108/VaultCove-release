export const GUARDIAN_VERSION = 1;

export const GUARDIAN_MODES = Object.freeze({
  standard: Object.freeze({ id:'standard', label:'Standard', reauth:false, exactDomain:false, blind:false, trustedApproval:false, cooldownMinutes:0 }),
  protected: Object.freeze({ id:'protected', label:'Protected', reauth:true, exactDomain:false, blind:false, trustedApproval:false, cooldownMinutes:0 }),
  strict: Object.freeze({ id:'strict', label:'Strict', reauth:true, exactDomain:true, blind:false, trustedApproval:false, cooldownMinutes:0 }),
  fortress: Object.freeze({ id:'fortress', label:'Fortress', reauth:true, exactDomain:true, blind:true, trustedApproval:true, cooldownMinutes:10 })
});

export const SECURITY_ZONES = Object.freeze({
  personal: Object.freeze({ id:'personal', label:'Personal', mode:'standard', splitTotp:'local' }),
  financial: Object.freeze({ id:'financial', label:'Financial', mode:'fortress', splitTotp:'approval' }),
  work: Object.freeze({ id:'work', label:'Work', mode:'strict', splitTotp:'local' }),
  recovery: Object.freeze({ id:'recovery', label:'Recovery', mode:'fortress', splitTotp:'approval' })
});

function cleanHost(value) {
  try {
    const parsed = new URL(/^[a-z][a-z0-9+.-]*:/i.test(String(value || '')) ? String(value) : `https://${String(value || '')}`);
    return parsed.hostname.toLowerCase().replace(/^www\./, '');
  } catch { return ''; }
}

export function defaultGuardianPolicy() {
  return {
    version: GUARDIAN_VERSION,
    mode: 'standard',
    zone: 'personal',
    exactDomainPinning: false,
    blindCredential: false,
    trustedDeviceApproval: false,
    splitTotp: 'local',
    cooldownMinutes: 0,
    quarantine: false,
    quarantineReason: '',
    breachAt: null,
    passkeyState: 'unknown'
  };
}

export function normalizeGuardianPolicy(value = {}, item = null) {
  const raw = value && typeof value === 'object' ? value : {};
  const zone = SECURITY_ZONES[String(raw.zone || '')] ? String(raw.zone) : 'personal';
  const requestedMode = GUARDIAN_MODES[String(raw.mode || '')] ? String(raw.mode) : SECURITY_ZONES[zone].mode;
  const base = GUARDIAN_MODES[requestedMode];
  const splitTotp = ['local','approval','disabled'].includes(String(raw.splitTotp || '')) ? String(raw.splitTotp) : SECURITY_ZONES[zone].splitTotp;
  const breachAt = raw.breachAt && Number.isFinite(Date.parse(String(raw.breachAt))) ? new Date(String(raw.breachAt)).toISOString() : null;
  const passkeyState = ['unknown','available','migrated','unavailable'].includes(String(raw.passkeyState || '')) ? String(raw.passkeyState) : 'unknown';
  const policy = {
    version: GUARDIAN_VERSION,
    mode: requestedMode,
    zone,
    exactDomainPinning: raw.exactDomainPinning == null ? base.exactDomain : Boolean(raw.exactDomainPinning),
    blindCredential: raw.blindCredential == null ? base.blind : Boolean(raw.blindCredential),
    trustedDeviceApproval: raw.trustedDeviceApproval == null ? base.trustedApproval : Boolean(raw.trustedDeviceApproval),
    splitTotp,
    cooldownMinutes: Math.max(0, Math.min(60, Number(raw.cooldownMinutes ?? base.cooldownMinutes) || 0)),
    quarantine: Boolean(raw.quarantine),
    quarantineReason: String(raw.quarantineReason || '').slice(0, 240),
    breachAt,
    passkeyState
  };
  if (item?.type !== 'login') return defaultGuardianPolicy();
  return policy;
}

export function applySecurityZone(policy, zoneId) {
  const zone = SECURITY_ZONES[String(zoneId || '')] || SECURITY_ZONES.personal;
  const mode = GUARDIAN_MODES[zone.mode];
  return normalizeGuardianPolicy({
    ...(policy || {}),
    zone: zone.id,
    mode: zone.mode,
    exactDomainPinning: mode.exactDomain,
    blindCredential: mode.blind,
    trustedDeviceApproval: mode.trustedApproval,
    splitTotp: zone.splitTotp,
    cooldownMinutes: mode.cooldownMinutes
  }, { type:'login' });
}

export function guardianPolicy(item) {
  return normalizeGuardianPolicy(item?.guardian || {}, item);
}

export function guardianRequiresReauth(item) {
  const policy = guardianPolicy(item);
  return Boolean(policy.mode !== 'standard' || item?.requireReauthBeforeFill);
}

export function guardianBlocksReveal(item) {
  return Boolean(guardianPolicy(item).blindCredential);
}

export function guardianRequiresApproval(item, operation = 'reveal') {
  const policy = guardianPolicy(item);
  if (!policy.trustedDeviceApproval) return false;
  return ['reveal','copy','totp','export','policy-change'].includes(String(operation || ''));
}

export function guardianCooldownMinutes(item) {
  return guardianPolicy(item).cooldownMinutes;
}

export function guardianAllowedHosts(item) {
  const hosts = new Set();
  for (const value of [...(item?.urls || []), ...(item?.trustedHosts || [])]) {
    const host = cleanHost(value);
    if (host) hosts.add(host);
  }
  return [...hosts];
}

export function guardianOriginAllowed(item, urlLike) {
  const policy = guardianPolicy(item);
  if (!policy.exactDomainPinning) return true;
  const current = cleanHost(urlLike?.hostname || urlLike);
  if (!current) return false;
  return guardianAllowedHosts(item).includes(current);
}

export function guardianQuarantineAssessment(item) {
  if (!item || item.type !== 'login') return { quarantine:false, reason:'' };
  const policy = guardianPolicy(item);
  if (policy.quarantine) return { quarantine:true, reason:policy.quarantineReason || 'This credential is quarantined until reviewed.' };
  const urls = Array.isArray(item.urls) ? item.urls : [];
  if (!urls.length) return { quarantine:true, reason:'No trusted website is saved for this imported login.' };
  for (const value of urls) {
    try {
      const parsed = new URL(value);
      if (!['http:','https:'].includes(parsed.protocol)) return { quarantine:true, reason:'Imported login contains an unsupported URL scheme.' };
      if (parsed.protocol === 'http:') return { quarantine:true, reason:'Imported login uses unencrypted HTTP and must be reviewed before use.' };
      if (parsed.hostname.toLowerCase().includes('xn--')) return { quarantine:true, reason:'Imported login uses an internationalized/punycode domain and must be reviewed for lookalike risk.' };
      if (parsed.username || parsed.password) return { quarantine:true, reason:'Imported URL contains embedded credentials.' };
    } catch { return { quarantine:true, reason:'Imported login contains an invalid website URL.' }; }
  }
  return { quarantine:false, reason:'' };
}

export function breachAssessment(item) {
  const policy = guardianPolicy(item);
  const breachMs = Date.parse(policy.breachAt || '');
  if (!Number.isFinite(breachMs)) return { state:'unknown', label:'No reported breach date', priority:0 };
  const changedMs = Date.parse(item?.lastPasswordChangeAt || '');
  if (!Number.isFinite(changedMs)) return { state:'review', label:'Breach date known; password-change date unknown', priority:2 };
  if (changedMs > breachMs) return { state:'post-breach', label:'Current password was changed after the reported breach', priority:1 };
  return { state:'high', label:'Current password predates the reported breach', priority:3 };
}

export function passkeyCoach(item) {
  const policy = guardianPolicy(item);
  if (policy.passkeyState === 'migrated') return { state:'migrated', label:'Passkey recorded as active; review password fallback security.' };
  if (policy.passkeyState === 'available') return { state:'available', label:'Passkey available; consider migrating this account.' };
  if (policy.passkeyState === 'unavailable') return { state:'unavailable', label:'Passkey marked unavailable; keep a unique generated password.' };
  const host = guardianAllowedHosts(item)[0] || '';
  const known = ['google.com','github.com','microsoft.com','apple.com','amazon.com','paypal.com','facebook.com','linkedin.com','dropbox.com'];
  if (known.some((entry) => host === entry || host.endsWith(`.${entry}`))) return { state:'likely', label:'This service commonly supports passkeys. Verify support in the official account security settings.' };
  return { state:'unknown', label:'Passkey availability has not been recorded.' };
}

export function guardianRiskSummary(items = []) {
  const logins = (Array.isArray(items) ? items : []).filter((item) => item?.type === 'login' && !item.deletedAt);
  let fortress = 0, quarantined = 0, breachHigh = 0, blind = 0, approval = 0, passkeyReady = 0;
  for (const item of logins) {
    const policy = guardianPolicy(item);
    if (policy.mode === 'fortress') fortress += 1;
    if (guardianQuarantineAssessment(item).quarantine) quarantined += 1;
    if (breachAssessment(item).state === 'high') breachHigh += 1;
    if (policy.blindCredential) blind += 1;
    if (policy.trustedDeviceApproval) approval += 1;
    if (['available','likely'].includes(passkeyCoach(item).state)) passkeyReady += 1;
  }
  return { total:logins.length, fortress, quarantined, breachHigh, blind, approval, passkeyReady };
}

export function backupConfidence(settings = {}, nowMs = Date.now()) {
  const lastBackupMs = Date.parse(settings.manualBackupLastVerifiedAt || settings.manualBackupLastSuccessAt || '');
  const drillMs = Date.parse(settings.guardianLastRecoveryDrillAt || '');
  const drMs = Date.parse(settings.disasterRecoveryLastSuccessAt || '');
  const pending = Boolean(settings.manualBackupPending);
  let score = 0;
  const checks = [];
  const recentBackup = Number.isFinite(lastBackupMs) && nowMs - lastBackupMs <= 31 * 24 * 60 * 60 * 1000;
  checks.push({ id:'manual', ok:recentBackup && !pending, label:recentBackup && !pending ? 'Verified manual backup is current' : 'Verified manual backup needs attention' });
  if (recentBackup && !pending) score += 35;
  const recentDrill = Number.isFinite(drillMs) && nowMs - drillMs <= 90 * 24 * 60 * 60 * 1000;
  checks.push({ id:'drill', ok:recentDrill, label:recentDrill ? 'Recovery Drill passed within 90 days' : 'Recovery Drill has not been passed recently' });
  if (recentDrill) score += 30;
  const drOk = Boolean(settings.disasterRecoveryEnabled && Number.isFinite(drMs) && !settings.disasterRecoveryLastError);
  checks.push({ id:'dr', ok:drOk, label:drOk ? 'Automatic Disaster Recovery is healthy' : 'Automatic Disaster Recovery is not fully protected' });
  if (drOk) score += 25;
  const offDevice = Boolean(settings.guardianOffDeviceBackupConfirmed);
  checks.push({ id:'offdevice', ok:offDevice, label:offDevice ? 'Off-device copy confirmed' : 'Off-device copy not confirmed' });
  if (offDevice) score += 10;
  const grade = score >= 90 ? 'Excellent' : score >= 70 ? 'Strong' : score >= 45 ? 'Fair' : 'Needs attention';
  return { score, grade, checks, lastBackupMs, drillMs, drMs };
}

export function recoveryPlaybook(item) {
  const host = guardianAllowedHosts(item)[0] || 'this account';
  const generic = [
    'Open the official website or app yourself; do not use links from unexpected messages.',
    'Change the password to a new unique generated password.',
    'Sign out other active sessions and devices.',
    'Verify recovery email addresses and phone numbers.',
    'Verify two-factor authentication and regenerate recovery codes if necessary.',
    'Review connected apps, API access, forwarding rules, and recent account activity.',
    'Confirm VaultCove saved the new credential and create a verified backup.'
  ];
  if (/google\.com$/.test(host)) generic.splice(5, 0, 'Review Gmail forwarding addresses, filters, app passwords, and Google account security activity.');
  if (/microsoft\.com$|live\.com$|outlook\.com$/.test(host)) generic.splice(5, 0, 'Review Microsoft aliases, sign-in methods, inbox forwarding, and recent sign-in activity.');
  if (/github\.com$/.test(host)) generic.splice(5, 0, 'Review GitHub SSH keys, personal access tokens, OAuth apps, deploy keys, and active sessions.');
  return { host, steps:generic };
}

export function createGuardianReceipt({ item, eventKind, occurredAt = new Date().toISOString(), deviceLabel = '', host = '', notification = '' } = {}) {
  return {
    id: crypto.randomUUID(),
    version: 1,
    eventKind: String(eventKind || 'security-event').slice(0, 80),
    itemId: String(item?.id || '').slice(0, 160),
    itemName: String(item?.name || 'Login').slice(0, 160),
    host: String(host || guardianAllowedHosts(item)[0] || '').slice(0, 253),
    occurredAt: new Date(occurredAt).toISOString(),
    deviceLabel: String(deviceLabel || '').slice(0, 120),
    notification: String(notification || '').slice(0, 80),
    passwordIncluded: false
  };
}

export function appendGuardianReceipt(vault, receipt) {
  if (!vault?.security) vault.security = {};
  const current = Array.isArray(vault.security.guardianReceipts) ? vault.security.guardianReceipts : [];
  vault.security.guardianReceipts = [...current, receipt].slice(-250);
  return receipt;
}
