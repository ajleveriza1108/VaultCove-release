import { decryptJson, encryptJson, unlockVaultKeyWrap } from './crypto.js';

export const DISASTER_RECOVERY_MAGIC = 'VAULTCOVE-DISASTER-RECOVERY';
export const DISASTER_RECOVERY_VERSION = 1;
const DISASTER_RECOVERY_AAD = 'VaultCove Disaster Recovery Backup v1';

function cloneJson(value) {
  return JSON.parse(JSON.stringify(value));
}

function normalizeRecoveryEmail(value) {
  const email = String(value || '').trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254) {
    throw new Error('A valid recovery email is required for Disaster Recovery.');
  }
  return email;
}

function validateBackupId(value) {
  const backupId = String(value || '').trim();
  if (!/^[0-9a-f-]{20,64}$/i.test(backupId)) throw new Error('Disaster Recovery backup ID is invalid.');
  return backupId;
}

export function isDisasterRecoveryExport(value) {
  return Boolean(
    value &&
    value.magic === DISASTER_RECOVERY_MAGIC &&
    Number(value.version) === DISASTER_RECOVERY_VERSION &&
    value.keyEnvelope &&
    value.recovery
  );
}

export async function createDisasterRecoveryExport(snapshot, vaultEnvelope, vaultKey, recoveryEmail) {
  if (!snapshot || typeof snapshot !== 'object') throw new Error('Disaster Recovery snapshot is invalid.');
  if (!vaultEnvelope || typeof vaultEnvelope !== 'object') throw new Error('Encrypted vault envelope is unavailable.');
  if (!vaultKey) throw new Error('VaultCove must be unlocked before creating Disaster Recovery backup.');

  const backupId = crypto.randomUUID();
  const email = normalizeRecoveryEmail(recoveryEmail);
  const createdAt = new Date().toISOString();
  const recovery = await encryptJson(vaultKey, {
    backupId,
    recoveryEmail: email,
    snapshot: cloneJson(snapshot)
  }, DISASTER_RECOVERY_AAD);

  return {
    magic: DISASTER_RECOVERY_MAGIC,
    version: DISASTER_RECOVERY_VERSION,
    createdAt,
    backupId,
    protection: {
      masterPasswordRequired: true,
      emailOtpRequired: true,
      storesMasterPassword: false
    },
    // Only the already-encrypted Master Password key wrap is copied. The live vault ciphertext
    // is intentionally excluded so Free/Premium backup scope cannot be bypassed through this wrapper.
    keyEnvelope: cloneJson({
      schemaVersion:vaultEnvelope.schemaVersion,
      cryptoProfile:vaultEnvelope.cryptoProfile,
      kdf:vaultEnvelope.kdf,
      keyWrap:vaultEnvelope.keyWrap,
      createdAt:vaultEnvelope.createdAt,
      updatedAt:vaultEnvelope.updatedAt
    }),
    recovery: {
      version: 1,
      algorithm: 'AES-256-GCM',
      aad: DISASTER_RECOVERY_AAD,
      iv: recovery.iv,
      ciphertext: recovery.ciphertext
    }
  };
}

export async function decryptDisasterRecoveryExport(payload, masterPassword) {
  if (!isDisasterRecoveryExport(payload)) throw new Error('This is not a supported VaultCove Disaster Recovery backup.');
  const backupId = validateBackupId(payload.backupId);
  const candidate = String(masterPassword || '');
  if (!candidate) throw new Error('Enter the Master Password that protected this Disaster Recovery backup.');

  let unlocked;
  try {
    unlocked = await unlockVaultKeyWrap(candidate, payload.keyEnvelope);
  } catch (error) {
    if (/incorrect master password/i.test(String(error?.message || ''))) {
      throw new Error('The Master Password does not match this Disaster Recovery backup.');
    }
    throw new Error('Disaster Recovery backup authentication failed. The file may be damaged or modified.');
  }

  let inner;
  try {
    inner = await decryptJson(unlocked.vaultKey, payload.recovery, DISASTER_RECOVERY_AAD);
  } catch {
    throw new Error('Disaster Recovery backup authentication failed. The file may be damaged or modified.');
  }

  if (validateBackupId(inner?.backupId) !== backupId) throw new Error('Disaster Recovery backup identity check failed.');
  const recoveryEmail = normalizeRecoveryEmail(inner?.recoveryEmail);
  if (!inner?.snapshot || typeof inner.snapshot !== 'object') throw new Error('Disaster Recovery snapshot is missing.');

  return {
    backupId,
    recoveryEmail,
    snapshot: inner.snapshot
  };
}
