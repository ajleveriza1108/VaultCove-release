import { randomId } from './encoding.js';
import { defaultGuardianPolicy, normalizeGuardianPolicy } from './guardian.js';

export const SHARED_KEYS_FOLDER_NAME = 'Shared Keys';
export const SHARED_KEYS_FOLDER_SYSTEM = 'shared-keys';

export function createEmptyVault() {
  return {
    dataVersion: 1,
    items: [],
    folders: [],
    sharingIdentity: null,
    trustedShareContacts: [],
    shareHistory: [],
    emailShareRecipients: [],
    recovery: { lastRecoveryKitAt: null },
    pendingLoginCaptures: [],
    security: { vaultTotp: { enabled: false, secret: '', recoveryCodeHashes: [], enabledAt: null }, captureInbox: null, activityLog: [], activityLogAnchor: '' },
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
}

export function createItem(type, fields = {}) {
  const now = new Date().toISOString();
  return {
    id: randomId('item'),
    type,
    name: fields.name?.trim() || defaultName(type),
    favorite: Boolean(fields.favorite),
    folderId: fields.folderId || null,
    tags: Array.isArray(fields.tags) ? fields.tags : [],
    notes: fields.notes || '',
    createdAt: now,
    updatedAt: now,
    deletedAt: null,
    ...defaultFields(type),
    ...fields
  };
}

export function defaultFields(type) {
  switch (type) {
    case 'login':
      return { nickname: '', username: '', password: '', urls: [], trustedHosts: [], totpSecret: '', autoLogin: false, requireReauthBeforeFill: false, customFields: [], passwordHistory: [], pendingPasswordChange: null, lastPasswordChangeAt: null, importedAt: null, siteVisual: null, guardian: defaultGuardianPolicy() };
    case 'card':
      return { cardholder: '', number: '', brand: '', expMonth: '', expYear: '', securityCode: '', billingAddress: '' };
    case 'bank':
      return { bankName: '', accountHolder: '', accountType: '', accountNumber: '', routingNumber: '', iban: '', swiftBic: '', branch: '', pin: '' };
    case 'identity':
      return { firstName: '', middleName: '', lastName: '', company: '', email: '', phone: '', address1: '', address2: '', city: '', state: '', postalCode: '', country: '', governmentId: '' };
    case 'note':
      return { text: '' };
    default:
      throw new Error(`Unsupported item type: ${type}`);
  }
}

export function defaultName(type) {
  return ({ login: 'New Login', card: 'New Card', bank: 'New Bank Account', identity: 'New Identity', note: 'Secure Note' })[type] || 'New Item';
}

export function normalizeEmailShareRecipients(value) {
  const recipients = Array.isArray(value) ? value : [];
  const seenIds = new Set();
  const seenEmails = new Set();
  const normalized = [];
  for (const entry of recipients) {
    const id = String(entry?.id || '').trim().slice(0, 120);
    const displayName = String(entry?.displayName || '').trim().replace(/\s+/g, ' ').slice(0, 80);
    const email = String(entry?.email || '').trim().toLowerCase().slice(0, 254);
    if (!id || !displayName || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) continue;
    if (seenIds.has(id) || seenEmails.has(email)) continue;
    seenIds.add(id);
    seenEmails.add(email);
    const createdAt = entry?.createdAt || new Date().toISOString();
    normalized.push({
      id,
      displayName,
      email,
      createdAt,
      updatedAt: entry?.updatedAt || createdAt
    });
  }
  return normalized;
}

export function normalizeShareHistory(value, nowMs = Date.now()) {
  const cutoff = nowMs - 30 * 24 * 60 * 60 * 1000;
  return (Array.isArray(value) ? value : [])
    .filter((entry) => entry && Date.parse(String(entry.occurredAt || '')) >= cutoff)
    .map((entry) => ({
      ...entry,
      itemNames: Array.isArray(entry.itemNames) ? entry.itemNames.map((name) => String(name || '').slice(0,120)).slice(0,50) : [],
      peerEmail: String(entry.peerEmail || '').trim().toLowerCase().slice(0,254),
      accessDays: Math.max(0, Math.min(3650, Number(entry.accessDays || 0) || 0))
    }))
    .slice(0, 500);
}

export function normalizeVault(vault) {
  return {
    dataVersion: 1,
    items: Array.isArray(vault?.items) ? vault.items.map((item) => item?.type === 'login' ? { ...item, guardian: normalizeGuardianPolicy(item.guardian || {}, item) } : item) : [],
    folders: Array.isArray(vault?.folders)
      ? vault.folders
          .filter((folder) => folder && folder.id && folder.name)
          .map((folder) => ({
            id: String(folder.id),
            name: String(folder.name).trim().slice(0, 80),
            system: folder.system === SHARED_KEYS_FOLDER_SYSTEM ? SHARED_KEYS_FOLDER_SYSTEM : '',
            createdAt: folder.createdAt || new Date().toISOString(),
            updatedAt: folder.updatedAt || folder.createdAt || new Date().toISOString()
          }))
      : [],
    sharingIdentity: vault?.sharingIdentity || null,
    trustedShareContacts: Array.isArray(vault?.trustedShareContacts) ? vault.trustedShareContacts : [],
    shareHistory: normalizeShareHistory(vault?.shareHistory),
    emailShareRecipients: normalizeEmailShareRecipients(vault?.emailShareRecipients),
    recovery: { lastRecoveryKitAt: null, ...(vault?.recovery || {}) },
    pendingLoginCaptures: Array.isArray(vault?.pendingLoginCaptures) ? vault.pendingLoginCaptures : [],
    security: {
      ...(vault?.security || {}),
      vaultTotp: { enabled: false, secret: '', recoveryCodeHashes: [], enabledAt: null, ...(vault?.security?.vaultTotp || {}) },
      captureInbox: vault?.security?.captureInbox || null,
      activityLog: Array.isArray(vault?.security?.activityLog) ? vault.security.activityLog.slice(-500) : [],
      activityLogAnchor: String(vault?.security?.activityLogAnchor || '').slice(0, 128),
      guardianReceipts: Array.isArray(vault?.security?.guardianReceipts) ? vault.security.guardianReceipts.slice(-250) : []
    },
    createdAt: vault?.createdAt || new Date().toISOString(),
    updatedAt: vault?.updatedAt || new Date().toISOString()
  };
}

export function upsertItem(vault, item) {
  const now = new Date().toISOString();
  const normalized = { ...item, updatedAt: now };
  const index = vault.items.findIndex((candidate) => candidate.id === item.id);
  if (index === -1) vault.items.push(normalized);
  else vault.items[index] = normalized;
  vault.updatedAt = now;
  return normalized;
}



export function createFolder(vault, name, { system = '' } = {}) {
  const value = String(name || '').trim().replace(/\s+/g, ' ').slice(0, 80);
  if (!value) throw new Error('Folder name is required.');
  vault.folders = Array.isArray(vault.folders) ? vault.folders : [];
  if (vault.folders.some((folder) => String(folder.name || '').toLowerCase() === value.toLowerCase())) {
    throw new Error('A folder with that name already exists.');
  }
  const now = new Date().toISOString();
  const systemValue = system === SHARED_KEYS_FOLDER_SYSTEM ? SHARED_KEYS_FOLDER_SYSTEM : '';
  const folder = { id: randomId('folder'), name: value, system: systemValue, createdAt: now, updatedAt: now };
  vault.folders.push(folder);
  vault.updatedAt = now;
  return folder;
}

export function ensureSharedKeysFolder(vault) {
  vault.folders = Array.isArray(vault.folders) ? vault.folders : [];
  let folder = vault.folders.find((candidate) => candidate?.system === SHARED_KEYS_FOLDER_SYSTEM) || null;
  let changed = false;

  if (!folder) {
    folder = vault.folders.find((candidate) => String(candidate?.name || '').trim().toLowerCase() === SHARED_KEYS_FOLDER_NAME.toLowerCase()) || null;
    if (folder) {
      folder.system = SHARED_KEYS_FOLDER_SYSTEM;
      folder.updatedAt = new Date().toISOString();
      vault.updatedAt = folder.updatedAt;
      changed = true;
    }
  }

  if (!folder) {
    folder = createFolder(vault, SHARED_KEYS_FOLDER_NAME, { system: SHARED_KEYS_FOLDER_SYSTEM });
    changed = true;
  }

  if (folder.name !== SHARED_KEYS_FOLDER_NAME) {
    folder.name = SHARED_KEYS_FOLDER_NAME;
    folder.updatedAt = new Date().toISOString();
    vault.updatedAt = folder.updatedAt;
    changed = true;
  }

  return { folder, changed };
}

export function renameFolder(vault, folderId, name) {
  const value = String(name || '').trim().replace(/\s+/g, ' ').slice(0, 80);
  if (!value) throw new Error('Folder name is required.');
  const folder = (vault.folders || []).find((candidate) => candidate.id === folderId);
  if (!folder) throw new Error('Folder was not found.');
  if (folder.system === SHARED_KEYS_FOLDER_SYSTEM) throw new Error('Shared Keys is an automatic VaultCove system folder and cannot be renamed.');
  if ((vault.folders || []).some((candidate) => candidate.id !== folderId && String(candidate.name || '').toLowerCase() === value.toLowerCase())) {
    throw new Error('A folder with that name already exists.');
  }
  folder.name = value;
  folder.updatedAt = new Date().toISOString();
  vault.updatedAt = folder.updatedAt;
  return folder;
}

export function deleteFolder(vault, folderId) {
  const folder = (vault.folders || []).find((candidate) => candidate.id === folderId);
  if (folder?.system === SHARED_KEYS_FOLDER_SYSTEM) throw new Error('Shared Keys is an automatic VaultCove system folder and cannot be deleted.');
  const before = (vault.folders || []).length;
  vault.folders = (vault.folders || []).filter((folder) => folder.id !== folderId);
  if (vault.folders.length === before) return false;
  const now = new Date().toISOString();
  for (const item of vault.items || []) {
    if (item.folderId === folderId) {
      item.folderId = null;
      item.updatedAt = now;
    }
  }
  vault.updatedAt = now;
  return true;
}

export function assignItemsToFolder(vault, itemIds, folderId = null) {
  const ids = new Set((Array.isArray(itemIds) ? itemIds : [itemIds]).map((value) => String(value || '')).filter(Boolean));
  const target = folderId ? (vault.folders || []).find((folder) => folder.id === folderId) : null;
  if (folderId && !target) throw new Error('Target folder was not found.');
  if (target?.system === SHARED_KEYS_FOLDER_SYSTEM) throw new Error('Shared Keys is reserved for received use-only shared access.');
  const now = new Date().toISOString();
  let moved = 0;
  for (const item of vault.items || []) {
    if (!ids.has(item.id) || item.deletedAt || item.sharedAccess?.mode === 'use-only') continue;
    item.folderId = target?.id || null;
    item.updatedAt = now;
    moved += 1;
  }
  if (moved) vault.updatedAt = now;
  return moved;
}

// Trash mutations are cryptographic operations implemented in core/trash.js.
// These legacy helpers refuse to create or reopen plaintext Trash records.
export function softDeleteItem() {
  throw new Error('Use moveVaultItemToTrash() so Trash contents are sealed before persistence.');
}

export function restoreItem(vault, id) {
  const item = vault.items.find((candidate) => candidate.id === id);
  if (!item) return false;
  if (item.trashSealed || item.trashEnvelope) {
    throw new Error('Use restoreVaultItemFromTrash() to decrypt a sealed Trash item only during an explicit restore.');
  }
  throw new Error('Legacy plaintext Trash restore is disabled. Reload VaultCove so the item can be sealed first.');
}

export function purgeItem(vault, id) {
  const before = vault.items.length;
  vault.items = vault.items.filter((candidate) => candidate.id !== id);
  if (vault.items.length !== before) vault.updatedAt = new Date().toISOString();
  return before !== vault.items.length;
}
