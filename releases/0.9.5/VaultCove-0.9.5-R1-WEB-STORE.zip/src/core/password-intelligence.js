// VaultCove Password Intelligence 2.0
// Local-only pattern/guess estimator inspired by password-cracker modeling.
// No password or derived token leaves the device.

const COMMON = new Set([
  'password','password1','passw0rd','qwerty','qwertyuiop','letmein','welcome','admin','administrator',
  'login','secret','master','changeme','iloveyou','monkey','dragon','football','baseball','sunshine','princess',
  'abc123','123456','12345678','123456789','111111','000000','1q2w3e4r','qazwsx','asdfgh','trustno1','vaultcove'
]);
const KEYBOARD_ROWS = ['1234567890','qwertyuiop','asdfghjkl','zxcvbnm','0987654321','poiuytrewq','lkjhgfdsa','mnbvcxz'];
const ALPHA = 'abcdefghijklmnopqrstuvwxyz';
const DIGITS = '0123456789';
const LEET = Object.freeze({ '0':'o','1':'i','3':'e','4':'a','5':'s','7':'t','8':'b','@':'a','$':'s','!':'i','+':'t' });

function leetNormalize(value) {
  return [...String(value || '').toLowerCase()].map((char) => LEET[char] || char).join('');
}
function compactToken(value) { return leetNormalize(value).replace(/[^a-z0-9]/g, ''); }
function hasRun(value, source, min = 4) {
  const normalized = String(value || '').toLowerCase();
  for (let len = Math.min(8, source.length); len >= min; len -= 1) {
    for (let i = 0; i <= source.length - len; i += 1) if (normalized.includes(source.slice(i, i + len))) return true;
  }
  return false;
}
function uniqueClassCount(value) {
  return [/[a-z]/,/[A-Z]/,/\d/,/[^A-Za-z0-9\s]/].filter((regex) => regex.test(value)).length;
}
function poolSize(value) {
  let pool = 0;
  if (/[a-z]/.test(value)) pool += 26;
  if (/[A-Z]/.test(value)) pool += 26;
  if (/\d/.test(value)) pool += 10;
  if (/[^A-Za-z0-9]/.test(value)) pool += 33;
  return Math.max(pool, 1);
}
function contextTokens(context) {
  return [...new Set((Array.isArray(context) ? context : [context]).flatMap((entry) => String(entry || '').toLowerCase().split(/[^a-z0-9]+/)).filter((entry) => entry.length >= 3))];
}

export function analyzePasswordIntelligence(password, context = []) {
  const value = String(password || '');
  if (!value) return { score: 0, label: 'Empty', entropy: 0, guessesLog10: 0, issues: ['No password saved'], patterns: ['empty'] };
  const lower = value.toLowerCase();
  const compact = compactToken(value);
  const patterns = [];
  const issues = [];

  if (value.length < 12) { patterns.push('short'); issues.push('Shorter than 12 characters'); }
  if (value.length < 16) patterns.push('under-16');
  if (uniqueClassCount(value) < 3) { patterns.push('low-class-variety'); issues.push('Limited character-class variety'); }
  if (new Set(value).size < Math.min(8, Math.max(4, Math.floor(value.length / 2)))) { patterns.push('low-unique-variety'); issues.push('Low character variety'); }
  if (/(.)\1{2,}/i.test(value)) { patterns.push('repeat'); issues.push('Repeated characters'); }
  if (/^(.{1,8})\1+$/i.test(value)) { patterns.push('repeated-block'); issues.push('Repeated word or block'); }
  if (COMMON.has(lower) || COMMON.has(compact) || [...COMMON].some((term) => compact.includes(term) && term.length >= 6)) {
    patterns.push('common-password'); issues.push('Contains a common password or word');
  }
  if (KEYBOARD_ROWS.some((row) => hasRun(lower, row, 4))) { patterns.push('keyboard'); issues.push('Contains a keyboard pattern'); }
  if (hasRun(lower, ALPHA, 4) || hasRun(lower, [...ALPHA].reverse().join(''), 4) || hasRun(lower, DIGITS, 4) || hasRun(lower, [...DIGITS].reverse().join(''), 4)) {
    patterns.push('sequence'); issues.push('Contains an obvious sequence');
  }
  if (/(?:19|20)\d{2}/.test(value)) { patterns.push('year'); issues.push('Contains a predictable year'); }
  if (/(?:0?[1-9]|1[0-2])[\-/.](?:0?[1-9]|[12]\d|3[01])[\-/.](?:19|20)?\d{2}/.test(value)) { patterns.push('date'); issues.push('Contains a predictable date'); }

  const contexts = contextTokens(context);
  if (contexts.some((token) => token.length >= 3 && compact.includes(compactToken(token)))) {
    patterns.push('personal-context'); issues.push('Contains account, site, email, or profile context');
  }

  // Start with brute-force search space, then conservatively penalize cracker-friendly patterns.
  let entropy = Math.log2(poolSize(value)) * value.length;
  const penaltyByPattern = {
    short: 18, 'under-16': 5, 'low-class-variety': 10, 'low-unique-variety': 12,
    repeat: 18, 'repeated-block': 28, 'common-password': 55, keyboard: 30,
    sequence: 26, year: 10, date: 18, 'personal-context': 28
  };
  const patternPenaltyScale = value.length >= 20 ? 0.35 : value.length >= 16 ? 0.65 : 1;
  entropy -= patterns.reduce((sum, pattern) => sum + (penaltyByPattern[pattern] || 0), 0) * patternPenaltyScale;
  entropy = Math.max(1, Math.min(256, entropy));

  // A conservative score aligned with offline-cracking resistance, not mere composition.
  let score = entropy >= 90 ? 4 : entropy >= 70 ? 3 : entropy >= 50 ? 2 : 1;
  if (patterns.includes('repeated-block')) score = Math.min(score, 1);
  if (value.length < 20 && patterns.includes('common-password')) score = Math.min(score, 1);
  if (value.length < 20 && (patterns.includes('keyboard') || patterns.includes('sequence') || patterns.includes('personal-context'))) score = Math.min(score, 2);
  if (value.length >= 20 && score >= 3 && issues.length === 0) score = 4;

  return {
    score,
    label: ['Empty','Weak','Fair','Strong','Very strong'][score],
    entropy: Math.round(entropy),
    guessesLog10: Number((entropy * Math.LOG10E * Math.LN2).toFixed(1)),
    issues: [...new Set(issues)],
    patterns: [...new Set(patterns)]
  };
}

export function passwordContextForItem(item, profile = {}) {
  if (!item) return [];
  const urls = Array.isArray(item.urls) ? item.urls : [];
  return [item.name, item.username, item.email, ...urls, profile.name, profile.email].filter(Boolean);
}
