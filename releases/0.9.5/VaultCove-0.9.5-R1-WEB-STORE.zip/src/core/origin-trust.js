// VaultCove Origin Trust Engine 2.0
// Local-only public/private suffix classification for phishing-safe site matching.
// The browser WHATWG URL parser remains authoritative for parsing and IDNA conversion.

const IPV4_RE = /^\d{1,3}(?:\.\d{1,3}){3}$/;

// Reviewed multi-label ICANN suffix snapshot covering common VaultCove customer regions.
// Unknown suffixes are handled conservatively as one-label public suffixes.
const MULTI_LABEL_ICANN_SUFFIXES = new Set([
  'ac.id','ac.in','ac.jp','ac.nz','ac.th','ac.uk','ac.za',
  'asn.au','co.id','co.il','co.in','co.jp','co.ke','co.kr','co.nz','co.th','co.uk','co.za',
  'com.ar','com.au','com.br','com.cn','com.co','com.hk','com.mx','com.my','com.ph','com.pk','com.pl','com.sg','com.tr','com.tw','com.ua','com.vn',
  'edu.au','edu.cn','edu.hk','edu.my','edu.ph','edu.sg','edu.tr',
  'firm.in','gen.in','go.id','go.jp','go.ke','go.kr','go.th','gov.au','gov.br','gov.cn','gov.hk','gov.in','gov.my','gov.ph','gov.sg','govt.nz',
  'id.au','ind.in','ltd.uk','me.uk','mil.in','net.ar','net.au','net.br','net.cn','net.hk','net.in','net.my','net.ph','net.sg','net.tr','net.uk',
  'ne.jp','nic.in','or.id','or.jp','or.ke','or.kr','or.th','org.ar','org.au','org.br','org.cn','org.hk','org.in','org.my','org.nz','org.ph','org.sg','org.tr','org.uk',
  'plc.uk','res.in','sch.id','sch.uk'
]);

// Private suffixes are tenant boundaries. Credentials from one tenant must never
// automatically authorize another tenant even though the infrastructure domain matches.
const PRIVATE_SUFFIXES = new Set([
  'github.io','pages.dev','vercel.app','netlify.app','appspot.com','firebaseapp.com',
  'web.app','herokuapp.com','azurewebsites.net','cloudfront.net','workers.dev',
  'onrender.com','railway.app','fly.dev','surge.sh','glitch.me','replit.app',
  'notion.site','myshopify.com','zendesk.com','freshdesk.com'
]);

function validIpv4(host) {
  return IPV4_RE.test(host) && host.split('.').every((part) => Number(part) >= 0 && Number(part) <= 255);
}

export function normalizeTrustHostname(value) {
  const raw = String(value || '').trim();
  if (!raw) return '';
  try {
    const parsed = new URL(/^[a-z][a-z0-9+.-]*:/i.test(raw) ? raw : `https://${raw}`);
    return parsed.hostname.toLowerCase().replace(/\.$/, '');
  } catch {
    return '';
  }
}

export function isUsableTrustHostname(value) {
  const host = normalizeTrustHostname(value);
  if (!host || host.length > 253) return false;
  if (validIpv4(host)) return true;
  if (host.includes(':')) return true; // WHATWG already validated IPv6.
  if (!host.includes('.')) return false;
  return host.split('.').every((label) => /^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/i.test(label));
}

export function classifyDomain(value) {
  const hostname = normalizeTrustHostname(value);
  if (!hostname) return { hostname: '', registrableDomain: '', publicSuffix: '', subdomain: '', isIp: false, isPrivate: false };
  if (validIpv4(hostname) || hostname.includes(':')) {
    return { hostname, registrableDomain: hostname, publicSuffix: '', subdomain: '', isIp: true, isPrivate: false };
  }

  const labels = hostname.split('.');
  for (const suffix of PRIVATE_SUFFIXES) {
    if (hostname === suffix || hostname.endsWith(`.${suffix}`)) {
      const suffixLabels = suffix.split('.').length;
      const registrableDomain = labels.length > suffixLabels ? labels.slice(-(suffixLabels + 1)).join('.') : hostname;
      return {
        hostname,
        registrableDomain,
        publicSuffix: suffix,
        subdomain: labels.slice(0, Math.max(0, labels.length - registrableDomain.split('.').length)).join('.'),
        isIp: false,
        isPrivate: true
      };
    }
  }

  const lastTwo = labels.slice(-2).join('.');
  const publicSuffix = MULTI_LABEL_ICANN_SUFFIXES.has(lastTwo) ? lastTwo : labels.at(-1) || '';
  const suffixLabels = publicSuffix.split('.').filter(Boolean).length;
  const registrableDomain = labels.length > suffixLabels ? labels.slice(-(suffixLabels + 1)).join('.') : hostname;
  return {
    hostname,
    registrableDomain,
    publicSuffix,
    subdomain: labels.slice(0, Math.max(0, labels.length - registrableDomain.split('.').length)).join('.'),
    isIp: false,
    isPrivate: false
  };
}

export function registrableTrustDomain(value) {
  return classifyDomain(value).registrableDomain;
}

export function sameTenantBoundary(leftValue, rightValue) {
  const left = classifyDomain(leftValue);
  const right = classifyDomain(rightValue);
  if (!left.hostname || !right.hostname) return false;
  if (left.isIp || right.isIp) return left.hostname === right.hostname;
  return left.registrableDomain === right.registrableDomain;
}

export function canApexCoverSubdomain(savedValue, currentValue) {
  const saved = classifyDomain(savedValue);
  const current = classifyDomain(currentValue);
  if (!saved.hostname || !current.hostname || saved.hostname === current.hostname) return false;
  if (saved.isIp || current.isIp || saved.isPrivate || current.isPrivate) return false;
  if (saved.registrableDomain !== current.registrableDomain) return false;
  return saved.hostname === saved.registrableDomain && current.hostname.endsWith(`.${saved.registrableDomain}`);
}

export function domainRiskSignals(value) {
  const parsed = classifyDomain(value);
  const host = parsed.hostname;
  const signals = [];
  if (!host) return ['invalid-host'];
  if (host.startsWith('xn--') || host.includes('.xn--')) signals.push('idn-punycode');
  if (parsed.isPrivate) signals.push('private-tenant-boundary');
  if (host.split('.').length >= 6) signals.push('deep-subdomain');
  if (/login|signin|account|verify|secure|auth/.test(parsed.subdomain) && parsed.subdomain.split('.').length >= 2) signals.push('credential-themed-subdomain');
  if (/-{2,}/.test(host) && !host.includes('xn--')) signals.push('unusual-hyphenation');
  return signals;
}

export const ORIGIN_TRUST_DATA = Object.freeze({
  multiLabelSuffixCount: MULTI_LABEL_ICANN_SUFFIXES.size,
  privateSuffixCount: PRIVATE_SUFFIXES.size,
  version: 2
});
