VaultCove 0.7.64 R1 Apps Script Licensing Backend

Protocol: v3
Standard Payhip license: 7 devices
Owner-admin license: unlimited devices

Important 0.7.27 security changes:
- Raw Payhip license keys are no longer stored in Apps Script Script Properties.
- The server keeps only HMAC hashes of license keys.
- The Chrome client encrypts its license key and refresh token per device with a non-extractable AES-256-GCM key held in extension-origin IndexedDB.
- vcInitializeLicenseSheets() purges legacy VC_PAYHIP_LICENSE_* properties.
- Owner-admin provisioning uses temporary VC_OWNER_ADMIN_KEY + VC_OWNER_ADMIN_EMAIL properties and vcAdminProvisionOwnerFromProperties(); the raw owner-admin property is deleted automatically.

Read SETUP.md and follow the steps in order.
