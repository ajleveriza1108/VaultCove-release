@echo off
setlocal EnableExtensions
cd /d "%~dp0"
echo ==============================================================================
echo VaultCove 0.9.5 R1 - FULL SOURCE UPDATE + VALIDATE + BUILD
echo ==============================================================================
echo Run normally - DO NOT Run as Administrator.
where pwsh.exe >nul 2>nul
if errorlevel 1 (
  echo [FAIL] PowerShell 7 ^(pwsh.exe^) was not found.
  pause
  exit /b 1
)
pwsh.exe -NoLogo -NoProfile -NonInteractive -Command "$e=$null;$t=$null;[System.Management.Automation.Language.Parser]::ParseFile('%~dp0UPDATE-VAULTCOVE-0.9.5-R1.ps1',[ref]$t,[ref]$e)|Out-Null;if($e.Count){foreach($err in $e){Write-Host ('[PARSER] '+$err.Message+' at line '+$err.Extent.StartLineNumber+', column '+$err.Extent.StartColumnNumber) -ForegroundColor Red};exit 1}else{Write-Host '[PASS] PowerShell 7 parser preflight passed.' -ForegroundColor Green}"
if errorlevel 1 (
  pause
  exit /b 1
)
pwsh.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0UPDATE-VAULTCOVE-0.9.5-R1.ps1"
set "RC=%ERRORLEVEL%"
pause
exit /b %RC%