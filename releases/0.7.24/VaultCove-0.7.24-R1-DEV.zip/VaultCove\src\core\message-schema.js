export const RUNTIME_PROTOCOL_VERSION = 1;

const WEB_HANDLER_TYPES = new Set([
  'MARK_VISITED_SAVED_SITE',
  'GET_PAGE_LOGINS',
  'ISSUE_SECURE_LOGIN_CAPABILITY',
  'FILL_PAGE_LOGIN',
  'NEW_LOGIN_CANDIDATE',
  'PASSWORD_CHANGE_CANDIDATE',
  'OPEN_HANDLER_UNLOCK'
]);

const EXTENSION_TYPES = new Set([
  'LOCK_VAULT','GET_VAULT_STATE','INITIALIZE_VAULT','UNLOCK_VAULT','FILL_ACTIVE_TAB_LOGIN',
  'ENABLE_ONDEMAND_HANDLER','SYNC_BROWSER_INTEGRATION','GET_ACTIVE_TAB_LOGINS','VERIFY_SENSITIVE_ACCESS',
  'CHECK_MASTER_PASSWORD_MATCH','SENSITIVE_ACCESS_STATUS','GET_SENSITIVE_LOGIN_FIELD','PASSWORD_CHANGE_CONFIRMED',
  'SET_SITE_HANDLER','GET_SITE_HANDLER_STATE','LIST_SITE_HANDLERS','REMOVE_ALL_SITE_HANDLERS','SYNC_ALWAYS_ON_HANDLER',
  'SET_HANDLER_SITE_EXCEPTION','LIST_HANDLER_SITE_EXCEPTIONS','CHECK_FOR_UPDATES','OPEN_LOGIN_ITEM','COMPLETE_HANDLER_UNLOCK',
  'OPEN_DASHBOARD'
]);

const SHAPES = Object.freeze({
  MARK_VISITED_SAVED_SITE: [],
  GET_PAGE_LOGINS: ['query'],
  ISSUE_SECURE_LOGIN_CAPABILITY: ['itemId','automatic','stage'],
  FILL_PAGE_LOGIN: ['capability','submit'],
  NEW_LOGIN_CANDIDATE: ['username','password','reason','pageTitle'],
  PASSWORD_CHANGE_CANDIDATE: ['username','password','reason','confidence'],
  OPEN_HANDLER_UNLOCK: [],
  LOCK_VAULT: [],
  GET_VAULT_STATE: [],
  INITIALIZE_VAULT: ['masterPassword'],
  UNLOCK_VAULT: ['masterPassword','secondFactor'],
  FILL_ACTIVE_TAB_LOGIN: ['tabId','itemId','submit'],
  ENABLE_ONDEMAND_HANDLER: ['tabId'],
  SYNC_BROWSER_INTEGRATION: ['injectExisting'],
  GET_ACTIVE_TAB_LOGINS: ['tabId'],
  VERIFY_SENSITIVE_ACCESS: ['masterPassword','secondFactor'],
  CHECK_MASTER_PASSWORD_MATCH: ['candidate'],
  SENSITIVE_ACCESS_STATUS: [],
  GET_SENSITIVE_LOGIN_FIELD: ['tabId','itemId','field'],
  PASSWORD_CHANGE_CONFIRMED: ['itemId'],
  SET_SITE_HANDLER: ['tabId','enabled'],
  GET_SITE_HANDLER_STATE: ['tabId'],
  LIST_SITE_HANDLERS: [],
  REMOVE_ALL_SITE_HANDLERS: [],
  SYNC_ALWAYS_ON_HANDLER: ['injectExisting'],
  SET_HANDLER_SITE_EXCEPTION: ['hostname','disabled'],
  LIST_HANDLER_SITE_EXCEPTIONS: [],
  CHECK_FOR_UPDATES: ['force'],
  OPEN_LOGIN_ITEM: ['itemId'],
  COMPLETE_HANDLER_UNLOCK: ['sourceTabId','sourceOrigin'],
  OPEN_DASHBOARD: []
});

function stringWithin(value, max, { allowEmpty = true } = {}) {
  return typeof value === 'string' && value.length <= max && (allowEmpty || value.length > 0);
}

function validateKnownFields(type, message) {
  const shape = SHAPES[type];
  if (!shape) return { ok: false, error: 'Unknown VaultCove runtime message.' };
  const base = WEB_HANDLER_TYPES.has(type) ? ['type','protocolVersion','requestId'] : ['type'];
  const allowed = new Set([...base, ...shape]);
  for (const key of Object.keys(message)) if (!allowed.has(key)) return { ok: false, error: `Unexpected field in ${type}: ${key}` };
  return { ok: true };
}

export function runtimeMessageSourceAllowed(type, sourceKind) {
  if (WEB_HANDLER_TYPES.has(type)) return sourceKind === 'web-handler';
  if (EXTENSION_TYPES.has(type)) return sourceKind === 'extension';
  return false;
}

export function validateRuntimeMessage(message) {
  if (!message || typeof message !== 'object' || Array.isArray(message) || !stringWithin(message.type, 80, { allowEmpty: false })) return { ok: false, error: 'Malformed VaultCove runtime message.' };
  const type = message.type;
  const known = validateKnownFields(type, message);
  if (!known.ok) return known;
  if (WEB_HANDLER_TYPES.has(type)) {
    if (message.protocolVersion !== RUNTIME_PROTOCOL_VERSION) return { ok: false, error: 'Unsupported VaultCove handler protocol version.' };
    if (!stringWithin(message.requestId, 96, { allowEmpty: false })) return { ok: false, error: 'Missing or invalid handler request ID.' };
  }

  const stringLimits = {
    query: 160, itemId: 200, capability: 160, username: 512, password: 4096, reason: 120,
    pageTitle: 160, confidence: 40, masterPassword: 4096, secondFactor: 128, candidate: 4096,
    field: 32, hostname: 253, sourceOrigin: 300, stage: 24
  };
  for (const [key, max] of Object.entries(stringLimits)) {
    if (key in message && !stringWithin(message[key], max)) return { ok: false, error: `Invalid ${key} field.` };
  }
  for (const key of ['tabId','sourceTabId']) if (key in message && (!Number.isInteger(message[key]) || message[key] < 0)) return { ok: false, error: `Invalid ${key}.` };
  for (const key of ['submit','automatic','enabled','injectExisting','disabled','force']) if (key in message && typeof message[key] !== 'boolean') return { ok: false, error: `Invalid ${key} flag.` };
  if ('field' in message && !['username','password'].includes(message.field)) return { ok: false, error: 'Unsupported sensitive field.' };
  if ('stage' in message && !['username','password'].includes(message.stage)) return { ok: false, error: 'Unsupported login stage.' };
  return { ok: true, type };
}

export function webHandlerMessageTypes() { return new Set(WEB_HANDLER_TYPES); }
