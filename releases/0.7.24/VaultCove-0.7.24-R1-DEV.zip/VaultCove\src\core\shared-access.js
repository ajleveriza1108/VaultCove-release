import { base64UrlToBytes, bytesToBase64Url, bytesToUtf8, randomBytes, utf8ToBytes } from './encoding.js';
import { createItem } from './model.js';

export const SHARED_ACCESS_VERSION = 1;
export const SHARED_ACCESS_MODE = 'use-only';
const SHARED_ACCESS_AAD = 'VaultCove:shared-access:credential:v1';
const SHARED_KEY_WRAP_AAD = 'VaultCove:shared-access:key-wrap:v1';

function aadForItem(prefix, itemId) {
  return utf8ToBytes(`${prefix}|${String(itemId || '')}`);
}

function expired(expiresAt) {
  const value = Date.parse(String(expiresAt || ''));
  return Number.isFinite(value) && Date.now() > value;
}

export function isUseOnlySharedLogin(item) {
  return Boolean(
    item &&
    item.type === 'login' &&
    !item.deletedAt &&
    item.sharedAccess?.version === SHARED_ACCESS_VERSION &&
    item.sharedAccess?.mode === SHARED_ACCESS_MODE &&
    item.sharedAccess?.sealedCredential?.ciphertext &&
    item.sharedAccess?.sealedCredential?.wrappedKey?.ciphertext
  );
}

export function sharedAccessIsExpired(item) {
  return isUseOnlySharedLogin(item) && expired(item.sharedAccess?.expiresAt);
}

export function sharedAccessLabel(item) {
  if (!isUseOnlySharedLogin(item)) return '';
  if (sharedAccessIsExpired(item)) return 'Shared access expired';
  const sender = String(item.sharedAccess?.senderDisplayName || '').trim();
  return sender ? `Shared access from ${sender}` : 'Shared use-only access';
}

export async function sealSharedLoginForVault(sourceItem, vaultKey, metadata = {}) {
  if (!sourceItem || sourceItem.type !== 'login') throw new Error('Only login credentials can be sealed as shared access.');
  if (!vaultKey) throw new Error('Vault key is required to seal shared access.');
  const now = new Date().toISOString();
  const shell = createItem('login', {
    name: String(sourceItem.name || 'Shared Login').slice(0, 160),
    username: '',
    password: '',
    urls: Array.isArray(sourceItem.urls) ? sourceItem.urls.slice(0, 10) : [],
    trustedHosts: Array.isArray(sourceItem.trustedHosts) ? sourceItem.trustedHosts.slice(0, 20) : [],
    notes: '',
    totpSecret: '',
    favorite: false,
    folderId: null,
    tags: ['Shared Access'],
    autoLogin: false,
    requireReauthBeforeFill: true,
    importedAt: now,
    pendingPasswordChange: null,
    passwordHistory: [],
    lastPasswordChangeAt: null
  });

  const perItemKeyBytes = randomBytes(32);
  const perItemKey = await crypto.subtle.importKey('raw', perItemKeyBytes, { name: 'AES-GCM' }, false, ['encrypt', 'decrypt']);
  const credentialIv = randomBytes(12);
  const credentialPayload = utf8ToBytes(JSON.stringify({
    username: String(sourceItem.username || ''),
    password: String(sourceItem.password || '')
  }));
  const credentialCiphertext = new Uint8Array(await crypto.subtle.encrypt(
    { name: 'AES-GCM', iv: credentialIv, additionalData: aadForItem(SHARED_ACCESS_AAD, shell.id), tagLength: 128 },
    perItemKey,
    credentialPayload
  ));

  const wrapIv = randomBytes(12);
  const wrappedKey = new Uint8Array(await crypto.subtle.encrypt(
    { name: 'AES-GCM', iv: wrapIv, additionalData: aadForItem(SHARED_KEY_WRAP_AAD, shell.id), tagLength: 128 },
    vaultKey,
    perItemKeyBytes
  ));

  shell.sharedAccess = {
    version: SHARED_ACCESS_VERSION,
    mode: SHARED_ACCESS_MODE,
    immutable: true,
    loginOnly: true,
    senderShareId: String(metadata.senderShareId || ''),
    senderDisplayName: String(metadata.senderDisplayName || '').slice(0, 80),
    senderFingerprint: String(metadata.senderFingerprint || ''),
    packageId: String(metadata.packageId || ''),
    receivedAt: now,
    expiresAt: metadata.expiresAt || null,
    sealedCredential: {
      algorithm: 'AES-256-GCM',
      iv: bytesToBase64Url(credentialIv),
      ciphertext: bytesToBase64Url(credentialCiphertext),
      wrappedKey: {
        algorithm: 'AES-256-GCM',
        iv: bytesToBase64Url(wrapIv),
        ciphertext: bytesToBase64Url(wrappedKey)
      }
    }
  };
  return shell;
}

export async function openSharedLoginForFill(item, vaultKey) {
  if (!isUseOnlySharedLogin(item)) return item;
  if (sharedAccessIsExpired(item)) throw new Error('This shared login access has expired. Ask the sender to create a new share package.');
  if (!vaultKey) throw new Error('Vault key is required to use shared access.');
  const envelope = item.sharedAccess.sealedCredential;
  let perItemKeyBytes;
  try {
    perItemKeyBytes = new Uint8Array(await crypto.subtle.decrypt(
      {
        name: 'AES-GCM',
        iv: base64UrlToBytes(envelope.wrappedKey.iv),
        additionalData: aadForItem(SHARED_KEY_WRAP_AAD, item.id),
        tagLength: 128
      },
      vaultKey,
      base64UrlToBytes(envelope.wrappedKey.ciphertext)
    ));
  } catch {
    throw new Error('Shared access key authentication failed. The item may have been modified.');
  }
  const perItemKey = await crypto.subtle.importKey('raw', perItemKeyBytes, { name: 'AES-GCM' }, false, ['decrypt']);
  let decrypted;
  try {
    decrypted = new Uint8Array(await crypto.subtle.decrypt(
      {
        name: 'AES-GCM',
        iv: base64UrlToBytes(envelope.iv),
        additionalData: aadForItem(SHARED_ACCESS_AAD, item.id),
        tagLength: 128
      },
      perItemKey,
      base64UrlToBytes(envelope.ciphertext)
    ));
  } catch {
    throw new Error('Shared credential authentication failed. The item may have been modified.');
  }
  const payload = JSON.parse(bytesToUtf8(decrypted));
  return {
    ...item,
    username: String(payload.username || ''),
    password: String(payload.password || ''),
    autoLogin: false,
    requireReauthBeforeFill: true
  };
}
