import { bytesToBase64Url, randomId, utf8ToBytes } from './encoding.js';

export const ACTIVITY_LOG_VERSION = 1;
export const ACTIVITY_LOG_MAX_EVENTS = 500;

function cleanText(value, max = 180) {
  return String(value ?? '').replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, max);
}

function cleanDetails(details = {}) {
  const output = {};
  if (!details || typeof details !== 'object' || Array.isArray(details)) return output;
  for (const key of Object.keys(details).sort().slice(0, 16)) {
    const safeKey = cleanText(key, 48);
    if (!safeKey) continue;
    const value = details[key];
    if (typeof value === 'boolean') output[safeKey] = value;
    else if (typeof value === 'number' && Number.isFinite(value)) output[safeKey] = value;
    else if (value != null) output[safeKey] = cleanText(value, 240);
  }
  return output;
}

function stableJson(value) {
  if (Array.isArray(value)) return `[${value.map(stableJson).join(',')}]`;
  if (value && typeof value === 'object') {
    return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${stableJson(value[key])}`).join(',')}}`;
  }
  return JSON.stringify(value);
}

async function sha256Base64Url(value) {
  const digest = new Uint8Array(await crypto.subtle.digest('SHA-256', utf8ToBytes(value)));
  return bytesToBase64Url(digest);
}

function eventPayload(event) {
  return {
    version: ACTIVITY_LOG_VERSION,
    id: event.id,
    type: event.type,
    at: event.at,
    details: event.details || {},
    previousHash: event.previousHash || ''
  };
}

export async function appendActivityEvent(vault, type, details = {}, at = new Date().toISOString()) {
  if (!vault || typeof vault !== 'object') throw new Error('An unlocked vault is required for the local activity log.');
  const safeType = cleanText(type, 64).toLowerCase().replace(/[^a-z0-9._-]/g, '-');
  if (!safeType) throw new Error('Activity event type is required.');

  vault.security = { ...(vault.security || {}) };
  const log = Array.isArray(vault.security.activityLog) ? [...vault.security.activityLog] : [];
  let anchor = cleanText(vault.security.activityLogAnchor || '', 128);
  const previousHash = log.length ? cleanText(log[log.length - 1]?.hash || '', 128) : anchor;
  const event = {
    version: ACTIVITY_LOG_VERSION,
    id: randomId('evt'),
    type: safeType,
    at: new Date(at).toISOString(),
    details: cleanDetails(details),
    previousHash
  };
  event.hash = await sha256Base64Url(stableJson(eventPayload(event)));
  log.push(event);

  while (log.length > ACTIVITY_LOG_MAX_EVENTS) {
    const removed = log.shift();
    if (removed?.hash) anchor = removed.hash;
  }
  vault.security.activityLog = log;
  vault.security.activityLogAnchor = anchor;
  return event;
}

export async function verifyActivityLog(vault) {
  const security = vault?.security || {};
  const log = Array.isArray(security.activityLog) ? security.activityLog : [];
  let expectedPrevious = cleanText(security.activityLogAnchor || '', 128);
  for (let index = 0; index < log.length; index += 1) {
    const event = log[index];
    if (!event || Number(event.version) !== ACTIVITY_LOG_VERSION) return { ok: false, index, reason: 'unsupported-event-version', count: log.length };
    if (String(event.previousHash || '') !== expectedPrevious) return { ok: false, index, reason: 'broken-previous-hash', count: log.length };
    const calculated = await sha256Base64Url(stableJson(eventPayload(event)));
    if (calculated !== String(event.hash || '')) return { ok: false, index, reason: 'event-hash-mismatch', count: log.length };
    expectedPrevious = calculated;
  }
  return { ok: true, count: log.length, latestHash: expectedPrevious, anchor: cleanText(security.activityLogAnchor || '', 128) };
}

export function activityLogEntries(vault, limit = 50) {
  const log = Array.isArray(vault?.security?.activityLog) ? vault.security.activityLog : [];
  return log.slice(-Math.max(0, Math.min(500, Number(limit) || 0))).reverse();
}
