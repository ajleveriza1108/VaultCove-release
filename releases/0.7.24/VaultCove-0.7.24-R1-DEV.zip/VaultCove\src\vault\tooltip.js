// VaultCove 0.7.15: custom button tooltips were removed.
// Keep this inert export only so stale cached module references fail safely.
export function installTooltips() { return 0; }
