import { TESTING_FULL_ACCESS } from './constants.js';
import { ensureDeviceId, ensureDeviceRecoveryToken } from './storage.js';
import { LICENSE_LEASE_PUBLIC_KEY_SPKI_BASE64 } from './license-key.js';
import { LICENSE_SERVICE_ENDPOINT } from './license-endpoint.js';

const STORAGE_KEY = 'vaultcoveLicenseClient';
const LICENSE_HOSTS = ['https://script.google.com/*', 'https://script.googleusercontent.com/*'];
const MAX_DEVICE_LABEL = 80;
const LICENSE_PROTOCOL_VERSION = 2;
const LICENSE_RESPONSE_MAX_CHARS = 64 * 1024;
const LICENSE_REQUEST_TIMEOUT_MS = 15_000;

function normalizeEmail(value) {
  return String(value || '').trim().toLowerCase();
}

function validateEmail(value) {
  const email = normalizeEmail(value);
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254) throw new Error('Enter a valid license email address.');
  return email;
}

export function validateLicenseServiceUrl(value) {
  const text = String(value || '').trim();
  if (!text || text === 'UNCONFIGURED') throw new Error('VaultCove licensing transport is not configured in this build yet.');
  let url;
  try { url = new URL(text); } catch { throw new Error('License-service URL is invalid.'); }
  if (url.protocol !== 'https:' || url.hostname !== 'script.google.com' || !/^\/macros\/s\/[^/]+\/exec$/.test(url.pathname)) {
    throw new Error('Use the HTTPS Apps Script Web App /macros/s/.../exec URL.');
  }
  return url.toString();
}

export async function ensureLicenseServicePermission() {
  const has = await chrome.permissions.contains({ origins: LICENSE_HOSTS });
  if (has) return true;
  return chrome.permissions.request({ origins: LICENSE_HOSTS });
}

export async function getLicenseClientState() {
  const result = await chrome.storage.local.get(STORAGE_KEY);
  return {
    refreshToken: '',
    lease: null,
    leaseSignature: '',
    leaseVerified: false,
    emailMasked: '',
    serialHint: '',
    lastValidatedAt: null,
    ...(result[STORAGE_KEY] || {})
  };
}

export async function clearLicenseClientState() {
  await chrome.storage.local.set({ [STORAGE_KEY]: {} });
}

function strictRequest(action, input = {}) {
  const allowed = {
    beginActivation: ['serial', 'email', 'installationId', 'deviceRecoveryToken', 'deviceLabel', 'platform', 'appVersion'],
    completeActivation: ['challengeId', 'code', 'installationId', 'deviceRecoveryToken'],
    completeRecoveryActivation: ['reclaimToken', 'installationId', 'deviceRecoveryToken', 'targetInstallationId', 'deviceLabel', 'platform', 'appVersion'],
    refreshLease: ['installationId', 'refreshToken'],
    beginManageDevices: ['installationId', 'refreshToken'],
    completeManageDevices: ['challengeId', 'code', 'installationId'],
    listDevices: ['managementToken', 'installationId'],
    deviceAction: ['managementToken', 'installationId', 'targetInstallationId', 'deviceAction'],
    releaseCurrentDevice: ['installationId', 'refreshToken']
  };
  if (!allowed[action]) throw new Error('Unsupported license-service action.');
  const requestBytes = crypto.getRandomValues(new Uint8Array(18));
  const nonce = Array.from(requestBytes, (byte) => byte.toString(16).padStart(2, '0')).join('');
  const output = {
    action,
    protocolVersion: LICENSE_PROTOCOL_VERSION,
    product: 'VaultCove',
    requestId: crypto.randomUUID(),
    nonce,
    clientTime: new Date().toISOString()
  };
  for (const key of allowed[action]) if (Object.prototype.hasOwnProperty.call(input, key)) output[key] = input[key];
  return output;
}

async function postLicense(action, input = {}) {
  const endpoint = validateLicenseServiceUrl(LICENSE_SERVICE_ENDPOINT);
  const payload = strictRequest(action, input);
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), LICENSE_REQUEST_TIMEOUT_MS);
  try {
    const response = await fetch(endpoint, {
      method: 'POST',
      redirect: 'follow',
      headers: { 'Content-Type': 'text/plain;charset=utf-8' },
      body: JSON.stringify(payload),
      cache: 'no-store',
      credentials: 'omit',
      referrerPolicy: 'no-referrer',
      signal: controller.signal
    });
    if (!response.ok) throw new Error(`License service returned HTTP ${response.status}.`);
    const declaredLength = Number(response.headers.get('content-length') || 0);
    if (declaredLength > LICENSE_RESPONSE_MAX_CHARS) throw new Error('License service response is unexpectedly large.');
    const responseText = await response.text();
    if (responseText.length > LICENSE_RESPONSE_MAX_CHARS) throw new Error('License service response is unexpectedly large.');
    let value;
    try { value = JSON.parse(responseText); } catch { throw new Error('License service returned invalid JSON.'); }
    if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error('License service returned an invalid response object.');
    if (!value.ok) throw new Error(String(value.error || 'License service rejected the request.').slice(0, 240));
    return value;
  } catch (error) {
    if (error?.name === 'AbortError') throw new Error('License service request timed out.');
    throw error;
  } finally {
    clearTimeout(timeout);
  }
}

function base64UrlToBytes(value) {
  const normalized = String(value || '').replace(/-/g, '+').replace(/_/g, '/');
  const padded = normalized + '='.repeat((4 - normalized.length % 4) % 4);
  const binary = atob(padded);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

function base64ToBytes(value) {
  const binary = atob(String(value || '').replace(/\s+/g, ''));
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

function canonicalLease(lease) {
  return JSON.stringify({
    protocolVersion: Number(lease.protocolVersion || 1),
    product: String(lease.product || ''),
    licenseId: String(lease.licenseId || ''),
    installationId: String(lease.installationId || ''),
    status: String(lease.status || ''),
    licenseType: String(lease.licenseType || 'standard'),
    maxDevices: Number(lease.maxDevices || 0),
    activeDevices: Number(lease.activeDevices || 0),
    retainedDevices: Number(lease.retainedDevices || 0),
    usedDevices: Number(lease.usedDevices || 0),
    emailMasked: String(lease.emailMasked || ''),
    issuedAt: String(lease.issuedAt || ''),
    expiresAt: String(lease.expiresAt || '')
  });
}

export async function verifySignedLicenseLease(lease, signature) {
  if (LICENSE_LEASE_PUBLIC_KEY_SPKI_BASE64 === 'UNCONFIGURED') {
    if (TESTING_FULL_ACCESS) return { verified: false, testingUnconfiguredKey: true };
    throw new Error('Production license verification public key is not configured.');
  }
  const publicKey = await crypto.subtle.importKey(
    'spki',
    base64ToBytes(LICENSE_LEASE_PUBLIC_KEY_SPKI_BASE64),
    { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' },
    false,
    ['verify']
  );
  const valid = await crypto.subtle.verify(
    { name: 'RSASSA-PKCS1-v1_5' },
    publicKey,
    base64UrlToBytes(signature),
    new TextEncoder().encode(canonicalLease(lease))
  );
  if (!valid) throw new Error('License lease signature verification failed.');
  return { verified: true };
}

async function saveLeaseResponse(result, serialHint = '') {
  if (!result.lease || !result.leaseSignature || !result.refreshToken) throw new Error('License service returned an incomplete activation response.');
  const verification = await verifySignedLicenseLease(result.lease, result.leaseSignature);
  const current = await getLicenseClientState();
  const next = {
    ...current,
    refreshToken: String(result.refreshToken),
    lease: result.lease,
    leaseSignature: String(result.leaseSignature),
    leaseVerified: Boolean(verification.verified),
    emailMasked: String(result.lease.emailMasked || ''),
    serialHint: serialHint || current.serialHint || '',
    lastValidatedAt: new Date().toISOString()
  };
  await chrome.storage.local.set({ [STORAGE_KEY]: next });
  return { ...result, verification };
}

export async function beginLicenseActivation({ serial, email, deviceLabel = '' }) {
  const installationId = await ensureDeviceId();
  const deviceRecoveryToken = await ensureDeviceRecoveryToken();
  const key = String(serial || '').trim();
  if (key.length < 8 || key.length > 200) throw new Error('Enter a valid VaultCove serial/license key.');
  const normalizedEmail = validateEmail(email);
  return postLicense('beginActivation', {
    serial: key,
    email: normalizedEmail,
    installationId,
    deviceRecoveryToken,
    deviceLabel: String(deviceLabel || '').trim().slice(0, MAX_DEVICE_LABEL),
    platform: `${navigator.platform || 'unknown'} / Chrome`,
    appVersion: chrome.runtime.getManifest().version
  });
}

export async function completeLicenseActivation({ challengeId, code, serialHint = '' }) {
  const installationId = await ensureDeviceId();
  const deviceRecoveryToken = await ensureDeviceRecoveryToken();
  const result = await postLicense('completeActivation', {
    challengeId: String(challengeId || ''),
    code: String(code || '').replace(/\D/g, '').slice(0, 6),
    installationId,
    deviceRecoveryToken
  });
  if (result.reclaimRequired) return result;
  return saveLeaseResponse(result, serialHint);
}

export async function completeRetainedDeviceRecovery({ reclaimToken, targetInstallationId, deviceLabel = '', serialHint = '' }) {
  const installationId = await ensureDeviceId();
  const deviceRecoveryToken = await ensureDeviceRecoveryToken();
  const result = await postLicense('completeRecoveryActivation', {
    reclaimToken: String(reclaimToken || ''),
    installationId,
    deviceRecoveryToken,
    targetInstallationId: String(targetInstallationId || '__new__'),
    deviceLabel: String(deviceLabel || '').trim().slice(0, MAX_DEVICE_LABEL),
    platform: `${navigator.platform || 'unknown'} / Chrome`,
    appVersion: chrome.runtime.getManifest().version
  });
  return saveLeaseResponse(result, serialHint);
}

export async function refreshLicenseLease() {
  const installationId = await ensureDeviceId();
  const client = await getLicenseClientState();
  if (!client.refreshToken) throw new Error('This installation is not activated.');
  const result = await postLicense('refreshLease', { installationId, refreshToken: client.refreshToken });
  return saveLeaseResponse({ ...result, refreshToken: client.refreshToken });
}

export async function beginDeviceManagement() {
  const installationId = await ensureDeviceId();
  const client = await getLicenseClientState();
  if (!client.refreshToken) throw new Error('Activate this installation first.');
  return postLicense('beginManageDevices', { installationId, refreshToken: client.refreshToken });
}

export async function completeDeviceManagement(challengeId, code) {
  const installationId = await ensureDeviceId();
  return postLicense('completeManageDevices', {
    challengeId: String(challengeId || ''),
    code: String(code || '').replace(/\D/g, '').slice(0, 6),
    installationId
  });
}

export async function listLicensedDevices(managementToken) {
  const installationId = await ensureDeviceId();
  return postLicense('listDevices', { managementToken: String(managementToken || ''), installationId });
}

export async function changeLicensedDevice(managementToken, targetInstallationId, deviceAction) {
  if (!['release', 'revoke', 'restore', 'retain'].includes(deviceAction)) throw new Error('Unsupported device action.');
  const installationId = await ensureDeviceId();
  return postLicense('deviceAction', {
    managementToken: String(managementToken || ''),
    installationId,
    targetInstallationId: String(targetInstallationId || ''),
    deviceAction
  });
}

export async function releaseCurrentDevice() {
  const installationId = await ensureDeviceId();
  const client = await getLicenseClientState();
  if (!client.refreshToken) throw new Error('This installation is not activated.');
  const result = await postLicense('releaseCurrentDevice', { installationId, refreshToken: client.refreshToken });
  await clearLicenseClientState({ keepEndpoint: true });
  return result;
}

export function licensePrivacyContract() {
  return {
    sent: ['serial during first activation only', 'license email', 'random installation ID', 'user device label', 'platform/app version', 'OTP/challenge responses', 'license refresh/management tokens', 'device recovery token during activation/recovery only'],
    neverSent: ['master password', 'vault key', 'saved websites', 'usernames', 'passwords', 'TOTP secrets for websites', 'cards', 'bank accounts', 'secure notes', 'VCShare private keys']
  };
}
