// Build-managed licensing transport endpoint.
// This value is intentionally unconfigured in the pre-licensing build. During
// the Payhip/Apps Script setup, the release builder will inject the approved
// HTTPS Apps Script endpoint here. The endpoint itself is not treated as a
// secret; Payhip/API secrets and signing private keys must remain server-side.
export const LICENSE_SERVICE_ENDPOINT = 'UNCONFIGURED';
