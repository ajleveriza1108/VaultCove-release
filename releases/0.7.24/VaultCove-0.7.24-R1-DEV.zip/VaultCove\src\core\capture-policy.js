export const CAPTURE_RATE_WINDOW_MS = 10 * 60 * 1000;
export const CAPTURE_RATE_PER_ORIGIN = 20;
export const CAPTURE_RATE_GLOBAL = 100;
export const CAPTURE_USERNAME_MAX = 512;
export const CAPTURE_PASSWORD_MAX = 4096;
export const CAPTURE_PAGE_TITLE_MAX = 160;

export function validateCaptureCandidate(candidate = {}, { requireUsername = true } = {}) {
  const username = String(candidate.username || '').trim();
  const password = String(candidate.password || '');
  const pageTitle = String(candidate.pageTitle || '').replace(/[\u0000-\u001f\u007f]/g, ' ').trim().slice(0, CAPTURE_PAGE_TITLE_MAX);
  const reason = String(candidate.reason || '').replace(/[\u0000-\u001f\u007f]/g, ' ').trim().slice(0, 80);
  const confidence = String(candidate.confidence || '').trim().slice(0, 32);
  if ((requireUsername && !username) || username.length > CAPTURE_USERNAME_MAX) return { ok: false, reason: 'invalid-username' };
  if (password.length < 4 || password.length > CAPTURE_PASSWORD_MAX) return { ok: false, reason: 'invalid-password' };
  return { ok: true, username, password, pageTitle, reason, confidence };
}

export function applyCaptureRateLimit(state = {}, origin = '', nowMs = Date.now()) {
  const now = Number(nowMs) || Date.now();
  const safeOrigin = String(origin || '').slice(0, 300);
  const current = state && typeof state === 'object' && !Array.isArray(state) ? state : {};
  const windowStartedAt = Number(current.windowStartedAt || 0);
  const fresh = !windowStartedAt || now - windowStartedAt >= CAPTURE_RATE_WINDOW_MS;
  const base = fresh ? { windowStartedAt: now, total: 0, origins: {} } : {
    windowStartedAt,
    total: Math.max(0, Number(current.total || 0)),
    origins: current.origins && typeof current.origins === 'object' && !Array.isArray(current.origins) ? { ...current.origins } : {}
  };
  const originCount = Math.max(0, Number(base.origins[safeOrigin] || 0));
  if (base.total >= CAPTURE_RATE_GLOBAL) return { allowed: false, reason: 'global-rate-limit', state: base };
  if (originCount >= CAPTURE_RATE_PER_ORIGIN) return { allowed: false, reason: 'origin-rate-limit', state: base };
  base.total += 1;
  base.origins[safeOrigin] = originCount + 1;
  return { allowed: true, state: base };
}
