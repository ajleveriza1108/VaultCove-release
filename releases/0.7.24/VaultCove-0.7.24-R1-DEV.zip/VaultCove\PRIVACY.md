# VaultCove Privacy - 0.7.24 R1

## 0.7.24 cropped profile preview

The Settings preview now reloads the already-saved local crop whenever Appearance and personalization is rendered. This is a local rendering repair only; VaultCove does not upload, synchronize, or transmit the original or cropped profile image.

## 0.7.21 local security metadata

The new activity history is stored inside the encrypted local vault. It records bounded security-event metadata such as a backup creation, restore, trash action, migration import, or Secure Login use. It does not record the actual password, master password, TOTP secret, private sharing key, or plaintext credential fields. No activity history is sent to GitHub, Payhip, Apps Script, Google, or another service.

One-use Secure Login capabilities and capture-rate state live only in Chrome extension session storage. They are ephemeral authorization/abuse-control data, not cloud identifiers. Migration limits and Restore Preview operate locally; previewing a backup does not upload it. The license-service endpoint remains unconfigured in this build and Payhip/API secrets are not embedded in the extension.


## Local website thumbnail permission

The Chrome `favicon` permission remains required because website thumbnails are enabled by default and use Chrome's own local favicon cache. VaultCove does not contact an external favicon service. Store website-origin access remains separately optional.

## Selective backup privacy

The encrypted backup screen shows exactly which categories will be exported. Login credentials are selected by default; Folders, Cards, Bank accounts, Identities, Secure notes, TOTP codes, Trash, Favorites, and Other settings require an explicit selection. New component restores replace only the categories contained in that backup, so unrelated local data does not need to be exported merely to preserve it.

"Other settings" is intentionally limited to portable user preferences through an allowlist. It excludes local device/license identity, private signing material, and platform-specific state. Use Only shared credentials are excluded from portable backup files because their access rights belong to the designated recipient context. Recovery identity material remains in the separately password-protected `.vcrecovery` format.

VaultCove is designed as an offline-first encrypted vault.

## Data kept locally

Vault records, passwords, usernames, saved URLs, secure notes, cards, bank records, identities, website TOTP secrets, private VCShare keys, pending login/password-change candidates, local security-health results, and visited-site visual metadata remain inside the encrypted local vault.

Website thumbnails are enabled by default and use only Chrome's local favicon cache after VaultCove has handled a matching saved site. VaultCove does not contact a third-party icon service or upload a list of saved or visited domains.


## First-run security notice email

New users can configure a security-notice email during the one-time Security Essentials setup. The address and preference are stored locally in the testing build. A queued notice contains only a generic password-change event, local device identifier, timestamp metadata, and the configured recipient email. It never contains the affected website, username, account title, old password, new password, vault key, or master password. No email is transmitted until the separate license-service email transport is connected.

## Developer update checks

The Developer build can check the official VaultCove release metadata for a newer version. It does not attach vault records, saved websites, usernames, passwords, cards, bank data, notes, TOTP secrets, master passwords, vault keys, or security-health data to that request.

## Licensing and devices

When the user tests Apps Script licensing, VaultCove may transmit only the fields allowed by the licensing protocol: serial during activation, license email, random installation ID, random device-recovery token, user device label, platform/app version, verification codes/challenge IDs, and random refresh/management tokens.

Never sent to licensing: master password, vault key, saved website list, usernames, passwords, website TOTP secrets, cards, bank accounts, secure notes, private VCShare keys, browsing history, MAC address, Windows serial, IMEI, or a hardware fingerprint.

The serial becomes associated with a verified email after the first successful activation if no email is already bound. Device-management actions require a fresh email verification session.

## VaultCove Authenticator

Google Authenticator or another TOTP app is used only to generate a local verification code for VaultCove. VaultCove does not send website passwords to Google Authenticator and does not connect the password vault to the user's Google account.

## Offline Recovery Kit

VaultCove does not upload `.vcrecovery` files. Recovery Kits are created locally and should be stored by the user on offline media. They may contain private sharing keys, a random device-recovery token, and optional VaultCove authenticator configuration, all encrypted with the user's separate Recovery Password. Website passwords are not included in the Recovery Kit.

## Sharing

`.vckey` contains a public sharing identity encrypted with its own file password. `.vcshare` contains recipient-encrypted shared records. A private sharing key never leaves the encrypted vault except when the user deliberately creates an encrypted offline Recovery Kit.

## Testing status

The current development build is Testing - Full Access. Trial expiration and feature lockout are not enforced while the product is being tested.


## Explicit export downloads

The Chrome `downloads` permission is used only when the user explicitly exports a VaultCove file such as an encrypted `.vckey`. VaultCove requests `saveAs: true`; it does not use this permission to download website content in the background.

## Local profile photo

An optional profile photo is resized inside the extension and stored only in local VaultCove settings on that device. It is not uploaded, cloud-synced, included in licensing requests, or sent to Payhip/Apps Script. It is intentionally excluded from portable settings backups.

## Locked login capture inbox

After VaultCove provisions a capture-inbox keypair, the public key may be used while the vault is locked to encrypt a submitted login/registration into a local hybrid RSA-OAEP + AES-GCM envelope. The private key remains inside the encrypted vault. On unlock, VaultCove drains and reconciles the queue, then removes successfully recovered queue entries.

## Profile crop editor

The selected profile image is processed in the extension page. VaultCove stores only the cropped local data image and does not upload the original or cropped photo.

## HTTP login capture

If new-login capture is enabled, VaultCove may locally capture a submitted username/email and password pair from an HTTP page just as it can from HTTPS. This data is not sent to VaultCove servers. HTTP itself is insecure, so Strict Secure Login never submits a saved VaultCove password over HTTP.
