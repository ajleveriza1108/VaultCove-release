import {
  changeMasterPassword,
  createVaultEnvelope,
  decryptJson,
  reencryptVault,
  unlockVaultEnvelope,
  verifyMasterPasswordForVaultKey
} from './crypto.js';
import { VAULT_AAD } from './constants.js';
import { createEmptyVault, normalizeVault } from './model.js';
import { drainLockedCaptureInbox, ensureCaptureInboxIdentity } from './capture-inbox.js';
import { findExistingLoginForCapture, prunePendingLoginCaptures, samePendingLoginCapture } from './login-capture.js';
import { isUseOnlySharedLogin, openSharedLoginForFill } from './shared-access.js';
import { appendActivityEvent } from './activity-log.js';
import { loginMatchesTrustedHost } from './site-match.js';
import { hardenAndExpireTrash } from './trash.js';
import { verifyRecoveryCode, verifyTotp } from './totp.js';
import {
  clearSensitiveAccess,
  clearSession,
  getSessionKey,
  getVaultEnvelope,
  grantSensitiveAccess,
  saveSessionKey,
  setVaultEnvelope,
  touchSession
} from './storage.js';



async function mergeLockedCaptures(vault, vaultKey) {
  const identity = await ensureCaptureInboxIdentity(vault);
  const drained = await drainLockedCaptureInbox(vault);
  let changed = Boolean(identity.changed);
  if (!drained.captures.length) return { changed, recovered: 0, failed: drained.failed || 0 };

  const pending = prunePendingLoginCaptures(vault.pendingLoginCaptures);
  for (const capture of drained.captures) {
    let handled = false;
    const sharedMatches = (vault.items || []).filter((item) => isUseOnlySharedLogin(item) && loginMatchesTrustedHost(item, capture.hostname));
    for (const sharedItem of sharedMatches) {
      try {
        const credential = await openSharedLoginForFill(sharedItem, vaultKey);
        if (String(credential.username || '').trim().toLowerCase() === String(capture.username || '').trim().toLowerCase()) {
          // Use-only shared credentials must never be turned into an owned captured password.
          handled = true;
          break;
        }
      } catch {}
    }
    if (handled) continue;

    const existing = findExistingLoginForCapture((vault.items || []).filter((item) => !isUseOnlySharedLogin(item)), capture.hostname, capture.username);
    if (existing) {
      if (String(existing.password || '') !== String(capture.password || '') && String(existing.pendingPasswordChange?.password || '') !== String(capture.password || '')) {
        existing.pendingPasswordChange = {
          password: String(capture.password || ''),
          detectedAt: capture.detectedAt || new Date().toISOString(),
          hostname: String(capture.hostname || ''),
          source: 'locked-login-capture',
          confidence: 'submitted-login'
        };
        changed = true;
      }
      continue;
    }

    if (!pending.some((entry) => samePendingLoginCapture(entry, capture))) {
      pending.push(capture);
      changed = true;
    }
  }
  vault.pendingLoginCaptures = prunePendingLoginCaptures(pending);
  return { changed, recovered: drained.captures.length, failed: drained.failed || 0 };
}

async function verifySecondFactor(vault, code, { consumeRecovery = false } = {}) {
  const protection = vault?.security?.vaultTotp;
  if (!protection?.enabled) return { ok: true, recoveryIndex: -1 };
  const candidate = String(code || '').trim();
  if (await verifyTotp(protection.secret, candidate)) return { ok: true, recoveryIndex: -1 };
  const recovery = await verifyRecoveryCode(candidate, protection.recoveryCodeHashes || []);
  if (!recovery.valid) throw new Error('Incorrect authenticator or recovery code.');
  if (consumeRecovery) protection.recoveryCodeHashes.splice(recovery.index, 1);
  return { ok: true, recoveryIndex: recovery.index };
}

export async function initializeVault(masterPassword) {
  if ((await getVaultEnvelope())) throw new Error('A vault already exists.');
  const vaultData = createEmptyVault();
  await ensureCaptureInboxIdentity(vaultData);
  const { envelope, rawVaultKey } = await createVaultEnvelope(masterPassword, vaultData);
  await setVaultEnvelope(envelope);
  await saveSessionKey(rawVaultKey);
  return vaultData;
}

export async function unlockVault(masterPassword, secondFactor = '') {
  const envelope = await getVaultEnvelope();
  if (!envelope) throw new Error('No vault exists yet.');
  const { rawVaultKey, vaultKey, vaultData } = await unlockVaultEnvelope(masterPassword, envelope);
  const vault = normalizeVault(vaultData);
  const result = await verifySecondFactor(vault, secondFactor, { consumeRecovery: true });
  const trashState = await hardenAndExpireTrash(vault, vaultKey);
  const captureState = await mergeLockedCaptures(vault, vaultKey);
  if (result.recoveryIndex >= 0 || trashState.changed || captureState.changed) {
    const updated = await reencryptVault(envelope, vaultKey, vault);
    await setVaultEnvelope(updated);
  }
  await saveSessionKey(rawVaultKey);
  return vault;
}

export async function loadUnlockedVault({ touch = true } = {}) {
  const envelope = await getVaultEnvelope();
  if (!envelope) return { state: 'setup', vault: null };
  const session = await getSessionKey();
  if (!session) return { state: 'locked', vault: null };
  try {
    const vault = normalizeVault(await decryptJson(session.vaultKey, envelope.vault, VAULT_AAD));
    const trashState = await hardenAndExpireTrash(vault, session.vaultKey);
    const captureState = await mergeLockedCaptures(vault, session.vaultKey);
    if (trashState.changed || captureState.changed) {
      const updated = await reencryptVault(envelope, session.vaultKey, vault);
      await setVaultEnvelope(updated);
    }
    if (touch) await touchSession();
    return { state: 'unlocked', vault, vaultKey: session.vaultKey, rawVaultKey: session.rawVaultKey };
  } catch {
    await clearSession();
    return { state: 'locked', vault: null };
  }
}

export async function saveUnlockedVault(vault, { touch = true } = {}) {
  const envelope = await getVaultEnvelope();
  const session = await getSessionKey();
  if (!envelope || !session) throw new Error('Vault is locked.');
  vault.updatedAt = new Date().toISOString();
  await hardenAndExpireTrash(vault, session.vaultKey);
  const updated = await reencryptVault(envelope, session.vaultKey, normalizeVault(vault));
  await setVaultEnvelope(updated);
  if (touch) await touchSession();
}

export async function verifySensitiveAccess(masterPassword, seconds = null, secondFactor = '') {
  const envelope = await getVaultEnvelope();
  const session = await getSessionKey();
  if (!envelope || !session) throw new Error('Vault is locked.');
  try {
    const valid = await verifyMasterPasswordForVaultKey(masterPassword, envelope, session.rawVaultKey);
    if (!valid) throw new Error('Incorrect master password.');
    const state = await loadUnlockedVault({ touch: false });
    if (state.state !== 'unlocked') throw new Error('Vault is locked.');
    await verifySecondFactor(state.vault, secondFactor);
  } catch (error) {
    await clearSensitiveAccess();
    if (error?.message === 'Incorrect master password.' || error?.message === 'Incorrect authenticator or recovery code.') throw error;
    throw new Error('Master-password verification failed. Lock and unlock VaultCove again if this continues.');
  }
  const until = await grantSensitiveAccess(seconds);
  await touchSession();
  return until;
}

export async function matchesCurrentMasterPassword(candidate) {
  const envelope = await getVaultEnvelope();
  const session = await getSessionKey();
  if (!envelope || !session) throw new Error('Vault is locked.');
  return verifyMasterPasswordForVaultKey(String(candidate || ''), envelope, session.rawVaultKey);
}

export async function rotateMasterPasswordVerified(currentMasterPassword, newMasterPassword, secondFactor = '') {
  const current = String(currentMasterPassword || '');
  const replacement = String(newMasterPassword || '');
  if (!current || !replacement) throw new Error('Current and new master passwords are required.');
  if (current === replacement) throw new Error('The new master password must be different from the current master password.');
  const envelope = await getVaultEnvelope();
  const session = await getSessionKey();
  if (!envelope || !session) throw new Error('Vault is locked.');
  const valid = await verifyMasterPasswordForVaultKey(current, envelope, session.rawVaultKey);
  if (!valid) throw new Error('Current master password is incorrect.');
  const state = await loadUnlockedVault({ touch: false });
  if (state.state !== 'unlocked') throw new Error('Vault is locked.');
  await verifySecondFactor(state.vault, secondFactor);

  // Re-wrap the same random vault key, then prove the new wrap can be opened
  // before replacing the only persisted envelope. This keeps rotation atomic.
  let updated = await changeMasterPassword(envelope, session.rawVaultKey, replacement);
  await appendActivityEvent(state.vault, 'master-password-changed', { method: 'verified-rotation' });
  updated = await reencryptVault(updated, session.vaultKey, state.vault);
  const verified = await verifyMasterPasswordForVaultKey(replacement, updated, session.rawVaultKey);
  if (!verified) throw new Error('The new master-password wrap could not be verified. The existing vault was left unchanged.');
  await setVaultEnvelope(updated);
  await clearSession();
  return true;
}

export async function rotateMasterPassword(newMasterPassword) {
  const envelope = await getVaultEnvelope();
  const session = await getSessionKey();
  if (!envelope || !session) throw new Error('Vault is locked.');
  const updated = await changeMasterPassword(envelope, session.rawVaultKey, newMasterPassword);
  await setVaultEnvelope(updated);
  await clearSession();
}

export async function lockVault() { await clearSession(); }
