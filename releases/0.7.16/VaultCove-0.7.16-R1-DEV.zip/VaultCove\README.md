# VaultCove 0.7.16 R1

## Chrome Web Store favicon packaging fix

VaultCove keeps Chrome-local website thumbnails enabled by default. The required local `favicon` permission remains in both Developer and Store manifests. The Store package continues to make HTTPS website access optional and removes Developer-only static content-script registration. This fixes the 0.7.15 publisher mismatch without changing vault data or the Strict Secure Login model.

## Strict Secure Login only

Saved-password **Fill** has been removed from the website handler and popup. VaultCove now uses Strict Secure Login: verify the exact top-level HTTPS destination, inject only for immediate submission, do not dispatch ordinary password input/change events, and clear the injected value if safe submission cannot proceed or shortly after submission. This reduces DOM exposure but cannot make an ordinary website password invisible to a malicious site, compromised browser renderer, or compromised PC at the instant the site must receive it.

## Selective encrypted `.vcvault` backup

VaultCove backups can now be scoped before export. **Login credentials are selected by default**; the user can additionally include Folders, Cards, Bank accounts, Identities, Secure notes, TOTP codes, Trash, Favorites, and Other settings. A new component backup restores only the components recorded in that backup, leaving unselected categories already present on the destination vault unchanged. Legacy full `.vcvault` backups remain supported and retain their original full-vault restore behavior.

Folder assignments, Favorites, and TOTP secrets are independent backup overlays, so choosing Login credentials alone does not silently carry those optional categories. If Trash is selected, trashed credentials are opened only inside the already-authorized backup operation, protected by the outer encrypted `.vcvault`, and re-sealed with fresh destination-vault protection during restore. Recipient-bound **Use Only** shared logins are intentionally excluded from portable backups. The Offline Recovery Kit remains the separate format for private sharing identity and device-recovery material.

## Gap-free Settings layout

Settings now uses three independent responsive vertical columns rather than shared grid rows. A tall card such as **Change master password** no longer forces unrelated shorter cards in the other columns to leave large blank spaces. At narrower widths the columns collapse cleanly to two and then one column.

## Reliable `.vckey` Save As on Windows

VaultCove no longer uses the File System Access `showSaveFilePicker()` path for `.vckey` export. Some Windows/Chromium combinations rendered that native picker with a working but invisible mouse pointer. The Chrome build now encrypts the `.vckey` first, then uses Chromium's browser-owned `downloads.download(..., saveAs:true)` flow. The user still chooses the destination, cancelling writes nothing, and restore/Open dialogs are unchanged.

## Premium password setup guidance

Password creation now behaves like a premium signup flow. VaultCove checks eight security requirements live: minimum length, lowercase, capital, number, special character, no three repeated characters, no obvious/common word or sequence, and at least eight unique characters. Confirmation must match, Show/Hide controls are provided, and Continue/Create stays disabled until every requirement passes.

- New Master Password: 16+ characters plus all four character classes.
- Recovery Password: 16+ characters plus all four character classes.
- New `.vckey` password: 14+ characters plus all four character classes.
- New `.vcshare` package password: 14+ characters plus all four character classes.

This stronger policy applies when creating a new password. Importing/restoring an existing encrypted file does not reject it merely because it predates the newer creation policy.

## Carried-forward security fixes

- Backup & Restore uses the exact visible `restoreFile` / `restoreSecret` controls and snapshots both before Sensitive Access, eliminating the null `files` restore regression.
- Encrypted `.vckey` import snapshots its selected file before authentication dialogs.
- New-vault-only Security Essentials includes security-notice email, auto-lock timing, Google Authenticator-compatible protection, Offline Recovery Kit, secure handler/capture defaults, and acknowledgement that VaultCove cannot recover a forgotten Master Password.
- Security-notice email configuration remains editable later in Settings; the testing build stores it locally until the license-service email transport is connected.

## VaultCove 0.7.10 R1
Vault Settings now includes searchable login-to-folder organization. Vault cards use a smaller Secure Login action with a dedicated Trash button. Trash is now a locked 30-day recovery area: deleted items are sealed inside a second authenticated encryption envelope and cannot be opened or used unless explicitly restored.


VaultCove is an offline-first Manifest V3 password and private-record vault. The canonical Windows development root is:

`D:\Windows Projects\VaultCove`

The current build is a **Testing - Full Access** build. Trial expiration and feature lockout are not enforced while VaultCove is under active development.


> 0.7.9 baseline recovery: the updater accepts a verified 0.7.7 installation and upgrades it directly; 0.7.8 does not need to have completed.

## 0.7.8 testing focus

VaultCove 0.7.8 is based on the accepted 0.7.6 source. The rejected 0.7.7 package is not a required baseline. This release fixes the lock screen so setup/unlock stays mathematically centered at every supported window size and Compact setting, and adds a live background/content-script acknowledgement so a website handler immediately recognizes a successful VaultCove unlock without reloading the website.

The Vault now has encrypted folder organization. Open **Vault > Vault Settings**, create folders, select one or multiple saved logins, choose a destination folder, and move them. A login can also be assigned to a folder from its encrypted item editor. Deleting a folder never deletes credentials; those items return to **No Folder**.

Encrypted `.vckey` files keep their existing separate `.vckey` file password. Converting a `.vckey` to readable TXT is blocked until Google Authenticator-compatible TOTP protection is enabled. Conversion then requires fresh VaultCove Sensitive Access (master password + authenticator/recovery code) and the `.vckey` file password. VaultCove does not create a third memorized TXT-conversion password. The TXT contains only the public sharing identity, never saved credentials, TOTP secrets, or private sharing keys.

## 0.7.1 R1 highlights

- Always-On Developer handler with duplicate dynamic-script registration repair. Supported HTTPS login fields can receive VaultCove without first clicking the extension icon.
- Search inside the website handler for sites with many saved accounts. Only masked summaries enter the page handler.
- Inline local password generation on signup, new-password, and password-change forms.
- New-login and password-change detection remain separate encrypted review flows. VaultCove does not silently overwrite credentials.
- Grid and List Vault browsing. Clicking a saved login can open its saved HTTPS site and perform a one-time Secure Login for that exact credential.
- Password-encrypted `.vckey` public sharing identities with a file password separate from the VaultCove master password.
- Multi-account VCShare v2 bundles for up to 50 selected login records.
- Encrypted offline `.vcrecovery` Recovery Kits for the private sharing identity, optional VaultCove authenticator configuration, and a random device-recovery token. Website passwords are not placed in the Recovery Kit.
- Six built-in themes: VaultCove Midnight, AMOLED Black, Graphite, Ocean, Warm Ivory, and Light Gray.
- Compact responsive UI, no button tooltips, accessible icon-only controls, and removal of decorative special-character controls from the main interface.
- Google Authenticator-compatible local TOTP protection for VaultCove. Google never receives or stores VaultCove website passwords.
- Apps Script licensing reference architecture with email-bound serials, Standard 7-device licenses, Admin 20-device licenses, signed leases, and Release, Revoke, Retain, and Restore device actions.
- Device recovery uses a random VaultCove recovery token, not a MAC address, Windows serial, IMEI, or hidden hardware fingerprint.
- Platform-neutral `.vcvault`, `.vcshare`, `.vckey`, `.vcrecovery`, license, and device-recovery formats are intended for Chrome and Android first, with iPhone/iOS compatibility planned later. License identity and activation must not depend on Windows-, Chrome-, Android-, or iOS-only hardware identifiers.

## Recovery model

VaultCove does not upload a recovery copy of the private sharing identity to a cloud service. If the only device that contains the private sharing identity is destroyed and no separate recovery copy exists, that same private identity cannot be recreated.

For one-device users, create an encrypted `.vcrecovery` file and keep at least one copy on offline media stored separately from the device. The Recovery Password must be different from the VaultCove master password.

A future Android companion can use the same recovery material and device protocol for direct device-to-device recovery. Until that app exists, `.vcrecovery` is the supported offline transfer/recovery format.

## Security boundaries

The encrypted vault uses a random 256-bit vault key protected by the master password. AES-256-GCM protects vault confidentiality and integrity. The master password is not transmitted to the Apps Script licensing service.

A destination website must temporarily receive a password when the user explicitly fills or securely logs in. Secure Login verifies the trusted HTTPS destination, releases only the selected credential, submits promptly, and clears the password field after a guarded fallback when safe.

Local TOTP is an application access-confirmation gate. It is not a separate cloud-held encryption key against a fully compromised local computer.

## Developer testing

Run:

`node tests\core-tests.mjs`

`node tests\static-security-checks.mjs`

Then reload the unpacked extension in `chrome://extensions` from exactly:

`D:\Windows Projects\VaultCove`

Use dummy accounts for browser-handler testing before relying on a development build for critical financial accounts.
